import {
  collection,
  doc,
  setDoc,
  deleteDoc,
  onSnapshot,
  getDocs,
} from 'firebase/firestore';
import { db, isFirebaseReady } from './config';
import {
  Assignment,
  AssignmentSubmission,
  SubmissionStatus,
} from '../types/assignment';
import { INITIAL_MOCK_ASSIGNMENTS } from '../data/mockAssignments';
import {
  syncAssignmentToGoogleSheet,
  syncSubmissionToGoogleSheet,
  syncDraftSaveToGoogleSheet,
  syncActivityLogToGoogleSheet,
} from '../services/googleSheetService';

const ASSIGNMENTS_COLLECTION = 'sinh10_assignments';
const SUBMISSIONS_COLLECTION = 'sinh10_submissions';
const LOCAL_STORAGE_ASSIGNMENTS_KEY = 'biogen10_assignments_v1';
const LOCAL_STORAGE_SUBMISSIONS_KEY = 'biogen10_submissions_v1';

// In-memory cache
let inMemoryAssignments: Assignment[] = [];
let inMemorySubmissions: AssignmentSubmission[] = [];

// Initialize local cache
function loadLocalAssignments(): Assignment[] {
  try {
    if (typeof localStorage !== 'undefined') {
      const raw = localStorage.getItem(LOCAL_STORAGE_ASSIGNMENTS_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    }
  } catch (e) {
    console.warn('Failed to read assignments from local storage:', e);
  }
  return [...INITIAL_MOCK_ASSIGNMENTS];
}

function loadLocalSubmissions(): AssignmentSubmission[] {
  try {
    if (typeof localStorage !== 'undefined') {
      const raw = localStorage.getItem(LOCAL_STORAGE_SUBMISSIONS_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          return parsed;
        }
      }
    }
  } catch (e) {
    console.warn('Failed to read submissions from local storage:', e);
  }
  return [];
}

inMemoryAssignments = loadLocalAssignments();
inMemorySubmissions = loadLocalSubmissions();

function persistLocalAssignments(assignments: Assignment[]) {
  inMemoryAssignments = [...assignments];
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(LOCAL_STORAGE_ASSIGNMENTS_KEY, JSON.stringify(assignments));
    }
  } catch (e) {
    console.warn('Failed to persist assignments locally:', e);
  }
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('biogen10_assignments_changed', { detail: assignments }));
  }
}

function persistLocalSubmissions(submissions: AssignmentSubmission[]) {
  inMemorySubmissions = [...submissions];
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(LOCAL_STORAGE_SUBMISSIONS_KEY, JSON.stringify(submissions));
    }
  } catch (e) {
    console.warn('Failed to persist submissions locally:', e);
  }
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('biogen10_submissions_changed', { detail: submissions }));
  }
}

// Subscribe to assignments from Firestore
export function subscribeToAssignments(callback: (assignments: Assignment[]) => void): () => void {
  callback([...inMemoryAssignments]);

  if (!isFirebaseReady) {
    const handler = () => callback([...inMemoryAssignments]);
    window.addEventListener('biogen10_assignments_changed', handler);
    return () => window.removeEventListener('biogen10_assignments_changed', handler);
  }

  try {
    const colRef = collection(db, ASSIGNMENTS_COLLECTION);
    const unsub = onSnapshot(
      colRef,
      (snapshot) => {
        if (!snapshot.empty) {
          const list: Assignment[] = [];
          snapshot.forEach((docSnap) => {
            list.push(docSnap.data() as Assignment);
          });
          // Sort by createdAt descending
          list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
          persistLocalAssignments(list);
          callback(list);
        } else {
          // If empty in cloud, seed initial mock assignments
          if (inMemoryAssignments.length === 0) {
            persistLocalAssignments(INITIAL_MOCK_ASSIGNMENTS);
            callback([...INITIAL_MOCK_ASSIGNMENTS]);
          } else {
            callback([...inMemoryAssignments]);
          }
        }
      },
      (error) => {
        console.warn('Assignments subscription error, using local:', error);
        callback([...inMemoryAssignments]);
      }
    );

    return () => unsub();
  } catch (err) {
    console.warn('Error initiating assignments listener:', err);
    return () => {};
  }
}

// Subscribe to submissions from Firestore
export function subscribeToSubmissions(
  assignmentId: string | null,
  callback: (submissions: AssignmentSubmission[]) => void
): () => void {
  const getFiltered = () =>
    assignmentId
      ? inMemorySubmissions.filter((s) => s.assignmentId === assignmentId)
      : [...inMemorySubmissions];

  callback(getFiltered());

  if (!isFirebaseReady) {
    const handler = () => callback(getFiltered());
    window.addEventListener('biogen10_submissions_changed', handler);
    return () => window.removeEventListener('biogen10_submissions_changed', handler);
  }

  try {
    const colRef = collection(db, SUBMISSIONS_COLLECTION);
    const unsub = onSnapshot(
      colRef,
      (snapshot) => {
        const list: AssignmentSubmission[] = [];
        snapshot.forEach((docSnap) => {
          list.push(docSnap.data() as AssignmentSubmission);
        });
        persistLocalSubmissions(list);
        callback(
          assignmentId
            ? list.filter((s) => s.assignmentId === assignmentId)
            : list
        );
      },
      (error) => {
        console.warn('Submissions subscription error, using local:', error);
        callback(getFiltered());
      }
    );

    return () => unsub();
  } catch (err) {
    console.warn('Error initiating submissions listener:', err);
    return () => {};
  }
}

/**
 * Teacher creates or updates an assignment
 */
export async function saveAssignmentToCloud(assignment: Assignment): Promise<boolean> {
  const idx = inMemoryAssignments.findIndex((a) => a.id === assignment.id);
  const updatedList = [...inMemoryAssignments];
  if (idx >= 0) {
    updatedList[idx] = { ...assignment, updatedAt: new Date().toISOString() };
  } else {
    updatedList.unshift({
      ...assignment,
      createdAt: assignment.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });
  }

  persistLocalAssignments(updatedList);

  if (isFirebaseReady) {
    try {
      const docRef = doc(db, ASSIGNMENTS_COLLECTION, assignment.id);
      await setDoc(docRef, assignment, { merge: true });
    } catch (err) {
      console.warn('Failed to save assignment to Firestore:', err);
    }
  }

  // Google Sheet Webhook Sync (Full detail to GiaoBai_PhieuHocTap & ChiTietPhieu_CauHoi_Bang)
  try {
    const detailedItems = [
      ...(assignment.questions || []).map((q) => ({
        type: 'question' as const,
        itemNumber: `Câu ${q.questionNumber}`,
        titleOrPrompt: q.prompt,
        points: q.points || '',
        suggestedAnswerOrStructure: q.suggestedAnswer || '',
      })),
      ...(assignment.tables || []).map((t) => ({
        type: 'table' as const,
        itemNumber: t.title,
        titleOrPrompt: t.description || t.title,
        points: '',
        suggestedAnswerOrStructure: `Các cột: ${t.columns.map((c) => c.header).join(' | ')}`,
      })),
    ];

    syncAssignmentToGoogleSheet({
      assignmentId: assignment.id,
      title: assignment.title,
      subject: assignment.subject,
      topicId: assignment.topicId,
      topicTitle: assignment.topicTitle,
      classNames: assignment.classNames?.join(', ') || assignment.classIds.join(', '),
      classIds: assignment.classIds,
      teacherName: assignment.teacherName,
      teacherCode: assignment.teacherCode || '',
      dueDate: assignment.dueDate,
      maxScore: assignment.maxScore || 10,
      instructions: assignment.instructions || '',
      questionCount: assignment.questions?.length || 0,
      tableCount: assignment.tables?.length || 0,
      allowAttachment: assignment.allowAttachment ?? true,
      attachmentsList: assignment.attachments?.map((a) => a.name).join('; ') || 'Không có',
      status: assignment.status,
      createdAt: assignment.createdAt || new Date().toISOString(),
      detailedItems,
    });

    syncActivityLogToGoogleSheet({
      timestamp: new Date().toISOString(),
      userCode: assignment.teacherCode || 'GV-ONLINE',
      fullName: assignment.teacherName || 'Giáo viên',
      username: 'teacher',
      role: 'teacher',
      className: assignment.classNames?.join(', ') || 'Tất cả các lớp',
      activityType: 'Giáo viên giao phiếu học tập',
      details: `Giao phiếu "${assignment.title}" (${assignment.questions?.length || 0} câu, ${assignment.tables?.length || 0} bảng) - Hạn: ${assignment.dueDate}`,
    });
  } catch (e) {
    console.warn('Google Sheet sync notice for assignment:', e);
  }

  return true;
}

/**
 * Teacher deletes an assignment
 */
export async function deleteAssignmentFromCloud(assignmentId: string): Promise<boolean> {
  const updatedList = inMemoryAssignments.filter((a) => a.id !== assignmentId);
  persistLocalAssignments(updatedList);

  if (isFirebaseReady) {
    try {
      const docRef = doc(db, ASSIGNMENTS_COLLECTION, assignmentId);
      await deleteDoc(docRef);
    } catch (err) {
      console.warn('Failed to delete assignment from Firestore:', err);
    }
  }

  return true;
}

/**
 * Get student's submission for an assignment
 */
export function getStudentSubmission(
  assignmentId: string,
  studentId: string
): AssignmentSubmission | null {
  return (
    inMemorySubmissions.find(
      (s) => s.assignmentId === assignmentId && s.studentId === studentId
    ) || null
  );
}

/**
 * Save student's submission (either auto-save draft or final submit)
 */
export async function saveSubmissionToCloud(
  submission: AssignmentSubmission
): Promise<boolean> {
  const subId = submission.id || `${submission.assignmentId}_${submission.studentId}`;
  const fullSubmission: AssignmentSubmission = {
    ...submission,
    id: subId,
    lastSavedAt: new Date().toISOString(),
  };

  const idx = inMemorySubmissions.findIndex((s) => s.id === subId);
  const updatedList = [...inMemorySubmissions];
  if (idx >= 0) {
    updatedList[idx] = fullSubmission;
  } else {
    updatedList.push(fullSubmission);
  }

  persistLocalSubmissions(updatedList);

  if (isFirebaseReady) {
    try {
      const docRef = doc(db, SUBMISSIONS_COLLECTION, subId);
      await setDoc(docRef, fullSubmission, { merge: true });
    } catch (err) {
      console.warn('Failed to save submission to Firestore:', err);
    }
  }

  // Synchronize detailed submission to Google Sheet (Sheet NopBai_ChamDiem & ChiTietBaiLam_HocSinh)
  try {
    const matchingAsg = inMemoryAssignments.find((a) => a.id === fullSubmission.assignmentId);

    // Format human-readable answers summary
    const answersSummary =
      matchingAsg?.questions
        ?.map((q) => {
          const ans = fullSubmission.answers?.[q.id] || '(Chưa điền)';
          return `[Câu ${q.questionNumber}]: ${ans}`;
        })
        .join('\n') ||
      Object.entries(fullSubmission.answers || {})
        .map(([k, v]) => `[${k}]: ${v}`)
        .join('\n');

    // Format human-readable tables summary
    const tableSummary =
      matchingAsg?.tables
        ?.map((tbl) => {
          const rowTexts: string[] = [];
          tbl.rows.forEach((r) => {
            const cellParts: string[] = [];
            tbl.columns.forEach((c) => {
              const val = fullSubmission.tableResponses?.[tbl.id]?.[r.id]?.[c.id] || r.cells[c.id] || '';
              cellParts.push(`${c.header}: ${val || '(trống)'}`);
            });
            rowTexts.push(`- Hàng [${r.cells[tbl.columns[0]?.id] || r.id}]: ${cellParts.join(' | ')}`);
          });
          return `[Bảng: ${tbl.title}]\n${rowTexts.join('\n')}`;
        })
        .join('\n\n') || '';

    // Format attachments summary
    const attSummary =
      fullSubmission.attachments
        ?.map((att) => {
          const sizeStr = att.size ? ` (${Math.round(att.size / 1024)} KB)` : '';
          return `${att.name}${sizeStr} [${att.type}]`;
        })
        .join('; ') || 'Không có';

    // Detailed line-by-line items for Sheet "ChiTietBaiLam_HocSinh"
    const detailedItems: any[] = [];

    // 1. Detailed Questions & Student Answers
    matchingAsg?.questions?.forEach((q) => {
      detailedItems.push({
        category: 'Câu hỏi tự luận',
        itemIndex: `Câu ${q.questionNumber}`,
        prompt: q.prompt,
        studentContent: fullSubmission.answers?.[q.id] || '(Chưa làm)',
        points: q.points || '',
        suggestedAnswer: q.suggestedAnswer || '',
      });
    });

    // 2. Detailed Table cells filled by student
    matchingAsg?.tables?.forEach((tbl) => {
      tbl.rows.forEach((r, rIdx) => {
        tbl.columns
          .filter((c) => c.isEditableByStudent)
          .forEach((c) => {
            const val = fullSubmission.tableResponses?.[tbl.id]?.[r.id]?.[c.id] || '(trống)';
            const rowLabel = r.cells[tbl.columns[0]?.id] || `Hàng ${rIdx + 1}`;
            detailedItems.push({
              category: 'Bảng tương tác',
              itemIndex: `${tbl.title} - ${rowLabel}`,
              prompt: `Cột "${c.header}" của ${rowLabel}`,
              studentContent: val,
            });
          });
      });
    });

    // 3. General Notes
    if (fullSubmission.generalNotes?.trim()) {
      detailedItems.push({
        category: 'Ghi chú',
        itemIndex: 'Ghi chú bổ sung',
        prompt: 'Lời giải thêm của học sinh',
        studentContent: fullSubmission.generalNotes.trim(),
      });
    }

    // 4. Attachments list
    fullSubmission.attachments?.forEach((att, idx) => {
      detailedItems.push({
        category: 'Ảnh / File đính kèm',
        itemIndex: `File ${idx + 1}`,
        prompt: att.name,
        studentContent: att.dataUrl?.startsWith('http')
          ? att.dataUrl
          : `[Tệp ảnh: ${att.name} (${att.size ? Math.round(att.size / 1024) + ' KB' : ''}) - Lưu trữ trên hệ thống]`,
      });
    });

    syncSubmissionToGoogleSheet({
      submissionId: subId,
      assignmentId: fullSubmission.assignmentId,
      assignmentTitle: fullSubmission.assignmentTitle,
      studentId: fullSubmission.studentId,
      studentName: fullSubmission.studentName,
      studentUsername: fullSubmission.studentUsername,
      className: fullSubmission.className,
      status: fullSubmission.status,
      submittedAt: fullSubmission.submittedAt || fullSubmission.lastSavedAt,
      score: fullSubmission.score,
      maxScore: matchingAsg?.maxScore || 10,
      feedback: fullSubmission.feedback,
      gradedAt: fullSubmission.gradedAt,
      gradedByTeacherName: fullSubmission.gradedByTeacherName,
      answersSummary,
      tableResponsesSummary: tableSummary,
      generalNotes: fullSubmission.generalNotes || '',
      attachmentsSummary: attSummary,
      detailedItems,
    });

    // Also record real-time draft & submission history to Sheet 13: LichSu_LuuBai
    syncDraftSaveToGoogleSheet({
      timestamp: fullSubmission.submittedAt || fullSubmission.lastSavedAt || new Date().toISOString(),
      submissionId: subId,
      assignmentId: fullSubmission.assignmentId,
      assignmentTitle: fullSubmission.assignmentTitle,
      studentCode: fullSubmission.studentCode || fullSubmission.studentUsername,
      studentName: fullSubmission.studentName,
      className: fullSubmission.className,
      saveType:
        fullSubmission.status === 'submitted' || fullSubmission.status === 'graded'
          ? 'Nộp bài chính thức'
          : 'Tự động lưu nháp',
      answeredQuestionsCount: Object.keys(fullSubmission.answers || {}).length,
      totalQuestions: matchingAsg?.questions?.length || 0,
      tableFilledCount: Object.keys(fullSubmission.tableResponses || {}).length,
      attachmentsCount: fullSubmission.attachments?.length || 0,
      notes: fullSubmission.generalNotes || '',
      totalCharacters: JSON.stringify(fullSubmission.answers || {}).length,
    });

    // Also record attendance & activity to Sheet 12: DiemDanh_HoatDong
    if (fullSubmission.status === 'submitted') {
      syncActivityLogToGoogleSheet({
        timestamp: new Date().toISOString(),
        userCode: fullSubmission.studentCode || fullSubmission.studentUsername,
        fullName: fullSubmission.studentName,
        username: fullSubmission.studentUsername,
        role: 'student',
        className: fullSubmission.className,
        activityType: 'Học sinh nộp bài tập trực tuyến',
        details: `Nộp bài cho phiếu "${fullSubmission.assignmentTitle}"`,
      });
    }
  } catch (e) {
    console.warn('Google Sheet sync notice for submission:', e);
  }

  return true;
}

/**
 * Teacher grades a submission and leaves feedback
 */
export async function gradeSubmissionInCloud(
  submissionId: string,
  score: number,
  feedback: string,
  allowResubmit: boolean = false,
  teacherId?: string,
  teacherName?: string
): Promise<boolean> {
  const sub = inMemorySubmissions.find((s) => s.id === submissionId);
  if (!sub) return false;

  const updatedSub: AssignmentSubmission = {
    ...sub,
    score,
    feedback,
    status: allowResubmit ? 'resubmit_requested' : 'graded',
    allowResubmit,
    gradedAt: new Date().toISOString(),
    gradedByTeacherId: teacherId || sub.gradedByTeacherId,
    gradedByTeacherName: teacherName || sub.gradedByTeacherName,
  };

  const res = await saveSubmissionToCloud(updatedSub);
  if (res && teacherName) {
    try {
      syncActivityLogToGoogleSheet({
        timestamp: new Date().toISOString(),
        userCode: teacherId || 'GV-ONLINE',
        fullName: teacherName,
        username: 'teacher',
        role: 'teacher',
        className: sub.className,
        activityType: 'Giáo viên chấm điểm bài tập',
        details: `Chấm bài HS ${sub.studentName} phiếu "${sub.assignmentTitle}": ${score}/10đ - Lời phê: "${feedback.slice(0, 50)}"`,
      });
    } catch (e) {
      console.warn(e);
    }
  }
  return res;
}

/**
 * Teacher allows student to resubmit
 */
export async function allowStudentResubmit(submissionId: string): Promise<boolean> {
  const sub = inMemorySubmissions.find((s) => s.id === submissionId);
  if (!sub) return false;

  const updatedSub: AssignmentSubmission = {
    ...sub,
    status: 'resubmit_requested',
    allowResubmit: true,
  };

  return await saveSubmissionToCloud(updatedSub);
}
