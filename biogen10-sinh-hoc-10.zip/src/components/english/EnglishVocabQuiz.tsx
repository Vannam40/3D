import React, { useMemo, useState } from 'react';
import { EnglishTerm } from '../../types/englishBio';
import { ENGLISH_BIO_TERMS } from '../../data/englishBioData';
import { speakEnglish, shuffle, VoiceGender } from '../../utils/speech';
import { Volume2, CheckCircle2, XCircle, RotateCcw, Award, Headphones, Languages, BookOpenText, ArrowRightLeft } from 'lucide-react';

export type QuizMode = 'en_to_vi' | 'vi_to_en' | 'def_to_term' | 'listen';

const MODE_INFO: Record<QuizMode, { label: string; hint: string; icon: React.ComponentType<{ className?: string }> }> = {
  en_to_vi: { label: 'Anh → Việt', hint: 'Chọn nghĩa tiếng Việt của thuật ngữ', icon: Languages },
  vi_to_en: { label: 'Việt → Anh', hint: 'Chọn thuật ngữ tiếng Anh đúng', icon: ArrowRightLeft },
  def_to_term: { label: 'Đọc định nghĩa', hint: 'Đọc định nghĩa tiếng Anh, chọn thuật ngữ', icon: BookOpenText },
  listen: { label: 'Nghe & chọn', hint: 'Nghe phát âm rồi chọn thuật ngữ đúng', icon: Headphones },
};

interface Question {
  term: EnglishTerm;
  mode: QuizMode;
  options: string[];
  answer: string;
}

function buildQuestions(pool: EnglishTerm[], count: number, modes: QuizMode[]): Question[] {
  const picked = shuffle(pool).slice(0, Math.min(count, pool.length));
  return picked.map((term, i) => {
    const mode = modes[i % modes.length];
    const answerOf = (t: EnglishTerm) => (mode === 'en_to_vi' ? t.vietnameseMeaning : t.englishTerm);
    const answer = answerOf(term);
    // Ưu tiên phương án nhiễu cùng bài, thiếu thì lấy thêm từ toàn bộ kho
    const sameLesson = pool.filter(t => t.id !== term.id);
    const others = ENGLISH_BIO_TERMS.filter(t => t.id !== term.id && !sameLesson.includes(t));
    const distractors: string[] = [];
    for (const t of [...shuffle(sameLesson), ...shuffle(others)]) {
      const v = answerOf(t);
      if (v !== answer && !distractors.includes(v)) distractors.push(v);
      if (distractors.length === 3) break;
    }
    return { term, mode, answer, options: shuffle([answer, ...distractors]) };
  });
}

interface Props {
  terms: EnglishTerm[];
  theme?: 'light' | 'dark';
  count?: number;
  voice?: VoiceGender;
  onFinish?: (correct: number, total: number) => void;
}

export const EnglishVocabQuiz: React.FC<Props> = ({ terms, theme = 'light', count = 10, voice = 'female', onFinish }) => {
  const [modes, setModes] = useState<QuizMode[]>(['en_to_vi', 'vi_to_en', 'def_to_term', 'listen']);
  const [seed, setSeed] = useState(0);
  const questions = useMemo(() => buildQuestions(terms, count, modes), [terms, count, modes, seed]);
  const [idx, setIdx] = useState(0);
  const [chosen, setChosen] = useState<string | null>(null);
  const [correct, setCorrect] = useState(0);
  const [done, setDone] = useState(false);

  const dark = theme === 'dark';
  const card = dark ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-sky-100 text-slate-800';
  const sub = dark ? 'text-slate-400' : 'text-slate-500';

  const restart = (newModes?: QuizMode[]) => {
    if (newModes) setModes(newModes);
    setSeed(s => s + 1);
    setIdx(0);
    setChosen(null);
    setCorrect(0);
    setDone(false);
  };

  if (questions.length < 2) {
    return <div className={`p-5 rounded-2xl border text-xs ${card}`}>Chưa đủ thuật ngữ để tạo bài luyện.</div>;
  }

  const q = questions[idx];
  const info = MODE_INFO[q.mode];
  const Icon = info.icon;

  const choose = (opt: string) => {
    if (chosen) return;
    setChosen(opt);
    if (opt === q.answer) setCorrect(c => c + 1);
    if (q.mode !== 'listen') speakEnglish(q.term.englishTerm, voice);
  };

  const next = () => {
    if (idx + 1 >= questions.length) {
      setDone(true);
      onFinish?.(correct, questions.length);
    } else {
      setIdx(i => i + 1);
      setChosen(null);
    }
  };

  if (done) {
    const pct = Math.round((correct / questions.length) * 100);
    return (
      <div className={`p-6 rounded-3xl border text-center space-y-3 ${card}`}>
        <Award className="h-12 w-12 mx-auto text-amber-500" />
        <h4 className="text-lg font-black">Hoàn thành! {correct}/{questions.length} câu đúng ({pct}%)</h4>
        <p className={`text-xs ${sub}`}>
          {pct >= 80 ? 'Excellent! Vốn từ English Biology của em rất tốt.' : pct >= 50 ? 'Good job! Ôn lại các thẻ từ còn nhầm rồi thử lại nhé.' : 'Keep trying! Hãy luyện thẻ từ (flashcard) trước rồi làm lại.'}
        </p>
        <button onClick={() => restart()} className="px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-sky-600 hover:bg-sky-500 inline-flex items-center gap-1.5">
          <RotateCcw className="h-3.5 w-3.5" /> Làm bộ câu mới
        </button>
      </div>
    );
  }

  return (
    <div className={`p-5 sm:p-6 rounded-3xl border space-y-4 ${card}`}>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap gap-1.5 text-[11px]">
          {(Object.keys(MODE_INFO) as QuizMode[]).map(m => {
            const on = modes.includes(m);
            return (
              <button
                key={m}
                onClick={() => {
                  const nm = on ? modes.filter(x => x !== m) : [...modes, m];
                  if (nm.length) restart(nm);
                }}
                className={`px-2.5 py-1 rounded-lg border font-bold transition ${
                  on ? 'bg-sky-600 border-sky-600 text-white' : dark ? 'border-slate-700 text-slate-400' : 'border-slate-200 text-slate-500'
                }`}
              >
                {MODE_INFO[m].label}
              </button>
            );
          })}
        </div>
        <span className="text-xs font-mono font-bold text-amber-600">
          Câu {idx + 1}/{questions.length} · Đúng {correct}
        </span>
      </div>

      <div className={`p-5 rounded-2xl border text-center space-y-2 ${dark ? 'bg-slate-950 border-slate-800' : 'bg-sky-50 border-sky-100'}`}>
        <div className={`flex items-center justify-center gap-1.5 text-[11px] font-bold uppercase tracking-wide ${sub}`}>
          <Icon className="h-3.5 w-3.5" /> {info.hint}
        </div>
        {q.mode === 'en_to_vi' && (
          <div className="flex items-center justify-center gap-2">
            <span className="text-2xl font-black">{q.term.englishTerm}</span>
            <button onClick={() => speakEnglish(q.term.englishTerm, voice)} className="p-1.5 rounded-lg bg-sky-600 text-white" title="Nghe">
              <Volume2 className="h-4 w-4" />
            </button>
          </div>
        )}
        {q.mode === 'vi_to_en' && <div className="text-2xl font-black">{q.term.vietnameseMeaning}</div>}
        {q.mode === 'def_to_term' && <div className="text-base font-semibold italic">“{q.term.definition}”</div>}
        {q.mode === 'listen' && (
          <button
            onClick={() => speakEnglish(q.term.englishTerm, voice, 0.8)}
            className="mx-auto flex items-center gap-2 px-5 py-3 rounded-2xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-sm"
          >
            <Headphones className="h-5 w-5" /> Bấm để nghe
          </button>
        )}
        {q.mode !== 'en_to_vi' && q.mode !== 'listen' && (
          <div className={`font-mono text-[11px] ${sub}`}>{chosen ? q.term.pronunciation : ' '}</div>
        )}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        {q.options.map(opt => {
          const isAns = opt === q.answer;
          const isPicked = opt === chosen;
          const cls = !chosen
            ? dark
              ? 'border-slate-700 bg-slate-950 hover:border-sky-500'
              : 'border-slate-200 bg-white hover:border-sky-400'
            : isAns
            ? 'border-emerald-500 bg-emerald-50 text-emerald-800'
            : isPicked
            ? 'border-rose-500 bg-rose-50 text-rose-800'
            : dark
            ? 'border-slate-800 bg-slate-950 opacity-60'
            : 'border-slate-200 bg-white opacity-60';
          return (
            <button key={opt} onClick={() => choose(opt)} className={`p-3 rounded-xl border text-left text-sm font-semibold flex items-center justify-between gap-2 transition ${cls}`}>
              <span>{opt}</span>
              {chosen && isAns && <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" />}
              {chosen && isPicked && !isAns && <XCircle className="h-4 w-4 text-rose-600 shrink-0" />}
            </button>
          );
        })}
      </div>

      {chosen && (
        <div className={`p-3 rounded-xl border text-xs space-y-1 ${dark ? 'bg-slate-950 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
          <div>
            <strong>{q.term.englishTerm}</strong> <span className="font-mono">{q.term.pronunciation}</span> — {q.term.vietnameseMeaning}
          </div>
          <div className={sub}>EN: {q.term.definition}</div>
          <div className="flex items-center gap-1.5">
            <span className="italic">“{q.term.exampleSentence}”</span>
            <button onClick={() => speakEnglish(q.term.exampleSentence, voice)} className="p-1 rounded bg-sky-600 text-white shrink-0" title="Nghe câu ví dụ">
              <Volume2 className="h-3 w-3" />
            </button>
          </div>
          <div className="flex justify-end pt-1">
            <button onClick={next} className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-amber-600 hover:bg-amber-500">
              {idx + 1 >= questions.length ? 'Xem kết quả' : 'Câu tiếp theo →'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
