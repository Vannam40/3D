import React, { useMemo, useState } from 'react';
import { ENGLISH_BIO_TERMS } from '../../data/englishBioData';
import { speakEnglish, VoiceGender, shuffle } from '../../utils/speech';
import { EnglishVocabQuiz } from './EnglishVocabQuiz';
import { Volume2, Layers, ListChecks, BookA, RotateCw, ChevronLeft, ChevronRight, Info, FileText } from 'lucide-react';
import { getLesson } from '../../data/bio10';

interface Props {
  topicId: string;
  topicTitleVi: string;
  titleEn: string;
  onQuizFinish?: (correct: number, total: number) => void;
}

/** Tab English Biology trong từng chủ đề: tóm tắt bài tiếng Anh, thẻ từ vựng, flashcard và bài luyện 4 dạng */
export const TopicEnglishLab: React.FC<Props> = ({ topicId, topicTitleVi, titleEn, onQuizFinish }) => {
  const terms = useMemo(() => ENGLISH_BIO_TERMS.filter(t => t.topicId === topicId), [topicId]);
  const lesson = getLesson(topicId);
  const summaryEn = lesson?.summaryEn || [];
  const [mode, setMode] = useState<'summary' | 'cards' | 'flash' | 'quiz'>(summaryEn.length ? 'summary' : 'cards');
  const [voice, setVoice] = useState<VoiceGender>('female');
  const [showVi, setShowVi] = useState(true);
  const [deck, setDeck] = useState(terms);
  const [fi, setFi] = useState(0);
  const [flipped, setFlipped] = useState(false);

  React.useEffect(() => {
    setDeck(terms);
    setFi(0);
    setFlipped(false);
  }, [terms]);

  const tabBtn = (key: typeof mode, label: string, Icon: React.ComponentType<{ className?: string }>) => (
    <button
      onClick={() => setMode(key)}
      className={`px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 text-xs transition ${
        mode === key ? 'bg-sky-600 text-white' : 'text-slate-600 hover:bg-slate-100'
      }`}
    >
      <Icon className="h-3.5 w-3.5" /> {label}
    </button>
  );

  const card = deck[fi];

  return (
    <div className="space-y-4">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pb-3 border-b border-slate-200">
        <div>
          <h3 className="text-base font-extrabold text-slate-900">English Biology · {titleEn}</h3>
          <p className="text-xs text-slate-500">
            {terms.length} thuật ngữ của “{topicTitleVi}” – tóm tắt bài tiếng Anh, nghe phát âm, định nghĩa song ngữ, luyện tập.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-1.5">
          <div className="flex items-center gap-1 p-1 bg-white rounded-2xl border border-slate-200">
            {summaryEn.length > 0 && tabBtn('summary', 'Lesson summary', FileText)}
            {tabBtn('cards', 'Thẻ từ vựng', BookA)}
            {tabBtn('flash', 'Flashcard', Layers)}
            {tabBtn('quiz', 'Luyện tập', ListChecks)}
          </div>
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-2xl border border-slate-200 text-xs">
            <button onClick={() => setVoice('female')} className={`px-2.5 py-1.5 rounded-xl font-bold ${voice === 'female' ? 'bg-rose-500 text-white' : 'text-slate-600'}`}>Giọng nữ</button>
            <button onClick={() => setVoice('male')} className={`px-2.5 py-1.5 rounded-xl font-bold ${voice === 'male' ? 'bg-sky-600 text-white' : 'text-slate-600'}`}>Giọng nam</button>
          </div>
        </div>
      </div>

      <p className="text-[11px] text-slate-500 flex items-start gap-1.5">
        <Info className="h-3.5 w-3.5 shrink-0 mt-0.5" />
        Phần tiếng Anh là bản dịch tương ứng với nội dung SGK Sinh học 10 (KNTT). Phát âm dùng giọng đọc có sẵn của trình duyệt.
      </p>

      {mode === 'summary' && lesson && (
        <div className="space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h4 className="text-sm font-extrabold text-slate-900">Lesson summary · {lesson.titleEn}</h4>
              <p className="text-[11px] text-slate-500">Tóm tắt bài bằng tiếng Anh – mỗi câu tương ứng một ý “Kiến thức cốt lõi” trong {lesson.pages}.</p>
            </div>
            <div className="flex items-center gap-2">
              <label className="flex items-center gap-1.5 text-xs text-slate-600 font-semibold">
                <input type="checkbox" checked={showVi} onChange={e => setShowVi(e.target.checked)} /> Hiện tiếng Việt
              </label>
              <button
                onClick={() => speakEnglish(summaryEn.join(' '), voice)}
                className="px-3 py-1.5 rounded-xl bg-sky-600 text-white text-xs font-bold flex items-center gap-1"
              >
                <Volume2 className="h-3.5 w-3.5" /> Nghe cả bài
              </button>
            </div>
          </div>
          <ol className="space-y-2.5">
            {summaryEn.map((en, i) => (
              <li key={i} className="p-4 rounded-2xl bg-white border border-sky-100 shadow-sm flex gap-3">
                <span className="h-6 w-6 shrink-0 rounded-full bg-sky-100 text-sky-700 text-xs font-black flex items-center justify-center">{i + 1}</span>
                <div className="flex-1 space-y-1.5">
                  <p className="text-sm text-slate-900 leading-relaxed">{en}</p>
                  {showVi && lesson.core[i] && <p className="text-xs text-slate-500 leading-relaxed italic">{lesson.core[i]}</p>}
                </div>
                <button onClick={() => speakEnglish(en, voice)} className="self-start p-2 rounded-xl border border-sky-200 bg-sky-50 text-sky-700 hover:bg-sky-100" title="Nghe câu này">
                  <Volume2 className="h-4 w-4" />
                </button>
              </li>
            ))}
          </ol>
        </div>
      )}

      {mode === 'cards' && (
        <>
          <label className="flex items-center gap-2 text-xs text-slate-600 font-semibold">
            <input type="checkbox" checked={showVi} onChange={e => setShowVi(e.target.checked)} /> Hiện nghĩa tiếng Việt
          </label>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {terms.map(term => (
              <div key={term.id} className="p-5 rounded-3xl bg-white border border-sky-100 space-y-2.5 shadow-sm hover:border-sky-300 transition text-slate-800">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h4 className="text-base font-extrabold text-slate-900">{term.englishTerm}</h4>
                    {showVi && <p className="text-xs font-bold text-sky-600">{term.vietnameseMeaning}</p>}
                  </div>
                  <button onClick={() => speakEnglish(term.englishTerm, voice)} className="p-2 rounded-xl border border-sky-200 bg-sky-50 text-sky-700 hover:bg-sky-100" title="Nghe phát âm">
                    <Volume2 className="h-4 w-4" />
                  </button>
                </div>
                <div className="font-mono text-xs text-sky-700 bg-sky-50 px-2.5 py-1 rounded-lg inline-block border border-sky-100 font-bold">{term.pronunciation}</div>
                <p className="text-xs text-slate-700 leading-relaxed">
                  <strong className="text-slate-900">EN:</strong> {term.definition}
                </p>
                {showVi && (
                  <p className="text-xs text-slate-600 leading-relaxed">
                    <strong className="text-slate-900">VI:</strong> {term.definitionVi}
                  </p>
                )}
                <div className="flex items-start gap-2 text-xs text-slate-600 italic bg-slate-50 p-3 rounded-xl border border-slate-200/80">
                  <span className="flex-1">“{term.exampleSentence}”</span>
                  <button onClick={() => speakEnglish(term.exampleSentence, voice)} className="p-1 rounded-lg bg-sky-600 text-white not-italic shrink-0" title="Nghe câu ví dụ">
                    <Volume2 className="h-3 w-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {mode === 'flash' && card && (
        <div className="max-w-xl mx-auto space-y-3">
          <button
            onClick={() => setFlipped(f => !f)}
            className="w-full min-h-[220px] rounded-3xl border-2 border-sky-200 bg-gradient-to-br from-white to-sky-50 p-6 shadow-sm text-center flex flex-col items-center justify-center gap-2"
          >
            {!flipped ? (
              <>
                <span className="text-[11px] font-bold uppercase text-slate-400">Mặt trước · bấm để lật</span>
                <span className="text-3xl font-black text-slate-900">{card.englishTerm}</span>
                <span className="font-mono text-sm text-sky-700">{card.pronunciation}</span>
              </>
            ) : (
              <>
                <span className="text-[11px] font-bold uppercase text-slate-400">Mặt sau</span>
                <span className="text-2xl font-black text-sky-700">{card.vietnameseMeaning}</span>
                <span className="text-sm text-slate-700">{card.definition}</span>
                <span className="text-xs text-slate-500">{card.definitionVi}</span>
              </>
            )}
          </button>
          <div className="flex items-center justify-between">
            <button onClick={() => { setFi(i => (i - 1 + deck.length) % deck.length); setFlipped(false); }} className="p-2 rounded-xl bg-white border border-slate-200"><ChevronLeft className="h-4 w-4" /></button>
            <div className="flex items-center gap-2 text-xs font-bold text-slate-600">
              <button onClick={() => speakEnglish(card.englishTerm, voice)} className="px-3 py-1.5 rounded-xl bg-sky-600 text-white flex items-center gap-1"><Volume2 className="h-3.5 w-3.5" /> Nghe</button>
              <button onClick={() => { setDeck(shuffle(terms)); setFi(0); setFlipped(false); }} className="px-3 py-1.5 rounded-xl bg-white border border-slate-200 flex items-center gap-1"><RotateCw className="h-3.5 w-3.5" /> Xáo thẻ</button>
              <span>{fi + 1}/{deck.length}</span>
            </div>
            <button onClick={() => { setFi(i => (i + 1) % deck.length); setFlipped(false); }} className="p-2 rounded-xl bg-white border border-slate-200"><ChevronRight className="h-4 w-4" /></button>
          </div>
        </div>
      )}

      {mode === 'quiz' && <EnglishVocabQuiz terms={terms} theme="light" voice={voice} count={Math.min(10, terms.length)} onFinish={onQuizFinish} />}
    </div>
  );
};
