import React from 'react';
import { useGeneticsTopics } from '../../data/topicsData';
import { LESSON_BY_ID } from '../../data/bio10';
import { MODEL_REGISTRY } from '../models3d/registry';
import { ModelLoader } from '../models3d/ModelLoader';
import { useAuth } from '../../hooks/useAuth';
import { Box } from 'lucide-react';

interface TopicModelRendererProps {
  topicId: string;
}

/**
 * Hiển thị mô hình 3D song ngữ của chủ đề (bài học SGK Sinh học 10).
 * Bài thực hành dùng lại mô hình của bài lí thuyết liên quan.
 */
export const TopicModelRenderer: React.FC<TopicModelRendererProps> = ({ topicId }) => {
  const { topics } = useGeneticsTopics();
  const { updateProgress } = useAuth();
  const topic = topics.find(t => t.id === topicId);
  const modelId =
    (topic?.interactiveType && MODEL_REGISTRY[topic.interactiveType] && topic.interactiveType) ||
    LESSON_BY_ID[topicId]?.modelId ||
    '';

  if (!modelId) {
    return (
      <div className="p-8 rounded-2xl bg-slate-900 border border-slate-800 text-slate-300 text-sm flex items-center gap-3">
        <Box className="h-5 w-5 text-cyan-400" />
        Chủ đề này chưa được gán mô hình 3D. Quản trị viên có thể chọn mô hình trong mục Quản lý chủ đề.
      </div>
    );
  }

  return (
    <ModelLoader
      modelId={modelId}
      onQuizFinish={(correct, total) => {
        if (total > 0) updateProgress(topicId, { interactiveCompleted: true }, correct * 4);
      }}
    />
  );
};
