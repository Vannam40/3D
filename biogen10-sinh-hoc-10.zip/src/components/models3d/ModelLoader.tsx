import React, { useEffect, useState } from 'react';
import { ModelDef, ModelShell } from './engine';
import { MODEL_REGISTRY } from './registry';
import { Loader2, AlertTriangle } from 'lucide-react';

interface Props {
  modelId: string;
  onQuizFinish?: (correct: number, total: number) => void;
}

/** Tải mô hình theo id rồi hiển thị trong khung ModelShell */
export const ModelLoader: React.FC<Props> = ({ modelId, onQuizFinish }) => {
  const [def, setDef] = useState<ModelDef | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    setDef(null);
    setError(null);
    const loader = MODEL_REGISTRY[modelId];
    if (!loader) {
      setError(`Không tìm thấy mô hình "${modelId}".`);
      return;
    }
    loader()
      .then(m => alive && setDef(m.default))
      .catch(e => alive && setError(String(e?.message || e)));
    return () => {
      alive = false;
    };
  }, [modelId]);

  if (error)
    return (
      <div className="p-6 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-sm flex items-center gap-2">
        <AlertTriangle className="h-4 w-4" /> {error}
      </div>
    );
  if (!def)
    return (
      <div className="h-[520px] rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-300 text-sm gap-2">
        <Loader2 className="h-5 w-5 animate-spin" /> Đang tải mô hình 3D…
      </div>
    );
  return <ModelShell def={def} onQuizFinish={onQuizFinish} />;
};
