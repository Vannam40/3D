/**
 * BioScene 3D engine – khung dùng chung cho các mô hình 3D Sinh học 10.
 * - Mỗi bộ phận (Part) bấm được, phát sáng khi chọn, có nhãn song ngữ Việt–Anh.
 * - Hỗ trợ các bước (stage) có chuyển động mượt.
 * - Trò chơi "Find the part": nghe/đọc tên tiếng Anh, bấm đúng bộ phận trên mô hình.
 */
import React, { createContext, useContext, useMemo, useRef, useState, useEffect, Suspense } from 'react';
import { Canvas, useFrame, ThreeEvent, ThreeElements } from '@react-three/fiber';
import { OrbitControls, Html } from '@react-three/drei';
import * as THREE from 'three';
import {
  Volume2, RotateCcw, Play, Pause, ChevronLeft, ChevronRight, Tags, Target, Trophy, Info, Box, MousePointerClick, X,
} from 'lucide-react';
import { speakEnglish } from '../../utils/speech';

/* ------------------------------------------------------------------ */
/* Kiểu dữ liệu                                                        */
/* ------------------------------------------------------------------ */
export interface PartInfo {
  id: string;
  nameVi: string;
  nameEn: string;
  ipa?: string;
  color: string;
  descVi: string;
  descEn: string;
  /** Chỉ hiện/được hỏi ở các bước này (chỉ số 0-based). Bỏ trống = mọi bước */
  stages?: number[];
}

export interface StageInfo {
  titleVi: string;
  titleEn: string;
  descVi: string;
  descEn?: string;
}

export interface SceneProps {
  stage: number;
}

export interface ModelDef {
  id: string;
  titleVi: string;
  titleEn: string;
  source: string;
  parts: PartInfo[];
  stages?: StageInfo[];
  Scene: React.FC<SceneProps>;
  camera?: [number, number, number];
  fov?: number;
  autoRotate?: boolean;
  /** Tự chạy các bước khi bấm Play (ms mỗi bước) */
  stageInterval?: number;
}

export type LabelMode = 'vi' | 'en' | 'both' | 'none';

interface Ctx {
  selected: string | null;
  hovered: string | null;
  labelMode: LabelMode;
  quizActive: boolean;
  partsById: Record<string, PartInfo>;
  stage: number;
  onPick: (id: string) => void;
  setHovered: (id: string | null) => void;
}

const SceneCtx = createContext<Ctx>({
  selected: null,
  hovered: null,
  labelMode: 'both',
  quizActive: false,
  partsById: {},
  stage: 0,
  onPick: () => {},
  setHovered: () => {},
});

const PartIdCtx = createContext<string | null>(null);

/** Lớp phủ DOM tự quản lý cho nhãn <Html>, tránh lỗi removeChild khi gỡ mô hình (React 19 + drei) */
const PortalCtx = createContext<React.MutableRefObject<HTMLDivElement | null> | null>(null);
function usePortal() {
  const ref = useContext(PortalCtx);
  return ref && ref.current ? (ref as React.MutableRefObject<HTMLElement>) : undefined;
}

/* ------------------------------------------------------------------ */
/* Primitive helpers                                                   */
/* ------------------------------------------------------------------ */
type V3 = [number, number, number];

/** Vật liệu tự phát sáng khi bộ phận cha được chọn / rê chuột */
export const M: React.FC<{ c: string; o?: number; r?: number; m?: number; e?: number; side?: THREE.Side; wire?: boolean }> = ({
  c, o = 1, r = 0.45, m = 0.05, e = 0, side, wire,
}) => {
  const { selected, hovered } = useContext(SceneCtx);
  const pid = useContext(PartIdCtx);
  const active = pid && (selected === pid || hovered === pid);
  const intensity = pid && selected === pid ? 0.65 : active ? 0.35 : e;
  return (
    <meshStandardMaterial
      color={c}
      roughness={r}
      metalness={m}
      transparent={o < 1}
      opacity={o}
      depthWrite={o >= 0.95}
      emissive={c}
      emissiveIntensity={intensity}
      side={side}
      wireframe={wire}
    />
  );
};

/** Nhóm bộ phận bấm được */
export const Part: React.FC<{ id: string; children: React.ReactNode } & Omit<ThreeElements['group'], 'id'>> = ({ id, children, ...rest }) => {
  const { onPick, setHovered, partsById, stage } = useContext(SceneCtx);
  const info = partsById[id];
  if (info?.stages && !info.stages.includes(stage)) return null;
  return (
    <PartIdCtx.Provider value={id}>
      <group
        {...rest}
        onClick={(e: ThreeEvent<MouseEvent>) => {
          e.stopPropagation();
          onPick(id);
        }}
        onPointerOver={(e: ThreeEvent<PointerEvent>) => {
          e.stopPropagation();
          setHovered(id);
          document.body.style.cursor = 'pointer';
        }}
        onPointerOut={() => {
          setHovered(null);
          document.body.style.cursor = 'auto';
        }}
      >
        {children}
      </group>
    </PartIdCtx.Provider>
  );
};

/** Nhãn song ngữ gắn vào bộ phận */
export const Label: React.FC<{ id: string; p: V3; side?: 'l' | 'r' }> = ({ id, p }) => {
  const { labelMode, quizActive, partsById, selected, stage, onPick } = useContext(SceneCtx);
  const info = partsById[id];
  const hidden = !info || labelMode === 'none' || quizActive || (info.stages && !info.stages.includes(stage));
  const isSel = selected === id;
  // Html luôn được gắn (tránh tạo/huỷ root React liên tục), chỉ ẩn nội dung
  const portal = usePortal();
  return (
    <Html portal={portal} position={p} center zIndexRange={[20, 0]} style={{ pointerEvents: hidden ? 'none' : 'auto' }}>
      {!hidden && info && (
        <button
          onClick={() => onPick(id)}
          className={`whitespace-nowrap rounded-lg border px-1.5 py-0.5 text-[10px] font-bold leading-tight shadow-md transition ${
            isSel ? 'bg-amber-400 text-slate-950 border-amber-200 scale-110' : 'bg-slate-950/80 text-white border-white/20 hover:bg-sky-600'
          }`}
          style={{ borderLeft: `3px solid ${info.color}` }}
        >
          {labelMode !== 'en' && <span className="block">{info.nameVi}</span>}
          {labelMode !== 'vi' && <span className={`block ${labelMode === 'both' ? 'text-sky-300 font-semibold' : ''}`}>{info.nameEn}</span>}
        </button>
      )}
    </Html>
  );
};

export const Ball: React.FC<{ p?: V3; r?: number; c: string; o?: number; seg?: number; s?: V3 }> = ({ p = [0, 0, 0], r = 0.2, c, o, seg = 24, s }) => (
  <mesh position={p} scale={s}>
    <sphereGeometry args={[r, seg, Math.max(8, Math.round(seg * 0.66))]} />
    <M c={c} o={o} />
  </mesh>
);

const UP = new THREE.Vector3(0, 1, 0);
/** Thanh trụ nối 2 điểm */
export const Rod: React.FC<{ a: V3; b: V3; r?: number; c: string; o?: number }> = ({ a, b, r = 0.04, c, o }) => {
  const { pos, quat, len } = useMemo(() => {
    const va = new THREE.Vector3(...a);
    const vb = new THREE.Vector3(...b);
    const dir = vb.clone().sub(va);
    const len = dir.length();
    const quat = new THREE.Quaternion().setFromUnitVectors(UP, dir.clone().normalize());
    return { pos: va.add(vb).multiplyScalar(0.5), quat, len };
  }, [a[0], a[1], a[2], b[0], b[1], b[2]]);
  return (
    <mesh position={pos} quaternion={quat}>
      <cylinderGeometry args={[r, r, len, 12]} />
      <M c={c} o={o} />
    </mesh>
  );
};

/** Ống cong qua các điểm */
export const Tube: React.FC<{ pts: V3[]; r?: number; c: string; o?: number; closed?: boolean; seg?: number }> = ({ pts, r = 0.05, c, o, closed, seg }) => {
  const geo = useMemo(() => {
    const curve = new THREE.CatmullRomCurve3(pts.map(q => new THREE.Vector3(...q)), !!closed);
    return new THREE.TubeGeometry(curve, seg || Math.max(24, pts.length * 12), r, 10, !!closed);
  }, [JSON.stringify(pts), r, closed, seg]);
  return (
    <mesh geometry={geo}>
      <M c={c} o={o} />
    </mesh>
  );
};

export const Caps: React.FC<{ p?: V3; len?: number; r?: number; c: string; o?: number; rot?: V3 }> = ({ p = [0, 0, 0], len = 1, r = 0.2, c, o, rot }) => (
  <mesh position={p} rotation={rot}>
    <capsuleGeometry args={[r, len, 8, 16]} />
    <M c={c} o={o} />
  </mesh>
);

export const BoxM: React.FC<{ p?: V3; s?: V3; c: string; o?: number; rot?: V3 }> = ({ p = [0, 0, 0], s = [1, 1, 1], c, o, rot }) => (
  <mesh position={p} rotation={rot}>
    <boxGeometry args={s} />
    <M c={c} o={o} />
  </mesh>
);

export const Ring: React.FC<{ p?: V3; R?: number; r?: number; c: string; o?: number; rot?: V3; arc?: number }> = ({ p = [0, 0, 0], R = 1, r = 0.05, c, o, rot, arc }) => (
  <mesh position={p} rotation={rot}>
    <torusGeometry args={[R, r, 12, 48, arc ?? Math.PI * 2]} />
    <M c={c} o={o} />
  </mesh>
);

export const Cyl: React.FC<{ p?: V3; rt?: number; rb?: number; h?: number; c: string; o?: number; rot?: V3; seg?: number; open?: boolean }> = ({ p = [0, 0, 0], rt = 0.3, rb, h = 1, c, o, rot, seg = 24, open }) => (
  <mesh position={p} rotation={rot}>
    <cylinderGeometry args={[rt, rb ?? rt, h, seg, 1, !!open]} />
    <M c={c} o={o} side={open ? THREE.DoubleSide : undefined} />
  </mesh>
);

/** Bán cầu/hình cầu cắt để nhìn vào bên trong tế bào */
export const Shell: React.FC<{ p?: V3; r?: number; c: string; o?: number; s?: V3; cut?: number }> = ({ p = [0, 0, 0], r = 1, c, o = 0.25, s, cut = 1.35 }) => (
  <mesh position={p} scale={s} rotation={[0, 0.6, 0]}>
    <sphereGeometry args={[r, 48, 32, cut, Math.PI * 2 - cut]} />
    <M c={c} o={o} side={THREE.DoubleSide} r={0.6} />
  </mesh>
);

/** Nhóm tự chuyển động mượt tới vị trí/tỉ lệ/góc quay đích */
export const Damp: React.FC<{ to?: V3; s?: number; rot?: V3; speed?: number; children: React.ReactNode }> = ({ to = [0, 0, 0], s = 1, rot = [0, 0, 0], speed = 3, children }) => {
  const ref = useRef<THREE.Group>(null);
  const tp = useMemo(() => new THREE.Vector3(...to), [to[0], to[1], to[2]]);
  const te = useMemo(() => new THREE.Quaternion().setFromEuler(new THREE.Euler(...rot)), [rot[0], rot[1], rot[2]]);
  useFrame((_, dt) => {
    const g = ref.current;
    if (!g) return;
    const k = 1 - Math.exp(-dt * speed);
    g.position.lerp(tp, k);
    const cs = g.scale.x + (Math.max(0.0001, s) - g.scale.x) * k;
    g.scale.setScalar(cs);
    g.quaternion.slerp(te, k);
    g.visible = cs > 0.02;
  });
  return (
    <group ref={ref} position={to} scale={Math.max(0.0001, s)}>
      {children}
    </group>
  );
};

/** Nhóm quay liên tục */
export const Spin: React.FC<{ speed?: number; axis?: 'x' | 'y' | 'z'; children: React.ReactNode } & ThreeElements['group']> = ({ speed = 0.4, axis = 'y', children, ...rest }) => {
  const ref = useRef<THREE.Group>(null);
  useFrame((_, dt) => {
    if (ref.current) ref.current.rotation[axis] += dt * speed;
  });
  return (
    <group ref={ref} {...rest}>
      {children}
    </group>
  );
};

/** Hạt chuyển động theo đường (vòng lặp) – dùng cho vận chuyển chất */
export const Flow: React.FC<{ path: V3[]; n?: number; r?: number; c: string; speed?: number; offset?: number }> = ({ path, n = 6, r = 0.08, c, speed = 0.25, offset = 0 }) => {
  const curve = useMemo(() => new THREE.CatmullRomCurve3(path.map(q => new THREE.Vector3(...q))), [JSON.stringify(path)]);
  const refs = useRef<(THREE.Mesh | null)[]>([]);
  useFrame(({ clock }) => {
    const t = clock.getElapsedTime() * speed + offset;
    refs.current.forEach((m, i) => {
      if (!m) return;
      const u = (t + i / n) % 1;
      m.position.copy(curve.getPointAt(u));
    });
  });
  return (
    <group>
      {Array.from({ length: n }).map((_, i) => (
        <mesh key={i} ref={el => (refs.current[i] = el)}>
          <sphereGeometry args={[r, 12, 8]} />
          <M c={c} e={0.25} />
        </mesh>
      ))}
    </group>
  );
};

/** Dao động nhẹ (bập bềnh) */
export const Bob: React.FC<{ amp?: number; speed?: number; phase?: number; children: React.ReactNode }> = ({ amp = 0.08, speed = 1.2, phase = 0, children }) => {
  const ref = useRef<THREE.Group>(null);
  useFrame(({ clock }) => {
    if (ref.current) ref.current.position.y = Math.sin(clock.getElapsedTime() * speed + phase) * amp;
  });
  return <group ref={ref}>{children}</group>;
};

/** Mũi tên chỉ hướng */
export const Arrow: React.FC<{ a: V3; b: V3; c?: string; r?: number }> = ({ a, b, c = '#fbbf24', r = 0.035 }) => {
  const { tip, quat } = useMemo(() => {
    const va = new THREE.Vector3(...a);
    const vb = new THREE.Vector3(...b);
    const dir = vb.clone().sub(va).normalize();
    return { tip: vb, quat: new THREE.Quaternion().setFromUnitVectors(UP, dir) };
  }, [a.join(), b.join()]);
  const shaftEnd: V3 = [tip.x - (tip.x - a[0]) * 0.08, tip.y - (tip.y - a[1]) * 0.08, tip.z - (tip.z - a[2]) * 0.08];
  return (
    <group>
      <Rod a={a} b={shaftEnd} r={r} c={c} />
      <mesh position={tip} quaternion={quat}>
        <coneGeometry args={[r * 3, r * 7, 12]} />
        <M c={c} />
      </mesh>
    </group>
  );
};

/** Chữ nổi đơn giản trong không gian (không phải nhãn bộ phận) */
export const Tag: React.FC<{ p: V3; children: React.ReactNode; tone?: 'amber' | 'sky' | 'rose' | 'emerald' | 'slate'; show?: boolean }> = ({ p, children, tone = 'slate', show = true }) => {
  const { labelMode } = useContext(SceneCtx);
  const tones: Record<string, string> = {
    amber: 'bg-amber-400 text-slate-950',
    sky: 'bg-sky-500 text-white',
    rose: 'bg-rose-500 text-white',
    emerald: 'bg-emerald-500 text-white',
    slate: 'bg-white/90 text-slate-900',
  };
  const portal = usePortal();
  return (
    <Html portal={portal} position={p} center zIndexRange={[10, 0]} style={{ pointerEvents: 'none' }}>
      {show && labelMode !== 'none' && <div className={`whitespace-nowrap rounded-md px-1.5 py-0.5 text-[10px] font-extrabold shadow ${tones[tone]}`}>{children}</div>}
    </Html>
  );
};

export function useStage() {
  return useContext(SceneCtx).stage;
}

/* ------------------------------------------------------------------ */
/* Shell – khung giao diện quanh Canvas                               */
/* ------------------------------------------------------------------ */
interface ShellProps {
  def: ModelDef;
  onQuizFinish?: (correct: number, total: number) => void;
}

export const ModelShell: React.FC<ShellProps> = ({ def, onQuizFinish }) => {
  const hostRef = useRef<HTMLDivElement>(null);
  const overlayRef = useRef<HTMLDivElement | null>(null);
  const [overlayReady, setOverlayReady] = useState(false);
  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;
    const d = document.createElement('div');
    d.style.cssText = 'position:absolute;inset:0;pointer-events:none;overflow:hidden;z-index:5';
    host.appendChild(d);
    overlayRef.current = d;
    setOverlayReady(true);
    return () => {
      // Gỡ lớp phủ sau khi Canvas đã dọn xong các nhãn
      setTimeout(() => d.remove(), 1500);
    };
  }, []);
  const [stage, setStage] = useState(0);
  const [selected, setSelected] = useState<string | null>(null);
  const [hovered, setHovered] = useState<string | null>(null);
  const [labelMode, setLabelMode] = useState<LabelMode>('both');
  const [autoRotate, setAutoRotate] = useState(def.autoRotate ?? true);
  const [playing, setPlaying] = useState(false);
  const [resetKey, setResetKey] = useState(0);
  const controlsRef = useRef<any>(null);

  // Quiz
  const [quiz, setQuiz] = useState<{ active: boolean; queue: string[]; idx: number; correct: number; feedback: null | { ok: boolean; picked: string } } | null>(null);

  const stages = def.stages || [];
  const partsById = useMemo(() => Object.fromEntries(def.parts.map(p => [p.id, p])), [def]);
  const visibleParts = def.parts.filter(p => !p.stages || p.stages.includes(stage));
  const selInfo = selected ? partsById[selected] : null;

  useEffect(() => {
    setStage(0);
    setSelected(null);
    setQuiz(null);
  }, [def.id]);

  useEffect(() => {
    if (selected && partsById[selected]?.stages && !partsById[selected].stages!.includes(stage)) setSelected(null);
  }, [stage]);

  useEffect(() => {
    if (!playing || stages.length < 2) return;
    const t = setInterval(() => setStage(s => (s + 1) % stages.length), def.stageInterval || 3500);
    return () => clearInterval(t);
  }, [playing, stages.length]);

  const startQuiz = () => {
    const pool = visibleParts.map(p => p.id);
    const queue = [...pool].sort(() => Math.random() - 0.5).slice(0, Math.min(5, pool.length));
    setSelected(null);
    setPlaying(false);
    setQuiz({ active: true, queue, idx: 0, correct: 0, feedback: null });
    if (queue[0]) setTimeout(() => speakEnglish(partsById[queue[0]].nameEn), 250);
  };

  const onPick = (id: string) => {
    if (quiz?.active) {
      if (quiz.feedback) return;
      const target = quiz.queue[quiz.idx];
      const ok = id === target;
      setSelected(target);
      setQuiz({ ...quiz, correct: quiz.correct + (ok ? 1 : 0), feedback: { ok, picked: id } });
      return;
    }
    setSelected(prev => (prev === id ? null : id));
  };

  const nextQuiz = () => {
    if (!quiz) return;
    const ni = quiz.idx + 1;
    setSelected(null);
    if (ni >= quiz.queue.length) {
      onQuizFinish?.(quiz.correct, quiz.queue.length);
      setQuiz({ ...quiz, active: false, idx: ni, feedback: null });
    } else {
      setQuiz({ ...quiz, idx: ni, feedback: null });
      setTimeout(() => speakEnglish(partsById[quiz.queue[ni]].nameEn), 200);
    }
  };

  const ctx: Ctx = { selected, hovered, labelMode, quizActive: !!quiz?.active, partsById, stage, onPick, setHovered };
  const quizTarget = quiz?.active ? partsById[quiz.queue[quiz.idx]] : null;

  return (
    <div className="space-y-3">
      {/* Title bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 p-3 rounded-2xl bg-slate-900 border border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-cyan-500 to-emerald-500 flex items-center justify-center text-white shrink-0">
            <Box className="h-5 w-5" />
          </div>
          <div>
            <div className="text-sm font-black text-white leading-tight">{def.titleVi}</div>
            <div className="text-[11px] font-semibold text-cyan-300">{def.titleEn} · <span className="text-slate-400">{def.source}</span></div>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
          <div className="flex items-center gap-0.5 p-0.5 rounded-lg bg-slate-800">
            <Tags className="h-3.5 w-3.5 text-slate-400 mx-1" />
            {(['both', 'vi', 'en', 'none'] as LabelMode[]).map(m => (
              <button
                key={m}
                onClick={() => setLabelMode(m)}
                className={`px-2 py-1 rounded-md font-bold ${labelMode === m ? 'bg-cyan-600 text-white' : 'text-slate-300 hover:text-white'}`}
              >
                {m === 'both' ? 'Song ngữ' : m === 'vi' ? 'Việt' : m === 'en' ? 'English' : 'Ẩn nhãn'}
              </button>
            ))}
          </div>
          <button onClick={() => setAutoRotate(a => !a)} className={`px-2 py-1.5 rounded-lg font-bold ${autoRotate ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-300'}`}>
            {autoRotate ? 'Đang xoay' : 'Tự xoay'}
          </button>
          <button
            onClick={() => {
              controlsRef.current?.reset?.();
              setResetKey(k => k + 1);
            }}
            className="px-2 py-1.5 rounded-lg font-bold bg-slate-800 text-slate-300 hover:text-white flex items-center gap-1"
          >
            <RotateCcw className="h-3 w-3" /> Góc nhìn
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-[1fr_340px] gap-3">
        {/* Canvas */}
        <div ref={hostRef} className="relative rounded-2xl overflow-hidden border border-slate-800 bg-[radial-gradient(ellipse_at_center,_#1e293b_0%,_#020617_75%)] h-[440px] sm:h-[520px]">
          <SceneCtx.Provider value={ctx}>
            {overlayReady && (
            <Canvas
              key={resetKey}
              dpr={[1, 1.75]}
              camera={{ position: def.camera || [0, 1.5, 7], fov: def.fov || 45 }}
              onPointerMissed={() => !quiz?.active && setSelected(null)}
            >
              <PortalCtx.Provider value={overlayRef}>
              <SceneCtx.Provider value={ctx}>
                <hemisphereLight args={['#e0f2fe', '#1e293b', 0.9]} />
                <directionalLight position={[5, 8, 5]} intensity={1.4} />
                <directionalLight position={[-6, -3, -4]} intensity={0.4} color="#a5b4fc" />
                <Suspense fallback={null}>
                  <def.Scene stage={stage} />
                </Suspense>
                <OrbitControls ref={controlsRef} makeDefault enablePan={false} autoRotate={autoRotate && !quiz?.active} autoRotateSpeed={0.6} minDistance={2} maxDistance={20} />
              </SceneCtx.Provider>
              </PortalCtx.Provider>
            </Canvas>
            )}
          </SceneCtx.Provider>

          <div className="absolute left-3 bottom-3 text-[10px] text-slate-400 flex items-center gap-1 bg-slate-950/70 px-2 py-1 rounded-lg pointer-events-none">
            <MousePointerClick className="h-3 w-3" /> Kéo để xoay · cuộn để phóng to · bấm vào bộ phận để xem chi tiết
          </div>

          {quiz?.active && quizTarget && (
            <div className="absolute top-3 left-1/2 -translate-x-1/2 w-[92%] max-w-md rounded-2xl bg-slate-950/90 border border-amber-500/60 p-3 text-center shadow-xl">
              <div className="text-[10px] font-bold text-amber-400 uppercase tracking-wider">
                Find the part · Câu {quiz.idx + 1}/{quiz.queue.length} · Đúng {quiz.correct}
              </div>
              <div className="flex items-center justify-center gap-2 mt-1">
                <span className="text-lg font-black text-white">{quizTarget.nameEn}</span>
                <button onClick={() => speakEnglish(quizTarget.nameEn)} className="p-1 rounded-md bg-amber-500 text-slate-950" title="Nghe lại">
                  <Volume2 className="h-3.5 w-3.5" />
                </button>
              </div>
              {quizTarget.ipa && <div className="text-[11px] font-mono text-slate-400">{quizTarget.ipa}</div>}
              {!quiz.feedback ? (
                <div className="text-[11px] text-slate-300 mt-1">Bấm vào bộ phận đúng trên mô hình 3D</div>
              ) : (
                <div className="mt-2 space-y-1.5">
                  <div className={`text-xs font-bold ${quiz.feedback.ok ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {quiz.feedback.ok ? 'Correct! Chính xác.' : `Chưa đúng – em chọn “${partsById[quiz.feedback.picked]?.nameVi || '?'}”. Bộ phận đúng đang phát sáng.`}
                  </div>
                  <div className="text-[11px] text-slate-300">{quizTarget.nameEn} = {quizTarget.nameVi}</div>
                  <button onClick={nextQuiz} className="px-3 py-1.5 rounded-lg bg-amber-500 text-slate-950 text-xs font-bold">
                    {quiz.idx + 1 >= quiz.queue.length ? 'Xem kết quả' : 'Tiếp →'}
                  </button>
                </div>
              )}
              <button onClick={() => setQuiz(null)} className="absolute top-2 right-2 text-slate-500 hover:text-white">
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          )}
        </div>

        {/* Side panel */}
        <div className="space-y-3">
          {stages.length > 0 && (
            <div className="rounded-2xl border border-slate-200 bg-white p-3 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-black text-slate-500 uppercase">Bước {stage + 1}/{stages.length}</span>
                <div className="flex items-center gap-1">
                  <button onClick={() => setStage(s => (s - 1 + stages.length) % stages.length)} className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200"><ChevronLeft className="h-3.5 w-3.5" /></button>
                  <button onClick={() => setPlaying(p => !p)} className={`p-1.5 rounded-lg ${playing ? 'bg-amber-500 text-white' : 'bg-sky-600 text-white'}`}>{playing ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}</button>
                  <button onClick={() => setStage(s => (s + 1) % stages.length)} className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200"><ChevronRight className="h-3.5 w-3.5" /></button>
                </div>
              </div>
              <div className="flex gap-1">
                {stages.map((_, i) => (
                  <button key={i} onClick={() => setStage(i)} className={`h-1.5 flex-1 rounded-full ${i === stage ? 'bg-sky-600' : i < stage ? 'bg-sky-300' : 'bg-slate-200'}`} />
                ))}
              </div>
              <div>
                <div className="text-sm font-extrabold text-slate-900">{stages[stage].titleVi}</div>
                <div className="text-[11px] font-bold text-sky-600 flex items-center gap-1">
                  {stages[stage].titleEn}
                  <button onClick={() => speakEnglish(stages[stage].titleEn)} className="text-sky-500 hover:text-sky-700"><Volume2 className="h-3 w-3" /></button>
                </div>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed">{stages[stage].descVi}</p>
                {stages[stage].descEn && <p className="text-[11px] text-slate-500 italic mt-1">{stages[stage].descEn}</p>}
              </div>
            </div>
          )}

          {selInfo && !quiz?.active ? (
            <div className="rounded-2xl border-2 bg-white p-3 space-y-2" style={{ borderColor: selInfo.color }}>
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="text-sm font-black text-slate-900">{selInfo.nameVi}</div>
                  <div className="text-xs font-bold text-sky-700">
                    {selInfo.nameEn} {selInfo.ipa && <span className="font-mono font-normal text-slate-500">{selInfo.ipa}</span>}
                  </div>
                </div>
                <button onClick={() => speakEnglish(selInfo.nameEn)} className="p-1.5 rounded-lg bg-sky-600 text-white shrink-0" title="Nghe phát âm">
                  <Volume2 className="h-3.5 w-3.5" />
                </button>
              </div>
              <p className="text-xs text-slate-700 leading-relaxed">{selInfo.descVi}</p>
              <div className="flex items-start gap-1.5 text-[11px] text-slate-600 italic bg-slate-50 rounded-lg p-2 border border-slate-200">
                <span className="flex-1">{selInfo.descEn}</span>
                <button onClick={() => speakEnglish(selInfo.descEn)} className="text-sky-600 not-italic"><Volume2 className="h-3 w-3" /></button>
              </div>
            </div>
          ) : (
            !quiz?.active && (
              <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-3 text-xs text-slate-500 flex items-start gap-2">
                <Info className="h-4 w-4 shrink-0 text-sky-500" />
                Bấm vào một bộ phận trên mô hình hoặc trong danh sách để xem mô tả song ngữ và nghe phát âm tiếng Anh.
              </div>
            )
          )}

          <div className="rounded-2xl border border-slate-200 bg-white p-3">
            <div className="text-[11px] font-black text-slate-500 uppercase mb-2">Bộ phận / Parts ({visibleParts.length})</div>
            <div className="max-h-[210px] overflow-y-auto space-y-1 pr-1">
              {visibleParts.map(p => (
                <button
                  key={p.id}
                  onClick={() => !quiz?.active && onPick(p.id)}
                  className={`w-full text-left px-2 py-1.5 rounded-lg text-xs flex items-center gap-2 ${selected === p.id ? 'bg-amber-50 ring-1 ring-amber-300' : 'hover:bg-slate-50'}`}
                >
                  <span className="h-2.5 w-2.5 rounded-full shrink-0" style={{ background: p.color }} />
                  <span className="font-bold text-slate-800">{quiz?.active ? '• • •' : p.nameVi}</span>
                  <span className="text-slate-400 truncate">{quiz?.active ? '' : p.nameEn}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="rounded-2xl border border-amber-200 bg-amber-50 p-3 space-y-2">
            <div className="flex items-center gap-1.5 text-xs font-black text-amber-800">
              <Target className="h-4 w-4" /> Thử thách 3D song ngữ
            </div>
            {quiz && !quiz.active ? (
              <div className="text-xs text-amber-900 flex items-center gap-2">
                <Trophy className="h-4 w-4 text-amber-600" /> Kết quả: {quiz.correct}/{quiz.queue.length} bộ phận đúng.
              </div>
            ) : (
              <p className="text-[11px] text-amber-900">Nghe tên tiếng Anh của một bộ phận, rồi bấm đúng bộ phận đó trên mô hình (nhãn sẽ được ẩn).</p>
            )}
            <button onClick={startQuiz} disabled={visibleParts.length < 2} className="w-full px-3 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black disabled:opacity-40">
              {quiz ? 'Chơi lại' : 'Bắt đầu: Find the part'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
