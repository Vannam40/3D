import type { ModelDef } from './engine';

/** Mỗi mô hình được tải khi cần (code-splitting) */
export const MODEL_REGISTRY: Record<string, () => Promise<{ default: ModelDef }>> = {
  m01_biology_fields: () => import('./models/m01_biology_fields'),
  m02_lab_methods: () => import('./models/m02_lab_methods'),
  m03_levels: () => import('./models/m03_levels'),
  m04_water: () => import('./models/m04_water'),
  m05_biomolecules: () => import('./models/m05_biomolecules'),
  m07_prokaryote: () => import('./models/m07_prokaryote'),
  m08_eukaryote: () => import('./models/m08_eukaryote'),
  m10_membrane_transport: () => import('./models/m10_membrane_transport'),
  m12_cell_signalling: () => import('./models/m12_cell_signalling'),
  m13_atp_enzyme: () => import('./models/m13_atp_enzyme'),
  m14_respiration_photosynthesis: () => import('./models/m14_respiration_photosynthesis'),
  m16_mitosis: () => import('./models/m16_mitosis'),
  m17_meiosis: () => import('./models/m17_meiosis'),
  m19_cell_technology: () => import('./models/m19_cell_technology'),
  m20_microbe_diversity: () => import('./models/m20_microbe_diversity'),
  m21_bacterial_growth: () => import('./models/m21_bacterial_growth'),
  m22_microbe_applications: () => import('./models/m22_microbe_applications'),
  m24_virus: () => import('./models/m24_virus'),
  m25_hiv_flu: () => import('./models/m25_hiv_flu'),
};

export const MODEL_IDS = Object.keys(MODEL_REGISTRY);
