import React, { useRef } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { ModelDef, Part, Label, M, Ball, Rod, Tube, Damp, Flow, Tag, Cyl, Bob } from '../engine';

type V3 = [number, number, number];

const parts: ModelDef['parts'] = [
  { id: 'direct', nameVi: 'Truyền tin trực tiếp', nameEn: 'Direct contact (gap junction)', ipa: '/dəˈrekt ˈkɒntækt/', color: '#38bdf8', stages: [0], descVi: 'Tín hiệu truyền trực tiếp giữa các tế bào liền kề qua mối liên kết hở.', descEn: 'Signals pass directly between neighbouring cells through gap junctions.' },
  { id: 'paracrine', nameVi: 'Truyền tin cận tiết', nameEn: 'Paracrine signalling', ipa: '/ˈpærəkrɪn ˈsɪɡnəlɪŋ/', color: '#a78bfa', stages: [0], descVi: 'Tế bào tiết phân tử tín hiệu truyền cho các tế bào lân cận.', descEn: 'A cell releases signals that act on nearby cells.' },
  { id: 'endocrine', nameVi: 'Truyền tin nội tiết', nameEn: 'Endocrine signalling', ipa: '/ˈendəʊkraɪn ˈsɪɡnəlɪŋ/', color: '#ef4444', stages: [0], descVi: 'Hormone được tiết vào máu, truyền tới các tế bào đích ở xa.', descEn: 'Hormones are released into the blood and reach distant target cells.' },
  { id: 'synapse', nameVi: 'Truyền tin qua synapse', nameEn: 'Synaptic signalling', ipa: '/sɪˈnæptɪk ˈsɪɡnəlɪŋ/', color: '#f59e0b', stages: [0], descVi: 'Chất dẫn truyền xung thần kinh được truyền qua khe synapse giữa tế bào thần kinh và tế bào đích.', descEn: 'Neurotransmitters cross the synapse between a nerve cell and its target cell.' },
  { id: 'signal', nameVi: 'Phân tử tín hiệu', nameEn: 'Signal molecule', ipa: '/ˈsɪɡnəl ˈmɒlɪkjuːl/', color: '#facc15', stages: [1, 2, 3], descVi: 'Chủ yếu là tín hiệu hoá học: amino acid, peptide, protein, nucleotide, hormone, thậm chí khí NO.', descEn: 'Mostly chemical signals: amino acids, peptides, proteins, nucleotides, hormones, even NO gas.' },
  { id: 'receptor', nameVi: 'Thụ thể', nameEn: 'Receptor', ipa: '/rɪˈseptə/', color: '#22c55e', stages: [1, 2, 3], descVi: 'Protein trên màng hoặc trong tế bào chất; liên kết với tín hiệu phù hợp như chìa khoá với ổ khoá rồi thay đổi cấu hình, chuyển sang trạng thái hoạt động.', descEn: 'A protein that binds a matching signal like a lock and key, then changes shape and becomes active.' },
  { id: 'relay', nameVi: 'Chuỗi protein truyền tin', nameEn: 'Relay molecules', ipa: '/ˈriːleɪ ˈmɒlɪkjuːlz/', color: '#38bdf8', stages: [2, 3], descVi: 'Thụ thể hoạt động lại hoạt hoá phân tử liền kề… cho tới phân tử đích cuối cùng – sự chuyển đổi tín hiệu trong tế bào.', descEn: 'The active receptor activates the next molecule, and so on, until the final target – signal transduction.' },
  { id: 'response', nameVi: 'Đáp ứng của tế bào', nameEn: 'Cellular response', ipa: '/ˈseljələ rɪˈspɒns/', color: '#f472b6', stages: [3], descVi: 'Đóng/mở gene (phiên mã, dịch mã), thay đổi chuyển hoá, hình dạng, vận động hoặc phân bào. Cùng một tín hiệu có thể gây đáp ứng khác nhau ở các tế bào khác nhau.', descEn: 'Turning genes on or off, changing metabolism, shape, movement or division; one signal can cause different responses.' },
  { id: 'membrane', nameVi: 'Màng tế bào đích', nameEn: 'Target cell membrane', ipa: '/ˈtɑːɡɪt sel ˈmembreɪn/', color: '#7dd3fc', stages: [1, 2, 3], descVi: 'Tế bào đích có thụ thể phù hợp mới tiếp nhận được tín hiệu.', descEn: 'Only a target cell with the right receptor can receive the signal.' },
];

const Cell: React.FC<{ p: V3; r?: number; c?: string }> = ({ p, r = 0.45, c = '#7dd3fc' }) => (
  <group position={p}>
    <Ball r={r} c={c} o={0.55} />
    <Ball r={r * 0.35} c="#4f46e5" />
  </group>
);

/** Phân tử truyền tin phát sáng theo nhịp */
const Pulse: React.FC<{ p: V3; i: number; on: boolean }> = ({ p, i, on }) => {
  const ref = useRef<THREE.MeshStandardMaterial>(null);
  useFrame(({ clock }) => {
    if (!ref.current) return;
    const t = clock.getElapsedTime() * 2.2 - i * 0.6;
    ref.current.emissiveIntensity = on ? 0.25 + Math.max(0, Math.sin(t)) * 1.2 : 0.05;
  });
  return (
    <mesh position={p}>
      <sphereGeometry args={[0.2, 20, 14]} />
      <meshStandardMaterial ref={ref} color="#38bdf8" emissive="#38bdf8" />
    </mesh>
  );
};

const RELAY: V3[] = [[0.1, 0.55, 0], [-0.25, 0.0, 0.1], [0.2, -0.5, 0], [-0.1, -1.0, 0.1]];

const Scene: ModelDef['Scene'] = ({ stage }) => {
  const overview = stage === 0;
  const docked = stage >= 1;
  return (
    <group>
      {/* Tổng quan 4 cách truyền tin */}
      <Damp s={overview ? 1 : 0}>
        <group position={[-3.1, 0.9, 0]}>
          <Part id="direct">
            <Cell p={[-0.45, 0, 0]} />
            <Cell p={[0.45, 0, 0]} />
            <Cyl rt={0.06} h={0.3} c="#38bdf8" rot={[0, 0, Math.PI / 2]} />
            <Flow path={[[-0.3, 0, 0], [0, 0, 0], [0.3, 0, 0]]} n={2} c="#fde047" r={0.05} speed={0.6} />
          </Part>
        </group>
        <group position={[-0.9, 0.9, 0]}>
          <Part id="paracrine">
            <Cell p={[0, 0, 0]} c="#c4b5fd" />
            <Cell p={[0.95, 0.35, 0]} />
            <Cell p={[0.95, -0.45, 0]} />
            <Flow path={[[0.3, 0.05, 0], [0.6, 0.2, 0], [0.75, 0.3, 0]]} n={3} c="#fde047" r={0.05} speed={0.5} />
            <Flow path={[[0.3, -0.1, 0], [0.6, -0.3, 0], [0.75, -0.4, 0]]} n={3} c="#fde047" r={0.05} speed={0.5} offset={0.4} />
          </Part>
        </group>
        <group position={[1.6, 0.9, 0]}>
          <Part id="endocrine">
            <Cell p={[-0.4, 0.55, 0]} c="#fca5a5" />
            <Tube pts={[[-0.9, 0, 0], [0, -0.1, 0], [0.9, 0, 0], [1.6, -0.3, 0]]} r={0.16} c="#ef4444" o={0.55} />
            <Flow path={[[-0.4, 0.2, 0], [-0.1, -0.05, 0], [0.9, 0, 0], [1.5, -0.25, 0]]} n={4} c="#fde047" r={0.06} speed={0.3} />
            <Cell p={[1.7, -0.8, 0]} />
          </Part>
        </group>
        <group position={[-1.0, -1.3, 0]}>
          <Part id="synapse">
            <Ball p={[-1.6, 0, 0]} r={0.4} c="#fbbf24" />
            <Tube pts={[[-1.2, 0, 0], [-0.4, 0.1, 0], [0.4, 0, 0]]} r={0.07} c="#f59e0b" />
            <Ball p={[0.55, 0, 0]} r={0.18} c="#f59e0b" />
            <Cell p={[1.35, 0, 0]} r={0.5} />
            <Flow path={[[0.7, 0, 0], [0.85, 0.02, 0], [0.95, 0, 0]]} n={3} c="#fde047" r={0.04} speed={0.8} />
          </Part>
        </group>
      </Damp>

      {/* Truyền tin trong tế bào */}
      <Damp s={overview ? 0 : 1}>
        <Part id="membrane">
          <mesh position={[0, -1.6, 0]} rotation={[0, 0, 0]}>
            <sphereGeometry args={[3.2, 48, 24, 0, Math.PI * 2, 0, 0.75]} />
            <M c="#7dd3fc" o={0.3} side={THREE.DoubleSide} />
          </mesh>
        </Part>
        <group position={[0, 1.6, 0]}>
          <Part id="receptor">
            <Cyl p={[0, -0.25, 0]} rt={0.14} h={0.9} c="#22c55e" />
            <Rod a={[0, 0.15, 0]} b={[-0.3, 0.55, 0]} r={0.09} c="#22c55e" />
            <Rod a={[0, 0.15, 0]} b={[0.3, 0.55, 0]} r={0.09} c="#22c55e" />
          </Part>
          <Part id="signal">
            <Damp to={docked ? [0, 0.45, 0] : [1.6, 1.6, 0]}>
              <Bob amp={docked ? 0 : 0.1}>
                <mesh>
                  <octahedronGeometry args={[0.2]} />
                  <M c="#facc15" e={0.4} />
                </mesh>
              </Bob>
            </Damp>
          </Part>
        </group>
        <Part id="relay">
          {RELAY.map((p, i) => (
            <Pulse key={i} p={p} i={i} on={stage >= 2} />
          ))}
          {RELAY.slice(0, -1).map((p, i) => (
            <Rod key={`r${i}`} a={p} b={RELAY[i + 1]} r={0.03} c="#7dd3fc" o={0.6} />
          ))}
        </Part>
        <Part id="response">
          <group position={[0, -2.0, 0]}>
            <Ball r={0.65} c="#6366f1" o={0.6} />
            <Bob amp={0.05} speed={4}>
              <Tube pts={[[-0.3, 0, 0.3], [-0.1, 0.15, 0.4], [0.1, -0.1, 0.35], [0.3, 0.05, 0.3]]} r={0.05} c="#f472b6" />
            </Bob>
            <Flow path={[[0.5, 0.3, 0.2], [1.1, 0.6, 0.2], [1.8, 0.9, 0.2]]} n={3} c="#f472b6" r={0.06} speed={0.35} />
          </group>
        </Part>
      </Damp>

      <Tag show={stage === 1} p={[1.4, 2.7, 0]} tone="amber">1. Tiếp nhận · Reception</Tag>
      <Tag show={stage === 2} p={[1.3, 0.1, 0]} tone="sky">2. Truyền tín hiệu · Transduction</Tag>
      <Tag show={stage === 3} p={[1.4, -1.5, 0]} tone="rose">3. Đáp ứng · Response</Tag>

      <Label id="direct" p={[-3.1, 1.6, 0]} />
      <Label id="paracrine" p={[-0.6, 1.75, 0]} />
      <Label id="endocrine" p={[1.9, 1.85, 0]} />
      <Label id="synapse" p={[-1.0, -0.65, 0]} />
      <Label id="signal" p={docked ? [-0.7, 2.2, 0] : [1.6, 3.6, 0]} />
      <Label id="receptor" p={[-0.9, 1.6, 0.2]} />
      <Label id="relay" p={[-1.0, -0.2, 0.2]} />
      <Label id="response" p={[-1.1, -2.2, 0.2]} />
      <Label id="membrane" p={[2.4, 1.05, 0]} />
    </group>
  );
};

const def: ModelDef = {
  id: 'm12_cell_signalling',
  titleVi: 'Truyền tin tế bào',
  titleEn: 'Cell signalling',
  source: 'SGK Sinh học 10 KNTT – Bài 12, tr. 73–76',
  parts,
  stages: [
    { titleVi: 'Bốn cách truyền tin giữa các tế bào', titleEn: 'Four types of cell-to-cell signalling', descVi: 'Truyền tin trực tiếp, cận tiết, nội tiết và qua synapse (Hình 12.1).', descEn: 'Direct contact, paracrine, endocrine and synaptic signalling.' },
    { titleVi: 'Tiếp nhận tín hiệu', titleEn: 'Reception', descVi: 'Phân tử tín hiệu liên kết vào protein thụ thể làm thụ thể thay đổi hình dạng.', descEn: 'A signal molecule binds to a receptor protein and changes its shape.' },
    { titleVi: 'Truyền tín hiệu', titleEn: 'Transduction', descVi: 'Chuỗi tương tác phân tử chuyển tiếp tín hiệu từ thụ thể tới các phân tử đích trong tế bào.', descEn: 'A chain of molecular interactions relays the signal from the receptor to target molecules.' },
    { titleVi: 'Đáp ứng', titleEn: 'Response', descVi: 'Tế bào phát tín hiệu điều khiển phiên mã, dịch mã hoặc điều hoà hoạt động của tế bào.', descEn: 'The cell controls transcription, translation or other activities.' },
  ],
  Scene,
  camera: [0, 0.6, 8],
  autoRotate: false,
};
export default def;
