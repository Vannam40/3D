import React, { useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { ModelDef, Part, Label, M, Ball, Rod, Tube, Damp, Caps, Tag, Arrow, Cyl, Flow } from '../engine';

type V3 = [number, number, number];

const parts: ModelDef['parts'] = [
  { id: 'fission', nameVi: 'Phân đôi', nameEn: 'Binary fission', ipa: '/ˈbaɪnəri ˈfɪʃn/', color: '#38bdf8', stages: [0], descVi: 'Hình thức sinh sản phổ biến nhất ở vi sinh vật: một tế bào mẹ phân chia thành hai tế bào con giống nhau. Vi khuẩn chỉ phân đôi vô tính.', descEn: 'The most common way microbes reproduce: one cell divides into two identical cells.' },
  { id: 'gen_time', nameVi: 'Thời gian thế hệ (g)', nameEn: 'Generation time (g)', ipa: '/ˌdʒenəˈreɪʃn taɪm/', color: '#fde047', stages: [0], descVi: 'Thời gian từ khi tế bào sinh ra đến khi phân chia (số tế bào tăng gấp đôi). E. coli g = 20 phút; Nₜ = N₀ × 2ⁿ.', descEn: 'The time for the cell number to double; for E. coli g = 20 min; Nt = N0 × 2ⁿ.' },
  { id: 'lag', nameVi: 'Pha tiềm phát', nameEn: 'Lag phase', ipa: '/læɡ feɪz/', color: '#94a3b8', stages: [1], descVi: 'Vi khuẩn thích nghi với môi trường, tổng hợp vật chất chuẩn bị phân chia; số lượng chưa tăng.', descEn: 'Bacteria adapt and prepare to divide; numbers do not increase yet.' },
  { id: 'log', nameVi: 'Pha luỹ thừa', nameEn: 'Log (exponential) phase', ipa: '/lɒɡ feɪz/', color: '#22c55e', stages: [1], descVi: 'Phân chia mạnh mẽ, số lượng tế bào tăng theo luỹ thừa, đạt cực đại cuối pha.', descEn: 'Cells divide rapidly and numbers rise exponentially.' },
  { id: 'stationary', nameVi: 'Pha cân bằng', nameEn: 'Stationary phase', ipa: '/ˈsteɪʃənri feɪz/', color: '#f59e0b', stages: [1], descVi: 'Dinh dưỡng giảm, chất độc tăng; số tế bào sinh ra bằng số tế bào chết đi.', descEn: 'Nutrients fall and toxins build up; new cells equal dying cells.' },
  { id: 'death', nameVi: 'Pha suy vong', nameEn: 'Death phase', ipa: '/deθ feɪz/', color: '#ef4444', stages: [1], descVi: 'Số lượng tế bào giảm dần do dinh dưỡng cạn kiệt, chất độc hại tích luỹ.', descEn: 'Cell numbers fall as nutrients run out and toxins accumulate.' },
  { id: 'continuous', nameVi: 'Nuôi cấy liên tục', nameEn: 'Continuous culture', ipa: '/kənˈtɪnjuəs ˈkʌltʃə/', color: '#0ea5e9', stages: [1], descVi: 'Thường xuyên bổ sung dinh dưỡng, loại bỏ sản phẩm → mật độ vi sinh vật giữ ở mức cân bằng, năng suất cao (sản xuất vitamin, enzyme, kháng sinh).', descEn: 'Nutrients are added and waste removed so the population stays at a productive level.' },
  { id: 'budding', nameVi: 'Nảy chồi (nấm men)', nameEn: 'Budding (yeast)', ipa: '/ˈbʌdɪŋ/', color: '#fde68a', stages: [2], descVi: 'Cá thể con hình thành ở một phía cá thể mẹ rồi tách ra; một cá thể mẹ có thể nảy nhiều chồi.', descEn: 'A new cell grows from one side of the parent and separates; one parent can form many buds.' },
  { id: 'spores', nameVi: 'Bào tử (vi nấm)', nameEn: 'Spores (mould)', ipa: '/spɔːz/', color: '#64748b', stages: [2], descVi: 'Nấm sinh sản bằng bào tử vô tính hoặc hữu tính (bào tử đính, bào tử tiếp hợp…).', descEn: 'Fungi reproduce by asexual or sexual spores.' },
  { id: 'endospore', nameVi: 'Nội bào tử (Bacillus)', nameEn: 'Endospore', ipa: '/ˈendəʊspɔː/', color: '#a855f7', stages: [2], descVi: 'Vỏ dày chứa calcium dipicolinate, giúp vi khuẩn sống tiềm sinh khi điều kiện bất lợi; KHÔNG phải hình thức sinh sản.', descEn: 'A thick-walled resistant form that helps bacteria survive harsh conditions; not a way of reproducing.' },
];

const Rod2: React.FC<{ p: V3; s?: number }> = ({ p, s = 1 }) => <Caps p={p} len={0.32 * s} r={0.11 * s} c="#38bdf8" rot={[0, 0, Math.PI / 2]} />;

/** Chồi lớn dần rồi tách */
const Bud: React.FC = () => {
  const ref = useRef<THREE.Group>(null);
  useFrame(({ clock }) => {
    const t = (clock.getElapsedTime() * 0.3) % 1;
    if (!ref.current) return;
    const s = 0.25 + t * 0.75;
    ref.current.scale.setScalar(s);
    ref.current.position.set(0.42 + t * 0.3, 0.42 + t * 0.25, 0);
  });
  return (
    <group ref={ref}>
      <Ball r={0.3} c="#fef3c7" />
    </group>
  );
};

const CURVE: V3[] = (() => {
  const out: V3[] = [];
  for (let i = 0; i <= 60; i++) {
    const x = i / 60;
    let y: number;
    if (x < 0.15) y = 0.08;
    else if (x < 0.5) y = 0.08 + Math.pow((x - 0.15) / 0.35, 2.2) * 0.82;
    else if (x < 0.75) y = 0.9 + Math.sin(((x - 0.5) / 0.25) * Math.PI) * 0.02;
    else y = 0.9 - ((x - 0.75) / 0.25) * 0.5;
    out.push([-3 + x * 6, -1.6 + y * 3.2, 0]);
  }
  return out;
})();
const seg = (a: number, b: number) => CURVE.slice(Math.round(a * 60), Math.round(b * 60) + 1);

const Scene: ModelDef['Scene'] = ({ stage }) => {
  const gens = useMemo(() => [1, 2, 4, 8].map((n, g) => Array.from({ length: n }, (_, i) => [-2.7 + g * 1.8, (i - (n - 1) / 2) * 0.42, 0] as V3)), []);
  return (
    <group>
      {/* Phân đôi */}
      <Damp s={stage === 0 ? 1 : 0}>
        <Part id="fission">
          {gens.map((g, gi) => g.map((p, i) => <Rod2 key={`${gi}-${i}`} p={p} />))}
          {gens.slice(0, -1).map((g, gi) =>
            g.map((p, i) => (
              <group key={`a${gi}${i}`}>
                <Rod a={[p[0] + 0.3, p[1], 0]} b={[gens[gi + 1][i * 2][0] - 0.3, gens[gi + 1][i * 2][1], 0]} r={0.012} c="#7dd3fc" o={0.6} />
                <Rod a={[p[0] + 0.3, p[1], 0]} b={[gens[gi + 1][i * 2 + 1][0] - 0.3, gens[gi + 1][i * 2 + 1][1], 0]} r={0.012} c="#7dd3fc" o={0.6} />
              </group>
            ))
          )}
        </Part>
        <Part id="gen_time">
          <Arrow a={[-3.0, -2.0, 0]} b={[3.0, -2.0, 0]} c="#fde047" r={0.025} />
          {[0, 1, 2, 3].map(g => <Ball key={g} p={[-2.7 + g * 1.8, -2.0, 0]} r={0.07} c="#fde047" />)}
        </Part>
      </Damp>

      {/* Đường cong sinh trưởng */}
      <Damp s={stage === 1 ? 1 : 0}>
        <Rod a={[-3.1, -1.65, 0]} b={[3.2, -1.65, 0]} r={0.02} c="#e2e8f0" />
        <Rod a={[-3.05, -1.7, 0]} b={[-3.05, 1.9, 0]} r={0.02} c="#e2e8f0" />
        <Part id="lag"><Tube pts={seg(0, 0.16)} r={0.07} c="#94a3b8" /></Part>
        <Part id="log"><Tube pts={seg(0.15, 0.51)} r={0.07} c="#22c55e" /></Part>
        <Part id="stationary"><Tube pts={seg(0.5, 0.76)} r={0.07} c="#f59e0b" /></Part>
        <Part id="death"><Tube pts={seg(0.75, 1)} r={0.07} c="#ef4444" /></Part>
        <Part id="continuous">
          <group position={[2.4, 2.3, 0]} scale={0.5}>
            <Cyl rt={0.7} h={1.4} c="#0ea5e9" o={0.35} />
            <Flow path={[[-1.6, 0.6, 0], [-0.8, 0.6, 0], [-0.3, 0.3, 0]]} n={3} c="#86efac" r={0.09} speed={0.4} />
            <Flow path={[[0.3, -0.3, 0], [0.9, -0.6, 0], [1.6, -0.6, 0]]} n={3} c="#fca5a5" r={0.09} speed={0.4} />
            {Array.from({ length: 10 }).map((_, i) => <Ball key={i} p={[Math.cos(i) * 0.4, -0.5 + (i % 5) * 0.22, Math.sin(i) * 0.4]} r={0.06} c="#38bdf8" />)}
          </group>
        </Part>
      </Damp>

      {/* Nảy chồi, bào tử, nội bào tử */}
      <Damp s={stage === 2 ? 1 : 0}>
        <group position={[-2.4, 0, 0]}>
          <Part id="budding">
            <Ball r={0.55} c="#fde68a" s={[1, 1.15, 1]} />
            <Bud />
          </Part>
        </group>
        <group position={[0, -0.3, 0]}>
          <Part id="spores">
            <Rod a={[0, -0.8, 0]} b={[0, 0.5, 0]} r={0.05} c="#cbd5e1" />
            {Array.from({ length: 10 }).map((_, i) => <Ball key={i} p={[Math.cos(i * 0.62) * 0.3, 0.7 + Math.sin(i * 0.62) * 0.2, Math.sin(i * 1.3) * 0.2]} r={0.1} c="#475569" />)}
          </Part>
        </group>
        <group position={[2.4, 0, 0]}>
          <Part id="endospore">
            <mesh rotation={[0, 0, Math.PI / 2]}>
              <capsuleGeometry args={[0.38, 1.0, 12, 20]} />
              <M c="#7dd3fc" o={0.35} />
            </mesh>
            <Ball p={[0.35, 0, 0]} r={0.22} c="#a855f7" s={[1.3, 1, 1]} />
          </Part>
        </group>
      </Damp>

      {[0, 1, 2, 3].map(g => (
        <Tag key={g} show={stage === 0} p={[-2.7 + g * 1.8, -2.35, 0]} tone="amber">{`${g * 20} phút · ${2 ** g} tế bào`}</Tag>
      ))}
      <Tag show={stage === 1} p={[0, -2.05, 0]} tone="slate">Thời gian · Time →</Tag>
      <Tag show={stage === 1} p={[-3.4, 2.1, 0]} tone="slate">Số tế bào · Cells</Tag>

      <Label id="fission" p={[0.0, 1.8, 0]} />
      <Label id="gen_time" p={[1.5, -1.6, 0]} />
      <Label id="lag" p={[-2.5, -0.95, 0]} />
      <Label id="log" p={[-0.9, 0.2, 0]} />
      <Label id="stationary" p={[0.9, 1.75, 0]} />
      <Label id="death" p={[2.6, 0.85, 0]} />
      <Label id="continuous" p={[2.4, 3.1, 0]} />
      <Label id="budding" p={[-2.4, 1.2, 0]} />
      <Label id="spores" p={[0, 1.15, 0]} />
      <Label id="endospore" p={[2.4, 0.8, 0]} />
    </group>
  );
};

const def: ModelDef = {
  id: 'm21_bacterial_growth',
  titleVi: 'Sinh trưởng và sinh sản của vi sinh vật',
  titleEn: 'Microbial growth and reproduction',
  source: 'SGK Sinh học 10 KNTT – Bài 21, tr. 122–130',
  parts,
  stages: [
    { titleVi: 'Phân đôi và thời gian thế hệ', titleEn: 'Binary fission and generation time', descVi: 'Sinh trưởng của quần thể vi khuẩn là sự tăng số lượng tế bào. Với E. coli (g = 20 phút): sau 60 phút từ 1 tế bào có 2³ = 8 tế bào.', descEn: 'Growth means more cells. For E. coli (g = 20 min), one cell becomes 2³ = 8 cells after 60 minutes.' },
    { titleVi: 'Đường cong sinh trưởng (nuôi cấy không liên tục)', titleEn: 'Growth curve (batch culture)', descVi: 'Bốn pha: tiềm phát → luỹ thừa → cân bằng → suy vong. Nuôi cấy liên tục giữ quần thể ở mức cân bằng cho năng suất cao.', descEn: 'Four phases: lag → log → stationary → death. Continuous culture keeps the population at a productive level.' },
    { titleVi: 'Nảy chồi, bào tử và nội bào tử', titleEn: 'Budding, spores and endospores', descVi: 'Ba hình thức sinh sản chính: phân đôi, bào tử, nảy chồi. Nội bào tử chỉ giúp vi khuẩn chống chịu, không phải sinh sản.', descEn: 'Three main ways: fission, spores and budding. Endospores help survival but are not reproduction.' },
  ],
  Scene,
  camera: [0, 0.3, 8],
  autoRotate: false,
};
export default def;
