import React from 'react';
import { ModelDef, Part, Label, Ball, Rod, Ring, Spin, Cyl, Caps, Tube, BoxM, Flow } from '../engine';

type V3 = [number, number, number];

const L = [
  { id: 'atom', vi: 'Nguyên tử', en: 'Atom', ipa: '/ˈætəm/', c: '#94a3b8', basic: false, dv: 'Cấp tổ chức trung gian nhỏ nhất; mọi vật sống và không sống đều cấu tạo từ nguyên tố hoá học.', de: 'The smallest intermediate level; all matter is made of chemical elements.' },
  { id: 'molecule', vi: 'Phân tử', en: 'Molecule', ipa: '/ˈmɒlɪkjuːl/', c: '#60a5fa', basic: false, dv: 'Cấp trung gian; các phân tử sinh học chỉ thể hiện đặc tính sống khi được tổ chức trong tế bào.', de: 'An intermediate level; biomolecules show life only when organised inside a cell.' },
  { id: 'organelle', vi: 'Bào quan', en: 'Organelle', ipa: '/ˌɔːɡəˈnel/', c: '#f87171', basic: false, dv: 'Cấp trung gian cấu thành nên tế bào (ví dụ ti thể).', de: 'An intermediate level that makes up the cell, e.g. a mitochondrion.' },
  { id: 'cell', vi: 'Tế bào', en: 'Cell', ipa: '/sel/', c: '#22d3ee', basic: true, dv: 'Cấp cơ bản – đơn vị tổ chức nhỏ nhất có đầy đủ các đặc điểm của sự sống.', de: 'A basic level – the smallest unit with all the characteristics of life.' },
  { id: 'tissue', vi: 'Mô', en: 'Tissue', ipa: '/ˈtɪʃuː/', c: '#f472b6', basic: false, dv: 'Cấp trung gian của cơ thể; gồm nhiều tế bào.', de: 'An intermediate level of the body made of many cells.' },
  { id: 'organ', vi: 'Cơ quan, hệ cơ quan', en: 'Organ & organ system', ipa: '/ˈɔːɡən/', c: '#fb7185', basic: false, dv: 'Bậc cấu trúc trung gian của cơ thể đa bào.', de: 'Intermediate levels of a multicellular body.' },
  { id: 'organism', vi: 'Cơ thể', en: 'Organism', ipa: '/ˈɔːɡənɪzəm/', c: '#22c55e', basic: true, dv: 'Cấp cơ bản; có các bậc trung gian là mô, cơ quan, hệ cơ quan.', de: 'A basic level with tissues, organs and organ systems inside.' },
  { id: 'population', vi: 'Quần thể', en: 'Population', ipa: '/ˌpɒpjuˈleɪʃn/', c: '#a3e635', basic: true, dv: 'Tập hợp các cá thể cùng loài sống trong một khu vực địa lí nhất định, vào thời điểm nhất định.', de: 'Individuals of one species living in one area at the same time.' },
  { id: 'community', vi: 'Quần xã', en: 'Community', ipa: '/kəˈmjuːnəti/', c: '#facc15', basic: true, dv: 'Các quần thể của nhiều loài khác nhau cùng tồn tại trong một khu vực ở cùng thời điểm.', de: 'Populations of different species living together in one area.' },
  { id: 'ecosystem', vi: 'Hệ sinh thái', en: 'Ecosystem', ipa: '/ˈiːkəʊsɪstəm/', c: '#34d399', basic: true, dv: 'Các quần xã tương tác với nhau và với môi trường. Năng lượng chủ yếu đến từ Mặt Trời.', de: 'Communities interacting with each other and the environment; energy comes mainly from the Sun.' },
];

const parts: ModelDef['parts'] = [
  ...L.map(l => ({ id: l.id, nameVi: l.vi, nameEn: l.en, ipa: l.ipa, color: l.c, descVi: `${l.basic ? '[Cấp cơ bản] ' : '[Cấp trung gian] '}${l.dv}`, descEn: l.de })),
  { id: 'sun', nameVi: 'Mặt Trời – nguồn năng lượng', nameEn: 'The Sun – energy source', ipa: '/sʌn/', color: '#fbbf24', descVi: 'Năng lượng cung cấp cho thế giới sống chủ yếu đến từ Mặt Trời và được truyền qua các cấp độ cùng với sự chuyển hoá vật chất.', descEn: 'Energy for the living world comes mainly from the Sun and flows through the levels with matter.' },
];

const pos = (i: number): V3 => {
  const t = i * 0.62;
  return [Math.cos(t) * 2.6, -2.2 + i * 0.5, Math.sin(t) * 2.6];
};

const Tree: React.FC<{ p?: V3; s?: number; c?: string }> = ({ p = [0, 0, 0], s = 1, c = '#22c55e' }) => (
  <group position={p} scale={s}>
    <Cyl p={[0, 0.15, 0]} rt={0.04} h={0.3} c="#92400e" />
    <mesh position={[0, 0.42, 0]}>
      <coneGeometry args={[0.18, 0.4, 10]} />
      <meshStandardMaterial color={c} />
    </mesh>
  </group>
);

const Icon: React.FC<{ id: string }> = ({ id }) => {
  switch (id) {
    case 'atom':
      return (
        <group>
          <Ball r={0.1} c="#f87171" />
          <Spin speed={2}><Ring R={0.28} r={0.012} c="#cbd5e1" rot={[1.2, 0, 0]} /><Ball p={[0.28, 0, 0]} r={0.04} c="#38bdf8" /></Spin>
          <Spin speed={-1.5}><Ring R={0.28} r={0.012} c="#cbd5e1" rot={[0.3, 1, 0]} /></Spin>
        </group>
      );
    case 'molecule':
      return (
        <group>
          <Ball r={0.15} c="#ef4444" />
          <Ball p={[0.18, 0.12, 0]} r={0.09} c="#f8fafc" />
          <Ball p={[-0.18, 0.12, 0]} r={0.09} c="#f8fafc" />
        </group>
      );
    case 'organelle':
      return (
        <group rotation={[0, 0, 0.5]}>
          <Caps len={0.3} r={0.13} c="#ef4444" rot={[0, 0, Math.PI / 2]} />
          <Tube pts={[[-0.2, 0.06, 0.05], [-0.1, -0.06, 0.08], [0, 0.06, 0.1], [0.1, -0.06, 0.08], [0.2, 0.06, 0.05]]} r={0.015} c="#fecaca" />
        </group>
      );
    case 'cell':
      return (
        <group>
          <Ball r={0.32} c="#22d3ee" o={0.45} />
          <Ball r={0.12} c="#4f46e5" />
        </group>
      );
    case 'tissue':
      return (
        <group>
          {[[-0.15, 0, 0], [0.15, 0, 0], [0, 0.15, 0], [0, -0.15, 0], [0, 0, 0.15]].map((p, i) => (
            <Ball key={i} p={p as V3} r={0.13} c="#f472b6" o={0.8} />
          ))}
        </group>
      );
    case 'organ':
      return (
        <group>
          <Ball p={[-0.09, 0.05, 0]} r={0.17} c="#e11d48" />
          <Ball p={[0.09, 0.05, 0]} r={0.17} c="#e11d48" />
          <mesh position={[0, -0.13, 0]} rotation={[Math.PI, 0, 0]}>
            <coneGeometry args={[0.24, 0.3, 16]} />
            <meshStandardMaterial color="#e11d48" />
          </mesh>
        </group>
      );
    case 'organism':
      return <Tree s={1.3} />;
    case 'population':
      return (
        <group>
          {[[-0.25, 0, 0], [0, 0, 0.15], [0.25, 0, -0.05], [0.05, 0, -0.25]].map((p, i) => (
            <Tree key={i} p={p as V3} s={0.8} />
          ))}
        </group>
      );
    case 'community':
      return (
        <group>
          <Tree p={[-0.25, 0, 0]} s={0.8} />
          <Tree p={[0.2, 0, 0.1]} s={0.6} c="#a3e635" />
          <Ball p={[0.05, 0.08, -0.2]} r={0.08} c="#f59e0b" />
          <Ball p={[0.28, 0.06, -0.2]} r={0.06} c="#78350f" />
        </group>
      );
    default:
      return (
        <group>
          <Cyl rt={0.42} h={0.06} c="#65a30d" />
          <Cyl p={[0.15, 0.04, 0.12]} rt={0.14} h={0.03} c="#0ea5e9" />
          <Tree p={[-0.18, 0.02, -0.05]} s={0.7} />
          <Tree p={[-0.02, 0.02, -0.22]} s={0.55} />
        </group>
      );
  }
};

const Scene: ModelDef['Scene'] = () => {
  const path = L.map((_, i) => pos(i));
  return (
    <group>
      <Tube pts={path} r={0.03} c="#475569" />
      <Flow path={path} n={8} c="#fde047" r={0.06} speed={0.08} />
      {L.map((l, i) => {
        const p = pos(i);
        return (
          <group key={l.id} position={p}>
            {l.basic && <Ring p={[0, -0.32, 0]} R={0.42} r={0.03} c="#fbbf24" rot={[Math.PI / 2, 0, 0]} />}
            <Part id={l.id}>
              <Icon id={l.id} />
            </Part>
          </group>
        );
      })}
      <group position={[0, 3.2, 0]}>
        <Part id="sun">
          <Ball r={0.45} c="#fbbf24" />
          <Spin speed={0.5}>
            {Array.from({ length: 10 }).map((_, i) => (
              <Rod key={i} a={[Math.cos(i * 0.63) * 0.55, 0, Math.sin(i * 0.63) * 0.55]} b={[Math.cos(i * 0.63) * 0.8, 0, Math.sin(i * 0.63) * 0.8]} r={0.025} c="#fde047" />
            ))}
          </Spin>
        </Part>
      </group>
      <Rod a={[0, 2.7, 0]} b={pos(9)} r={0.015} c="#fde047" o={0.5} />
      <BoxM p={[0, -2.75, 0]} s={[0.01, 0.01, 0.01]} c="#000" o={0} />
      {L.map((l, i) => {
        const p = pos(i);
        return <Label key={l.id} id={l.id} p={[p[0], p[1] + 0.55, p[2]]} />;
      })}
      <Label id="sun" p={[0, 3.85, 0]} />
    </group>
  );
};

const def: ModelDef = {
  id: 'm03_levels',
  titleVi: 'Các cấp độ tổ chức của thế giới sống',
  titleEn: 'Levels of organisation of the living world',
  source: 'SGK Sinh học 10 KNTT – Bài 3, tr. 18–22',
  parts,
  Scene,
  camera: [0, 1.2, 7.2],
  autoRotate: true,
};
export default def;
