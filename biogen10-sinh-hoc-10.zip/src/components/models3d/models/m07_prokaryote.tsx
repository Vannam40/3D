import React, { useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { ModelDef, Part, Label, M, Ball, Tube, Ring, Spin } from '../engine';

const parts: ModelDef['parts'] = [
  { id: 'flagellum', nameVi: 'Roi', nameEn: 'Flagellum', ipa: '/fləˈdʒeləm/', color: '#f59e0b', descVi: 'Cấu tạo từ bó sợi protein, là cơ quan vận động của tế bào; vi khuẩn có thể có một hoặc vài roi.', descEn: 'A bundle of protein fibres that moves the cell. A bacterium may have one or several flagella.' },
  { id: 'pili', nameVi: 'Lông', nameEn: 'Pili', ipa: '/ˈpaɪlaɪ/', color: '#fde047', descVi: 'Ngắn hơn nhưng nhiều hơn roi; giúp vi khuẩn bám dính, tiếp hợp hoặc bám vào bề mặt tế bào sinh vật khác.', descEn: 'Shorter and more numerous than flagella; they help bacteria attach to surfaces and to each other.' },
  { id: 'capsule', nameVi: 'Màng ngoài (vỏ nhầy)', nameEn: 'Outer layer', ipa: '/ˈaʊtə ˈleɪə/', color: '#a78bfa', descVi: 'Ở một số vi khuẩn, bao phủ thành tế bào, cấu tạo chủ yếu từ lipopolysaccharide; giúp vi khuẩn gây bệnh tránh tế bào bạch cầu.', descEn: 'In some bacteria it covers the cell wall; made mainly of lipopolysaccharide; protects pathogens from white blood cells.' },
  { id: 'wall', nameVi: 'Thành tế bào', nameEn: 'Cell wall', ipa: '/sel wɔːl/', color: '#22c55e', descVi: 'Dày 10–20 nm, cấu tạo bởi peptidoglycan; giữ ổn định hình dạng và bảo vệ tế bào. Gram dương thành dày, Gram âm thành mỏng.', descEn: '10–20 nm thick, made of peptidoglycan; keeps the cell shape and protects it.' },
  { id: 'membrane', nameVi: 'Màng tế bào', nameEn: 'Plasma membrane', ipa: '/ˈplæzmə ˈmembreɪn/', color: '#38bdf8', descVi: 'Lớp kép phospholipid và protein; trao đổi chất có chọn lọc, nơi diễn ra chuyển hoá vật chất và năng lượng.', descEn: 'A phospholipid bilayer with proteins; it controls exchange and is a site of energy metabolism.' },
  { id: 'cytoplasm', nameVi: 'Tế bào chất', nameEn: 'Cytoplasm', ipa: '/ˈsaɪtəʊplæzəm/', color: '#93c5fd', descVi: 'Bào tương dạng keo lỏng (chủ yếu là nước, chất hữu cơ, vô cơ), có hạt dự trữ và ribosome; nơi diễn ra phản ứng hoá sinh.', descEn: 'A jelly-like fluid with storage granules and ribosomes, where biochemical reactions take place.' },
  { id: 'nucleoid', nameVi: 'Vùng nhân', nameEn: 'Nucleoid', ipa: '/ˈnjuːkliɔɪd/', color: '#ef4444', descVi: 'Không có màng bao bọc, hầu hết chỉ chứa một phân tử DNA dạng vòng, mạch kép mang thông tin di truyền.', descEn: 'No membrane; contains one circular double-stranded DNA molecule that controls the cell.' },
  { id: 'plasmid', nameVi: 'Plasmid', nameEn: 'Plasmid', ipa: '/ˈplæzmɪd/', color: '#f472b6', descVi: 'DNA nhỏ dạng vòng, mạch kép; thường mang gene kháng kháng sinh; dùng làm vector trong kĩ thuật chuyển gene.', descEn: 'Small circular double-stranded DNA; often carries antibiotic-resistance genes; used as a vector in gene transfer.' },
  { id: 'ribosome', nameVi: 'Ribosome', nameEn: 'Ribosome', ipa: '/ˈraɪbəsəʊm/', color: '#e2e8f0', descVi: 'Bào quan duy nhất trong tế bào chất nhân sơ (10 000–100 000 hạt); nơi tổng hợp protein.', descEn: 'The only organelle in the prokaryotic cytoplasm; the site of protein synthesis.' },
];

/** Thân vi khuẩn hình que */
const Body: React.FC<{ len: number; r: number; c: string; o: number }> = ({ len, r, c, o }) => (
  <mesh rotation={[0, 0, Math.PI / 2]}>
    <capsuleGeometry args={[r, len, 16, 32]} />
    <M c={c} o={o} r={0.7} />
  </mesh>
);

const Flagellum: React.FC = () => {
  const ref = useRef<THREE.Group>(null);
  useFrame((_, dt) => {
    if (ref.current) ref.current.rotation.x += dt * 6;
  });
  const pts = useMemo(() => {
    const a: [number, number, number][] = [];
    for (let i = 0; i <= 40; i++) {
      const x = 2.15 + i * 0.07;
      a.push([x, Math.sin(i * 0.5) * 0.18, Math.cos(i * 0.5) * 0.18]);
    }
    return a;
  }, []);
  return (
    <group ref={ref}>
      <Tube pts={pts} r={0.035} c="#f59e0b" />
    </group>
  );
};

const Scene: ModelDef['Scene'] = () => {
  const ribos = useMemo(() => Array.from({ length: 70 }, () => [(Math.random() - 0.5) * 3, (Math.random() - 0.5) * 1.0, (Math.random() - 0.5) * 1.0] as [number, number, number]), []);
  const pili = useMemo(
    () =>
      Array.from({ length: 22 }, (_, i) => {
        const t = (i / 22) * Math.PI * 2;
        const x = -1.4 + (i % 7) * 0.45;
        const dir: [number, number, number] = [0, Math.cos(t), Math.sin(t)];
        return { a: [x, dir[1] * 0.95, dir[2] * 0.95] as [number, number, number], b: [x, dir[1] * 1.35, dir[2] * 1.35] as [number, number, number] };
      }),
    []
  );
  const dnaPts = useMemo(() => {
    const a: [number, number, number][] = [];
    for (let i = 0; i < 26; i++) {
      const t = (i / 26) * Math.PI * 2;
      a.push([Math.cos(t) * 0.9 + Math.sin(t * 5) * 0.2, Math.sin(t * 3) * 0.25, Math.sin(t) * 0.45 + Math.cos(t * 4) * 0.12]);
    }
    return a;
  }, []);
  return (
    <group rotation={[0.2, -0.4, 0]}>
      <Part id="capsule">
        <Body len={3.4} r={1.2} c="#a78bfa" o={0.12} />
      </Part>
      <Part id="wall">
        <mesh rotation={[0, 0, Math.PI / 2]}>
          <capsuleGeometry args={[1.05, 3.4, 16, 32]} />
          <M c="#22c55e" o={0.28} r={0.8} side={THREE.DoubleSide} />
        </mesh>
      </Part>
      <Part id="membrane">
        <mesh rotation={[0, 0, Math.PI / 2]}>
          <capsuleGeometry args={[0.95, 3.35, 16, 32]} />
          <M c="#38bdf8" o={0.22} side={THREE.DoubleSide} />
        </mesh>
      </Part>
      <Part id="cytoplasm">
        <mesh rotation={[0, 0, Math.PI / 2]}>
          <capsuleGeometry args={[0.88, 3.3, 12, 24]} />
          <M c="#93c5fd" o={0.12} />
        </mesh>
      </Part>
      <Part id="nucleoid">
        <Spin speed={0.15}>
          <Tube pts={dnaPts} r={0.04} c="#ef4444" closed />
        </Spin>
      </Part>
      <Part id="plasmid">
        <Ring p={[1.4, 0.35, 0.3]} R={0.18} r={0.03} c="#f472b6" rot={[0.6, 0.3, 0]} />
        <Ring p={[-1.5, -0.3, -0.25]} R={0.14} r={0.03} c="#f472b6" rot={[1.2, 0.2, 0.4]} />
        <Ring p={[1.0, -0.45, -0.35]} R={0.12} r={0.03} c="#f472b6" rot={[0.2, 1, 0]} />
      </Part>
      <Part id="ribosome">
        {ribos.map((p, i) => (
          <Ball key={i} p={p} r={0.045} c="#e2e8f0" seg={8} />
        ))}
      </Part>
      <Part id="pili">
        {pili.map((q, i) => (
          <mesh key={i} position={[(q.a[0] + q.b[0]) / 2, (q.a[1] + q.b[1]) / 2, (q.a[2] + q.b[2]) / 2]} rotation={[Math.atan2(q.a[2], q.a[1]), 0, 0]}>
            <cylinderGeometry args={[0.012, 0.012, 0.42, 6]} />
            <M c="#fde047" />
          </mesh>
        ))}
      </Part>
      <Part id="flagellum">
        <Flagellum />
      </Part>

      <Label id="flagellum" p={[4.3, 0.4, 0]} />
      <Label id="pili" p={[-0.5, 1.55, 0]} />
      <Label id="capsule" p={[-2.6, 1.15, 0.2]} />
      <Label id="wall" p={[-2.3, -1.15, 0.4]} />
      <Label id="membrane" p={[0.2, -1.0, 0.6]} />
      <Label id="cytoplasm" p={[-1.2, 0.5, 0.5]} />
      <Label id="nucleoid" p={[0, 0.35, 0.2]} />
      <Label id="plasmid" p={[1.45, 0.65, 0.3]} />
      <Label id="ribosome" p={[-1.0, -0.4, 0.4]} />
    </group>
  );
};

const def: ModelDef = {
  id: 'm07_prokaryote',
  titleVi: 'Tế bào nhân sơ (vi khuẩn)',
  titleEn: 'Prokaryotic cell (bacterium)',
  source: 'SGK Sinh học 10 KNTT – Bài 7, tr. 44–47',
  parts,
  Scene,
  camera: [0, 2, 7.5],
};
export default def;
