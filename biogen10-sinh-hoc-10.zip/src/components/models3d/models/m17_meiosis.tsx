import React, { useMemo } from 'react';
import * as THREE from 'three';
import { ModelDef, Part, Label, M, Damp, Rod, Tag, Bob } from '../engine';
import { Chromatid, MAT, PAT, MAT2, PAT2 } from './chromo';

type V3 = [number, number, number];

const parts: ModelDef['parts'] = [
  { id: 'membrane', nameVi: 'Màng tế bào', nameEn: 'Cell membrane', ipa: '/sel ˈmembreɪn/', color: '#38bdf8', descVi: 'Tế bào chất phân chia ở kì cuối I và kì cuối II, tạo tổng cộng 4 tế bào con.', descEn: 'The cytoplasm divides in telophase I and telophase II, giving four daughter cells in total.' },
  { id: 'nucleus_env', nameVi: 'Màng nhân', nameEn: 'Nuclear envelope', ipa: '/ˈnjuːkliə ˈenvələʊp/', color: '#818cf8', stages: [0, 1, 7], descVi: 'Tiêu biến ở kì đầu, xuất hiện lại khi hình thành nhân mới.', descEn: 'It breaks down in prophase and reforms around the new nuclei.' },
  { id: 'chromosome', nameVi: 'NST kép / NST đơn', nameEn: 'Chromosome', ipa: '/ˈkrəʊməsəʊm/', color: '#ef4444', descVi: 'Trước giảm phân I, mỗi NST nhân đôi thành NST kép. Giảm phân có hai lần phân bào nhưng chỉ một lần nhân đôi DNA. (Mô hình 2n = 4: đỏ/cam từ mẹ, xanh/tím từ bố.)', descEn: 'Before meiosis I each chromosome is copied. Meiosis has two divisions but only one round of DNA replication.' },
  { id: 'homolog', nameVi: 'Cặp NST tương đồng', nameEn: 'Homologous pair', ipa: '/həˈmɒləɡəs peə/', color: '#fbbf24', stages: [1, 2], descVi: 'Ở kì đầu I, các NST kép bắt đôi với nhau thành từng cặp tương đồng; ở kì giữa I các cặp xếp thành hai hàng ở mặt phẳng xích đạo.', descEn: 'In prophase I duplicated chromosomes pair up as homologous pairs; in metaphase I they line up in two rows.' },
  { id: 'crossover', nameVi: 'Trao đổi chéo', nameEn: 'Crossing over', ipa: '/ˈkrɒsɪŋ ˈəʊvə/', color: '#f472b6', stages: [1], descVi: 'Các chromatid không chị em trong cặp tương đồng có thể trao đổi đoạn với nhau ở kì đầu I → tạo tổ hợp gene mới.', descEn: 'Non-sister chromatids exchange segments in prophase I, creating new gene combinations.' },
  { id: 'spindle', nameVi: 'Thoi phân bào', nameEn: 'Spindle', ipa: '/ˈspɪndl/', color: '#cbd5e1', stages: [2, 3, 5, 6], descVi: 'Ở kì giữa I, vi ống đính vào một phía tâm động của mỗi NST kép; ở kì giữa II, vi ống gắn cả hai phía tâm động.', descEn: 'In metaphase I microtubules attach to one side of each centromere; in metaphase II to both sides.' },
  { id: 'gamete', nameVi: 'Tế bào con (n) → giao tử', nameEn: 'Haploid cells (gametes)', ipa: '/ˈhæplɔɪd selz/', color: '#34d399', stages: [7], descVi: 'Từ 1 tế bào tạo 4 tế bào con có số NST giảm một nửa (n), chứa tổ hợp NST khác nhau; sau đó biến đổi thành giao tử.', descEn: 'One cell gives four cells with half the chromosome number (n) and different combinations; they become gametes.' },
];

// c: 0 A mẹ, 1 A bố, 2 B mẹ, 3 B bố
const CH = [
  { len: 0.72, col: MAT, pair: 0 },
  { len: 0.72, col: PAT, pair: 0 },
  { len: 0.46, col: MAT2, pair: 1 },
  { len: 0.46, col: PAT2, pair: 1 },
];
const INTER: V3[] = [[-0.35, 0.3, 0.1], [0.3, 0.25, -0.15], [-0.2, -0.35, 0.2], [0.35, -0.3, -0.1]];
// sau kì đầu I: cặp A trao đổi chéo giữa chromatid trong (A mẹ s=1, A bố s=0)
function bottomColor(stage: number, c: number, s: number) {
  if (stage >= 1 && c === 0 && s === 1) return PAT;
  if (stage >= 1 && c === 1 && s === 0) return MAT;
  return CH[c].col;
}
// phía của mỗi NST ở giảm phân I (cặp B xếp ngược – phân li độc lập)
const SIDE = [-1, 1, 1, -1];
// tế bào con sau GP I: trái (x<0) chứa A mẹ + B bố, phải chứa A bố + B mẹ
const PAIR_Y = [0.55, 0.55, -0.55, -0.55];

function pos(stage: number, c: number, s: number): { to: V3; sc: number; tilt: number } {
  const sd = s === 0 ? -1 : 1;
  const side = SIDE[c];
  const cx = side * 2.6;
  const rowY = CH[c].pair === 0 ? 0.45 : -0.5; // vị trí trên hàng xích đạo ở GP II
  switch (stage) {
    case 0: return { to: [INTER[c][0] + sd * 0.04, INTER[c][1], INTER[c][2]], sc: 0.55, tilt: c };
    case 1: {
      const base = c % 2 === 0 ? -0.18 : 0.18;
      return { to: [base + sd * 0.085, CH[c].pair === 0 ? 0.6 : -0.65, 0], sc: 0.9, tilt: 0.25 };
    }
    case 2: return { to: [side * 0.26 + sd * 0.085, PAIR_Y[c], 0], sc: 1, tilt: 0 };
    case 3: return { to: [side * 1.55 + sd * 0.085, PAIR_Y[c] * 0.8, 0], sc: 1, tilt: side * 0.2 };
    case 4: return { to: [cx + sd * 0.085, PAIR_Y[c] * 0.7, 0], sc: 0.75, tilt: 0.5 };
    case 5: return { to: [cx + sd * 0.085, rowY, 0], sc: 0.85, tilt: 0 };
    case 6: return { to: [cx + sd * 0.8, rowY * 0.8, 0], sc: 0.85, tilt: sd * 0.2 };
    default: return { to: [cx + sd * 1.05, rowY * 0.5, 0], sc: 0.55, tilt: c * 0.8 };
  }
}

const Scene: ModelDef['Scene'] = ({ stage }) => {
  // 4 tế bào: vị trí theo bước
  const cells: { to: V3; s: number }[] = [0, 1, 2, 3].map(i => {
    const sx = i < 2 ? -1 : 1;
    const sd = i % 2 === 0 ? -1 : 1;
    if (stage <= 3) return { to: [0, 0, 0], s: 1 };
    if (stage <= 6) return { to: [sx * 2.6, 0, 0], s: 0.62 };
    return { to: [sx * 2.6 + sd * 1.05, 0, 0], s: 0.3 };
  });
  const nucS = stage === 0 ? 1 : stage === 1 ? 0.8 : stage === 7 ? 0.3 : 0;

  const fibres = useMemo(() => {
    const out: [V3, V3][] = [];
    if (stage === 2 || stage === 3) {
      for (let c = 0; c < 4; c++) for (let s = 0; s < 2; s++) out.push([[SIDE[c] * 2.3, 0, 0], pos(stage, c, s).to]);
    }
    if (stage === 5 || stage === 6) {
      for (let c = 0; c < 4; c++) for (let s = 0; s < 2; s++) {
        const cx = SIDE[c] * 2.6;
        out.push([[cx + (s === 0 ? -1.3 : 1.3), 0, 0], pos(stage, c, s).to]);
      }
    }
    return out;
  }, [stage]);

  return (
    <group>
      <Part id="membrane">
        {cells.map((c, i) => (
          <Damp key={i} to={c.to} s={c.s}>
            <mesh scale={[1.4, 1.05, 1.05]}>
              <sphereGeometry args={[2.2, 40, 28]} />
              <M c="#38bdf8" o={0.11} r={0.8} />
            </mesh>
          </Damp>
        ))}
      </Part>
      <Part id="gamete">
        {cells.map((c, i) => (
          <Damp key={i} to={c.to} s={stage === 7 ? 0.32 : 0}>
            <mesh>
              <sphereGeometry args={[2.0, 32, 24]} />
              <M c="#34d399" o={0.18} />
            </mesh>
          </Damp>
        ))}
      </Part>

      <Part id="nucleus_env">
        {cells.map((c, i) => (
          <Damp key={i} to={stage === 7 ? c.to : [0, 0, 0]} s={stage === 7 ? nucS : i === 0 ? nucS : 0}>
            <mesh>
              <sphereGeometry args={[1.3, 32, 24]} />
              <M c="#818cf8" o={0.2} side={THREE.DoubleSide} />
            </mesh>
          </Damp>
        ))}
      </Part>

      <Part id="chromosome">
        {CH.map((ch, c) =>
          [0, 1].map(s => {
            const p = pos(stage, c, s);
            return <Chromatid key={`${c}-${s}`} to={p.to} len={ch.len} top={ch.col} bottom={bottomColor(stage, c, s)} s={p.sc} tilt={p.tilt} />;
          })
        )}
      </Part>

      <Part id="homolog">
        {[0, 1].map(pair => {
          const a = pos(stage, pair * 2, 0).to;
          const b = pos(stage, pair * 2 + 1, 1).to;
          return (
            <mesh key={pair} position={[(a[0] + b[0]) / 2, (a[1] + b[1]) / 2, 0]} rotation={[0, 0, stage === 1 ? 0.25 : 0]}>
              <capsuleGeometry args={[0.38, pair === 0 ? 0.75 : 0.45, 8, 16]} />
              <M c="#fbbf24" o={0.16} />
            </mesh>
          );
        })}
      </Part>

      <Part id="crossover">
        <Bob amp={0.04} speed={3}>
          <mesh position={[0, 0.38, 0.12]}>
            <torusGeometry args={[0.13, 0.03, 8, 24]} />
            <M c="#f472b6" e={0.6} />
          </mesh>
        </Bob>
      </Part>

      <Part id="spindle">
        {fibres.map(([a, b], i) => (
          <Rod key={`${stage}-${i}`} a={a} b={b} r={0.01} c="#cbd5e1" o={0.7} />
        ))}
      </Part>

      <Tag show={stage === 2} p={[0, -1.6, 0]} tone="amber">Hai hàng · Two rows</Tag>
      <Tag show={stage === 5} p={[0, -1.9, 0]} tone="amber">Một hàng trong mỗi tế bào · One row</Tag>
      <Tag show={stage === 7} p={[0, -1.4, 0]} tone="emerald">2n = 4 → 4 tế bào n = 2</Tag>

      <Label id="membrane" p={[stage >= 4 ? 3.6 : 2.6, stage >= 4 ? 1.35 : 1.9, 0]} />
      <Label id="nucleus_env" p={stage === 7 ? [1.55, 0.95, 0] : [0, 1.45, 0.4]} />
      <Label id="chromosome" p={stage === 7 ? [-1.6, 1.0, 0.4] : stage >= 4 ? [-2.6, -1.3, 0.4] : [-0.9, -1.1, 0.4]} />
      <Label id="homolog" p={[-1.1, stage === 1 ? 1.0 : 0.95, 0.3]} />
      <Label id="crossover" p={[-0.6, 0.35, 0.3]} />
      <Label id="spindle" p={stage >= 5 ? [3.4, 0.9, 0.3] : [1.3, 0.75, 0.3]} />
      <Label id="gamete" p={[-3.65, -1.05, 0]} />
    </group>
  );
};

const def: ModelDef = {
  id: 'm17_meiosis',
  titleVi: 'Giảm phân (2n = 4)',
  titleEn: 'Meiosis (2n = 4)',
  source: 'SGK Sinh học 10 KNTT – Bài 17, tr. 104–107',
  parts,
  stages: [
    { titleVi: 'Kì trung gian', titleEn: 'Interphase', descVi: 'Trước khi bước vào giảm phân I, mỗi NST được nhân đôi tạo thành NST kép.', descEn: 'Before meiosis I, each chromosome is copied into a duplicated chromosome.' },
    { titleVi: 'Kì đầu I', titleEn: 'Prophase I', descVi: 'Các NST kép bắt đôi thành từng cặp tương đồng và dần co xoắn; các chromatid không chị em có thể trao đổi đoạn (trao đổi chéo); màng nhân, hạch nhân tiêu biến.', descEn: 'Homologous chromosomes pair up and condense; non-sister chromatids may cross over; the nuclear envelope breaks down.' },
    { titleVi: 'Kì giữa I', titleEn: 'Metaphase I', descVi: 'Các cặp NST kép tương đồng co xoắn cực đại, tập trung thành hai hàng ở mặt phẳng xích đạo; vi ống đính vào một phía tâm động.', descEn: 'Homologous pairs line up in two rows at the equator; microtubules attach to one side of each centromere.' },
    { titleVi: 'Kì sau I', titleEn: 'Anaphase I', descVi: 'Hai NST kép trong cặp tương đồng tách rời nhau, mỗi NST đi về một cực (phân li ngẫu nhiên, độc lập giữa các cặp).', descEn: 'The two chromosomes of each homologous pair separate and move to opposite poles.' },
    { titleVi: 'Kì cuối I', titleEn: 'Telophase I', descVi: 'NST dãn xoắn, thoi phân bào tiêu biến; tế bào chất phân chia tạo hai tế bào con có số NST kép giảm một nửa.', descEn: 'Two daughter cells form, each with half the number of duplicated chromosomes.' },
    { titleVi: 'Kì giữa II', titleEn: 'Metaphase II', descVi: 'Trong mỗi tế bào, các NST kép co xoắn cực đại, tập trung thành một hàng ở mặt phẳng xích đạo; vi ống gắn cả hai phía tâm động.', descEn: 'In each cell, chromosomes line up in one row; microtubules attach to both sides of each centromere.' },
    { titleVi: 'Kì sau II', titleEn: 'Anaphase II', descVi: 'Hai chromatid của mỗi NST kép tách rời nhau, di chuyển về hai cực của tế bào.', descEn: 'Sister chromatids separate and move to opposite poles.' },
    { titleVi: 'Kết quả: 4 tế bào n', titleEn: 'Result: four haploid cells', descVi: 'Từ 1 tế bào qua hai lần phân bào tạo 4 tế bào con có số NST giảm đi một nửa, chứa tổ hợp NST khác nhau (nhờ phân li ngẫu nhiên và trao đổi chéo).', descEn: 'One cell produces four cells with half the chromosome number and different combinations of chromosomes.' },
  ],
  Scene,
  camera: [0, 0.8, 10.5],
  autoRotate: false,
  stageInterval: 3200,
};
export default def;
