import React from 'react';
import { ModelDef, Part, Label, M, Ball, BoxM, Cyl, Rod, Ring, Spin, Arrow, Damp, Flow } from '../engine';

type V3 = [number, number, number];
const EQUIP = [0];
const PROC = [1];

const STEPS = [
  { id: 'observe', vi: 'Quan sát, thu thập dữ liệu', en: 'Observation', ipa: '/ˌɒbzəˈveɪʃn/', c: '#38bdf8', dv: 'Mọi nghiên cứu đều bắt đầu từ quan sát để thu thập dữ liệu; cần kiên trì, thận trọng, dùng công cụ thích hợp.', de: 'Every study begins with observation to collect data, using suitable tools patiently and carefully.' },
  { id: 'question', vi: 'Đặt câu hỏi', en: 'Asking questions', ipa: '/ˈɑːskɪŋ ˈkwestʃənz/', c: '#22d3ee', dv: 'Sau khi thu được số liệu, nhà khoa học đặt câu hỏi và tìm cách lí giải.', de: 'After collecting data, scientists ask questions and try to explain them.' },
  { id: 'hypothesis', vi: 'Hình thành giả thuyết', en: 'Forming a hypothesis', ipa: '/haɪˈpɒθəsɪs/', c: '#a78bfa', dv: 'Giả thuyết khoa học là cách giải thích có thể kiểm chứng bằng thực nghiệm; dùng suy luận diễn giải đưa ra dự đoán "nếu… thì…".', de: 'A hypothesis is a testable explanation; deduction gives "if… then…" predictions.' },
  { id: 'experiment', vi: 'Thiết kế và tiến hành thí nghiệm kiểm chứng', en: 'Testing with experiments', ipa: '/ɪkˈsperɪmənt/', c: '#f59e0b', dv: 'Gồm lô đối chứng và lô thí nghiệm; mọi yếu tố giống nhau trừ yếu tố cần nghiên cứu.', de: 'A control group and an experimental group that differ only in the factor being studied.' },
  { id: 'analyse', vi: 'Phân tích kết quả', en: 'Analysing results', ipa: '/ˈænəlaɪzɪŋ rɪˈzʌlts/', c: '#f472b6', dv: 'Trình bày dữ liệu bằng bảng, đồ thị; trục hoành – biến độc lập, trục tung – biến phụ thuộc; dùng thống kê.', de: 'Data are shown in tables and graphs; the x-axis is the independent variable, the y-axis the dependent one.' },
  { id: 'conclude', vi: 'Rút ra kết luận', en: 'Drawing conclusions', ipa: '/ˈdrɔːɪŋ kənˈkluːʒnz/', c: '#22c55e', dv: 'Chấp nhận hoặc bác bỏ giả thuyết; giả thuyết được kiểm nghiệm rộng rãi, được thừa nhận thì thành học thuyết.', de: 'Accept or reject the hypothesis; a widely tested and accepted one becomes a theory.' },
];

const parts: ModelDef['parts'] = [
  { id: 'microscope', nameVi: 'Kính hiển vi quang học', nameEn: 'Light microscope', ipa: '/laɪt ˈmaɪkrəskəʊp/', color: '#e2e8f0', stages: EQUIP, descVi: 'Dùng nguồn sáng điện hay ánh sáng mặt trời; phóng đại tối đa 1 500 lần, độ phân giải khoảng 200 nm. (Kính hiển vi điện tử dùng chùm electron, phóng đại tới 50 triệu lần.)', descEn: 'Uses electric light or sunlight; up to 1,500× magnification and about 200 nm resolution.' },
  { id: 'objective', nameVi: 'Vật kính', nameEn: 'Objective lens', ipa: '/əbˈdʒektɪv lenz/', color: '#fbbf24', stages: EQUIP, descVi: 'Thấu kính gần mẫu vật (10x, 40x, 100x); khi quan sát dùng vật kính nhỏ trước rồi mới chuyển sang lớn.', descEn: 'The lens near the specimen (10×, 40×, 100×); start with low power, then switch to high power.' },
  { id: 'stage', nameVi: 'Bàn kính', nameEn: 'Stage', ipa: '/steɪdʒ/', color: '#64748b', stages: EQUIP, descVi: 'Nơi đặt tiêu bản (lam kính) để quan sát.', descEn: 'Where the slide is placed for observation.' },
  { id: 'slide', nameVi: 'Tiêu bản (lam kính)', nameEn: 'Slide', ipa: '/slaɪd/', color: '#7dd3fc', stages: EQUIP, descVi: 'Mẫu mô cắt lát đủ mỏng hoặc tiêu bản tươi NST (cố định, nhuộm, dầm ép) để quan sát dưới kính hiển vi.', descEn: 'A thin section or squash preparation placed on glass for viewing under the microscope.' },
  { id: 'centrifuge', nameVi: 'Máy li tâm', nameEn: 'Centrifuge', ipa: '/ˈsentrɪfjuːdʒ/', color: '#38bdf8', stages: EQUIP, descVi: 'Dùng trong kĩ thuật phân đoạn tế bào: lực li tâm ở các tốc độ khác nhau tách các bào quan theo khối lượng.', descEn: 'Used in cell fractionation: spinning at different speeds separates organelles by mass.' },
  { id: 'pipette', nameVi: 'Pipet (ống hút)', nameEn: 'Pipette', ipa: '/pɪˈpet/', color: '#f472b6', stages: EQUIP, descVi: 'Ống hút, có loại điều chỉnh định lượng dung dịch cần lấy rất chính xác.', descEn: 'A dropper; some types measure liquid volumes very precisely.' },
  { id: 'magnifier', nameVi: 'Kính lúp', nameEn: 'Magnifying glass', ipa: '/ˈmæɡnɪfaɪɪŋ ɡlɑːs/', color: '#a3e635', stages: EQUIP, descVi: 'Thiết bị đơn giản giúp quan sát vật nhỏ.', descEn: 'A simple tool for looking at small objects.' },
  ...STEPS.map(s => ({ id: s.id, nameVi: s.vi, nameEn: s.en, ipa: s.ipa, color: s.c, stages: PROC, descVi: s.dv, descEn: s.de })),
];

const Microscope: React.FC = () => (
  <group position={[-1.6, 0, 0]} scale={1.35}>
    <Part id="microscope">
      <BoxM p={[0, 0.08, 0]} s={[1.1, 0.16, 0.8]} c="#e2e8f0" />
      <Rod a={[-0.3, 0.15, -0.2]} b={[-0.3, 1.6, -0.2]} r={0.09} c="#cbd5e1" />
      <Rod a={[-0.3, 1.6, -0.2]} b={[0.05, 1.9, -0.1]} r={0.08} c="#cbd5e1" />
      <Cyl p={[0.08, 2.15, -0.05]} rt={0.09} h={0.5} c="#94a3b8" rot={[0, 0, -0.35]} />
      <Cyl p={[0.18, 1.62, 0]} rt={0.15} h={0.35} c="#cbd5e1" />
      <Ball p={[0.15, 0.35, 0]} r={0.12} c="#fef08a" />
    </Part>
    <Part id="objective">
      <Cyl p={[0.12, 1.33, 0.08]} rt={0.05} h={0.3} c="#fbbf24" rot={[0.25, 0, 0]} />
      <Cyl p={[0.28, 1.33, -0.04]} rt={0.05} h={0.26} c="#f59e0b" rot={[0, 0, -0.25]} />
      <Cyl p={[0.05, 1.33, -0.12]} rt={0.05} h={0.22} c="#d97706" rot={[-0.25, 0, 0]} />
    </Part>
    <Part id="stage">
      <BoxM p={[0.18, 0.95, 0]} s={[0.8, 0.06, 0.6]} c="#64748b" />
    </Part>
    <Part id="slide">
      <BoxM p={[0.18, 0.995, 0]} s={[0.55, 0.02, 0.18]} c="#7dd3fc" o={0.8} />
      <Ball p={[0.18, 1.01, 0]} r={0.04} c="#ef4444" s={[1, 0.3, 1]} />
    </Part>
  </group>
);

const Centrifuge: React.FC = () => (
  <group position={[0.9, 0, 0.2]}>
    <Part id="centrifuge">
      <Cyl p={[0, 0.3, 0]} rt={0.55} h={0.6} c="#0ea5e9" />
      <Cyl p={[0, 0.62, 0]} rt={0.5} h={0.04} c="#bae6fd" o={0.6} />
      <Spin speed={6} position={[0, 0.66, 0]}>
        {[0, 1, 2, 3].map(i => (
          <Cyl key={i} p={[Math.cos((i * Math.PI) / 2) * 0.3, 0.1, Math.sin((i * Math.PI) / 2) * 0.3]} rt={0.05} h={0.25} c="#f8fafc" />
        ))}
      </Spin>
    </Part>
  </group>
);

const Scene: ModelDef['Scene'] = ({ stage }) => (
  <group position={[0, -0.9, 0]}>
    {/* Bàn thí nghiệm */}
    <Damp s={stage === 0 ? 1 : 0}>
      <BoxM p={[0, -0.1, 0]} s={[5.2, 0.2, 2.2]} c="#334155" />
      <Microscope />
      <Centrifuge />
      <group position={[2.0, 0, -0.4]}>
        <Part id="pipette">
          <Cyl p={[0, 0.6, 0]} rt={0.05} rb={0.015} h={1.0} c="#f9a8d4" o={0.8} rot={[0, 0, 0.3]} />
          <Ball p={[-0.17, 1.1, 0]} r={0.09} c="#f472b6" />
        </Part>
      </group>
      <group position={[2.0, 0.08, 0.6]}>
        <Part id="magnifier">
          <Ring p={[0, 0.25, 0]} R={0.22} r={0.04} c="#a3e635" rot={[Math.PI / 2 - 0.3, 0, 0]} />
          <Cyl p={[0, 0.25, 0]} rt={0.21} h={0.02} c="#e0f2fe" o={0.45} rot={[-0.3, 0, 0]} />
          <Rod a={[0.15, 0.08, 0.15]} b={[0.45, -0.05, 0.45]} r={0.04} c="#3f6212" />
        </Part>
      </group>
    </Damp>

    {/* Quy trình nghiên cứu: bậc thang */}
    <Damp s={stage === 1 ? 1 : 0} to={[0, 0.2, 0]}>
      {STEPS.map((s, i) => {
        const p: V3 = [-2.5 + i * 1.0, i * 0.35, 0];
        return (
          <group key={s.id}>
            <Part id={s.id}>
              <BoxM p={[p[0], p[1] / 2, 0]} s={[0.85, p[1] + 0.2, 0.9]} c={s.c} />
              <Ball p={[p[0], p[1] + 0.25, 0]} r={0.14} c="#f8fafc" />
            </Part>
            {i < STEPS.length - 1 && <Arrow a={[p[0] + 0.2, p[1] + 0.55, 0]} b={[p[0] + 0.8, p[1] + 0.9, 0]} c="#fde68a" r={0.025} />}
          </group>
        );
      })}
      <Flow path={[[-2.5, 0.6, 0.6], [-0.5, 1.3, 0.6], [1.5, 2.0, 0.6], [2.5, 2.4, 0.6]]} n={5} c="#fde047" r={0.06} speed={0.18} />
    </Damp>

    <Label id="microscope" p={[-2.4, 3.3, 0]} />
    <Label id="objective" p={[-0.9, 1.85, 0.4]} />
    <Label id="stage" p={[-2.1, 1.25, 0.6]} />
    <Label id="slide" p={[-1.0, 1.4, 0.7]} />
    <Label id="centrifuge" p={[0.9, 1.25, 0.2]} />
    <Label id="pipette" p={[2.0, 1.55, -0.4]} />
    <Label id="magnifier" p={[2.2, 0.75, 0.9]} />
    {STEPS.map((s, i) => (
      <Label key={s.id} id={s.id} p={[-2.5 + i * 1.0, 0.2 + i * 0.35 + 0.75, 0.5]} />
    ))}
  </group>
);

const def: ModelDef = {
  id: 'm02_lab_methods',
  titleVi: 'Thiết bị và quy trình nghiên cứu sinh học',
  titleEn: 'Laboratory equipment and the scientific method',
  source: 'SGK Sinh học 10 KNTT – Bài 2, tr. 12–17',
  parts,
  stages: [
    { titleVi: 'Thiết bị nghiên cứu và học tập', titleEn: 'Research equipment', descVi: 'Kính hiển vi (quang học, điện tử), máy li tâm, kính lúp, pipet… Cần hiểu rõ cấu trúc, cách vận hành để tránh hư hỏng và đảm bảo an toàn.', descEn: 'Microscopes, centrifuges, magnifying glasses and pipettes; learn how to operate them safely.' },
    { titleVi: 'Quy trình nghiên cứu khoa học', titleEn: 'The scientific method', descVi: 'Quan sát → Đặt câu hỏi → Hình thành giả thuyết → Thí nghiệm kiểm chứng → Phân tích kết quả → Rút ra kết luận.', descEn: 'Observe → Ask questions → Form a hypothesis → Test with experiments → Analyse results → Draw conclusions.' },
  ],
  Scene,
  camera: [0, 2.2, 7.5],
  autoRotate: false,
};
export default def;
