import React from 'react';
import * as THREE from 'three';
import { ModelDef, Part, Label, M, Ball, Rod, Cyl, Flow, Bob, BoxM, Spin, Tube, Tag, Ring } from '../engine';

type V3 = [number, number, number];

const parts: ModelDef['parts'] = [
  { id: 'fermenter', nameVi: 'Bình lên men (công nghệ lên men)', nameEn: 'Fermenter', ipa: '/fəˈmentə/', color: '#0ea5e9', descVi: 'Công nghệ lên men và công nghệ thu hồi sản phẩm là then chốt của công nghệ vi sinh vật: nuôi vi sinh vật trong bình lên men để thu sinh khối, kháng sinh, vaccine, enzyme…', descEn: 'Fermentation and product-recovery technologies are key: microbes are grown in fermenters to make antibiotics, vaccines and enzymes.' },
  { id: 'yeast', nameVi: 'Nấm men – bánh mì, bia, rượu', nameEn: 'Yeast – bread, beer, wine', ipa: '/jiːst/', color: '#fde68a', descVi: 'Saccharomyces cerevisiae lên men ethanol: tinh bột → glucose → ethanol + CO₂.', descEn: 'Saccharomyces cerevisiae carries out ethanol fermentation: glucose → ethanol + CO₂.' },
  { id: 'lactic', nameVi: 'Vi khuẩn lactic – sữa chua', nameEn: 'Lactic acid bacteria – yogurt', ipa: '/ˈlæktɪk ˈæsɪd bækˈtɪəriə/', color: '#f8fafc', descVi: 'Vi khuẩn lactic lên men glucose thành lactic acid → sữa chua, pho mát, dưa chua.', descEn: 'Lactic acid bacteria turn glucose into lactic acid → yogurt, cheese and pickles.' },
  { id: 'soy', nameVi: 'Nấm mốc tương – nước tương, nước mắm', nameEn: 'Koji mould – soy sauce, fish sauce', ipa: '/ˈkəʊdʒi məʊld/', color: '#92400e', descVi: 'Khả năng phân giải ngoại bào của vi sinh vật (VD Aspergillus oryzae) được dùng sản xuất nước tương, xì dầu, nước mắm.', descEn: 'Microbes that digest food outside their cells (e.g. Aspergillus oryzae) are used to make soy and fish sauce.' },
  { id: 'medicine', nameVi: 'Y dược: kháng sinh, vaccine, insulin', nameEn: 'Medicine: antibiotics, vaccines, insulin', ipa: '/ˈmedsn/', color: '#f43f5e', descVi: 'Sản xuất kháng sinh, vaccine, amino acid, hormone, probiotics; insulin, interferon từ vi khuẩn, nấm men tái tổ hợp; chẩn đoán bằng PCR.', descEn: 'Antibiotics, vaccines, hormones and probiotics; insulin and interferon from recombinant microbes.' },
  { id: 'farming', nameVi: 'Nông nghiệp: phân bón, thuốc trừ sâu vi sinh', nameEn: 'Farming: biofertilisers, biopesticides', ipa: '/ˌbaɪəʊˈfɜːtəlaɪzəz/', color: '#22c55e', descVi: 'Vi sinh vật cố định N₂, chuyển lân khó tiêu thành dễ tiêu, phân giải mùn → phân bón vi sinh; ức chế sâu bệnh → thuốc trừ sâu vi sinh.', descEn: 'Microbes fix nitrogen, release phosphorus and humus nutrients, and control pests.' },
  { id: 'biogas', nameVi: 'Hầm biogas', nameEn: 'Biogas digester', ipa: '/ˈbaɪəʊɡæs/', color: '#a3e635', descVi: 'Chất thải chăn nuôi được Archaea sinh methane phân giải trong bể kín tạo khí biogas làm chất đốt.', descEn: 'Methane-producing archaea break down manure in a closed tank to make biogas fuel.' },
  { id: 'wastewater', nameVi: 'Xử lí nước thải, tràn dầu', nameEn: 'Wastewater & oil-spill treatment', ipa: '/ˈweɪstwɔːtə ˈtriːtmənt/', color: '#38bdf8', descVi: 'Bể hiếu khí, thiếu khí, kị khí với hệ vi sinh vật riêng chuyển chất thải thành CH₄, CO₂; vi khuẩn Alcanivorax borkumensis "ăn" dầu.', descEn: 'Aerobic and anaerobic tanks convert waste into CH₄ and CO₂; Alcanivorax borkumensis breaks down oil.' },
];

const Microbe: React.FC<{ p: V3; c: string; rod?: boolean }> = ({ p, c, rod }) =>
  rod ? (
    <mesh position={p} rotation={[0, 0, 1]}>
      <capsuleGeometry args={[0.05, 0.12, 4, 8]} />
      <M c={c} />
    </mesh>
  ) : (
    <Ball p={p} r={0.07} c={c} seg={10} />
  );

const R = 3.0;
const ring = (i: number, n: number, y = -0.6): V3 => [Math.cos((i / n) * Math.PI * 2 + 0.3) * R, y, Math.sin((i / n) * Math.PI * 2 + 0.3) * R];

const Scene: ModelDef['Scene'] = () => (
  <group>
    {/* Bình lên men trung tâm */}
    <Part id="fermenter">
      <Cyl p={[0, 0.2, 0]} rt={0.9} h={2.2} c="#0ea5e9" o={0.28} />
      <Cyl p={[0, 1.35, 0]} rt={0.92} h={0.12} c="#94a3b8" />
      <Cyl p={[0, -0.92, 0]} rt={0.92} h={0.12} c="#94a3b8" />
      <Spin speed={2} position={[0, 0.2, 0]}>
        <Rod a={[0, -0.8, 0]} b={[0, 1.2, 0]} r={0.03} c="#cbd5e1" />
        <BoxM p={[0, -0.4, 0]} s={[1.1, 0.06, 0.12]} c="#cbd5e1" />
        <BoxM p={[0, 0.4, 0]} s={[1.1, 0.06, 0.12]} c="#cbd5e1" />
      </Spin>
      {Array.from({ length: 30 }).map((_, i) => (
        <Bob key={i} amp={0.05} speed={1 + (i % 5) * 0.3} phase={i}>
          <Microbe p={[Math.cos(i * 1.7) * 0.6, -0.7 + (i % 10) * 0.18, Math.sin(i * 1.7) * 0.6]} c={i % 2 ? '#fde68a' : '#f8fafc'} rod={i % 3 === 0} />
        </Bob>
      ))}
      <Flow path={[[0.3, -0.8, 0.2], [0.35, 0.2, 0.25], [0.3, 1.2, 0.2], [0.4, 2.0, 0.2]]} n={6} c="#e0f2fe" r={0.05} speed={0.35} />
    </Part>

    {/* Các ứng dụng xung quanh */}
    <group position={ring(0, 7)}>
      <Part id="yeast">
        <Ball p={[0, 0, 0]} r={0.35} c="#d97706" s={[1.5, 0.8, 0.9]} />
        <Ball p={[0, 0.15, 0]} r={0.3} c="#f59e0b" s={[1.4, 0.6, 0.85]} />
        <Cyl p={[0.75, 0.15, 0]} rt={0.14} rb={0.17} h={0.7} c="#78350f" o={0.85} />
        <Cyl p={[0.75, 0.62, 0]} rt={0.05} h={0.25} c="#78350f" />
      </Part>
    </group>
    <group position={ring(1, 7)}>
      <Part id="lactic">
        <Cyl rt={0.3} h={0.6} c="#f8fafc" o={0.9} />
        <Cyl p={[0, 0.33, 0]} rt={0.31} h={0.06} c="#38bdf8" />
        <Cyl p={[0.7, -0.05, 0]} rt={0.3} h={0.5} c="#bef264" o={0.7} />
      </Part>
    </group>
    <group position={ring(2, 7)}>
      <Part id="soy">
        <Cyl rt={0.16} h={0.8} c="#451a03" o={0.9} />
        <Cyl p={[0, 0.5, 0]} rt={0.06} h={0.25} c="#dc2626" />
        <Cyl p={[0.45, -0.1, 0]} rt={0.13} h={0.6} c="#b45309" o={0.85} />
      </Part>
    </group>
    <group position={ring(3, 7)}>
      <Part id="medicine">
        <mesh rotation={[0, 0, 0.7]}>
          <capsuleGeometry args={[0.13, 0.35, 8, 16]} />
          <M c="#f43f5e" />
        </mesh>
        <Cyl p={[0.45, 0, 0]} rt={0.05} h={0.7} c="#e2e8f0" o={0.8} rot={[0, 0, -0.5]} />
        <Cyl p={[0.6, -0.3, 0]} rt={0.012} h={0.3} c="#94a3b8" rot={[0, 0, -0.5]} />
      </Part>
    </group>
    <group position={ring(4, 7)}>
      <Part id="farming">
        <BoxM p={[0, -0.05, 0]} s={[0.5, 0.6, 0.3]} c="#65a30d" />
        <Cyl p={[0.55, 0, 0]} rt={0.04} h={0.6} c="#15803d" />
        <Ball p={[0.7, 0.2, 0]} r={0.12} c="#22c55e" s={[1.6, 0.6, 0.8]} />
        <Ball p={[0.42, 0.3, 0]} r={0.12} c="#4ade80" s={[1.6, 0.6, 0.8]} />
      </Part>
    </group>
    <group position={ring(5, 7)}>
      <Part id="biogas">
        <mesh>
          <sphereGeometry args={[0.45, 24, 16, 0, Math.PI * 2, 0, Math.PI / 2]} />
          <M c="#a3e635" side={THREE.DoubleSide} />
        </mesh>
        <Tube pts={[[0, 0.45, 0], [0.1, 0.8, 0], [0.5, 0.9, 0]]} r={0.04} c="#64748b" />
        <Bob amp={0.08} speed={3}><Ball p={[0.6, 1.05, 0]} r={0.08} c="#93c5fd" /></Bob>
      </Part>
    </group>
    <group position={ring(6, 7)}>
      <Part id="wastewater">
        <BoxM p={[0, -0.1, 0]} s={[0.9, 0.4, 0.6]} c="#0c4a6e" o={0.6} />
        <BoxM p={[0, 0.03, 0]} s={[0.85, 0.05, 0.55]} c="#38bdf8" o={0.7} />
        {Array.from({ length: 6 }).map((_, i) => <Bob key={i} amp={0.06} speed={2 + i * 0.4} phase={i}><Ball p={[-0.35 + i * 0.14, 0.12, 0]} r={0.04} c="#e0f2fe" /></Bob>)}
      </Part>
    </group>

    {Array.from({ length: 7 }).map((_, i) => {
      const p = ring(i, 7, -0.6);
      return <Rod key={i} a={[p[0] * 0.33, -0.3, p[2] * 0.33]} b={[p[0] * 0.78, -0.55, p[2] * 0.78]} r={0.015} c="#7dd3fc" o={0.6} />;
    })}
    <Ring p={[0, -0.95, 0]} R={R} r={0.02} c="#334155" rot={[Math.PI / 2, 0, 0]} />

    <Label id="fermenter" p={[0, 1.75, 0]} />
    {['yeast', 'lactic', 'soy', 'medicine', 'farming', 'biogas', 'wastewater'].map((id, i) => {
      const p = ring(i, 7, 0.45);
      return <Label key={id} id={id} p={p} />;
    })}
  </group>
);

const def: ModelDef = {
  id: 'm22_microbe_applications',
  titleVi: 'Vai trò và ứng dụng của vi sinh vật',
  titleEn: 'Roles and applications of microorganisms',
  source: 'SGK Sinh học 10 KNTT – Bài 22, tr. 131–137',
  parts,
  Scene,
  camera: [0, 3.2, 7.2],
  autoRotate: true,
};
export default def;
