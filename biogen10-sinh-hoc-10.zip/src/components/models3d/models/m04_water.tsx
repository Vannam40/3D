import React, { useMemo } from 'react';
import { ModelDef, Part, Label, Ball, Rod, Damp, Tag, Spin, Bob } from '../engine';

type V3 = [number, number, number];
const HX = 0.593, HY = -0.459;

const parts: ModelDef['parts'] = [
  { id: 'oxygen', nameVi: 'Nguyên tử oxygen', nameEn: 'Oxygen atom', ipa: '/ˈɒksɪdʒən ˈætəm/', color: '#ef4444', stages: [0, 1], descVi: 'Hút electron mạnh hơn hydrogen nên các electron trong liên kết lệch về phía oxygen → phía oxygen tích điện âm (δ–).', descEn: 'Oxygen pulls electrons more strongly than hydrogen, so the oxygen end is slightly negative (δ–).' },
  { id: 'hydrogen', nameVi: 'Nguyên tử hydrogen', nameEn: 'Hydrogen atom', ipa: '/ˈhaɪdrədʒən ˈætəm/', color: '#e2e8f0', stages: [0, 1], descVi: 'Mỗi phân tử nước có 2 nguyên tử H; phía các nguyên tử hydrogen tích điện dương (δ+).', descEn: 'Each water molecule has two hydrogen atoms; the hydrogen end is slightly positive (δ+).' },
  { id: 'covalent', nameVi: 'Liên kết cộng hoá trị', nameEn: 'Covalent bond', ipa: '/kəʊˈveɪlənt bɒnd/', color: '#94a3b8', stages: [0, 3], descVi: 'Trong phân tử nước, 1 nguyên tử O liên kết với 2 nguyên tử H bằng hai liên kết cộng hoá trị. Carbon tạo được 4 liên kết cộng hoá trị.', descEn: 'In water, one O atom is joined to two H atoms by two covalent bonds. Carbon can form four covalent bonds.' },
  { id: 'polarity', nameVi: 'Tính phân cực (δ+ / δ–)', nameEn: 'Polarity', ipa: '/pəˈlærəti/', color: '#f59e0b', stages: [0], descVi: 'Phân tử nước là phân tử phân cực, giống như thanh nam châm: một đầu δ–, một đầu δ+. Nhờ phân cực, nước hoà tan được nhiều chất.', descEn: 'Water is a polar molecule like a tiny magnet; this lets it dissolve many substances.' },
  { id: 'hbond', nameVi: 'Liên kết hydrogen', nameEn: 'Hydrogen bond', ipa: '/ˈhaɪdrədʒən bɒnd/', color: '#38bdf8', stages: [1, 2], descVi: 'Lực hút giữa các phần mang điện trái dấu của các phân tử; một phân tử nước có thể hình thành tối đa 4 liên kết hydrogen.', descEn: 'The attraction between opposite charges of molecules; one water molecule can form up to four hydrogen bonds.' },
  { id: 'ice', nameVi: 'Nước đá', nameEn: 'Ice', ipa: '/aɪs/', color: '#bae6fd', stages: [2], descVi: 'Các phân tử nước liên kết hydrogen bền thành mạng lưới, khoảng cách giữa các phân tử xa hơn so với nước lỏng.', descEn: 'Molecules are held in a lattice by stable hydrogen bonds and are farther apart than in liquid water.' },
  { id: 'liquid', nameVi: 'Nước lỏng', nameEn: 'Liquid water', ipa: '/ˈlɪkwɪd ˈwɔːtə/', color: '#0ea5e9', stages: [2], descVi: 'Liên kết hydrogen liên tục hình thành và bị phá vỡ; các phân tử ở gần nhau hơn.', descEn: 'Hydrogen bonds constantly form and break; molecules are closer together.' },
  { id: 'carbon', nameVi: 'Nguyên tử carbon', nameEn: 'Carbon atom', ipa: '/ˈkɑːbən ˈætəm/', color: '#475569', stages: [3], descVi: 'Có 4 electron hoá trị ở vòng ngoài nên tạo được bốn liên kết cộng hoá trị, hình thành bộ khung carbon đa dạng.', descEn: 'It has four outer electrons, so it forms four covalent bonds and builds varied carbon skeletons.' },
  { id: 'chain', nameVi: 'Mạch thẳng', nameEn: 'Straight chain', ipa: '/streɪt tʃeɪn/', color: '#a78bfa', stages: [3], descVi: 'Bộ khung hydrocarbon dạng mạch thẳng.', descEn: 'A straight hydrocarbon skeleton.' },
  { id: 'branch', nameVi: 'Mạch nhánh', nameEn: 'Branched chain', ipa: '/brɑːntʃt tʃeɪn/', color: '#f472b6', stages: [3], descVi: 'Bộ khung carbon phân nhánh.', descEn: 'A branched carbon skeleton.' },
  { id: 'ring', nameVi: 'Mạch vòng', nameEn: 'Ring', ipa: '/rɪŋ/', color: '#34d399', stages: [3], descVi: 'Bộ khung carbon dạng vòng; khung hydrocarbon liên kết nhóm chức tạo carbohydrate, lipid, protein, nucleic acid.', descEn: 'A ring of carbon atoms; with functional groups, skeletons form carbohydrates, lipids, proteins and nucleic acids.' },
];

/** Một phân tử nước; tham số part = có gắn vào bộ phận để bấm hay không */
const Water: React.FC<{ p?: V3; rot?: V3; tagged?: boolean; s?: number }> = ({ p = [0, 0, 0], rot = [0, 0, 0], tagged, s = 1 }) => {
  const body = (
    <>
      <Ball r={0.42} c="#ef4444" />
    </>
  );
  const hs = (
    <>
      <Ball p={[HX, HY, 0]} r={0.26} c="#e2e8f0" />
      <Ball p={[-HX, HY, 0]} r={0.26} c="#e2e8f0" />
    </>
  );
  const bonds = (
    <>
      <Rod a={[0, 0, 0]} b={[HX, HY, 0]} r={0.07} c="#94a3b8" />
      <Rod a={[0, 0, 0]} b={[-HX, HY, 0]} r={0.07} c="#94a3b8" />
    </>
  );
  return (
    <group position={p} rotation={rot} scale={s}>
      {tagged ? <Part id="oxygen">{body}</Part> : body}
      {tagged ? <Part id="hydrogen">{hs}</Part> : hs}
      {tagged ? <Part id="covalent">{bonds}</Part> : bonds}
    </group>
  );
};

function rotZ(v: [number, number], rz: number): [number, number] {
  return [v[0] * Math.cos(rz) - v[1] * Math.sin(rz), v[0] * Math.sin(rz) + v[1] * Math.cos(rz)];
}
function towards(a: V3, b: V3, da: number, db: number): [V3, V3] {
  const d = [b[0] - a[0], b[1] - a[1], b[2] - a[2]];
  const L = Math.hypot(d[0], d[1], d[2]);
  const u = d.map(x => x / L);
  return [[a[0] + u[0] * da, a[1] + u[1] * da, a[2] + u[2] * da], [b[0] - u[0] * db, b[1] - u[1] * db, b[2] - u[2] * db]];
}
/** 4 phân tử láng giềng: 2 nhận liên kết từ H trung tâm, 2 cho H vào O trung tâm */
const NEIGH = (() => {
  const out: { p: V3; rz: number; a: V3; b: V3 }[] = [];
  // nhận: O láng giềng nằm trên phương O–H trung tâm, H của nó hướng ra ngoài
  [1, -1].forEach(sg => {
    const h: V3 = [sg * HX, HY, 0];
    const p: V3 = [sg * HX * 3.3, HY * 3.3, 0];
    const ang = Math.atan2(p[1], p[0]);
    const rz = ang + Math.PI / 2; // xoay để hai H của láng giềng hướng ra xa tâm
    const [a, b] = towards(h, p, 0.27, 0.45);
    out.push({ p, rz, a, b });
  });
  // cho: một H của láng giềng hướng vào O trung tâm
  [1, -1].forEach(sg => {
    const p: V3 = [sg * 1.15, 2.05, 0];
    const toC = Math.atan2(-p[1], -p[0]);
    const base = Math.atan2(HY, -sg * HX);
    const rz = toC - base;
    const hv = rotZ([-sg * HX, HY], rz);
    const hp: V3 = [p[0] + hv[0], p[1] + hv[1], 0];
    const [b, a] = towards(hp, [0, 0, 0], 0.27, 0.45);
    out.push({ p, rz, a, b });
  });
  return out;
})();

const Dashes: React.FC<{ a: V3; b: V3; c?: string }> = ({ a, b, c = '#38bdf8' }) => {
  const pts = useMemo(() => Array.from({ length: 7 }, (_, i) => {
    const t = (i + 0.5) / 7;
    return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t] as V3;
  }), [a.join(), b.join()]);
  return <>{pts.map((p, i) => <Ball key={i} p={p} r={0.035} c={c} seg={8} />)}</>;
};

const Carbon: React.FC<{ p: V3 }> = ({ p }) => <Ball p={p} r={0.22} c="#475569" />;
const H: React.FC<{ p: V3 }> = ({ p }) => <Ball p={p} r={0.12} c="#e2e8f0" />;

const Scene: ModelDef['Scene'] = ({ stage }) => {
  // tứ diện cho methane
  const tet: V3[] = [[0.6, 0.6, 0.6], [-0.6, -0.6, 0.6], [-0.6, 0.6, -0.6], [0.6, -0.6, -0.6]];
  const hex = (cx: number, cy: number, r: number): V3[] => Array.from({ length: 6 }, (_, i) => [cx + Math.cos((i * Math.PI) / 3) * r, cy + Math.sin((i * Math.PI) / 3) * r, 0]);
  const iceHex = hex(-2.3, 0, 1.25);
  const liquid: V3[] = [[1.8, 0.4, 0.2], [2.6, -0.2, -0.3], [2.1, -0.7, 0.4], [2.9, 0.6, 0.1], [1.6, -0.3, -0.5], [2.5, 0.1, 0.6]];
  const chain: V3[] = [[-2.6, 1.2, 0], [-1.95, 1.55, 0], [-1.3, 1.2, 0], [-0.65, 1.55, 0]];
  const branch: V3[] = [[0.6, 1.2, 0], [1.25, 1.55, 0], [1.9, 1.2, 0], [1.25, 2.25, 0]];
  const ring = hex(1.0, -1.2, 0.65);

  return (
    <group>
      {/* Bước 1: phân tử nước */}
      <Damp s={stage === 0 ? 1.6 : 0}>
        <Water tagged />
        <Part id="polarity">
          <mesh position={[0, -0.15, 0]} rotation={[0, 0, 0]}>
            <torusGeometry args={[1.0, 0.012, 6, 48]} />
            <meshStandardMaterial color="#f59e0b" transparent opacity={0.4} />
          </mesh>
        </Part>
      </Damp>

      {/* Bước 2: liên kết hydrogen */}
      <Damp s={stage === 1 ? 1.1 : 0}>
        <Water tagged />
        {NEIGH.map((n, i) => (
          <Water key={i} p={n.p} rot={[0, 0, n.rz]} />
        ))}
        <Part id="hbond">
          {NEIGH.map((n, i) => (
            <Dashes key={i} a={n.a} b={n.b} />
          ))}
        </Part>
      </Damp>

      {/* Bước 3: nước đá và nước lỏng */}
      <Damp s={stage === 2 ? 1 : 0}>
        <Part id="ice">
          {iceHex.map((p, i) => (
            <Water key={i} p={p} rot={[0, 0, (i * Math.PI) / 3 + Math.PI / 2]} s={0.55} />
          ))}
        </Part>
        <Part id="hbond">
          {iceHex.map((p, i) => {
            const q = iceHex[(i + 1) % 6];
            return <Dashes key={i} a={p} b={q} />;
          })}
        </Part>
        <Part id="liquid">
          <Spin speed={0.4} position={[2.25, 0, 0]}>
            {liquid.map((p, i) => (
              <Bob key={i} amp={0.12} speed={2 + i * 0.3} phase={i}>
                <Water p={[p[0] - 2.25, p[1], p[2]]} rot={[i, i * 0.7, i * 1.3]} s={0.5} />
              </Bob>
            ))}
          </Spin>
        </Part>
      </Damp>

      {/* Bước 4: carbon và bộ khung carbon */}
      <Damp s={stage === 3 ? 1 : 0}>
        <group position={[-1.9, -1.1, 0]}>
          <Part id="carbon">
            <Spin speed={0.5}>
              <Carbon p={[0, 0, 0]} />
              {tet.map((t, i) => (
                <group key={i}>
                  <Rod a={[0, 0, 0]} b={t} r={0.05} c="#94a3b8" />
                  <H p={t} />
                </group>
              ))}
            </Spin>
          </Part>
        </group>
        <Part id="chain">
          {chain.map((p, i) => (
            <group key={i}>
              <Carbon p={p} />
              {i < chain.length - 1 && <Rod a={p} b={chain[i + 1]} r={0.05} c="#a78bfa" />}
            </group>
          ))}
        </Part>
        <Part id="branch">
          {branch.map((p, i) => (
            <Carbon key={i} p={p} />
          ))}
          <Rod a={branch[0]} b={branch[1]} r={0.05} c="#f472b6" />
          <Rod a={branch[1]} b={branch[2]} r={0.05} c="#f472b6" />
          <Rod a={branch[1]} b={branch[3]} r={0.05} c="#f472b6" />
        </Part>
        <Part id="ring">
          {ring.map((p, i) => (
            <group key={i}>
              <Carbon p={p} />
              <Rod a={p} b={ring[(i + 1) % 6]} r={0.05} c="#34d399" />
            </group>
          ))}
        </Part>
      </Damp>

      <Tag show={stage === 0} p={[-0.2, 1.25, 0.6]} tone="rose">δ– (oxygen)</Tag>
      <Tag show={stage === 0} p={[0, -1.6, 0]} tone="sky">δ+ (hydrogen)</Tag>
      <Tag show={stage === 1} p={[0, -2.75, 0]} tone="amber">Tối đa 4 liên kết hydrogen · up to 4 H-bonds</Tag>
      <Label id="oxygen" p={[0.95, 0.75, 0]} />
      <Label id="hydrogen" p={stage === 0 ? [1.6, -0.9, 0] : [1.1, -0.35, 0.3]} />
      <Label id="covalent" p={stage === 0 ? [-1.5, -0.3, 0] : [-2.0, 0.6, 0]} />
      <Label id="polarity" p={[-1.7, 0.9, 0]} />
      <Label id="hbond" p={stage === 1 ? [1.55, -1.0, 0.3] : [-2.3, 1.55, 0.2]} />
      <Label id="ice" p={[-2.3, -1.75, 0]} />
      <Label id="liquid" p={[2.2, -1.5, 0]} />
      <Label id="carbon" p={[-1.9, -0.05, 0]} />
      <Label id="chain" p={[-1.6, 2.15, 0]} />
      <Label id="branch" p={[1.25, 2.85, 0]} />
      <Label id="ring" p={[2.1, -1.2, 0]} />
    </group>
  );
};

const def: ModelDef = {
  id: 'm04_water',
  titleVi: 'Phân tử nước và vai trò của carbon',
  titleEn: 'The water molecule and the role of carbon',
  source: 'SGK Sinh học 10 KNTT – Bài 4, tr. 23–27',
  parts,
  stages: [
    { titleVi: 'Cấu trúc phân tử nước', titleEn: 'Structure of a water molecule', descVi: 'Một nguyên tử O liên kết với 2 nguyên tử H bằng hai liên kết cộng hoá trị; phía O tích điện âm (δ–), phía H tích điện dương (δ+) → phân tử phân cực.', descEn: 'One O atom bonds covalently to two H atoms; the O end is δ– and the H end is δ+, so water is polar.' },
    { titleVi: 'Liên kết hydrogen giữa các phân tử nước', titleEn: 'Hydrogen bonds between water molecules', descVi: 'Lực hút giữa các phần mang điện trái dấu tạo liên kết hydrogen; một phân tử nước tạo tối đa 4 liên kết → sức căng bề mặt, nhiệt dung đặc trưng cao, nhiệt bay hơi cao.', descEn: 'Opposite charges attract to form hydrogen bonds (up to four per molecule), giving surface tension and high specific heat.' },
    { titleVi: 'Nước đá và nước lỏng', titleEn: 'Ice and liquid water', descVi: 'Trong nước đá các phân tử liên kết thành mạng, khoảng cách xa hơn; trong nước lỏng các phân tử gần nhau hơn (Hình 4.3b).', descEn: 'In ice, molecules form a lattice and are farther apart; in liquid water they are closer together.' },
    { titleVi: 'Carbon và bộ khung carbon', titleEn: 'Carbon and carbon skeletons', descVi: 'Carbon có 4 electron hoá trị, tạo 4 liên kết cộng hoá trị → khung carbon mạch thẳng, mạch nhánh, mạch vòng, nền tảng của các hợp chất hữu cơ.', descEn: 'Carbon forms four covalent bonds, building straight, branched and ring skeletons – the basis of organic compounds.' },
  ],
  Scene,
  camera: [0, 0.8, 7.5],
  autoRotate: false,
};
export default def;
