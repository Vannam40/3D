import React, { useMemo } from 'react';
import * as THREE from 'three';
import { ModelDef, Part, Label, M, Ball, Rod, Tube, Damp, Cyl, Spin, Caps, Bob, Tag } from '../engine';

type V3 = [number, number, number];

const parts: ModelDef['parts'] = [
  { id: 'bacteria', nameVi: 'Vi khuẩn (cầu, que, xoắn)', nameEn: 'Bacteria (cocci, rods, spirals)', ipa: '/bækˈtɪəriə/', color: '#38bdf8', stages: [0], descVi: 'Vi sinh vật nhân sơ, nhóm có số lượng lớn nhất (khoảng 1/2 sinh khối Trái Đất); hình dạng phổ biến: cầu, que, xoắn.', descEn: 'Prokaryotes; the most numerous group (about half of Earth’s biomass); common shapes are spheres, rods and spirals.' },
  { id: 'archaea', nameVi: 'Archaea (cổ khuẩn)', nameEn: 'Archaea', ipa: '/ɑːˈkiːə/', color: '#f97316', stages: [0], descVi: 'Nhân sơ đơn bào, giống vi khuẩn nhưng có họ hàng gần với sinh vật nhân thực; nhiều loài sống ở điều kiện cực kì khắc nghiệt.', descEn: 'Single-celled prokaryotes, similar to bacteria but related to eukaryotes; many live in extreme conditions.' },
  { id: 'algae', nameVi: 'Vi tảo', nameEn: 'Microalgae', ipa: '/ˈmaɪkrəʊˌældʒiː/', color: '#22c55e', stages: [0], descVi: 'Vi sinh vật nhân thực quang tự dưỡng (năng lượng ánh sáng, carbon từ CO₂).', descEn: 'Photoautotrophic eukaryotic microbes (light energy, carbon from CO₂).' },
  { id: 'yeast', nameVi: 'Nấm men', nameEn: 'Yeast', ipa: '/jiːst/', color: '#fde68a', stages: [0], descVi: 'Nấm đơn bào nhân thực, hoá dị dưỡng; sinh sản bằng nảy chồi.', descEn: 'A single-celled eukaryotic fungus, a chemoheterotroph that reproduces by budding.' },
  { id: 'protozoa', nameVi: 'Động vật nguyên sinh', nameEn: 'Protozoa', ipa: '/ˌprəʊtəˈzəʊə/', color: '#c084fc', stages: [0], descVi: 'Vi sinh vật nhân thực hoá dị dưỡng, ví dụ trùng giày.', descEn: 'Chemoheterotrophic eukaryotic microbes such as Paramecium.' },
  { id: 'mold', nameVi: 'Vi nấm (nấm mốc)', nameEn: 'Microfungi (mould)', ipa: '/məʊld/', color: '#94a3b8', stages: [0], descVi: 'Vi sinh vật nhân thực; sinh sản bằng bào tử (VD bào tử đính).', descEn: 'Eukaryotic microbes that reproduce by spores, e.g. conidia.' },
  { id: 'gram_pos', nameVi: 'Vi khuẩn Gram dương', nameEn: 'Gram-positive bacterium', ipa: '/ˌɡræm ˈpɒzətɪv/', color: '#7c3aed', stages: [1], descVi: 'Thành peptidoglycan dày, giữ màu tím kết tinh sau khi rửa cồn → màu tím.', descEn: 'A thick peptidoglycan wall keeps the crystal violet stain → purple.' },
  { id: 'gram_neg', nameVi: 'Vi khuẩn Gram âm', nameEn: 'Gram-negative bacterium', ipa: '/ˌɡræm ˈneɡətɪv/', color: '#ef4444', stages: [1], descVi: 'Thành mỏng, có màng ngoài; mất màu tím khi rửa cồn, bắt màu đỏ fuchsin.', descEn: 'A thin wall with an outer membrane loses the violet stain and takes up red fuchsin.' },
  { id: 'colony', nameVi: 'Khuẩn lạc', nameEn: 'Colony', ipa: '/ˈkɒləni/', color: '#f8fafc', stages: [2], descVi: 'Tập hợp tế bào sinh ra từ một tế bào ban đầu trên môi trường thạch, nhìn được bằng mắt thường.', descEn: 'A group of cells from one original cell on agar, visible to the naked eye.' },
  { id: 'agar', nameVi: 'Đĩa thạch (phân lập)', nameEn: 'Agar plate', ipa: '/ˈeɪɡɑː pleɪt/', color: '#fcd34d', stages: [2], descVi: 'Pha loãng mẫu, phết lên bề mặt thạch đặc để mỗi tế bào phát triển thành một khuẩn lạc riêng rẽ – thu vi sinh vật thuần khiết.', descEn: 'A diluted sample is spread on solid agar so each cell grows into a separate colony.' },
];

const R = 2.6;
const at = (i: number): V3 => [Math.cos((i / 6) * Math.PI * 2) * R, 0, Math.sin((i / 6) * Math.PI * 2) * R];

const Cilia: React.FC = () => {
  const pts = useMemo(() => Array.from({ length: 28 }, (_, i) => {
    const t = (i / 28) * Math.PI * 2;
    return { a: [Math.cos(t) * 0.55, Math.sin(t) * 0.25, 0] as V3, b: [Math.cos(t) * 0.7, Math.sin(t) * 0.33, 0] as V3 };
  }), []);
  return <>{pts.map((p, i) => <Rod key={i} a={p.a} b={p.b} r={0.01} c="#e9d5ff" />)}</>;
};

const Scene: ModelDef['Scene'] = ({ stage }) => (
  <group>
    <Damp s={stage === 0 ? 1 : 0}>
      <group>
        <group position={at(0)}>
          <Part id="bacteria">
            <Caps p={[-0.3, 0.3, 0]} len={0.45} r={0.12} c="#38bdf8" rot={[0, 0, 1.2]} />
            {[[0.2, -0.1], [0.42, -0.1], [0.31, 0.08]].map(([x, y], i) => <Ball key={i} p={[x, y, 0]} r={0.11} c="#0ea5e9" />)}
            <Tube pts={Array.from({ length: 12 }, (_, i) => [-0.4 + i * 0.07, -0.45 + Math.sin(i * 1.1) * 0.08, Math.cos(i * 1.1) * 0.08] as V3)} r={0.035} c="#7dd3fc" />
          </Part>
        </group>
        <group position={at(1)}>
          <Part id="archaea">
            <Ball r={0.32} c="#f97316" s={[1.2, 0.8, 1]} />
            {Array.from({ length: 10 }).map((_, i) => <Rod key={i} a={[Math.cos(i * 0.63) * 0.33, Math.sin(i * 0.63) * 0.22, 0]} b={[Math.cos(i * 0.63) * 0.45, Math.sin(i * 0.63) * 0.3, 0]} r={0.015} c="#fed7aa" />)}
          </Part>
        </group>
        <group position={at(2)}>
          <Part id="algae">
            <Ball r={0.3} c="#86efac" o={0.7} s={[0.8, 1.1, 0.8]} />
            <Ball p={[0, -0.08, 0]} r={0.2} c="#16a34a" />
            <Tube pts={[[0, 0.32, 0], [-0.1, 0.55, 0], [-0.25, 0.7, 0]]} r={0.015} c="#bbf7d0" />
            <Tube pts={[[0, 0.32, 0], [0.1, 0.55, 0], [0.25, 0.7, 0]]} r={0.015} c="#bbf7d0" />
          </Part>
        </group>
        <group position={at(3)}>
          <Part id="yeast">
            <Ball r={0.3} c="#fde68a" s={[1, 1.2, 1]} />
            <Bob amp={0.03}><Ball p={[0.28, 0.32, 0]} r={0.15} c="#fef3c7" /></Bob>
            <Ball p={[-0.05, 0, 0.2]} r={0.08} c="#ca8a04" />
          </Part>
        </group>
        <group position={at(4)}>
          <Part id="protozoa">
            <Ball r={0.55} c="#c084fc" o={0.75} s={[1, 0.45, 0.45]} />
            <Ball p={[0.05, 0, 0.1]} r={0.1} c="#7e22ce" />
            <Cilia />
          </Part>
        </group>
        <group position={at(5)}>
          <Part id="mold">
            <Tube pts={[[-0.5, -0.4, 0], [-0.1, -0.35, 0.05], [0.3, -0.42, 0], [0.55, -0.35, 0]]} r={0.03} c="#94a3b8" />
            {[-0.25, 0.25].map(x => (
              <group key={x}>
                <Rod a={[x, -0.38, 0]} b={[x, 0.25, 0]} r={0.025} c="#cbd5e1" />
                {Array.from({ length: 6 }).map((_, i) => <Ball key={i} p={[x + Math.cos(i) * 0.12, 0.32 + Math.sin(i) * 0.08, Math.sin(i * 2) * 0.1]} r={0.06} c="#475569" />)}
              </group>
            ))}
          </Part>
        </group>
      </group>
    </Damp>

    {/* Nhuộm Gram */}
    <Damp s={stage === 1 ? 1 : 0}>
      <group position={[-1.6, 0, 0]}>
        <Part id="gram_pos">
          <mesh rotation={[0, 0, Math.PI / 2]}>
            <capsuleGeometry args={[0.75, 1.4, 12, 24]} />
            <M c="#7c3aed" o={0.85} />
          </mesh>
          <mesh rotation={[0, 0, Math.PI / 2]}>
            <capsuleGeometry args={[0.5, 1.3, 12, 24]} />
            <M c="#c4b5fd" o={0.5} />
          </mesh>
        </Part>
      </group>
      <group position={[1.8, 0, 0]}>
        <Part id="gram_neg">
          <mesh rotation={[0, 0, Math.PI / 2]}>
            <capsuleGeometry args={[0.68, 1.4, 12, 24]} />
            <M c="#ef4444" o={0.45} side={THREE.DoubleSide} />
          </mesh>
          <mesh rotation={[0, 0, Math.PI / 2]}>
            <capsuleGeometry args={[0.6, 1.38, 12, 24]} />
            <M c="#fca5a5" o={0.7} />
          </mesh>
        </Part>
      </group>
    </Damp>

    {/* Khuẩn lạc */}
    <Damp s={stage === 2 ? 1 : 0}>
      <Part id="agar">
        <Cyl p={[0, -0.6, 0]} rt={2.2} h={0.25} c="#fcd34d" o={0.85} />
        <Cyl p={[0, -0.4, 0]} rt={2.3} h={0.5} c="#e0f2fe" o={0.12} open />
      </Part>
      <Part id="colony">
        {Array.from({ length: 22 }).map((_, i) => {
          const a = i * 2.4;
          const r = 0.4 + (i % 7) * 0.24;
          return <Ball key={i} p={[Math.cos(a) * r, -0.46, Math.sin(a) * r]} r={0.08 + (i % 3) * 0.05} c="#f8fafc" s={[1, 0.4, 1]} />;
        })}
      </Part>
    </Damp>

    <Tag show={stage === 1} p={[-1.6, -1.3, 0]} tone="slate">Thành dày → tím</Tag>
    <Tag show={stage === 1} p={[1.8, -1.3, 0]} tone="rose">Thành mỏng + màng ngoài → đỏ</Tag>
    <Tag show={stage === 1} p={[0, 1.6, 0]} tone="amber">Tím kết tinh → iodine → cồn 95% → fuchsin</Tag>

    {['bacteria', 'archaea', 'algae', 'yeast', 'protozoa', 'mold'].map((id, i) => {
      const p = at(i);
      return <Label key={id} id={id} p={[p[0], 0.95, p[2]]} />;
    })}
    <Label id="gram_pos" p={[-1.6, 1.0, 0]} />
    <Label id="gram_neg" p={[1.8, 1.0, 0]} />
    <Label id="colony" p={[0.6, 0.2, 0]} />
    <Label id="agar" p={[-2.0, -1.2, 0.8]} />
  </group>
);

const def: ModelDef = {
  id: 'm20_microbe_diversity',
  titleVi: 'Sự đa dạng và phương pháp nghiên cứu vi sinh vật',
  titleEn: 'Diversity of microorganisms and research methods',
  source: 'SGK Sinh học 10 KNTT – Bài 20, tr. 116–121',
  parts,
  stages: [
    { titleVi: 'Các nhóm vi sinh vật', titleEn: 'Groups of microorganisms', descVi: 'Nhân sơ: vi khuẩn, Archaea. Nhân thực: vi tảo, nấm đơn bào, vi nấm, động vật nguyên sinh. Kích thước nhỏ → trao đổi chất, sinh trưởng, sinh sản nhanh, phân bố rộng.', descEn: 'Prokaryotes: bacteria, archaea. Eukaryotes: microalgae, yeasts, moulds, protozoa.' },
    { titleVi: 'Phương pháp nhuộm Gram', titleEn: 'Gram staining', descVi: 'Dùng 4 thuốc thử: tím kết tinh, iodine, ethyl alcohol 95%, fuchsin. Gram dương màu tím, Gram âm màu đỏ → giúp chọn thuốc điều trị.', descEn: 'Crystal violet, iodine, 95% alcohol and fuchsin: Gram-positive stays purple, Gram-negative turns red.' },
    { titleVi: 'Phân lập và nuôi cấy', titleEn: 'Isolation and culture', descVi: 'Pha loãng mẫu, phết lên thạch đặc → mỗi tế bào tạo một khuẩn lạc riêng; nuôi khuẩn lạc trong môi trường lỏng để nhân số lượng lớn.', descEn: 'Spread a diluted sample on agar so each cell forms a colony; grow colonies in liquid medium.' },
  ],
  Scene,
  camera: [0, 3.2, 7.2],
  autoRotate: true,
};
export default def;
