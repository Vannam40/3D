import React, { useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { ModelDef, Part, Label, M, Ball, Rod, Tube, Flow, Tag, Cyl, Bob } from '../engine';

type V3 = [number, number, number];

const parts: ModelDef['parts'] = [
  { id: 'bilayer', nameVi: 'Lớp kép phospholipid', nameEn: 'Phospholipid bilayer', ipa: '/ˌfɒsfəʊˈlɪpɪd ˈbaɪleɪə/', color: '#38bdf8', descVi: 'Đầu ưa nước quay ra ngoài, đuôi kị nước quay vào trong; phospholipid luôn di chuyển → màng linh hoạt (mô hình khảm động).', descEn: 'Hydrophilic heads face out and hydrophobic tails face in; the lipids keep moving (fluid mosaic model).' },
  { id: 'cholesterol', nameVi: 'Cholesterol', nameEn: 'Cholesterol', ipa: '/kəˈlestərɒl/', color: '#facc15', stages: [0], descVi: 'Chèn giữa lớp kép phospholipid (tế bào động vật) để điều chỉnh độ linh hoạt của màng.', descEn: 'Inserted between phospholipids (animal cells) to adjust membrane fluidity.' },
  { id: 'glycoprotein', nameVi: 'Glycoprotein', nameEn: 'Glycoprotein', ipa: '/ˌɡlaɪkəʊˈprəʊtiːn/', color: '#a3e635', stages: [0], descVi: 'Protein màng liên kết chuỗi đường ngắn; tạo đặc điểm nhận diện đặc trưng cho từng loại tế bào.', descEn: 'A membrane protein with short sugar chains; it helps cells recognise each other.' },
  { id: 'channel', nameVi: 'Protein kênh', nameEn: 'Channel protein', ipa: '/ˈtʃænl ˈprəʊtiːn/', color: '#f472b6', descVi: 'Protein xuyên màng tạo đường ống/lỗ cho từng loại chất đi qua (khuếch tán tăng cường); tính đặc thù cao.', descEn: 'A transmembrane protein forming a pore for specific substances (facilitated diffusion).' },
  { id: 'aquaporin', nameVi: 'Kênh aquaporin', nameEn: 'Aquaporin', ipa: '/ˌækwəˈpɔːrɪn/', color: '#22d3ee', stages: [0, 2], descVi: 'Kênh chuyên vận chuyển nước với tốc độ khoảng 3 tỉ phân tử nước/giây.', descEn: 'A water channel that moves about 3 billion water molecules per second.' },
  { id: 'carrier', nameVi: 'Protein mang', nameEn: 'Carrier protein', ipa: '/ˈkæriə ˈprəʊtiːn/', color: '#fb923c', stages: [0, 2], descVi: 'Khi liên kết với chất cần vận chuyển, cấu hình protein mang bị biến đổi để đưa chất qua màng.', descEn: 'It changes shape when it binds a substance and carries it across the membrane.' },
  { id: 'pump', nameVi: 'Bơm Na⁺–K⁺', nameEn: 'Sodium–potassium pump', ipa: '/ˈsəʊdiəm pəˈtæsiəm pʌmp/', color: '#ef4444', descVi: 'Protein dùng năng lượng ATP vận chuyển Na⁺ ra và K⁺ vào tế bào ngược chiều gradient nồng độ (vận chuyển chủ động).', descEn: 'Uses ATP to move Na⁺ out and K⁺ in against their concentration gradients (active transport).' },
  { id: 'simple', nameVi: 'Khuếch tán đơn giản (O₂, CO₂)', nameEn: 'Simple diffusion', ipa: '/ˈsɪmpl dɪˈfjuːʒn/', color: '#e2e8f0', stages: [1], descVi: 'Phân tử nhỏ, không phân cực (O₂, CO₂, nước) đi trực tiếp qua lớp kép phospholipid từ nơi nồng độ cao đến nơi nồng độ thấp, không tốn năng lượng.', descEn: 'Small non-polar molecules pass straight through the bilayer from high to low concentration, using no energy.' },
  { id: 'ions', nameVi: 'Ion qua kênh (khuếch tán tăng cường)', nameEn: 'Ions (facilitated diffusion)', ipa: '/ˈaɪənz/', color: '#f9a8d4', stages: [2], descVi: 'Ion, chất phân cực không qua được lớp kép phospholipid nên đi qua protein kênh, xuôi gradient; có hiện tượng bão hoà kênh.', descEn: 'Ions cannot cross the bilayer, so they pass through channel proteins down the gradient.' },
  { id: 'atp', nameVi: 'ATP (năng lượng)', nameEn: 'ATP (energy)', ipa: '/ˌeɪ tiː ˈpiː/', color: '#fde047', stages: [3], descVi: 'Vận chuyển chủ động cần năng lượng ATP để bơm chất ngược gradient nồng độ.', descEn: 'Active transport needs ATP to pump substances against the gradient.' },
  { id: 'endo', nameVi: 'Nhập bào (thực bào/ẩm bào)', nameEn: 'Endocytosis', ipa: '/ˌendəʊsaɪˈtəʊsɪs/', color: '#a78bfa', stages: [4], descVi: 'Màng tế bào bao lấy vật cần vận chuyển tạo túi vận chuyển đi vào tế bào chất; thực bào "ăn" phân tử lớn, ẩm bào lấy chất tan. Tốn năng lượng.', descEn: 'The membrane wraps around material to form a vesicle that moves into the cell; it uses energy.' },
  { id: 'exo', nameVi: 'Xuất bào', nameEn: 'Exocytosis', ipa: '/ˌeksəʊsaɪˈtəʊsɪs/', color: '#34d399', stages: [4], descVi: 'Túi vận chuyển liên kết với màng tế bào, giải phóng chất kích thước lớn ra ngoài (VD protein sữa).', descEn: 'A vesicle fuses with the membrane and releases large substances outside (e.g. milk proteins).' },
];

const COLS = 13, ROWS = 4;
const X0 = -3.3, DX = 0.55, Z0 = -0.9, DZ = 0.6;
// vị trí trống trong lớp kép cho protein
const HOLES: [number, number][] = [[1, 1], [4, 2], [6, 1], [9, 2], [11, 1]];

const Bilayer: React.FC = () => {
  const items = useMemo(() => {
    const out: { p: V3; flip: boolean }[] = [];
    for (let i = 0; i < COLS; i++)
      for (let j = 0; j < ROWS; j++) {
        if (HOLES.some(([a, b]) => a === i && b === j)) continue;
        const x = X0 + i * DX + (j % 2) * 0.12;
        const z = Z0 + j * DZ;
        out.push({ p: [x, 0.62, z], flip: false });
        out.push({ p: [x, -0.62, z], flip: true });
      }
    return out;
  }, []);
  return (
    <>
      {items.map((it, k) => (
        <group key={k} position={it.p} rotation={[it.flip ? Math.PI : 0, 0, 0]}>
          <Ball r={0.16} c="#38bdf8" seg={10} />
          <Rod a={[-0.05, -0.08, 0]} b={[-0.05, -0.55, 0]} r={0.025} c="#fde68a" />
          <Rod a={[0.05, -0.08, 0]} b={[0.05, -0.55, 0]} r={0.025} c="#fde68a" />
        </group>
      ))}
    </>
  );
};

const holeX = (i: number, j: number) => X0 + i * DX + (j % 2) * 0.12;
const holeZ = (j: number) => Z0 + j * DZ;

/** Túi nhập bào đi xuyên vào trong */
const Vesicle: React.FC<{ dir: 1 | -1; x: number; c: string }> = ({ dir, x, c }) => {
  const ref = useRef<THREE.Group>(null);
  useFrame(({ clock }) => {
    const t = (clock.getElapsedTime() * 0.25) % 1;
    if (ref.current) {
      const y = dir === -1 ? 1.9 - t * 3.8 : -1.9 + t * 3.8;
      ref.current.position.set(x, y, 0.9);
    }
  });
  return (
    <group ref={ref}>
      <mesh>
        <sphereGeometry args={[0.38, 24, 16]} />
        <M c={c} o={0.45} />
      </mesh>
      <Ball r={0.16} c={dir === -1 ? '#f59e0b' : '#fef08a'} />
    </group>
  );
};

const Scene: ModelDef['Scene'] = ({ stage }) => {
  const outside = useMemo(() => Array.from({ length: 16 }, () => [-3.0 + Math.random() * 1.0, 1.3 + Math.random() * 0.8, -0.8 + Math.random() * 1.6] as V3), []);
  const naOut = useMemo(() => Array.from({ length: 10 }, () => [1.7 + Math.random() * 1.6, 1.3 + Math.random() * 0.8, -0.8 + Math.random() * 1.6] as V3), []);
  const kIn = useMemo(() => Array.from({ length: 10 }, () => [1.7 + Math.random() * 1.6, -1.3 - Math.random() * 0.8, -0.8 + Math.random() * 1.6] as V3), []);
  const chX = holeX(4, 2), chZ = holeZ(2);
  const aqX = holeX(6, 1), aqZ = holeZ(1);
  const caX = holeX(9, 2), caZ = holeZ(2);
  const puX = holeX(11, 1), puZ = holeZ(1);
  const gpX = holeX(1, 1), gpZ = holeZ(1);

  return (
    <group rotation={[0.25, 0, 0]}>
      <Part id="bilayer">
        <Bilayer />
      </Part>

      <Part id="cholesterol">
        {[[-2.2, 0.2, 0.35], [0.4, -0.25, -0.6], [2.1, 0.25, 0.65]].map((p, i) => (
          <Cyl key={i} p={p as V3} rt={0.06} h={0.45} c="#facc15" />
        ))}
      </Part>

      <Part id="glycoprotein">
        <group position={[gpX, 0, gpZ]}>
          <Ball r={0.42} c="#65a30d" s={[0.8, 1.9, 0.8]} />
          <Tube pts={[[0, 0.8, 0], [0.15, 1.1, 0.05], [-0.05, 1.35, 0], [0.2, 1.55, 0.1]]} r={0.05} c="#a3e635" />
          <Ball p={[0.2, 1.6, 0.1]} r={0.08} c="#d9f99d" />
          <Ball p={[-0.15, 1.3, 0]} r={0.07} c="#d9f99d" />
        </group>
      </Part>

      <Part id="channel">
        <group position={[chX, 0, chZ]}>
          {Array.from({ length: 6 }).map((_, i) => (
            <Cyl key={i} p={[Math.cos(i * 1.047) * 0.22, 0, Math.sin(i * 1.047) * 0.22]} rt={0.11} h={1.6} c="#f472b6" />
          ))}
        </group>
      </Part>

      <Part id="aquaporin">
        <group position={[aqX, 0, aqZ]}>
          {Array.from({ length: 4 }).map((_, i) => (
            <Cyl key={i} p={[Math.cos(i * 1.57) * 0.2, 0, Math.sin(i * 1.57) * 0.2]} rt={0.1} h={1.55} c="#22d3ee" />
          ))}
        </group>
      </Part>

      <Part id="carrier">
        <group position={[caX, 0, caZ]}>
          <Bob amp={0.06} speed={2}>
            <Ball r={0.42} c="#fb923c" s={[1, 2.0, 1]} />
            <Ball p={[0, 0.15, 0.35]} r={0.12} c="#fde047" />
          </Bob>
        </group>
      </Part>

      <Part id="pump">
        <group position={[puX, 0, puZ]}>
          <Ball r={0.45} c="#ef4444" s={[1.1, 1.9, 1.1]} />
          <Ball p={[0, -0.3, 0.42]} r={0.1} c="#fca5a5" />
        </group>
      </Part>

      {/* Bước 2: khuếch tán đơn giản */}
      <Part id="simple">
        {outside.map((p, i) => <Ball key={i} p={p} r={0.07} c="#e2e8f0" seg={8} />)}
        <Flow path={[[-2.5, 1.6, 0], [-2.55, 0.5, 0.1], [-2.45, -0.5, 0], [-2.6, -1.8, 0.2]]} n={5} c="#e2e8f0" r={0.08} speed={0.35} />
        <Flow path={[[-3.0, 1.8, -0.4], [-2.9, 0.4, -0.3], [-3.0, -0.6, -0.4], [-2.9, -1.9, -0.3]]} n={4} c="#e2e8f0" r={0.08} speed={0.3} offset={0.3} />
      </Part>

      {/* Bước 3: khuếch tán tăng cường */}
      <Part id="ions">
        <Flow path={[[chX, 1.9, chZ], [chX, 0.8, chZ], [chX, -0.8, chZ], [chX, -1.9, chZ]]} n={5} c="#f9a8d4" r={0.08} speed={0.4} />
        <Flow path={[[aqX, 1.9, aqZ], [aqX, 0.8, aqZ], [aqX, -0.8, aqZ], [aqX, -1.9, aqZ]]} n={7} c="#7dd3fc" r={0.06} speed={0.7} />
        <Flow path={[[caX, 1.9, caZ + 0.4], [caX, 0.3, caZ + 0.4], [caX, -0.3, caZ + 0.4], [caX, -1.9, caZ + 0.4]]} n={3} c="#fde047" r={0.09} speed={0.25} />
      </Part>

      {/* Bước 4: vận chuyển chủ động */}
      <group visible={stage === 3}>
        {naOut.map((p, i) => <Ball key={`na${i}`} p={p} r={0.07} c="#f97316" seg={8} />)}
        {kIn.map((p, i) => <Ball key={`k${i}`} p={p} r={0.07} c="#a855f7" seg={8} />)}
      </group>
      {stage === 3 && (
        <group>
          <Flow path={[[puX - 0.15, -1.9, puZ], [puX - 0.15, -0.6, puZ], [puX - 0.15, 0.6, puZ], [puX - 0.15, 1.9, puZ]]} n={3} c="#f97316" r={0.09} speed={0.3} />
          <Flow path={[[puX + 0.15, 1.9, puZ], [puX + 0.15, 0.6, puZ], [puX + 0.15, -0.6, puZ], [puX + 0.15, -1.9, puZ]]} n={2} c="#a855f7" r={0.09} speed={0.3} />
        </group>
      )}
      <Part id="atp">
        <Bob amp={0.1} speed={3}>
          <group position={[puX - 0.7, -1.3, puZ + 0.4]}>
            <Ball r={0.13} c="#fde047" />
            <Ball p={[0.22, 0, 0]} r={0.09} c="#f59e0b" />
            <Ball p={[0.38, 0, 0]} r={0.09} c="#f59e0b" />
            <Ball p={[0.54, 0, 0]} r={0.09} c="#f59e0b" />
          </group>
        </Bob>
      </Part>

      {/* Bước 5: nhập bào – xuất bào */}
      <Part id="endo">
        <Vesicle dir={-1} x={-1.6} c="#a78bfa" />
      </Part>
      <Part id="exo">
        <Vesicle dir={1} x={1.3} c="#34d399" />
      </Part>

      <Tag p={[3.3, 1.75, 0]} tone="sky">Ngoài tế bào · Outside</Tag>
      <Tag p={[3.3, -1.75, 0]} tone="slate">Tế bào chất · Cytoplasm</Tag>
      <Tag show={stage === 1} p={[-2.6, 2.3, 0]} tone="amber">Nồng độ cao → thấp</Tag>
      <Tag show={stage === 3} p={[2.6, 2.4, 0]} tone="rose">Ngược gradient – cần ATP</Tag>

      <Label id="bilayer" p={[-0.6, 1.3, 1.6]} />
      <Label id="cholesterol" p={[0.4, -0.25, -1.1]} />
      <Label id="glycoprotein" p={[gpX, 2.0, gpZ]} />
      <Label id="channel" p={[chX, 1.15, chZ + 0.4]} />
      <Label id="aquaporin" p={[aqX, -1.15, aqZ + 0.4]} />
      <Label id="carrier" p={[caX, 1.25, caZ]} />
      <Label id="pump" p={[puX, -1.25, puZ + 0.3]} />
      <Label id="simple" p={[-2.6, -2.25, 0]} />
      <Label id="ions" p={[chX, -2.25, chZ]} />
      <Label id="atp" p={[puX - 0.4, -1.75, puZ + 0.4]} />
      <Label id="endo" p={[-1.6, 2.35, 0.9]} />
      <Label id="exo" p={[1.3, 2.35, 0.9]} />
    </group>
  );
};

const def: ModelDef = {
  id: 'm10_membrane_transport',
  titleVi: 'Màng tế bào và trao đổi chất qua màng',
  titleEn: 'The cell membrane and membrane transport',
  source: 'SGK Sinh học 10 KNTT – Bài 8 (màng tế bào) & Bài 10, tr. 64–70',
  parts,
  stages: [
    { titleVi: 'Cấu trúc màng – mô hình khảm động', titleEn: 'Fluid mosaic model', descVi: 'Lớp kép phospholipid xen protein xuyên màng, protein bám màng, cholesterol, glycoprotein (Singer & Nicolson, 1972).', descEn: 'A phospholipid bilayer with transmembrane and peripheral proteins, cholesterol and glycoproteins.' },
    { titleVi: 'Khuếch tán đơn giản', titleEn: 'Simple diffusion', descVi: 'Vận chuyển thụ động: chất đi từ nơi nồng độ cao đến nơi nồng độ thấp qua lớp kép phospholipid, không tốn năng lượng.', descEn: 'Passive transport from high to low concentration directly through the bilayer, without energy.' },
    { titleVi: 'Khuếch tán tăng cường & thẩm thấu', titleEn: 'Facilitated diffusion & osmosis', descVi: 'Ion, chất phân cực đi qua protein kênh hoặc protein mang; nước đi qua kênh aquaporin (thẩm thấu). Vẫn xuôi gradient, không tốn năng lượng.', descEn: 'Ions and polar molecules pass through channel or carrier proteins; water moves through aquaporins (osmosis).' },
    { titleVi: 'Vận chuyển chủ động', titleEn: 'Active transport', descVi: 'Bơm Na⁺–K⁺ dùng ATP đưa Na⁺ ra, K⁺ vào ngược chiều gradient nồng độ.', descEn: 'The Na⁺–K⁺ pump uses ATP to move ions against their concentration gradients.' },
    { titleVi: 'Nhập bào và xuất bào', titleEn: 'Endocytosis and exocytosis', descVi: 'Phân tử lớn được vận chuyển nhờ biến dạng màng: thực bào, ẩm bào (vào) và xuất bào (ra); đều tốn năng lượng.', descEn: 'Large molecules move by changing the membrane shape: phagocytosis, pinocytosis and exocytosis use energy.' },
  ],
  Scene,
  camera: [0, 2.0, 6.6],
  autoRotate: false,
  stageInterval: 5000,
};
export default def;
