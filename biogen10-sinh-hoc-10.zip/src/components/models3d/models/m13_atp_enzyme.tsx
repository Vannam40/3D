import React from 'react';
import * as THREE from 'three';
import { ModelDef, Part, Label, M, Ball, Rod, Damp, Cyl, Bob, Tag, Spin, Flow } from '../engine';

type V3 = [number, number, number];

const parts: ModelDef['parts'] = [
  { id: 'adenine', nameVi: 'Adenine', nameEn: 'Adenine', ipa: '/ˈædəniːn/', color: '#3b82f6', stages: [0, 1], descVi: 'Một trong ba thành phần của ATP (base nitơ).', descEn: 'One of the three parts of ATP (a nitrogenous base).' },
  { id: 'ribose', nameVi: 'Đường ribose', nameEn: 'Ribose sugar', ipa: '/ˈraɪbəʊs/', color: '#e2e8f0', stages: [0, 1], descVi: 'Đường 5 carbon trong phân tử ATP.', descEn: 'The 5-carbon sugar in ATP.' },
  { id: 'phosphate', nameVi: 'Ba gốc phosphate', nameEn: 'Three phosphate groups', ipa: '/ˈfɒsfeɪt ɡruːps/', color: '#f59e0b', stages: [0, 1], descVi: 'ATP có 3 gốc phosphate; khi liên kết giữa các gốc phosphate bị phá vỡ sẽ giải phóng năng lượng.', descEn: 'ATP has three phosphate groups; breaking the bonds between them releases energy.' },
  { id: 'hebond', nameVi: 'Liên kết giàu năng lượng', nameEn: 'High-energy bond', ipa: '/haɪ ˈenədʒi bɒnd/', color: '#facc15', stages: [0, 1], descVi: 'ATP có hai liên kết phosphate giàu năng lượng; liên kết ngoài cùng dễ bị phá vỡ nhất: ATP → ADP + năng lượng.', descEn: 'ATP has two high-energy phosphate bonds; breaking the outer one gives ADP and energy.' },
  { id: 'energy', nameVi: 'Năng lượng giải phóng', nameEn: 'Released energy', ipa: '/rɪˈliːst ˈenədʒi/', color: '#fde047', stages: [1], descVi: 'ATP như viên pin sạc: liên tục được sinh ra và ngay lập tức được sử dụng cho tổng hợp, vận chuyển các chất, co cơ… → "đồng tiền" năng lượng.', descEn: 'ATP works like a rechargeable battery: constantly made and used at once – the energy currency of the cell.' },
  { id: 'enzyme', nameVi: 'Enzyme', nameEn: 'Enzyme', ipa: '/ˈenzaɪm/', color: '#22c55e', stages: [2, 3, 4], descVi: 'Chất xúc tác sinh học, đa số là protein; làm giảm năng lượng hoạt hoá, tăng tốc độ phản ứng; không bị biến đổi sau phản ứng.', descEn: 'A biological catalyst, usually a protein, that lowers activation energy and is unchanged after the reaction.' },
  { id: 'active_site', nameVi: 'Trung tâm hoạt động', nameEn: 'Active site', ipa: '/ˈæktɪv saɪt/', color: '#f472b6', stages: [2, 3, 4], descVi: 'Vùng không gian đặc biệt liên kết đặc hiệu với cơ chất; khi liên kết cả hai đều biến đổi cấu hình → tính đặc hiệu của enzyme.', descEn: 'A special region that binds the substrate specifically; both change shape slightly when they bind.' },
  { id: 'substrate', nameVi: 'Cơ chất', nameEn: 'Substrate', ipa: '/ˈsʌbstreɪt/', color: '#38bdf8', stages: [2, 3], descVi: 'Chất chịu tác động của enzyme.', descEn: 'The substance the enzyme acts on.' },
  { id: 'products', nameVi: 'Sản phẩm', nameEn: 'Products', ipa: '/ˈprɒdʌkts/', color: '#a78bfa', stages: [4], descVi: 'Sau phản ứng, sản phẩm có cấu hình thay đổi, rời khỏi enzyme; enzyme trở lại hình dạng ban đầu.', descEn: 'After the reaction the products leave and the enzyme returns to its original shape.' },
];

const P_X = [1.0, 1.75, 2.5];

const Scene: ModelDef['Scene'] = ({ stage }) => {
  const split = stage === 1;
  const atpOn = stage <= 1;
  const enzOn = stage >= 2;
  const subTo: V3 = stage === 2 ? [2.5, 0.0, 0.3] : [1.05, 0, 0.25];
  return (
    <group>
      {/* ---------- ATP ---------- */}
      <Damp s={atpOn ? 1 : 0} to={[-1.0, 0, 0]}>
        <Part id="adenine">
          <Cyl p={[-1.7, 0.45, 0]} rt={0.38} h={0.12} c="#3b82f6" seg={6} rot={[Math.PI / 2, 0, 0]} />
          <Cyl p={[-1.15, 0.6, 0]} rt={0.3} h={0.12} c="#2563eb" seg={5} rot={[Math.PI / 2, 0, 0]} />
        </Part>
        <Rod a={[-1.4, 0.3, 0]} b={[-0.75, 0, 0]} r={0.05} c="#94a3b8" />
        <Part id="ribose">
          <Cyl p={[-0.45, -0.1, 0]} rt={0.36} h={0.12} c="#e2e8f0" seg={5} rot={[Math.PI / 2, 0, 0]} />
        </Part>
        <Rod a={[-0.1, -0.05, 0]} b={[0.8, 0, 0]} r={0.05} c="#94a3b8" />
        <Part id="phosphate">
          {P_X.map((x, i) => (
            <Damp key={i} to={split && i === 2 ? [3.4, 0.6, 0] : [x, 0, 0]}>
              <Ball r={0.27} c="#f59e0b" />
              <Ball p={[0, 0.3, 0]} r={0.1} c="#ef4444" />
              <Ball p={[0, -0.3, 0]} r={0.1} c="#ef4444" />
            </Damp>
          ))}
        </Part>
        <Part id="hebond">
          <Bob amp={0.03} speed={6}>
            <Rod a={[1.25, 0, 0]} b={[1.5, 0, 0]} r={0.07} c="#facc15" />
          </Bob>
          <Damp s={split ? 0 : 1}>
            <Bob amp={0.03} speed={6} phase={1}>
              <Rod a={[2.0, 0, 0]} b={[2.25, 0, 0]} r={0.07} c="#facc15" />
            </Bob>
          </Damp>
        </Part>
        <Part id="energy">
          <group position={[2.7, 0.3, 0]}>
            <Spin speed={2}>
              {Array.from({ length: 8 }).map((_, i) => (
                <Rod key={i} a={[Math.cos(i * 0.785) * 0.2, Math.sin(i * 0.785) * 0.2, 0]} b={[Math.cos(i * 0.785) * 0.55, Math.sin(i * 0.785) * 0.55, 0]} r={0.03} c="#fde047" />
              ))}
            </Spin>
          </group>
        </Part>
      </Damp>

      {/* ---------- Enzyme ---------- */}
      <Damp s={enzOn ? 1 : 0}>
        <Part id="enzyme">
          <mesh rotation={[0, Math.PI + (stage === 3 ? 0.25 : 0.5), 0]}>
            <sphereGeometry args={[1.3, 48, 32, 0, Math.PI * 2 - (stage === 3 ? 0.5 : 1.0)]} />
            <M c="#22c55e" side={THREE.DoubleSide} />
          </mesh>
        </Part>
        <Part id="active_site">
          <mesh position={[1.12, 0, 0.25]} rotation={[0, Math.PI / 2 - 0.25, 0]}>
            <torusGeometry args={[0.55, 0.05, 8, 32]} />
            <M c="#f472b6" e={0.4} />
          </mesh>
        </Part>
        <Part id="substrate">
          <Damp to={subTo}>
            <Bob amp={stage === 2 ? 0.1 : 0}>
              <Ball p={[0, 0.14, 0]} r={0.25} c="#38bdf8" s={[1, 0.6, 1]} />
              <Ball p={[0, -0.14, 0]} r={0.25} c="#0ea5e9" s={[1, 0.6, 1]} />
            </Bob>
          </Damp>
        </Part>
        <Part id="products">
          <Damp to={stage === 4 ? [2.4, 0.8, 0.3] : [1.05, 0.15, 0.25]}>
            <Ball r={0.25} c="#a78bfa" s={[1, 0.6, 1]} />
          </Damp>
          <Damp to={stage === 4 ? [2.5, -0.8, 0.3] : [1.05, -0.15, 0.25]}>
            <Ball r={0.25} c="#8b5cf6" s={[1, 0.6, 1]} />
          </Damp>
        </Part>
      </Damp>

      <Tag show={stage === 0} p={[0, -1.0, 0]} tone="amber">ATP = Adenine + Ribose + 3 Phosphate</Tag>
      <Tag show={stage === 1} p={[0.4, -1.0, 0]} tone="amber">ATP → ADP + Pi + năng lượng</Tag>
      <Tag show={stage === 2} p={[0.3, -1.8, 0]} tone="sky">(1) Enzyme kết hợp cơ chất</Tag>
      <Tag show={stage === 3} p={[0.3, -1.8, 0]} tone="sky">(2) Enzyme xúc tác phản ứng</Tag>
      <Tag show={stage === 4} p={[0.3, -1.8, 0]} tone="sky">(3) Sản phẩm tách khỏi enzyme</Tag>

      <Label id="adenine" p={[-2.4, 1.1, 0]} />
      <Label id="ribose" p={[-1.45, -0.7, 0]} />
      <Label id="phosphate" p={[0.75, 0.75, 0]} />
      <Label id="hebond" p={[0.6, -0.5, 0.2]} />
      <Label id="energy" p={[1.7, 1.2, 0]} />
      <Label id="enzyme" p={[-0.9, 1.5, 0]} />
      <Label id="active_site" p={[0.75, 0.75, 0.3]} />
      <Label id="substrate" p={stage === 2 ? [2.3, 0.65, 0] : [1.2, -0.55, 0.3]} />
      <Label id="products" p={[3.1, 0, 0]} />
    </group>
  );
};

const def: ModelDef = {
  id: 'm13_atp_enzyme',
  titleVi: 'ATP và cơ chế hoạt động của enzyme',
  titleEn: 'ATP and how enzymes work',
  source: 'SGK Sinh học 10 KNTT – Bài 13, tr. 78–84',
  parts,
  stages: [
    { titleVi: 'Cấu tạo phân tử ATP', titleEn: 'Structure of ATP', descVi: 'ATP gồm adenine, đường ribose và 3 gốc phosphate với hai liên kết phosphate giàu năng lượng.', descEn: 'ATP is made of adenine, ribose and three phosphates with two high-energy bonds.' },
    { titleVi: 'ATP → ADP: giải phóng năng lượng', titleEn: 'ATP → ADP: releasing energy', descVi: 'Liên kết ngoài cùng bị phá vỡ, ATP chuyển thành ADP, giải phóng năng lượng cho hoạt động sống; ADP lại được nạp năng lượng thành ATP.', descEn: 'Breaking the outer bond turns ATP into ADP and releases energy; ADP is recharged into ATP.' },
    { titleVi: 'Enzyme kết hợp với cơ chất', titleEn: 'Enzyme binds the substrate', descVi: 'Trung tâm hoạt động có cấu hình phù hợp với cơ chất, liên kết đặc hiệu.', descEn: 'The active site fits the substrate and binds it specifically.' },
    { titleVi: 'Enzyme xúc tác phản ứng', titleEn: 'The enzyme catalyses the reaction', descVi: 'Khi liên kết, cả enzyme và cơ chất đều biến đổi cấu hình làm liên kết chặt hơn; năng lượng hoạt hoá giảm.', descEn: 'Both change shape and bind tightly; the activation energy is lowered.' },
    { titleVi: 'Sản phẩm tách khỏi enzyme', titleEn: 'Products are released', descVi: 'Sản phẩm rời enzyme, enzyme trở lại hình dạng ban đầu và tiếp tục xúc tác.', descEn: 'The products leave and the enzyme returns to its original shape to work again.' },
  ],
  Scene,
  camera: [1.5, 0.6, 7],
  autoRotate: false,
};
export default def;
