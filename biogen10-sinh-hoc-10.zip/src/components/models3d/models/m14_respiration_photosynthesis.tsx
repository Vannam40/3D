import React, { useMemo } from 'react';
import * as THREE from 'three';
import { ModelDef, Part, Label, M, Ball, Rod, Damp, Cyl, Flow, Tag, Ring, Arrow, Spin, BoxM } from '../engine';

type V3 = [number, number, number];

const parts: ModelDef['parts'] = [
  { id: 'glycolysis', nameVi: 'Đường phân', nameEn: 'Glycolysis', ipa: '/ɡlaɪˈkɒləsɪs/', color: '#fbbf24', stages: [0], descVi: 'Diễn ra ở tế bào chất, không cần O₂: 1 glucose (6C) → 2 pyruvate (3C) + 2 NADH + 2 ATP.', descEn: 'In the cytoplasm without O₂: one glucose → two pyruvate + 2 NADH + 2 ATP.' },
  { id: 'mito_outer', nameVi: 'Màng ngoài ti thể', nameEn: 'Outer mitochondrial membrane', ipa: '/ˈaʊtə ˌmaɪtəˈkɒndriəl ˈmembreɪn/', color: '#fca5a5', stages: [0, 2], descVi: 'Màng ngoài trơn nhẵn; ti thể có màng kép.', descEn: 'The smooth outer membrane; mitochondria have a double membrane.' },
  { id: 'cristae', nameVi: 'Màng trong – mào (cristae)', nameEn: 'Inner membrane – cristae', ipa: '/ˈkrɪstiː/', color: '#ef4444', stages: [0, 2], descVi: 'Màng trong gấp nếp tạo mào, chứa phức hệ enzyme tổng hợp ATP; nơi diễn ra chuỗi truyền electron – giai đoạn tạo nhiều ATP nhất.', descEn: 'The folded inner membrane holds ATP-making enzymes; the electron transport chain makes the most ATP here.' },
  { id: 'matrix', nameVi: 'Chất nền ti thể', nameEn: 'Mitochondrial matrix', ipa: '/ˈmeɪtrɪks/', color: '#fdba74', stages: [0], descVi: 'Chứa nhiều enzyme hô hấp, DNA và ribosome. Pyruvate → acetyl-CoA đi vào chu trình Krebs, giải phóng CO₂, NADH, FADH₂, ATP.', descEn: 'Contains respiratory enzymes, DNA and ribosomes; pyruvate becomes acetyl-CoA and enters the Krebs cycle.' },
  { id: 'krebs', nameVi: 'Chu trình Krebs', nameEn: 'Krebs cycle', ipa: '/ˈkrebz ˌsaɪkl/', color: '#f97316', stages: [0], descVi: 'Mỗi pyruvate đi vào chu trình giải phóng 2 CO₂, 3 NADH, 1 FADH₂ và 1 ATP.', descEn: 'Each pyruvate releases 2 CO₂, 3 NADH, 1 FADH₂ and 1 ATP in the cycle.' },
  { id: 'chloro_env', nameVi: 'Màng kép lục lạp', nameEn: 'Chloroplast envelope', ipa: '/ˈklɒrəplɑːst ˈenvələʊp/', color: '#86efac', stages: [1, 2], descVi: 'Lục lạp có hai lớp màng; màng trong không gấp khúc.', descEn: 'The chloroplast has two membranes; the inner one is not folded.' },
  { id: 'granum', nameVi: 'Granum (chồng thylakoid)', nameEn: 'Granum (thylakoid stack)', ipa: '/ˈɡreɪnəm/', color: '#15803d', stages: [1, 2], descVi: 'Các túi dẹp thylakoid chứa diệp lục xếp chồng thành granum. Pha sáng diễn ra ở màng thylakoid: tạo ATP, NADPH và giải phóng O₂ từ quang phân li nước.', descEn: 'Stacks of thylakoids with chlorophyll; the light reactions make ATP and NADPH and release O₂ here.' },
  { id: 'stroma', nameVi: 'Chất nền (stroma)', nameEn: 'Stroma', ipa: '/ˈstrəʊmə/', color: '#bbf7d0', stages: [1], descVi: 'Chứa enzyme cố định CO₂, DNA vòng và ribosome; nơi diễn ra pha tối (chu trình Calvin).', descEn: 'Contains CO₂-fixing enzymes, DNA and ribosomes; the Calvin cycle happens here.' },
  { id: 'calvin', nameVi: 'Chu trình Calvin (pha tối)', nameEn: 'Calvin cycle', ipa: '/ˈkælvɪn ˌsaɪkl/', color: '#22c55e', stages: [1], descVi: '3 CO₂ được năng lượng ATP, NADPH chuyển thành 1 G3P; 2 G3P tạo 1 glucose.', descEn: 'ATP and NADPH turn 3 CO₂ into one G3P; two G3P make one glucose.' },
  { id: 'light', nameVi: 'Ánh sáng', nameEn: 'Light', ipa: '/laɪt/', color: '#fde047', stages: [1, 2], descVi: 'Photon ánh sáng đập vào diệp lục làm electron cao năng bật ra, chuyển qua chuỗi truyền electron.', descEn: 'Photons excite chlorophyll electrons, which pass along an electron transport chain.' },
  { id: 'glucose_flow', nameVi: 'Glucose + O₂', nameEn: 'Glucose + O₂', ipa: '/ˈɡluːkəʊs/', color: '#facc15', stages: [2], descVi: 'Sản phẩm quang hợp (glucose, O₂) là nguyên liệu cho hô hấp tế bào ở ti thể.', descEn: 'Products of photosynthesis (glucose, O₂) are raw materials for respiration.' },
  { id: 'co2_flow', nameVi: 'CO₂ + H₂O', nameEn: 'CO₂ + H₂O', ipa: '/ˌsiː əʊ ˈtuː/', color: '#94a3b8', stages: [2], descVi: 'Sản phẩm hô hấp (CO₂, H₂O) lại là nguyên liệu cho quang hợp → hai quá trình liên hệ mật thiết.', descEn: 'Products of respiration (CO₂, H₂O) are raw materials for photosynthesis.' },
];

const Mito: React.FC<{ full: boolean }> = ({ full }) => {
  const cristae = useMemo(() => Array.from({ length: 7 }, (_, i) => -1.2 + i * 0.4), []);
  return (
    <group>
      <Part id="mito_outer">
        <mesh rotation={[0, 0, Math.PI / 2]}>
          <capsuleGeometry args={[0.95, 2.4, 16, 32]} />
          <M c="#fca5a5" o={0.22} side={THREE.DoubleSide} />
        </mesh>
      </Part>
      <Part id="cristae">
        {cristae.map((x, i) => (
          <BoxM key={i} p={[x, i % 2 ? 0.2 : -0.2, 0]} s={[0.07, 1.25, 1.2]} c="#ef4444" o={0.85} />
        ))}
        {full && cristae.map((x, i) => <Flow key={`f${i}`} path={[[x + 0.06, -0.6, 0.3], [x + 0.06, 0, 0.35], [x + 0.06, 0.6, 0.3]]} n={2} c="#fde047" r={0.04} speed={0.5} offset={i * 0.2} />)}
      </Part>
      {full && (
        <Part id="matrix">
          <mesh rotation={[0, 0, Math.PI / 2]}>
            <capsuleGeometry args={[0.8, 2.3, 12, 24]} />
            <M c="#fdba74" o={0.14} />
          </mesh>
          <Ball p={[0.35, 0.55, 0.3]} r={0.05} c="#f8fafc" />
          <Ball p={[-0.55, -0.6, 0.2]} r={0.05} c="#f8fafc" />
        </Part>
      )}
      {full && (
        <Part id="krebs">
          <Spin speed={0.8} position={[0.2, 0, 0.75]} rotation={[0, 0, 0]}>
            <Ring R={0.32} r={0.04} c="#f97316" />
            <Ball p={[0.32, 0, 0]} r={0.07} c="#fde047" />
          </Spin>
        </Part>
      )}
    </group>
  );
};

const Chloro: React.FC<{ full: boolean }> = ({ full }) => {
  const grana: V3[] = [[-1.0, -0.1, 0], [-0.2, 0.25, 0.2], [0.65, -0.2, 0], [1.3, 0.2, -0.1]];
  return (
    <group>
      <Part id="chloro_env">
        <mesh scale={[1.9, 0.95, 1.0]}>
          <sphereGeometry args={[1, 40, 28, 0.6, Math.PI * 2 - 0.6]} />
          <M c="#86efac" o={0.3} side={THREE.DoubleSide} />
        </mesh>
      </Part>
      {full && (
        <Part id="stroma">
          <mesh scale={[1.75, 0.82, 0.86]}>
            <sphereGeometry args={[1, 32, 24]} />
            <M c="#bbf7d0" o={0.12} />
          </mesh>
        </Part>
      )}
      <Part id="granum">
        {grana.map((g, gi) => (
          <group key={gi} position={g}>
            {Array.from({ length: 5 }).map((_, k) => (
              <Cyl key={k} p={[0, -0.24 + k * 0.12, 0]} rt={0.24} h={0.08} c="#15803d" />
            ))}
          </group>
        ))}
        {grana.slice(0, -1).map((g, i) => (
          <Rod key={i} a={g} b={grana[i + 1]} r={0.03} c="#16a34a" />
        ))}
      </Part>
      {full && (
        <Part id="calvin">
          <Spin speed={-0.7} position={[0.15, -0.45, 0.55]}>
            <Ring R={0.3} r={0.04} c="#22c55e" />
            <Ball p={[0.3, 0, 0]} r={0.07} c="#a3e635" />
          </Spin>
        </Part>
      )}
    </group>
  );
};

const Scene: ModelDef['Scene'] = ({ stage }) => {
  const mitoTo: V3 = stage === 0 ? [0.6, 0, 0] : stage === 2 ? [2.2, -0.2, 0] : [6, 0, 0];
  const chloroTo: V3 = stage === 1 ? [0, 0, 0] : stage === 2 ? [-2.2, 0.3, 0] : [-6, 0, 0];
  return (
    <group>
      <Damp to={mitoTo} s={stage === 1 ? 0 : stage === 2 ? 0.75 : 1}>
        <Mito full={stage === 0} />
      </Damp>
      <Damp to={chloroTo} s={stage === 0 ? 0 : stage === 2 ? 0.8 : 1.3}>
        <Chloro full={stage === 1} />
      </Damp>

      {/* Đường phân ngoài ti thể */}
      <Part id="glycolysis">
        <group position={[-2.6, 0.2, 0]}>
          <Cyl rt={0.3} h={0.08} c="#fbbf24" seg={6} rot={[Math.PI / 2, 0, 0]} />
          <Arrow a={[0.35, 0, 0]} b={[0.95, 0, 0]} c="#fbbf24" r={0.03} />
          <Cyl p={[1.25, 0.25, 0]} rt={0.18} h={0.08} c="#f59e0b" seg={3} rot={[Math.PI / 2, 0, 0]} />
          <Cyl p={[1.25, -0.25, 0]} rt={0.18} h={0.08} c="#f59e0b" seg={3} rot={[Math.PI / 2, 0, 0]} />
          <Flow path={[[1.4, 0, 0], [1.9, 0, 0], [2.3, 0, 0]]} n={2} c="#f59e0b" r={0.07} speed={0.4} />
        </group>
      </Part>

      {/* Ánh sáng */}
      <Part id="light">
        <group position={stage === 2 ? [-2.2, 1.6, 0] : [0, 2.3, 0]}>
          {[-0.9, -0.3, 0.3, 0.9].map(x => (
            <Flow key={x} path={[[x - 0.4, 1.2, 0], [x, 0.4, 0], [x * 0.6, -0.6, 0]]} n={2} c="#fde047" r={0.06} speed={0.6} offset={x} />
          ))}
          <Ball p={[-1.6, 1.3, 0]} r={0.35} c="#fde047" />
        </group>
      </Part>

      {/* Quan hệ hai bào quan */}
      <Part id="glucose_flow">
        <Flow path={[[-0.6, 0.9, 0], [0, 1.25, 0], [0.9, 1.2, 0], [1.5, 0.7, 0]]} n={4} c="#facc15" r={0.08} speed={0.3} />
        <Arrow a={[-0.6, 1.0, 0]} b={[1.4, 0.8, 0]} c="#facc15" r={0.02} />
      </Part>
      <Part id="co2_flow">
        <Flow path={[[1.5, -1.0, 0], [0.9, -1.4, 0], [0, -1.4, 0], [-0.8, -0.9, 0]]} n={4} c="#94a3b8" r={0.08} speed={0.3} />
        <Arrow a={[1.4, -1.1, 0]} b={[-0.7, -1.0, 0]} c="#94a3b8" r={0.02} />
      </Part>

      <Tag show={stage === 0} p={[0.6, -1.45, 0]} tone="amber">C₆H₁₂O₆ + 6O₂ → 6CO₂ + 6H₂O + ATP</Tag>
      <Tag show={stage === 1} p={[0, -1.55, 0]} tone="emerald">6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂</Tag>
      <Tag show={stage === 2} p={[-2.2, -1.3, 0]} tone="emerald">Lục lạp · Chloroplast</Tag>
      <Tag show={stage === 2} p={[2.2, -1.3, 0]} tone="rose">Ti thể · Mitochondrion</Tag>

      <Label id="glycolysis" p={[-2.3, 0.85, 0]} />
      <Label id="mito_outer" p={stage === 2 ? [2.2, 0.75, 0] : [1.6, 1.2, 0]} />
      <Label id="cristae" p={stage === 2 ? [3.2, -0.35, 0] : [-0.1, -0.95, 0.6]} />
      <Label id="matrix" p={[2.15, 0.4, 0.6]} />
      <Label id="krebs" p={[0.8, 0.35, 0.9]} />
      <Label id="chloro_env" p={stage === 2 ? [-3.1, 1.1, 0] : [-2.0, 1.15, 0]} />
      <Label id="granum" p={stage === 2 ? [-2.3, -0.5, 0.5] : [-1.3, -0.65, 0.5]} />
      <Label id="stroma" p={[1.9, 0.75, 0.4]} />
      <Label id="calvin" p={[0.4, -0.85, 0.9]} />
      <Label id="light" p={stage === 2 ? [-3.8, 2.9, 0] : [-1.6, 4.0, 0]} />
      <Label id="glucose_flow" p={[0.4, 1.65, 0]} />
      <Label id="co2_flow" p={[0.4, -1.8, 0]} />
    </group>
  );
};

const def: ModelDef = {
  id: 'm14_respiration_photosynthesis',
  titleVi: 'Hô hấp tế bào và quang hợp',
  titleEn: 'Cellular respiration and photosynthesis',
  source: 'SGK Sinh học 10 KNTT – Bài 8 & Bài 14, tr. 85–93',
  parts,
  stages: [
    { titleVi: 'Hô hấp tế bào ở ti thể', titleEn: 'Cellular respiration in the mitochondrion', descVi: 'Đường phân (tế bào chất) → chu trình Krebs (chất nền) → chuỗi truyền electron (màng trong). 1 glucose tạo khoảng 30–32 ATP.', descEn: 'Glycolysis → Krebs cycle → electron transport chain; one glucose gives about 30–32 ATP.' },
    { titleVi: 'Quang hợp ở lục lạp', titleEn: 'Photosynthesis in the chloroplast', descVi: 'Pha sáng ở màng thylakoid tạo ATP, NADPH, giải phóng O₂; pha tối (chu trình Calvin) ở chất nền cố định CO₂ thành đường.', descEn: 'Light reactions on thylakoids make ATP, NADPH and O₂; the Calvin cycle in the stroma fixes CO₂ into sugar.' },
    { titleVi: 'Mối quan hệ lục lạp – ti thể', titleEn: 'Chloroplast–mitochondrion link', descVi: 'Tổng hợp cung cấp nguyên liệu cho phân giải; phân giải tạo năng lượng và nguyên liệu cho tổng hợp.', descEn: 'Synthesis supplies materials for breakdown, and breakdown supplies energy and materials for synthesis.' },
  ],
  Scene,
  camera: [0, 0.6, 7.5],
  autoRotate: false,
  stageInterval: 5000,
};
export default def;
