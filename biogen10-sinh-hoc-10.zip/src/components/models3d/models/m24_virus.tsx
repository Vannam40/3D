import React, { useMemo } from 'react';
import * as THREE from 'three';
import { ModelDef, Part, Label, M, Ball, Rod, Tube, Damp, Cyl, Bob, Tag, Spin, Ring } from '../engine';

type V3 = [number, number, number];
const SHAPES = [0];
const CYCLE = [1, 2, 3, 4, 5, 6];

const parts: ModelDef['parts'] = [
  { id: 'capsid', nameVi: 'Vỏ capsid', nameEn: 'Capsid', ipa: '/ˈkæpsɪd/', color: '#38bdf8', stages: SHAPES, descVi: 'Vỏ protein bao bọc lõi nucleic acid – thành phần có ở mọi virus. Hình dạng đa dạng: xoắn, đa diện, cầu, phức tạp.', descEn: 'The protein coat around the nucleic acid core, found in all viruses; shapes vary.' },
  { id: 'genome', nameVi: 'Lõi nucleic acid', nameEn: 'Nucleic acid core', ipa: '/njuːˌkliːɪk ˈæsɪd kɔː/', color: '#ef4444', stages: SHAPES, descVi: 'Vật chất di truyền là DNA hoặc RNA, mạch đơn hoặc mạch kép; hệ gene từ 3 đến khoảng 2 000 gene.', descEn: 'DNA or RNA, single- or double-stranded; from 3 to about 2,000 genes.' },
  { id: 'envelope', nameVi: 'Vỏ ngoài', nameEn: 'Envelope', ipa: '/ˈenvələʊp/', color: '#a78bfa', stages: SHAPES, descVi: 'Ở một số virus động vật: lớp màng kép phospholipid bên ngoài capsid.', descEn: 'In some animal viruses, a phospholipid membrane outside the capsid.' },
  { id: 'spikes', nameVi: 'Gai glycoprotein', nameEn: 'Glycoprotein spikes', ipa: '/ˌɡlaɪkəʊˈprəʊtiːn spaɪks/', color: '#facc15', stages: SHAPES, descVi: 'Trên vỏ ngoài, giúp virus tiếp cận và bám vào thụ thể của tế bào chủ.', descEn: 'On the envelope; they help the virus reach and bind host-cell receptors.' },
  { id: 'tail', nameVi: 'Đuôi và sợi đuôi (thể thực khuẩn)', nameEn: 'Tail and tail fibres', ipa: '/teɪl ənd teɪl ˈfaɪbəz/', color: '#94a3b8', stages: SHAPES, descVi: 'Bộ phận chuyên biệt của thể thực khuẩn dùng để bám và tiêm DNA vào vi khuẩn.', descEn: 'Special parts of a bacteriophage used to attach and inject DNA into a bacterium.' },
  { id: 'bacterium', nameVi: 'Tế bào vi khuẩn (vật chủ)', nameEn: 'Host bacterium', ipa: '/həʊst bækˈtɪəriəm/', color: '#22c55e', stages: CYCLE, descVi: 'Virus chỉ nhân lên được trong tế bào sống; mỗi virus chỉ lây nhiễm một số loài nhất định (phổ vật chủ).', descEn: 'Viruses multiply only inside living cells; each virus infects certain hosts (host range).' },
  { id: 'phage', nameVi: 'Thể thực khuẩn', nameEn: 'Bacteriophage', ipa: '/bækˈtɪəriəfeɪdʒ/', color: '#38bdf8', stages: [1, 2, 3, 4, 5], descVi: 'Virus kí sinh ở vi khuẩn.', descEn: 'A virus that infects bacteria.' },
  { id: 'viral_dna', nameVi: 'DNA của virus', nameEn: 'Viral DNA', ipa: '/ˈvaɪrəl ˌdiː en ˈeɪ/', color: '#ef4444', stages: [2, 3, 4], descVi: 'Được tiêm vào tế bào, thu hút enzyme của tế bào phiên mã, dịch mã và nhân bản vật chất di truyền của virus.', descEn: 'Injected into the cell, it uses host enzymes to make viral proteins and copies of itself.' },
  { id: 'parts', nameVi: 'Bộ phận virus mới', nameEn: 'New viral parts', ipa: '/njuː ˈvaɪrəl pɑːts/', color: '#7dd3fc', stages: [3], descVi: 'Giai đoạn tổng hợp: tổng hợp protein vỏ và nhân bản nucleic acid.', descEn: 'Synthesis: coat proteins and nucleic acid copies are made.' },
  { id: 'virions', nameVi: 'Virus mới', nameEn: 'New virions', ipa: '/njuː ˈvaɪriɒnz/', color: '#0ea5e9', stages: [4, 5], descVi: 'Lắp lõi nucleic acid vào vỏ protein tạo hạt virus hoàn chỉnh, rồi giải phóng ra ngoài (phá vỡ tế bào).', descEn: 'Nucleic acid is packed into coats to form complete virions, which are then released.' },
  { id: 'prophage', nameVi: 'DNA virus tích hợp (tiềm tan)', nameEn: 'Integrated viral DNA (lysogeny)', ipa: '/ˈprəʊfeɪdʒ/', color: '#f472b6', stages: [6], descVi: 'Chu kì tiềm tan: DNA virus tích hợp vào hệ gene vi khuẩn, nhân lên cùng sự phân chia tế bào; khi gặp stress, tách ra và chuyển sang sinh tan.', descEn: 'In the lysogenic cycle viral DNA joins the bacterial genome and is copied with it; stress can switch it to the lytic cycle.' },
];

/** Thể thực khuẩn thu nhỏ */
const Phage: React.FC<{ s?: number; empty?: boolean; c?: string }> = ({ s = 1, empty, c = '#38bdf8' }) => (
  <group scale={s}>
    <mesh position={[0, 0.55, 0]}>
      <icosahedronGeometry args={[0.32, 0]} />
      <M c={c} o={empty ? 0.4 : 1} />
    </mesh>
    <Cyl p={[0, 0.1, 0]} rt={0.07} h={0.6} c="#64748b" />
    <Cyl p={[0, -0.22, 0]} rt={0.16} h={0.06} c="#475569" seg={6} />
    {[0, 1, 2, 3, 4, 5].map(i => {
      const a = (i / 6) * Math.PI * 2;
      return <Tube key={i} pts={[[Math.cos(a) * 0.12, -0.24, Math.sin(a) * 0.12], [Math.cos(a) * 0.35, -0.3, Math.sin(a) * 0.35], [Math.cos(a) * 0.4, -0.55, Math.sin(a) * 0.4]]} r={0.015} c="#94a3b8" />;
    })}
  </group>
);

const Scene: ModelDef['Scene'] = ({ stage }) => {
  const tmv = useMemo(() => Array.from({ length: 70 }, (_, i) => {
    const t = i * 0.55;
    return [Math.cos(t) * 0.22, -0.9 + i * 0.026, Math.sin(t) * 0.22] as V3;
  }), []);
  const spikes = useMemo(() => Array.from({ length: 40 }, () => new THREE.Vector3().randomDirection()), []);
  const insideDna = useMemo(() => Array.from({ length: 16 }, (_, i) => [-0.9 + i * 0.12, Math.sin(i) * 0.25, Math.cos(i * 1.3) * 0.25] as V3), []);
  const bact = stage >= 1;
  const burst = stage === 5;

  return (
    <group>
      {/* -------- Bước 0: hình dạng virus -------- */}
      <Damp s={stage === 0 ? 1 : 0}>
        {/* Virus khảm thuốc lá – xoắn */}
        <group position={[-3.0, 0, 0]}>
          <Spin speed={0.3}>
            <Part id="capsid">
              {tmv.map((p, i) => <Ball key={i} p={[p[0] * 1.6, p[1], p[2] * 1.6]} r={0.09} c="#38bdf8" seg={8} />)}
            </Part>
            <Part id="genome">
              <Tube pts={tmv} r={0.03} c="#ef4444" />
            </Part>
          </Spin>
        </group>
        {/* Adenovirus – đa diện */}
        <group position={[-1.0, 0, 0]}>
          <Part id="capsid">
            <mesh>
              <icosahedronGeometry args={[0.6, 0]} />
              <M c="#0ea5e9" o={0.85} />
            </mesh>
          </Part>
          <Part id="genome">
            <Ball r={0.3} c="#ef4444" />
          </Part>
        </group>
        {/* Virus cúm – cầu, có vỏ ngoài */}
        <group position={[1.1, 0, 0]}>
          <Part id="envelope">
            <Ball r={0.62} c="#a78bfa" o={0.55} />
          </Part>
          <Part id="genome">
            {[0, 1, 2, 3].map(i => <Tube key={i} pts={[[-0.2, -0.2 + i * 0.12, 0], [0, -0.15 + i * 0.12, 0.1], [0.2, -0.2 + i * 0.12, 0]]} r={0.03} c="#ef4444" />)}
          </Part>
          <Part id="spikes">
            {spikes.map((v, i) => (
              <group key={i}>
                <Rod a={[v.x * 0.6, v.y * 0.6, v.z * 0.6]} b={[v.x * 0.8, v.y * 0.8, v.z * 0.8]} r={0.02} c="#facc15" />
                <Ball p={[v.x * 0.82, v.y * 0.82, v.z * 0.82]} r={0.04} c="#fde047" seg={6} />
              </group>
            ))}
          </Part>
        </group>
        {/* Thể thực khuẩn – phức tạp */}
        <group position={[3.1, -0.1, 0]}>
          <Part id="capsid">
            <mesh position={[0, 0.65, 0]}>
              <icosahedronGeometry args={[0.45, 0]} />
              <M c="#38bdf8" o={0.75} />
            </mesh>
          </Part>
          <Part id="genome">
            <Ball p={[0, 0.65, 0]} r={0.2} c="#ef4444" />
          </Part>
          <Part id="tail">
            <Cyl p={[0, 0.0, 0]} rt={0.09} h={0.8} c="#64748b" />
            <Cyl p={[0, -0.42, 0]} rt={0.22} h={0.07} c="#475569" seg={6} />
            {[0, 1, 2, 3, 4, 5].map(i => {
              const a = (i / 6) * Math.PI * 2;
              return <Tube key={i} pts={[[Math.cos(a) * 0.15, -0.44, Math.sin(a) * 0.15], [Math.cos(a) * 0.45, -0.5, Math.sin(a) * 0.45], [Math.cos(a) * 0.55, -0.85, Math.sin(a) * 0.55]]} r={0.02} c="#94a3b8" />;
            })}
          </Part>
        </group>
      </Damp>

      {/* -------- Chu kì nhân lên -------- */}
      <Damp s={bact ? 1 : 0}>
        <Part id="bacterium">
          <mesh rotation={[0, 0, Math.PI / 2]} scale={burst ? 1.08 : 1}>
            <capsuleGeometry args={[1.0, 2.2, 16, 32]} />
            <M c="#22c55e" o={burst ? 0.12 : 0.25} side={THREE.DoubleSide} />
          </mesh>
          {stage !== 6 && <Tube pts={[[-0.9, 0.2, 0], [-0.4, -0.3, 0.2], [0.2, 0.25, -0.1], [0.7, -0.2, 0.1], [0.3, -0.4, -0.2], [-0.5, 0.35, -0.2]]} r={0.035} c="#86efac" closed />}
        </Part>
        <Part id="phage">
          <Damp to={stage === 1 ? [0.3, 1.9, 0] : [0.3, 1.75, 0]} s={stage >= 1 && stage <= 5 ? 1 : 0}>
            <Bob amp={stage === 1 ? 0.06 : 0}>
              <Phage empty={stage >= 2} />
            </Bob>
          </Damp>
        </Part>
        <Part id="viral_dna">
          {stage === 2 && <Tube pts={[[0.3, 1.35, 0], [0.25, 0.8, 0.05], [0.0, 0.3, 0.1], [-0.4, 0.1, 0]]} r={0.04} c="#ef4444" />}
          {(stage === 3 || stage === 4) && [0, 1, 2, 3].map(i => (
            <group key={i} position={[-1.1 + i * 0.7, -0.4 + (i % 2) * 0.6, 0.2]} scale={0.5}>
              <Tube pts={insideDna} r={0.06} c="#ef4444" />
            </group>
          ))}
        </Part>
        <Part id="parts">
          {Array.from({ length: 10 }).map((_, i) => (
            <Bob key={i} amp={0.05} speed={2 + i * 0.2} phase={i}>
              <mesh position={[-1.4 + (i % 5) * 0.65, i < 5 ? 0.45 : -0.6, -0.1]}>
                <icosahedronGeometry args={[0.13, 0]} />
                <M c="#7dd3fc" />
              </mesh>
            </Bob>
          ))}
        </Part>
        <Part id="virions">
          {Array.from({ length: 8 }).map((_, i) => {
            const inside: V3 = [-1.5 + (i % 4) * 1.0, i < 4 ? 0.35 : -0.55, 0];
            const a = (i / 8) * Math.PI * 2;
            const out: V3 = [Math.cos(a) * 3.0, Math.sin(a) * 1.9, 0.3];
            return (
              <Damp key={i} to={burst ? out : inside} rot={[0, 0, burst ? a - Math.PI / 2 : 0]} speed={1.5}>
                <Phage s={0.5} c="#0ea5e9" />
              </Damp>
            );
          })}
        </Part>
        <Part id="prophage">
          <group>
            <Ring R={0.7} r={0.04} c="#86efac" rot={[Math.PI / 2, 0, 0]} />
            <mesh rotation={[Math.PI / 2, 0, 0]}>
              <torusGeometry args={[0.7, 0.07, 8, 32, 0.9]} />
              <M c="#f472b6" e={0.4} />
            </mesh>
          </group>
        </Part>
      </Damp>

      <Tag show={stage === 0} p={[-3.0, -1.35, 0]} tone="slate">Xoắn – khảm thuốc lá</Tag>
      <Tag show={stage === 0} p={[-1.0, -1.35, 0]} tone="slate">Đa diện – Adenovirus</Tag>
      <Tag show={stage === 0} p={[1.1, -1.35, 0]} tone="slate">Cầu – virus cúm</Tag>
      <Tag show={stage === 0} p={[3.1, -1.35, 0]} tone="slate">Phức tạp – thể thực khuẩn</Tag>

      <Label id="capsid" p={[-1.0, 0.95, 0]} />
      <Label id="genome" p={[-3.0, 1.25, 0]} />
      <Label id="envelope" p={[1.1, 1.05, 0]} />
      <Label id="spikes" p={[1.75, 0.55, 0.3]} />
      <Label id="tail" p={[3.75, -0.3, 0]} />
      <Label id="bacterium" p={[-2.1, -1.2, 0]} />
      <Label id="phage" p={[1.25, 2.4, 0]} />
      <Label id="viral_dna" p={stage === 2 ? [-0.6, 0.55, 0.2] : [-1.5, -0.9, 0.3]} />
      <Label id="parts" p={[1.4, 0.95, 0]} />
      <Label id="virions" p={burst ? [2.6, 2.1, 0] : [1.7, 0.95, 0]} />
      <Label id="prophage" p={[0, 0.95, 0]} />
    </group>
  );
};

const def: ModelDef = {
  id: 'm24_virus',
  titleVi: 'Cấu tạo virus và quá trình nhân lên',
  titleEn: 'Virus structure and replication',
  source: 'SGK Sinh học 10 KNTT – Bài 24, tr. 141–144',
  parts,
  stages: [
    { titleVi: 'Cấu tạo và hình dạng virus', titleEn: 'Virus structure and shapes', descVi: 'Mọi virus gồm lõi nucleic acid và vỏ capsid; một số có vỏ ngoài với gai glycoprotein. Hình dạng: xoắn, đa diện, cầu, phức tạp. Kích thước 20–300 nm.', descEn: 'All viruses have a nucleic acid core and a capsid; some have an envelope with spikes. Size: 20–300 nm.' },
    { titleVi: '(1) Hấp phụ', titleEn: '(1) Attachment', descVi: 'Virus bám vào tế bào chủ nhờ gai glycoprotein/protein bề mặt tương tác đặc hiệu với thụ thể (như chìa khoá – ổ khoá).', descEn: 'The virus binds specific receptors on the host cell (lock and key).' },
    { titleVi: '(2) Xâm nhập', titleEn: '(2) Penetration', descVi: 'Thể thực khuẩn tiêm DNA vào tế bào vi khuẩn, vỏ protein bỏ lại bên ngoài.', descEn: 'A bacteriophage injects its DNA; the protein coat stays outside.' },
    { titleVi: '(3) Tổng hợp', titleEn: '(3) Synthesis', descVi: 'DNA virus thu hút enzyme của tế bào phiên mã, dịch mã tạo protein virus và nhân bản vật chất di truyền.', descEn: 'Viral DNA uses host enzymes to make viral proteins and copies of its genome.' },
    { titleVi: '(4) Lắp ráp', titleEn: '(4) Assembly', descVi: 'Lắp lõi nucleic acid vào vỏ protein tạo hạt virus hoàn chỉnh.', descEn: 'Nucleic acid is packed into protein coats to form complete virions.' },
    { titleVi: '(5) Giải phóng – chu kì sinh tan', titleEn: '(5) Release – lytic cycle', descVi: 'Virus thoát ra khỏi tế bào chủ, phá vỡ tế bào.', descEn: 'New viruses leave the host cell, bursting it.' },
    { titleVi: 'Chu kì tiềm tan', titleEn: 'Lysogenic cycle', descVi: 'DNA virus tích hợp vào hệ gene tế bào chủ, nhân lên cùng sự phân chia của tế bào; khi gặp stress, DNA virus tách ra, gene được biểu hiện → chuyển sang sinh tan.', descEn: 'Viral DNA joins the host genome and is copied with it; under stress it leaves and the lytic cycle begins.' },
  ],
  Scene,
  camera: [0, 0.6, 8],
  autoRotate: false,
};
export default def;
