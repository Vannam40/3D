import React, { useMemo } from 'react';
import * as THREE from 'three';
import { ModelDef, Part, Label, M, Damp, Rod, Tag } from '../engine';
import { Chromatid, Centromere, MAT, PAT, MAT2, PAT2 } from './chromo';

type V3 = [number, number, number];

const parts: ModelDef['parts'] = [
  { id: 'membrane', nameVi: 'Màng tế bào', nameEn: 'Cell membrane', ipa: '/sel ˈmembreɪn/', color: '#38bdf8', descVi: 'Sau khi phân chia nhân, vùng giữa tế bào động vật co thắt lại chia tế bào thành hai tế bào con.', descEn: 'After the nucleus divides, the middle of an animal cell pinches in to form two daughter cells.' },
  { id: 'nucleus_env', nameVi: 'Màng nhân', nameEn: 'Nuclear envelope', ipa: '/ˈnjuːkliə ˈenvələʊp/', color: '#818cf8', stages: [0, 1, 4, 5], descVi: 'Tiêu biến ở kì đầu và tái xuất hiện ở kì cuối, hình thành hai nhân mới.', descEn: 'It breaks down in prophase and reappears in telophase to form two new nuclei.' },
  { id: 'nucleolus', nameVi: 'Hạch nhân', nameEn: 'Nucleolus', ipa: '/njuːˈkliːələs/', color: '#312e81', stages: [0, 4, 5], descVi: 'Tiêu biến cùng màng nhân ở kì đầu, xuất hiện lại ở kì cuối.', descEn: 'It disappears in prophase and reappears in telophase.' },
  { id: 'chromosome', nameVi: 'Nhiễm sắc thể (NST)', nameEn: 'Chromosome', ipa: '/ˈkrəʊməsəʊm/', color: '#ef4444', descVi: 'Ở pha S mỗi NST đơn nhân đôi thành NST kép gồm hai chromatid. NST co xoắn dần ở kì đầu, co xoắn tối đa ở kì giữa; ở kì sau mỗi NST kép tách thành hai NST đơn về hai cực; ở kì cuối dãn xoắn. (Mô hình: 2n = 4; màu đỏ/cam từ mẹ, xanh/tím từ bố.)', descEn: 'In S phase each chromosome is copied into two chromatids. They condense in prophase, line up in metaphase, separate in anaphase and uncoil in telophase.' },
  { id: 'centromere', nameVi: 'Tâm động', nameEn: 'Centromere', ipa: '/ˈsentrəmɪə/', color: '#fde047', stages: [1, 2, 3], descVi: 'Nơi hai chromatid chị em đính với nhau; vi ống của thoi phân bào đính vào 2 phía tâm động ở kì giữa.', descEn: 'Where the sister chromatids are joined; spindle microtubules attach to both sides of it in metaphase.' },
  { id: 'spindle', nameVi: 'Thoi phân bào', nameEn: 'Spindle', ipa: '/ˈspɪndl/', color: '#cbd5e1', stages: [1, 2, 3], descVi: 'Bắt đầu hình thành ở kì đầu, kéo các NST về hai cực ở kì sau, tiêu biến ở kì cuối.', descEn: 'It starts forming in prophase, pulls chromosomes to the poles in anaphase and disappears in telophase.' },
  { id: 'centrosome', nameVi: 'Trung thể', nameEn: 'Centrosome', ipa: '/ˈsentrəsəʊm/', color: '#fb7185', descVi: 'Nhân đôi ở kì trung gian (tế bào động vật); hai trung thể đi về hai cực, hình thành thoi phân bào.', descEn: 'It is copied in interphase (animal cells); the two centrosomes move to the poles and form the spindle.' },
  { id: 'furrow', nameVi: 'Vùng co thắt (phân chia tế bào chất)', nameEn: 'Cleavage furrow', ipa: '/ˈkliːvɪdʒ ˈfʌrəʊ/', color: '#f472b6', stages: [4], descVi: 'Ở tế bào động vật, vùng giữa tế bào dần co thắt lại; ở tế bào thực vật, vách ngăn xuất hiện ở mặt phẳng xích đạo.', descEn: 'In animal cells the middle pinches in; in plant cells a cell plate forms at the equator.' },
];

const CH = [
  { len: 0.72, col: MAT },
  { len: 0.72, col: PAT },
  { len: 0.46, col: MAT2 },
  { len: 0.46, col: PAT2 },
];
const INTER: V3[] = [[-0.35, 0.3, 0.1], [0.3, 0.25, -0.15], [-0.2, -0.35, 0.2], [0.35, -0.3, -0.1]];
const MY = [0.95, 0.15, -0.55, -1.05];

function chromatidPos(stage: number, k: number, s: number): { to: V3; sc: number; tilt: number } {
  const side = s === 0 ? -1 : 1;
  const b = INTER[k];
  switch (stage) {
    case 0: return { to: [b[0] + side * 0.04, b[1], b[2]], sc: 0.55, tilt: k * 0.9 };
    case 1: return { to: [b[0] * 1.6 + side * 0.08, b[1] * 1.6, b[2]], sc: 0.85, tilt: k * 0.6 - 0.8 };
    case 2: return { to: [side * 0.085, MY[k], 0], sc: 1, tilt: 0 };
    case 3: return { to: [side * 1.55, MY[k] * 0.75, 0], sc: 1, tilt: side * 0.25 };
    case 4: return { to: [side * 2.05, MY[k] * 0.45, 0], sc: 0.6, tilt: k * 0.7 };
    default: return { to: [side * 2.7, MY[k] * 0.45, 0], sc: 0.55, tilt: k * 0.7 };
  }
}

const POLES: Record<number, [V3, V3]> = {
  0: [[0.1, 1.35, 0.2], [0.35, 1.35, 0.2]],
  1: [[-1.7, 0.2, 0], [1.7, 0.2, 0]],
  2: [[-2.4, 0, 0], [2.4, 0, 0]],
  3: [[-2.4, 0, 0], [2.4, 0, 0]],
  4: [[-2.9, 0, 0], [2.9, 0, 0]],
  5: [[-3.5, 0, 0], [3.5, 0, 0]],
};

const Scene: ModelDef['Scene'] = ({ stage }) => {
  const cellX = stage <= 3 ? [0, 0] : stage === 4 ? [-1.15, 1.15] : [-2.7, 2.7];
  const cellS = stage === 5 ? 0.72 : stage === 4 ? 0.88 : 1;
  const nucX = stage <= 1 ? [0, 0] : stage === 4 ? [-2.05, 2.05] : [-2.7, 2.7];
  const nucS = stage === 0 ? 1 : stage === 1 ? 0.8 : stage >= 4 ? 0.62 : 0;
  const poles = POLES[stage];

  const fibres = useMemo(() => {
    if (stage < 1 || stage > 3) return [] as [V3, V3][];
    const out: [V3, V3][] = [];
    for (let k = 0; k < 4; k++)
      for (let s = 0; s < 2; s++) {
        const { to } = chromatidPos(stage, k, s);
        if (stage === 1) continue;
        out.push([poles[s], to]);
      }
    // sợi cực nối hai cực
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      out.push([[poles[0][0], poles[0][1] + Math.cos(a) * 0.05, Math.sin(a) * 0.05], [0, Math.cos(a) * 1.2, Math.sin(a) * 1.2]]);
      out.push([[poles[1][0], poles[1][1] + Math.cos(a) * 0.05, Math.sin(a) * 0.05], [0, Math.cos(a) * 1.2, Math.sin(a) * 1.2]]);
    }
    return out;
  }, [stage]);

  return (
    <group>
      <Part id="membrane">
        {[0, 1].map(i => (
          <Damp key={i} to={[cellX[i], 0, 0]} s={cellS}>
            <mesh scale={[1.45, 1.05, 1.05]}>
              <sphereGeometry args={[2.25, 48, 32]} />
              <M c="#38bdf8" o={0.13} r={0.8} />
            </mesh>
          </Damp>
        ))}
      </Part>
      <Part id="furrow">
        <mesh rotation={[0, Math.PI / 2, 0]}>
          <torusGeometry args={[1.35, 0.08, 10, 48]} />
          <M c="#f472b6" e={0.3} />
        </mesh>
      </Part>

      <Part id="nucleus_env">
        {[0, 1].map(i => (
          <Damp key={i} to={[nucX[i], 0, 0]} s={nucS}>
            <mesh>
              <sphereGeometry args={[1.25, 36, 24]} />
              <M c="#818cf8" o={0.22} side={THREE.DoubleSide} />
            </mesh>
          </Damp>
        ))}
      </Part>
      <Part id="nucleolus">
        {[0, 1].map(i => (
          <Damp key={i} to={[nucX[i] + 0.2, 0.4, 0.3]} s={stage === 0 ? 1 : 0.7}>
            <mesh>
              <sphereGeometry args={[0.22, 16, 12]} />
              <M c="#312e81" />
            </mesh>
          </Damp>
        ))}
      </Part>

      <Part id="chromosome">
        {CH.map((c, k) =>
          [0, 1].map(s => {
            const p = chromatidPos(stage, k, s);
            return <Chromatid key={`${k}-${s}`} to={p.to} len={c.len} top={c.col} bottom={c.col} s={p.sc} tilt={p.tilt} />;
          })
        )}
      </Part>
      <Part id="centromere">
        {CH.map((_, k) =>
          [0, 1].map(s => {
            const p = chromatidPos(stage, k, s);
            return <Centromere key={`${k}-${s}`} to={p.to} />;
          })
        )}
      </Part>

      <Part id="spindle">
        {fibres.map(([a, b], i) => (
          <Rod key={`${stage}-${i}`} a={a} b={b} r={0.01} c="#cbd5e1" o={0.7} />
        ))}
      </Part>

      <Part id="centrosome">
        {[0, 1].map(i => (
          <Damp key={i} to={poles[i]}>
            <mesh>
              <cylinderGeometry args={[0.07, 0.07, 0.24, 10]} />
              <M c="#fb7185" />
            </mesh>
            <mesh rotation={[Math.PI / 2, 0, 0]} position={[0.12, 0, 0]}>
              <cylinderGeometry args={[0.07, 0.07, 0.24, 10]} />
              <M c="#fb7185" />
            </mesh>
          </Damp>
        ))}
      </Part>

      <Tag show={stage === 2} p={[0, -1.75, 0]} tone="amber">Mặt phẳng xích đạo · Equator</Tag>

      <Label id="membrane" p={[stage >= 4 ? cellX[1] + 1.2 : 2.6, 1.9, 0]} />
      <Label id="nucleus_env" p={[nucX[0], 1.35, 0.4]} />
      <Label id="nucleolus" p={[nucX[0] + 0.25, 0.7, 0.5]} />
      <Label id="chromosome" p={[stage >= 3 ? -1.6 : 0.6, stage === 2 ? 1.45 : -0.9, 0.4]} />
      <Label id="centromere" p={[0.45, 0.2, 0.3]} />
      <Label id="spindle" p={[1.1, 0.95, 0.4]} />
      <Label id="centrosome" p={[poles[1][0], poles[1][1] + 0.45, 0]} />
      <Label id="furrow" p={[0, 1.6, 0.4]} />
    </group>
  );
};

const def: ModelDef = {
  id: 'm16_mitosis',
  titleVi: 'Chu kì tế bào và nguyên phân (2n = 4)',
  titleEn: 'The cell cycle and mitosis (2n = 4)',
  source: 'SGK Sinh học 10 KNTT – Bài 16, tr. 97–103',
  parts,
  stages: [
    { titleVi: 'Kì trung gian (G1 – S – G2)', titleEn: 'Interphase', descVi: 'Tế bào tăng kích thước, tổng hợp bào quan và các chất (G1); nhân đôi DNA tạo NST kép (S); chuẩn bị phân chia (G2). Trung thể nhân đôi.', descEn: 'The cell grows (G1), copies its DNA to form duplicated chromosomes (S) and prepares to divide (G2).' },
    { titleVi: 'Kì đầu', titleEn: 'Prophase', descVi: 'Thoi phân bào bắt đầu hình thành; NST dần co xoắn; màng nhân và hạch nhân tiêu biến.', descEn: 'The spindle starts to form, chromosomes condense, and the nuclear envelope and nucleolus break down.' },
    { titleVi: 'Kì giữa', titleEn: 'Metaphase', descVi: 'NST co xoắn tối đa, nằm ở mặt phẳng xích đạo; vi ống của thoi phân bào đính vào 2 phía tâm động.', descEn: 'Chromosomes are fully condensed and line up at the equator; microtubules attach to both sides of each centromere.' },
    { titleVi: 'Kì sau', titleEn: 'Anaphase', descVi: 'Hai chromatid của mỗi NST kép tách nhau thành hai NST đơn, di chuyển về hai cực. Kì sau có thời gian ngắn nhất.', descEn: 'Sister chromatids separate into single chromosomes and move to opposite poles. It is the shortest phase.' },
    { titleVi: 'Kì cuối', titleEn: 'Telophase', descVi: 'NST dãn xoắn; màng nhân và hạch nhân tái xuất hiện, hình thành hai nhân mới; thoi phân bào tiêu biến; vùng giữa tế bào co thắt.', descEn: 'Chromosomes uncoil, two new nuclei form, the spindle disappears and the cell begins to pinch in.' },
    { titleVi: 'Kết quả: 2 tế bào con', titleEn: 'Result: two daughter cells', descVi: 'Từ 1 tế bào mẹ tạo 2 tế bào con có bộ NST giống nhau và giống tế bào mẹ (2n) → duy trì ổn định vật chất di truyền.', descEn: 'One parent cell gives two daughter cells with identical chromosome sets (2n), keeping genetic material stable.' },
  ],
  Scene,
  camera: [0, 1.2, 9],
  autoRotate: false,
  stageInterval: 3200,
};
export default def;
