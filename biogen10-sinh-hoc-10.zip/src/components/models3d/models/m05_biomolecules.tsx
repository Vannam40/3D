import React, { useMemo } from 'react';
import { ModelDef, Part, Label, Ball, Rod, Tube, Damp, Spin, Cyl, Bob } from '../engine';

type V3 = [number, number, number];
const S = { carb: [0], lipid: [1], prot: [2], nucl: [3] };

const parts: ModelDef['parts'] = [
  // Carbohydrate
  { id: 'glucose', nameVi: 'Glucose (đường đơn)', nameEn: 'Glucose (monosaccharide)', ipa: '/ˈɡluːkəʊs/', color: '#fbbf24', stages: S.carb, descVi: 'Đường đơn 6 carbon; cùng fructose, galactose là nguồn năng lượng và nguyên liệu cấu tạo các phân tử khác. Carbohydrate có C : H : O = 1 : 2 : 1.', descEn: 'A 6-carbon simple sugar; a source of energy and a building block. Carbohydrates have C : H : O = 1 : 2 : 1.' },
  { id: 'glycosidic', nameVi: 'Liên kết glycosidic', nameEn: 'Glycosidic bond', ipa: '/ˌɡlaɪkəˈsɪdɪk bɒnd/', color: '#f97316', stages: S.carb, descVi: 'Liên kết cộng hoá trị nối hai đường đơn (loại đi một phân tử nước) tạo đường đôi như maltose, sucrose, lactose.', descEn: 'A covalent bond joining two sugars (removing water) to form disaccharides such as maltose.' },
  { id: 'starch', nameVi: 'Tinh bột', nameEn: 'Starch', ipa: '/stɑːtʃ/', color: '#fde68a', stages: S.carb, descVi: 'Đường đa dự trữ năng lượng ở thực vật, gồm hàng trăm đến hàng nghìn glucose, ít phân nhánh.', descEn: 'The energy store of plants: hundreds to thousands of glucose units, little branching.' },
  { id: 'glycogen', nameVi: 'Glycogen', nameEn: 'Glycogen', ipa: '/ˈɡlaɪkədʒən/', color: '#fb923c', stages: S.carb, descVi: 'Phân nhánh rất mạnh, tan tốt hơn tinh bột; dự trữ năng lượng ở động vật và nấm (gan, cơ).', descEn: 'Highly branched; stores energy in animals and fungi (liver and muscle).' },
  { id: 'cellulose', nameVi: 'Cellulose', nameEn: 'Cellulose', ipa: '/ˈseljuləʊs/', color: '#a3e635', stages: S.carb, descVi: 'Mạch thẳng, không phân nhánh; nhiều phân tử xếp song song thành bó sợi vững chắc – thành phần chính của thành tế bào thực vật.', descEn: 'Straight unbranched chains lying side by side in strong fibres – the main part of plant cell walls.' },
  // Lipid
  { id: 'glycerol', nameVi: 'Glycerol', nameEn: 'Glycerol', ipa: '/ˈɡlɪsərɒl/', color: '#f472b6', stages: S.lipid, descVi: 'Mỡ, dầu (triglyceride) gồm 1 glycerol liên kết với 3 acid béo.', descEn: 'A fat or oil (triglyceride) is one glycerol joined to three fatty acids.' },
  { id: 'fatty_acid', nameVi: 'Acid béo', nameEn: 'Fatty acid', ipa: '/ˈfæti ˈæsɪd/', color: '#fde047', stages: S.lipid, descVi: 'Mạch hydrocarbon dài kị nước. Acid béo no → mỡ rắn; acid béo không no (mạch gấp khúc) → dầu lỏng.', descEn: 'A long hydrophobic hydrocarbon chain. Saturated → solid fat; unsaturated (kinked) → liquid oil.' },
  { id: 'phospholipid', nameVi: 'Phospholipid', nameEn: 'Phospholipid', ipa: '/ˌfɒsfəʊˈlɪpɪd/', color: '#38bdf8', stages: S.lipid, descVi: 'Glycerol + 2 acid béo + nhóm phosphate: đầu ưa nước, hai đuôi kị nước → phân tử lưỡng cực, cấu tạo màng tế bào.', descEn: 'Glycerol + two fatty acids + a phosphate group: a hydrophilic head and two hydrophobic tails that form membranes.' },
  { id: 'steroid', nameVi: 'Steroid (cholesterol)', nameEn: 'Steroid (cholesterol)', ipa: '/ˈstɪərɔɪd/', color: '#c084fc', stages: S.lipid, descVi: 'Không chứa acid béo; các nguyên tử carbon tạo 4 vòng. Cholesterol là thành phần màng, tiền thân testosterone, estrogen.', descEn: 'No fatty acids; four carbon rings. Cholesterol is part of membranes and a precursor of sex hormones.' },
  // Protein
  { id: 'amino_acid', nameVi: 'Amino acid', nameEn: 'Amino acid', ipa: '/əˌmiːnəʊ ˈæsɪd/', color: '#22d3ee', stages: S.prot, descVi: 'Carbon trung tâm liên kết với nhóm amino (–NH₂), nhóm carboxyl (–COOH), nguyên tử H và nhóm R. Có 20 loại, 9 loại không thay thế.', descEn: 'A central carbon with an amino group, a carboxyl group, an H atom and an R group. There are 20 kinds.' },
  { id: 'peptide', nameVi: 'Liên kết peptide', nameEn: 'Peptide bond', ipa: '/ˈpeptaɪd bɒnd/', color: '#f8fafc', stages: S.prot, descVi: 'Liên kết cộng hoá trị nối hai amino acid (loại một phân tử nước) → chuỗi polypeptide.', descEn: 'A covalent bond joining two amino acids (removing water) to form a polypeptide.' },
  { id: 'primary', nameVi: 'Cấu trúc bậc 1', nameEn: 'Primary structure', ipa: '/ˈpraɪməri ˈstrʌktʃə/', color: '#60a5fa', stages: S.prot, descVi: 'Trình tự các amino acid trong chuỗi polypeptide.', descEn: 'The sequence of amino acids in the polypeptide chain.' },
  { id: 'secondary', nameVi: 'Cấu trúc bậc 2', nameEn: 'Secondary structure', ipa: '/ˈsekəndri ˈstrʌktʃə/', color: '#a78bfa', stages: S.prot, descVi: 'Chuỗi polypeptide cuộn xoắn (xoắn α) hoặc gấp nếp.', descEn: 'The chain coils (α-helix) or folds into sheets.' },
  { id: 'tertiary', nameVi: 'Cấu trúc bậc 3', nameEn: 'Tertiary structure', ipa: '/ˈtɜːʃəri ˈstrʌktʃə/', color: '#f472b6', stages: S.prot, descVi: 'Cấu trúc không gian ba chiều đặc trưng do tương tác giữa các nhóm R; được duy trì bởi liên kết yếu, disulphide, ion.', descEn: 'A specific 3D shape from interactions between R groups, held by weak bonds, disulphide and ionic bonds.' },
  { id: 'quaternary', nameVi: 'Cấu trúc bậc 4', nameEn: 'Quaternary structure', ipa: '/kwəˈtɜːnəri ˈstrʌktʃə/', color: '#fb7185', stages: S.prot, descVi: 'Hai hay nhiều chuỗi polypeptide liên kết với nhau. Khi pH, nhiệt độ thay đổi, protein bị biến tính, mất chức năng.', descEn: 'Two or more polypeptide chains joined together. Changes in pH or temperature cause denaturation.' },
  // Nucleic acid
  { id: 'backbone', nameVi: 'Khung đường – phosphate', nameEn: 'Sugar–phosphate backbone', ipa: '/ˈʃʊɡə ˈfɒsfeɪt ˈbækbəʊn/', color: '#94a3b8', stages: S.nucl, descVi: 'Các nucleotide nối với nhau bằng liên kết phosphodiester; hai chuỗi polynucleotide song song, ngược chiều.', descEn: 'Nucleotides are linked by phosphodiester bonds; the two strands are antiparallel.' },
  { id: 'at_pair', nameVi: 'Cặp A – T', nameEn: 'A–T base pair', ipa: '/eɪ tiː beɪs peə/', color: '#ef4444', stages: S.nucl, descVi: 'A của mạch này liên kết với T của mạch kia bằng 2 liên kết hydrogen.', descEn: 'Adenine pairs with thymine by two hydrogen bonds.' },
  { id: 'gc_pair', nameVi: 'Cặp G – C', nameEn: 'G–C base pair', ipa: '/dʒiː siː beɪs peə/', color: '#22c55e', stages: S.nucl, descVi: 'G liên kết với C bằng 3 liên kết hydrogen. Số A = T, số G = C.', descEn: 'Guanine pairs with cytosine by three hydrogen bonds; A = T and G = C.' },
  { id: 'nucleotide', nameVi: 'Nucleotide', nameEn: 'Nucleotide', ipa: '/ˈnjuːkliətaɪd/', color: '#f59e0b', stages: S.nucl, descVi: 'Gồm gốc phosphate, đường 5 carbon (deoxyribose ở DNA, ribose ở RNA) và một base nitơ.', descEn: 'A phosphate group, a 5-carbon sugar (deoxyribose in DNA, ribose in RNA) and a nitrogenous base.' },
  { id: 'rna', nameVi: 'RNA (một mạch)', nameEn: 'RNA (single strand)', ipa: '/ˌɑːr en ˈeɪ/', color: '#c084fc', stages: S.nucl, descVi: 'Một chuỗi polynucleotide; base A, U, G, C (không có T). mRNA làm khuôn, tRNA vận chuyển amino acid, rRNA cấu tạo ribosome.', descEn: 'One polynucleotide chain with bases A, U, G, C. mRNA, tRNA and rRNA have different roles.' },
];

const Hex: React.FC<{ p: V3; c: string; rot?: V3; r?: number }> = ({ p, c, rot = [Math.PI / 2, 0, 0], r = 0.2 }) => <Cyl p={p} rt={r} h={0.07} c={c} seg={6} rot={rot} />;

const BASE_COL: Record<string, string> = { A: '#ef4444', T: '#3b82f6', G: '#22c55e', C: '#f59e0b' };

const Scene: ModelDef['Scene'] = ({ stage }) => {
  // carbohydrate
  const starch = useMemo(() => Array.from({ length: 10 }, (_, i) => [Math.cos(i * 0.9) * 0.35, -1.0 + i * 0.22, Math.sin(i * 0.9) * 0.35] as V3), []);
  const glycoMain = useMemo(() => Array.from({ length: 7 }, (_, i) => [0.25 * Math.sin(i), -1.0 + i * 0.32, 0] as V3), []);
  const glycoB1 = useMemo(() => Array.from({ length: 4 }, (_, i) => [0.3 + i * 0.28, -0.35 + i * 0.22, 0.05] as V3), []);
  const glycoB2 = useMemo(() => Array.from({ length: 3 }, (_, i) => [-0.3 - i * 0.28, 0.3 + i * 0.22, -0.05] as V3), []);
  // protein
  const prim = useMemo(() => Array.from({ length: 9 }, (_, i) => [-0.9 + i * 0.22, Math.sin(i * 1.2) * 0.12, 0] as V3), []);
  const helix = useMemo(() => Array.from({ length: 40 }, (_, i) => [Math.cos(i * 0.6) * 0.25, -0.9 + i * 0.045, Math.sin(i * 0.6) * 0.25] as V3), []);
  const fold = useMemo(() => [[-0.4, -0.5, 0], [0.3, -0.6, 0.2], [0.5, 0, -0.2], [0, 0.4, 0.3], [-0.5, 0.2, -0.1], [-0.2, -0.1, 0.4], [0.3, 0.5, 0], [0.1, -0.3, -0.4], [-0.3, 0.6, 0.1]] as V3[], []);
  // DNA
  const seq = 'ATGCGTACGATC';
  const dna = useMemo(() => seq.split('').map((b, i) => {
    const t = i * 0.6;
    const y = -1.6 + i * 0.28;
    return { b, y, a: [Math.cos(t) * 0.7, y, Math.sin(t) * 0.7] as V3, c: [Math.cos(t + Math.PI) * 0.7, y, Math.sin(t + Math.PI) * 0.7] as V3 };
  }), []);
  const comp: Record<string, string> = { A: 'T', T: 'A', G: 'C', C: 'G' };
  const rna = useMemo(() => Array.from({ length: 12 }, (_, i) => [2.4 + Math.sin(i * 0.8) * 0.3, -1.5 + i * 0.26, Math.cos(i * 0.8) * 0.3] as V3), []);

  return (
    <group>
      {/* ---------- Carbohydrate ---------- */}
      <Damp s={stage === 0 ? 1 : 0}>
        <group position={[-3.2, 0, 0]}>
          <Part id="glucose">
            <Bob><Hex p={[0, 0.6, 0]} c="#fbbf24" r={0.35} /></Bob>
          </Part>
          <Part id="glycosidic">
            <Hex p={[-0.3, -0.7, 0]} c="#fbbf24" />
            <Hex p={[0.3, -0.7, 0]} c="#fbbf24" />
            <Rod a={[-0.1, -0.7, 0]} b={[0.1, -0.7, 0]} r={0.05} c="#f97316" />
          </Part>
        </group>
        <group position={[-1.2, 0, 0]}>
          <Part id="starch">
            <Spin speed={0.4}>
              {starch.map((p, i) => <Hex key={i} p={p} c="#fde68a" r={0.15} rot={[Math.PI / 2, 0, i]} />)}
              <Tube pts={starch} r={0.025} c="#f97316" />
            </Spin>
          </Part>
        </group>
        <group position={[0.8, 0, 0]}>
          <Part id="glycogen">
            {[glycoMain, glycoB1, glycoB2].map((arr, k) => (
              <group key={k}>
                {arr.map((p, i) => <Hex key={i} p={p} c="#fb923c" r={0.13} />)}
                <Tube pts={arr} r={0.02} c="#c2410c" />
              </group>
            ))}
          </Part>
        </group>
        <group position={[2.9, 0, 0]}>
          <Part id="cellulose">
            {[-0.35, 0, 0.35].map(z =>
              [-0.25, 0.25].map(x => (
                <group key={`${x}${z}`}>
                  {Array.from({ length: 7 }).map((_, i) => <Hex key={i} p={[x, -1.0 + i * 0.32, z]} c="#a3e635" r={0.13} />)}
                  <Rod a={[x, -1.0, z]} b={[x, 0.95, z]} r={0.02} c="#4d7c0f" />
                </group>
              ))
            )}
          </Part>
        </group>
      </Damp>

      {/* ---------- Lipid ---------- */}
      <Damp s={stage === 1 ? 1 : 0}>
        <group position={[-2.6, 0, 0]}>
          <Part id="glycerol">
            <Cyl p={[0, 0, 0]} rt={0.15} h={1.1} c="#f472b6" />
          </Part>
          <Part id="fatty_acid">
            {[0.4, 0, -0.4].map((y, k) => (
              <Tube key={k} pts={Array.from({ length: 9 }, (_, i) => [0.2 + i * 0.2, y + (i % 2 ? 0.07 : -0.07) - (k === 2 && i > 4 ? (i - 4) * 0.12 : 0), 0] as V3)} r={0.05} c="#fde047" />
            ))}
          </Part>
        </group>
        <group position={[0.6, 0.2, 0]}>
          <Part id="phospholipid">
            {[-1, 1].map(side =>
              Array.from({ length: 5 }).map((_, i) => (
                <group key={`${side}${i}`} position={[-0.8 + i * 0.4, side * 0.6, 0]} rotation={[0, 0, side === 1 ? 0 : Math.PI]}>
                  <Ball p={[0, 0.2, 0]} r={0.15} c="#38bdf8" />
                  <Rod a={[-0.06, 0.08, 0]} b={[-0.06, -0.45, 0]} r={0.03} c="#fde047" />
                  <Rod a={[0.06, 0.08, 0]} b={[0.06, -0.45, 0]} r={0.03} c="#fde047" />
                </group>
              ))
            )}
          </Part>
        </group>
        <group position={[2.9, 0, 0]}>
          <Part id="steroid">
            <Spin speed={0.4}>
              <Hex p={[-0.33, -0.2, 0]} c="#c084fc" r={0.22} rot={[Math.PI / 2, 0, 0]} />
              <Hex p={[0.05, 0, 0]} c="#c084fc" r={0.22} rot={[Math.PI / 2, 0, 0]} />
              <Hex p={[0.43, -0.2, 0]} c="#c084fc" r={0.22} rot={[Math.PI / 2, 0, 0]} />
              <Cyl p={[0.78, 0.02, 0]} rt={0.18} h={0.07} c="#a855f7" seg={5} rot={[Math.PI / 2, 0, 0]} />
            </Spin>
          </Part>
        </group>
      </Damp>

      {/* ---------- Protein ---------- */}
      <Damp s={stage === 2 ? 1 : 0}>
        <group position={[-3.0, 0.9, 0]}>
          <Part id="amino_acid">
            <Ball r={0.16} c="#475569" />
            <Rod a={[0, 0, 0]} b={[-0.42, 0, 0]} r={0.04} c="#94a3b8" />
            <Ball p={[-0.48, 0, 0]} r={0.13} c="#3b82f6" />
            <Rod a={[0, 0, 0]} b={[0.42, 0, 0]} r={0.04} c="#94a3b8" />
            <Ball p={[0.5, 0, 0]} r={0.13} c="#ef4444" />
            <Rod a={[0, 0, 0]} b={[0, 0.35, 0]} r={0.03} c="#94a3b8" />
            <Ball p={[0, 0.4, 0]} r={0.08} c="#f8fafc" />
            <Rod a={[0, 0, 0]} b={[0, -0.4, 0]} r={0.04} c="#94a3b8" />
            <Ball p={[0, -0.5, 0]} r={0.15} c="#22d3ee" />
          </Part>
        </group>
        <group position={[-2.9, -0.8, 0]}>
          <Part id="primary">
            {prim.map((p, i) => <Ball key={i} p={p} r={0.1} c={['#60a5fa', '#f472b6', '#facc15', '#34d399'][i % 4]} />)}
          </Part>
          <Part id="peptide">
            {prim.slice(0, -1).map((p, i) => <Rod key={i} a={p} b={prim[i + 1]} r={0.03} c="#f8fafc" />)}
          </Part>
        </group>
        <group position={[-0.6, 0, 0]}>
          <Part id="secondary">
            <Spin speed={0.5}><Tube pts={helix} r={0.06} c="#a78bfa" /></Spin>
          </Part>
        </group>
        <group position={[1.1, 0, 0]}>
          <Part id="tertiary">
            <Spin speed={0.3}><Tube pts={fold} r={0.09} c="#f472b6" /></Spin>
          </Part>
        </group>
        <group position={[3.0, 0, 0]}>
          <Part id="quaternary">
            <Spin speed={0.3}>
              {[[-0.35, 0.35, 0], [0.35, 0.35, 0], [-0.35, -0.35, 0], [0.35, -0.35, 0]].map((p, i) => (
                <group key={i} position={p as V3} scale={0.55}>
                  <Tube pts={fold} r={0.12} c={i % 2 ? '#fb7185' : '#f43f5e'} />
                </group>
              ))}
            </Spin>
          </Part>
        </group>
      </Damp>

      {/* ---------- Nucleic acid ---------- */}
      <Damp s={stage === 3 ? 1 : 0}>
        <group position={[-0.6, 0, 0]}>
          <Spin speed={0.35}>
            <Part id="backbone">
              <Tube pts={dna.map(d => d.a)} r={0.07} c="#94a3b8" />
              <Tube pts={dna.map(d => d.c)} r={0.07} c="#cbd5e1" />
            </Part>
            {dna.map((d, i) => {
              const mid: V3 = [(d.a[0] + d.c[0]) / 2, d.y, (d.a[2] + d.c[2]) / 2];
              const pair = d.b === 'A' || d.b === 'T' ? 'at_pair' : 'gc_pair';
              return (
                <Part key={i} id={pair}>
                  <Rod a={d.a} b={mid} r={0.06} c={BASE_COL[d.b]} />
                  <Rod a={mid} b={d.c} r={0.06} c={BASE_COL[comp[d.b]]} />
                </Part>
              );
            })}
          </Spin>
        </group>
        <group position={[-3.0, 0.2, 0]}>
          <Part id="nucleotide">
            <Ball p={[0, 0.45, 0]} r={0.17} c="#f59e0b" />
            <Rod a={[0, 0.45, 0]} b={[0, 0, 0]} r={0.04} c="#94a3b8" />
            <Cyl p={[0, -0.05, 0]} rt={0.2} h={0.08} c="#e2e8f0" seg={5} rot={[Math.PI / 2, 0, 0]} />
            <Rod a={[0.15, -0.1, 0]} b={[0.6, -0.4, 0]} r={0.06} c="#ef4444" />
          </Part>
        </group>
        <Part id="rna">
          <Tube pts={rna} r={0.06} c="#c084fc" />
          {rna.map((p, i) => <Rod key={i} a={p} b={[p[0] + 0.35, p[1], p[2]]} r={0.045} c={['#ef4444', '#a855f7', '#22c55e', '#f59e0b'][i % 4]} />)}
        </Part>
      </Damp>

      {/* Labels */}
      <Label id="glucose" p={[-3.2, 1.15, 0]} />
      <Label id="glycosidic" p={[-3.2, -1.15, 0]} />
      <Label id="starch" p={[-1.2, 1.35, 0]} />
      <Label id="glycogen" p={[0.8, 1.35, 0]} />
      <Label id="cellulose" p={[2.9, 1.35, 0]} />
      <Label id="glycerol" p={[-2.6, 0.85, 0]} />
      <Label id="fatty_acid" p={[-1.6, -0.75, 0]} />
      <Label id="phospholipid" p={[0.6, 1.35, 0]} />
      <Label id="steroid" p={[3.1, 0.6, 0]} />
      <Label id="amino_acid" p={[-3.0, 1.55, 0]} />
      <Label id="primary" p={[-2.9, -0.45, 0]} />
      <Label id="peptide" p={[-2.9, -1.2, 0]} />
      <Label id="secondary" p={[-0.6, 1.2, 0]} />
      <Label id="tertiary" p={[1.1, 1.0, 0]} />
      <Label id="quaternary" p={[3.0, 1.1, 0]} />
      <Label id="backbone" p={[-0.6, 2.0, 0]} />
      <Label id="at_pair" p={[0.6, -0.9, 0.5]} />
      <Label id="gc_pair" p={[0.6, 0.4, 0.5]} />
      <Label id="nucleotide" p={[-3.0, 0.95, 0]} />
      <Label id="rna" p={[2.6, 1.85, 0]} />
    </group>
  );
};

const def: ModelDef = {
  id: 'm05_biomolecules',
  titleVi: 'Các phân tử sinh học',
  titleEn: 'Biological molecules',
  source: 'SGK Sinh học 10 KNTT – Bài 5, tr. 28–40',
  parts,
  stages: [
    { titleVi: 'Carbohydrate – chất đường bột', titleEn: 'Carbohydrates', descVi: 'Đường đơn (glucose, fructose, galactose), đường đôi (liên kết glycosidic), đường đa (tinh bột, glycogen, cellulose, chitin).', descEn: 'Monosaccharides, disaccharides (glycosidic bond) and polysaccharides (starch, glycogen, cellulose, chitin).' },
    { titleVi: 'Lipid – chất béo', titleEn: 'Lipids', descVi: 'Đặc tính chung là kị nước: mỡ và dầu (glycerol + 3 acid béo), phospholipid (lưỡng cực, tạo màng), steroid (4 vòng carbon).', descEn: 'All are hydrophobic: fats and oils, phospholipids (form membranes) and steroids (four carbon rings).' },
    { titleVi: 'Protein – chất đạm', titleEn: 'Proteins', descVi: 'Đơn phân là amino acid nối bằng liên kết peptide; 4 bậc cấu trúc; cấu trúc không gian quy định chức năng.', descEn: 'Amino acids joined by peptide bonds; four levels of structure; the 3D shape determines function.' },
    { titleVi: 'Nucleic acid – DNA và RNA', titleEn: 'Nucleic acids – DNA and RNA', descVi: 'DNA: hai chuỗi polynucleotide song song ngược chiều, A–T (2 liên kết H), G–C (3 liên kết H). RNA: một chuỗi, base A, U, G, C.', descEn: 'DNA: two antiparallel strands with A–T and G–C pairs. RNA: one strand with A, U, G, C.' },
  ],
  Scene,
  camera: [0, 0.5, 8],
  autoRotate: false,
  stageInterval: 5000,
};
export default def;
