import React from 'react';
import { ModelDef, Part, Label, M, Ball, Rod, Damp, Cyl, Arrow, Tag, Tube, Bob, Spin } from '../engine';

type V3 = [number, number, number];

const parts: ModelDef['parts'] = [
  { id: 'donor', nameVi: 'Tế bào tuyến vú (cừu A)', nameEn: 'Mammary cell (sheep A)', ipa: '/ˈmæməri sel/', color: '#f472b6', stages: [0], descVi: 'Lấy nhân của tế bào tuyến vú cừu cái A.', descEn: 'The nucleus is taken from a mammary gland cell of ewe A.' },
  { id: 'egg', nameVi: 'Tế bào trứng đã loại nhân (cừu B)', nameEn: 'Enucleated egg (sheep B)', ipa: '/ɪˈnjuːklieɪtɪd eɡ/', color: '#fde68a', stages: [0], descVi: 'Loại bỏ nhân tế bào trứng của cừu cái B rồi chuyển nhân tế bào tuyến vú vào.', descEn: 'The egg of ewe B has its nucleus removed, and the mammary nucleus is inserted.' },
  { id: 'embryo', nameVi: 'Phôi', nameEn: 'Embryo', ipa: '/ˈembriəʊ/', color: '#fb923c', stages: [0], descVi: 'Tế bào trứng chuyển nhân phát triển thành phôi rồi được cấy vào tử cung cừu C.', descEn: 'The egg with the new nucleus develops into an embryo implanted into ewe C.' },
  { id: 'clone', nameVi: 'Cừu nhân bản (Dolly)', nameEn: 'Cloned sheep (Dolly)', ipa: '/kləʊnd ʃiːp/', color: '#e2e8f0', stages: [0], descVi: 'Cừu Dolly (1996) – động vật có vú nhân bản đầu tiên; giống cừu A về kiểu gene. Ở Việt Nam đã nhân bản thành công lợn Ỉ.', descEn: 'Dolly (1996), the first cloned mammal, is genetically identical to sheep A.' },
  { id: 'stem', nameVi: 'Tế bào gốc', nameEn: 'Stem cell', ipa: '/stem sel/', color: '#22d3ee', stages: [1], descVi: 'Có thể phân chia và biệt hoá thành nhiều loại tế bào. Tế bào gốc phôi (vạn năng) → mọi loại tế bào; tế bào gốc trưởng thành (đa tiềm năng) → một số loại.', descEn: 'It can divide and differentiate into many cell types: embryonic stem cells into all types, adult ones into some.' },
  { id: 'neuron', nameVi: 'Tế bào thần kinh', nameEn: 'Nerve cell', ipa: '/nɜːv sel/', color: '#a78bfa', stages: [1], descVi: 'Liệu pháp tế bào gốc kì vọng chữa tổn thương tế bào thần kinh, bệnh Parkinson.', descEn: 'Stem-cell therapy aims to repair damaged nerve cells, e.g. in Parkinson’s disease.' },
  { id: 'blood', nameVi: 'Tế bào máu', nameEn: 'Blood cells', ipa: '/blʌd selz/', color: '#ef4444', stages: [1], descVi: 'Tế bào gốc tuỷ xương được nuôi cấy rồi truyền lại để tái tạo tế bào máu, chữa ung thư máu.', descEn: 'Bone-marrow stem cells are grown and returned to rebuild blood cells.' },
  { id: 'muscle', nameVi: 'Tế bào cơ tim', nameEn: 'Heart muscle cell', ipa: '/hɑːt ˈmʌsl sel/', color: '#fb7185', stages: [1], descVi: 'Kì vọng chữa cơ tim bị tổn thương do đột quỵ.', descEn: 'Hoped to repair heart muscle damaged by stroke.' },
  { id: 'pancreas', nameVi: 'Tế bào tuyến tuỵ', nameEn: 'Pancreatic cell', ipa: '/ˌpæŋkriˈætɪk sel/', color: '#fbbf24', stages: [1], descVi: 'Liệu pháp tế bào gốc chữa tiểu đường type 1 (Hình 19.3).', descEn: 'Stem-cell therapy for type 1 diabetes.' },
  { id: 'explant', nameVi: 'Mẫu mô thực vật', nameEn: 'Plant explant', ipa: '/ˈeksplɑːnt/', color: '#4ade80', stages: [2], descVi: 'Mô tế bào chuyên hoá tách khỏi cây, nuôi cấy vô trùng với chất dinh dưỡng và hormone thực vật.', descEn: 'Specialised tissue taken from a plant and grown in sterile medium with nutrients and hormones.' },
  { id: 'callus', nameVi: 'Mô sẹo (callus)', nameEn: 'Callus', ipa: '/ˈkæləs/', color: '#d9f99d', stages: [2], descVi: 'Tế bào biệt hoá trở về trạng thái chưa phân hoá, tạo khối mô phân sinh.', descEn: 'Specialised cells return to an undifferentiated mass.' },
  { id: 'plantlet', nameVi: 'Cây con', nameEn: 'Plantlet', ipa: '/ˈplɑːntlət/', color: '#16a34a', stages: [2], descVi: 'Tế bào mô sẹo phân chia, hình thành rễ, thân, lá → cây con có kiểu gene giống nhau.', descEn: 'Callus cells form roots, stems and leaves – plantlets with identical genes.' },
  { id: 'medium', nameVi: 'Môi trường dinh dưỡng + hormone', nameEn: 'Culture medium + hormones', ipa: '/ˈkʌltʃə ˈmiːdiəm/', color: '#7dd3fc', stages: [2], descVi: 'Cơ sở khoa học: môi trường dinh dưỡng có bổ sung hormone thực vật thích hợp giúp tế bào tái sinh thành cây.', descEn: 'A nutrient medium with suitable plant hormones lets cells regenerate into plants.' },
];

const Sheep: React.FC<{ p: V3; s?: number; c?: string; face?: string }> = ({ p, s = 1, c = '#f1f5f9', face = '#1e293b' }) => (
  <group position={p} scale={s}>
    <Ball r={0.45} c={c} s={[1.4, 0.9, 0.9]} />
    <Ball p={[0.62, 0.22, 0]} r={0.2} c={face} s={[1.3, 1, 0.9]} />
    {[[-0.35, -0.12], [0.35, -0.12], [-0.35, 0.12], [0.35, 0.12]].map(([x, z], i) => (
      <Cyl key={i} p={[x, -0.5, z]} rt={0.05} h={0.4} c={face} />
    ))}
  </group>
);

const Scene: ModelDef['Scene'] = ({ stage }) => (
  <group>
    {/* Nhân bản vô tính */}
    <Damp s={stage === 0 ? 1 : 0}>
      <Sheep p={[-3.0, 1.3, 0]} s={0.75} face="#f8fafc" />
      <Tag show={stage === 0} p={[-3.0, 2.1, 0]} tone="slate">Cừu A</Tag>
      <Sheep p={[-3.0, -1.3, 0]} s={0.75} face="#0f172a" />
      <Tag show={stage === 0} p={[-3.0, -0.5, 0]} tone="slate">Cừu B</Tag>
      <Part id="donor">
        <Ball p={[-1.6, 1.0, 0]} r={0.35} c="#f472b6" o={0.6} />
        <Ball p={[-1.6, 1.0, 0]} r={0.14} c="#7c3aed" />
      </Part>
      <Part id="egg">
        <Ball p={[-1.6, -1.0, 0]} r={0.42} c="#fde68a" o={0.75} />
        <Bob amp={0.05}><Ball p={[-1.35, -0.6, 0.3]} r={0.08} c="#475569" /></Bob>
      </Part>
      <Arrow a={[-1.4, 0.7, 0]} b={[-0.55, 0.05, 0]} c="#c084fc" />
      <Arrow a={[-1.2, -0.85, 0]} b={[-0.55, -0.15, 0]} c="#fde68a" />
      <Part id="embryo">
        <group position={[0.1, 0, 0]}>
          {[[0, 0.12, 0], [0.12, -0.08, 0], [-0.12, -0.08, 0], [0, 0, 0.12]].map((p, i) => (
            <Ball key={i} p={p as V3} r={0.14} c="#fb923c" />
          ))}
          <Ball r={0.35} c="#fed7aa" o={0.3} />
        </group>
      </Part>
      <Arrow a={[0.55, 0, 0]} b={[1.4, 0, 0]} c="#fb923c" />
      <Sheep p={[2.0, -0.95, 0]} s={0.75} face="#0f172a" c="#cbd5e1" />
      <Tag show={stage === 0} p={[2.0, -1.8, 0]} tone="slate">Cừu C mang thai hộ</Tag>
      <Arrow a={[2.4, -0.2, 0]} b={[2.8, 0.55, 0]} c="#e2e8f0" />
      <Part id="clone">
        <Bob amp={0.06}><Sheep p={[3.1, 1.2, 0]} s={0.7} face="#f8fafc" /></Bob>
      </Part>
    </Damp>

    {/* Tế bào gốc */}
    <Damp s={stage === 1 ? 1 : 0}>
      <Part id="stem">
        <Bob amp={0.08}>
          <Ball r={0.65} c="#22d3ee" o={0.6} />
          <Ball r={0.25} c="#0e7490" />
        </Bob>
      </Part>
      {([[-2.4, 1.2, 0], [2.4, 1.2, 0], [-2.4, -1.3, 0], [2.4, -1.3, 0]] as V3[]).map((p, i) => (
        <Arrow key={i} a={[p[0] * 0.3, p[1] * 0.3, 0]} b={[p[0] * 0.72, p[1] * 0.72, 0]} c="#67e8f9" />
      ))}
      <Part id="neuron">
        <group position={[-2.6, 1.3, 0]}>
          <Ball r={0.25} c="#a78bfa" />
          <Tube pts={[[0.2, 0, 0], [0.6, 0.1, 0], [1.0, -0.05, 0]]} r={0.04} c="#a78bfa" />
          {[0.8, 2.2, 3.6, 5.0].map(a => <Rod key={a} a={[0, 0, 0]} b={[Math.cos(a) * 0.5, Math.sin(a) * 0.5, 0]} r={0.025} c="#c4b5fd" />)}
        </group>
      </Part>
      <Part id="blood">
        <group position={[2.5, 1.3, 0]}>
          {[[0, 0, 0], [0.4, 0.15, 0.1], [0.15, -0.35, -0.1]].map((p, i) => (
            <mesh key={i} position={p as V3} rotation={[0.4 * i, 0.8, 0]}>
              <torusGeometry args={[0.16, 0.08, 10, 20]} />
              <M c="#ef4444" />
            </mesh>
          ))}
        </group>
      </Part>
      <Part id="muscle">
        <group position={[-2.6, -1.3, 0]}>
          {[-0.2, 0, 0.2].map(y => <Ball key={y} p={[0, y, 0]} r={0.16} c="#fb7185" s={[3.2, 0.9, 0.9]} />)}
        </group>
      </Part>
      <Part id="pancreas">
        <group position={[2.6, -1.3, 0]}>
          {[[0, 0, 0], [0.3, 0.1, 0], [-0.25, 0.15, 0.1], [0.05, -0.28, 0]].map((p, i) => <Ball key={i} p={p as V3} r={0.17} c="#fbbf24" />)}
        </group>
      </Part>
    </Damp>

    {/* Nuôi cấy mô thực vật */}
    <Damp s={stage === 2 ? 1 : 0}>
      {[-2.4, 0, 2.4].map((x, i) => (
        <group key={i} position={[x, -0.8, 0]}>
          <Part id="medium">
            <Cyl rt={0.85} h={0.18} c="#7dd3fc" o={0.4} />
            <Cyl p={[0, 0.1, 0]} rt={0.9} h={0.2} c="#e0f2fe" o={0.15} open />
          </Part>
        </group>
      ))}
      <Part id="explant">
        <mesh position={[-2.4, -0.62, 0]} rotation={[-Math.PI / 2, 0, 0.4]}>
          <circleGeometry args={[0.35, 5]} />
          <M c="#4ade80" />
        </mesh>
      </Part>
      <Part id="callus">
        <group position={[0, -0.55, 0]}>
          {[[0, 0, 0], [0.15, 0.06, 0.1], [-0.14, 0.05, -0.08], [0.05, 0.12, -0.12], [-0.08, 0.1, 0.13]].map((p, i) => <Ball key={i} p={p as V3} r={0.16} c="#d9f99d" />)}
        </group>
      </Part>
      <Part id="plantlet">
        <group position={[2.4, -0.65, 0]}>
          <Ball r={0.18} c="#d9f99d" />
          <Spin speed={0.4}>
            <Cyl p={[0, 0.45, 0]} rt={0.04} h={0.8} c="#15803d" />
            <Ball p={[0.18, 0.6, 0]} r={0.14} c="#22c55e" s={[1.8, 0.5, 0.8]} />
            <Ball p={[-0.18, 0.8, 0]} r={0.14} c="#22c55e" s={[1.8, 0.5, 0.8]} />
            {[-0.4, 0, 0.4].map(a => <Rod key={a} a={[0, -0.05, 0]} b={[a * 0.5, -0.3, 0.1]} r={0.02} c="#f8fafc" />)}
          </Spin>
        </group>
      </Part>
      <Arrow a={[-1.55, -0.3, 0]} b={[-0.75, -0.3, 0]} c="#86efac" />
      <Arrow a={[0.75, -0.3, 0]} b={[1.55, -0.3, 0]} c="#86efac" />
    </Damp>

    <Label id="donor" p={[-1.6, 1.6, 0]} />
    <Label id="egg" p={[-1.6, -1.65, 0]} />
    <Label id="embryo" p={[0.1, 0.65, 0]} />
    <Label id="clone" p={[3.1, 2.0, 0]} />
    <Label id="stem" p={[0, 0.95, 0]} />
    <Label id="neuron" p={[-2.6, 2.0, 0]} />
    <Label id="blood" p={[2.6, 2.0, 0]} />
    <Label id="muscle" p={[-2.6, -1.85, 0]} />
    <Label id="pancreas" p={[2.6, -1.9, 0]} />
    <Label id="explant" p={[-2.4, 0.0, 0]} />
    <Label id="callus" p={[0, 0.05, 0]} />
    <Label id="plantlet" p={[2.4, 0.75, 0]} />
    <Label id="medium" p={[0, -1.45, 0]} />
  </group>
);

const def: ModelDef = {
  id: 'm19_cell_technology',
  titleVi: 'Công nghệ tế bào động vật và thực vật',
  titleEn: 'Animal and plant cell technology',
  source: 'SGK Sinh học 10 KNTT – Bài 19, tr. 110–114',
  parts,
  stages: [
    { titleVi: 'Nhân bản vô tính vật nuôi', titleEn: 'Animal cloning', descVi: 'Chuyển nhân tế bào tuyến vú cừu A vào trứng đã loại nhân của cừu B → phôi → cấy vào tử cung cừu C → cừu Dolly (1996).', descEn: 'A mammary nucleus from sheep A is put into an enucleated egg from sheep B; the embryo grows in sheep C → Dolly.' },
    { titleVi: 'Tế bào gốc và liệu pháp tế bào gốc', titleEn: 'Stem cells and stem-cell therapy', descVi: 'Nuôi cấy tế bào gốc trong môi trường thích hợp để phân chia rồi biệt hoá thành các loại tế bào khác nhau, thay thế tế bào bệnh.', descEn: 'Stem cells are grown to divide and differentiate into different cell types to replace diseased cells.' },
    { titleVi: 'Nuôi cấy mô tế bào thực vật', titleEn: 'Plant tissue culture', descVi: 'Mẫu mô → mô sẹo (callus) → rễ, thân, lá → cây con có kiểu gene giống nhau; nhân nhanh giống quý, cây sạch bệnh.', descEn: 'Explant → callus → roots, shoots and leaves → genetically identical plantlets.' },
  ],
  Scene,
  camera: [0, 0.4, 8],
  autoRotate: false,
  stageInterval: 5000,
};
export default def;
