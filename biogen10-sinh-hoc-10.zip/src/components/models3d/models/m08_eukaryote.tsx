import React, { useMemo } from 'react';
import * as THREE from 'three';
import { ModelDef, Part, Label, M, Ball, Tube, Ring, Rod, Shell, Damp, Spin, Cyl, Caps } from '../engine';

const ANIMAL = [0];
const PLANT = [1];

const parts: ModelDef['parts'] = [
  { id: 'membrane', nameVi: 'Màng tế bào (màng sinh chất)', nameEn: 'Plasma membrane', ipa: '/ˈplæzmə ˈmembreɪn/', color: '#38bdf8', descVi: 'Lớp kép phospholipid và protein theo mô hình khảm động; ngăn cách tế bào với môi trường, kiểm soát chất ra vào (thấm chọn lọc), tiếp nhận và truyền thông tin.', descEn: 'A phospholipid bilayer with proteins (fluid mosaic model); it is selectively permeable and receives signals.' },
  { id: 'nucleus', nameVi: 'Nhân tế bào', nameEn: 'Nucleus', ipa: '/ˈnjuːkliəs/', color: '#6366f1', descVi: 'Thường hình cầu, đường kính khoảng 5 µm; màng kép có nhiều lỗ; chứa chất nhiễm sắc (DNA). Là trung tâm điều khiển mọi hoạt động sống của tế bào.', descEn: 'Usually spherical, about 5 µm across, with a double membrane and pores; it contains DNA and controls the cell.' },
  { id: 'nucleolus', nameVi: 'Hạch nhân (nhân con)', nameEn: 'Nucleolus', ipa: '/njuːˈkliːələs/', color: '#1e1b4b', descVi: 'Nằm trong nhân, là nơi tổng hợp các phân tử rRNA.', descEn: 'Found inside the nucleus; it is where rRNA is made.' },
  { id: 'rer', nameVi: 'Lưới nội chất hạt', nameEn: 'Rough endoplasmic reticulum', ipa: '/rʌf ˌendəʊˈplæzmɪk rɪˈtɪkjələm/', color: '#0ea5e9', descVi: 'Hệ thống ống và túi dẹp nối với màng nhân, có ribosome bám; protein tổng hợp được đưa vào túi vận chuyển tới bộ máy Golgi.', descEn: 'Tubes and flat sacs joined to the nuclear envelope, studded with ribosomes; it sends proteins to the Golgi.' },
  { id: 'ser', nameVi: 'Lưới nội chất trơn', nameEn: 'Smooth endoplasmic reticulum', ipa: '/smuːð ˌendəʊˈplæzmɪk rɪˈtɪkjələm/', color: '#22d3ee', descVi: 'Ít hoặc không có ribosome; tổng hợp lipid, chuyển hoá đường, khử độc, dự trữ Ca²⁺ (phát triển mạnh ở tế bào gan).', descEn: 'Few or no ribosomes; makes lipids, detoxifies and stores Ca²⁺ – well developed in liver cells.' },
  { id: 'ribosome', nameVi: 'Ribosome', nameEn: 'Ribosome', ipa: '/ˈraɪbəsəʊm/', color: '#e2e8f0', descVi: 'Không có màng, đường kính khoảng 150 Å, gồm rRNA và protein với 2 tiểu đơn vị; là "nhà máy" tổng hợp protein.', descEn: 'No membrane, about 150 Å, made of rRNA and protein with two subunits – the protein factory.' },
  { id: 'golgi', nameVi: 'Bộ máy Golgi', nameEn: 'Golgi apparatus', ipa: '/ˈɡɒldʒi ˌæpəˈreɪtəs/', color: '#f59e0b', descVi: 'Các túi dẹp xếp song song, tách rời; chế biến, lắp ráp, đóng gói và phân phối protein, lipid.', descEn: 'Stacked, separate flat sacs that modify, package and send out proteins and lipids.' },
  { id: 'mito', nameVi: 'Ti thể', nameEn: 'Mitochondrion', ipa: '/ˌmaɪtəˈkɒndriən/', color: '#ef4444', descVi: 'Màng kép, màng trong gấp nếp thành mào (cristae); chứa DNA và ribosome riêng; "nhà máy điện" tổng hợp ATP.', descEn: 'Double membrane with folded cristae; has its own DNA and ribosomes – the power plant that makes ATP.' },
  { id: 'lysosome', nameVi: 'Lysosome', nameEn: 'Lysosome', ipa: '/ˈlaɪsəsəʊm/', color: '#a855f7', stages: ANIMAL, descVi: 'Túi màng đơn chứa enzyme thuỷ phân; hình thành từ bộ máy Golgi; tái chế bào quan hỏng, tiêu hoá thức ăn theo thực bào (có ở tế bào động vật).', descEn: 'A single-membrane sac of digestive enzymes formed from the Golgi; it recycles old organelles (animal cells).' },
  { id: 'peroxisome', nameVi: 'Peroxysome', nameEn: 'Peroxisome', ipa: '/pəˈrɒksɪsəʊm/', color: '#84cc16', descVi: 'Hình cầu, màng đơn; chứa enzyme phân giải H₂O₂, khử độc và chuyển hoá lipid.', descEn: 'A small single-membrane sphere with enzymes that break down H₂O₂ and lipids.' },
  { id: 'centrosome', nameVi: 'Trung thể', nameEn: 'Centrosome', ipa: '/ˈsentrəsəʊm/', color: '#fb7185', stages: ANIMAL, descVi: 'Gồm 2 trung tử xếp vuông góc, mỗi trung tử gồm nhiều bộ ba vi ống; hình thành thoi phân bào (tế bào động vật).', descEn: 'Two centrioles at right angles made of microtubule triplets; it forms the spindle (animal cells).' },
  { id: 'cytoskeleton', nameVi: 'Khung xương tế bào', nameEn: 'Cytoskeleton', ipa: '/ˌsaɪtəʊˈskelɪtn/', color: '#94a3b8', descVi: 'Mạng vi sợi, sợi trung gian và vi ống; nâng đỡ, duy trì hình dạng, neo giữ bào quan, hỗ trợ di chuyển.', descEn: 'Microfilaments, intermediate filaments and microtubules that support the cell and anchor organelles.' },
  { id: 'wall', nameVi: 'Thành tế bào', nameEn: 'Cell wall', ipa: '/sel wɔːl/', color: '#16a34a', stages: PLANT, descVi: 'Ở thực vật cấu tạo từ cellulose (gia cố lignin); ở nấm là chitin. Chức năng bảo vệ, định hình tế bào.', descEn: 'Made of cellulose in plants (chitin in fungi); it protects the cell and gives it shape.' },
  { id: 'chloroplast', nameVi: 'Lục lạp', nameEn: 'Chloroplast', ipa: '/ˈklɒrəplɑːst/', color: '#22c55e', stages: PLANT, descVi: 'Màng kép; bên trong có thylakoid chứa diệp lục xếp chồng thành granum, chất nền stroma; nơi quang hợp.', descEn: 'Double membrane with stacks of thylakoids (grana) in the stroma; the site of photosynthesis.' },
  { id: 'vacuole', nameVi: 'Không bào trung tâm', nameEn: 'Central vacuole', ipa: '/ˈsentrəl ˈvækjuəʊl/', color: '#7dd3fc', stages: PLANT, descVi: 'Một lớp màng; không bào lớn giữa tế bào thực vật giúp điều hoà áp suất thẩm thấu, chứa sắc tố, chất dự trữ, chất thải.', descEn: 'A large single-membrane sac in plant cells that controls osmotic pressure and stores substances.' },
];

const Scene: ModelDef['Scene'] = ({ stage }) => {
  const plant = stage === 1;
  const freeRibos = useMemo(() => Array.from({ length: 60 }, () => {
    const v = new THREE.Vector3().randomDirection().multiplyScalar(1.3 + Math.random() * 1.4);
    return [v.x, v.y * 0.8, v.z] as [number, number, number];
  }), []);
  const serPts = useMemo(() => Array.from({ length: 3 }, (_, k) => Array.from({ length: 8 }, (_, i) => [1.0 + i * 0.12, -0.9 + Math.sin(i * 1.3 + k) * 0.25 - k * 0.25, 0.6 + Math.cos(i + k) * 0.25] as [number, number, number])), []);
  const fibres = useMemo(() => Array.from({ length: 14 }, () => {
    const a = new THREE.Vector3().randomDirection().multiplyScalar(2.6);
    const b = new THREE.Vector3().randomDirection().multiplyScalar(2.6);
    return [[a.x, a.y * 0.85, a.z], [b.x, b.y * 0.85, b.z]] as [number, number, number][];
  }), []);
  const nucPos: [number, number, number] = plant ? [-1.55, 0.3, 0.3] : [-0.4, 0.1, 0];
  const cellScale: [number, number, number] = plant ? [1.25, 0.95, 0.95] : [1, 0.85, 1];

  return (
    <group>
      {/* Màng tế bào – cắt mở để nhìn bên trong */}
      <Part id="membrane">
        <Shell r={3} c="#38bdf8" o={0.22} s={cellScale} />
      </Part>
      {/* Thành tế bào thực vật */}
      <Part id="wall">
        <mesh scale={[1.29, 0.99, 0.99]} rotation={[0, 0.6, 0]}>
          <sphereGeometry args={[3.08, 48, 32, 1.35, Math.PI * 2 - 1.35]} />
          <M c="#16a34a" o={0.35} side={THREE.DoubleSide} r={0.9} />
        </mesh>
      </Part>

      {/* Nhân */}
      <Damp to={nucPos}>
        <Part id="nucleus">
          <mesh rotation={[0, 0.6, 0]}>
            <sphereGeometry args={[0.95, 40, 28, 1.6, Math.PI * 2 - 1.6]} />
            <M c="#6366f1" o={0.75} side={THREE.DoubleSide} />
          </mesh>
          {Array.from({ length: 8 }).map((_, i) => (
            <Ring key={i} p={[Math.cos(i) * 0.96, Math.sin(i * 1.7) * 0.5, Math.sin(i) * 0.96]} R={0.07} r={0.02} c="#c7d2fe" rot={[i, i * 0.5, 0]} />
          ))}
          <Tube pts={[[-0.4, 0.2, 0], [-0.1, -0.3, 0.2], [0.3, 0.1, -0.1], [0.1, 0.45, 0.2], [-0.3, 0.4, -0.2], [0.35, -0.35, 0]]} r={0.03} c="#a5b4fc" />
        </Part>
        <Part id="nucleolus">
          <Ball p={[0.15, -0.05, 0.05]} r={0.32} c="#312e81" />
        </Part>
        {/* Lưới nội chất hạt bao quanh nhân */}
        <Part id="rer">
          {[0, 1, 2, 3].map(k => (
            <group key={k}>
              <Ring R={1.15 + k * 0.18} r={0.05} c="#0ea5e9" rot={[Math.PI / 2, 0, 0.3 + k * 0.08]} arc={Math.PI * 1.1} />
              {Array.from({ length: 10 }).map((_, i) => {
                const t = 0.3 + k * 0.08 + (i / 10) * Math.PI * 1.1;
                const R = 1.15 + k * 0.18;
                return <Ball key={i} p={[Math.cos(t) * R, 0.07, -Math.sin(t) * R * 0 + Math.sin(t) * R]} r={0.035} c="#e2e8f0" seg={6} />;
              })}
            </group>
          ))}
        </Part>
      </Damp>

      <Part id="ser">
        {serPts.map((pts, i) => (
          <Tube key={i} pts={pts} r={0.06} c="#22d3ee" />
        ))}
      </Part>

      {/* Bộ máy Golgi */}
      <Damp to={plant ? [0.9, 1.4, -0.4] : [1.5, 0.9, 0.2]} rot={[0.3, 0.4, 0.2]}>
        <Part id="golgi">
          {[0, 1, 2, 3, 4].map(i => (
            <mesh key={i} position={[0, i * 0.12 - 0.24, 0]} scale={[1, 0.35, 1]}>
              <torusGeometry args={[0.55 - i * 0.04, 0.07, 10, 32, Math.PI * 1.2]} />
              <M c="#f59e0b" />
            </mesh>
          ))}
          <Ball p={[0.7, 0.35, 0.2]} r={0.08} c="#fcd34d" />
          <Ball p={[0.75, -0.1, -0.15]} r={0.07} c="#fcd34d" />
        </Part>
      </Damp>

      {/* Ti thể */}
      <Part id="mito">
        {([[1.2, -0.5, -1.2, 0.4], [-0.8, -1.3, 1.0, 1.2], [0.5, 1.4, 1.2, 2.0], [-1.7, -0.6, -1.2, 0.9]] as number[][]).map(([x, y, z, r], i) => (
          <group key={i} position={[x, y, z]} rotation={[0, r, 0.4]}>
            <Caps len={0.6} r={0.24} c="#ef4444" o={0.75} rot={[0, 0, Math.PI / 2]} />
            <Tube pts={Array.from({ length: 9 }, (_, k) => [-0.4 + k * 0.1, (k % 2 ? 0.14 : -0.14), 0] as [number, number, number])} r={0.025} c="#fecaca" />
          </group>
        ))}
      </Part>

      {/* Lysosome & peroxysome */}
      <Part id="lysosome">
        <Ball p={[0.6, -1.2, 1.3]} r={0.2} c="#a855f7" />
        <Ball p={[-1.6, 1.1, 0.6]} r={0.16} c="#a855f7" />
        <Ball p={[2.0, -0.2, -0.6]} r={0.17} c="#a855f7" />
      </Part>
      <Part id="peroxisome">
        <Ball p={[0.2, -1.6, -0.6]} r={0.14} c="#84cc16" />
        <Ball p={[-0.6, 1.4, -1.0]} r={0.13} c="#84cc16" />
      </Part>

      {/* Ribosome tự do */}
      <Part id="ribosome">
        {freeRibos.map((p, i) => (
          <Ball key={i} p={p} r={0.04} c="#e2e8f0" seg={6} />
        ))}
      </Part>

      {/* Trung thể */}
      <Part id="centrosome">
        <group position={[0.9, 0.2, 1.4]}>
          <Cyl rt={0.08} h={0.32} c="#fb7185" />
          <Cyl rt={0.08} h={0.32} c="#fb7185" rot={[Math.PI / 2, 0, 0]} p={[0.18, 0, 0]} />
        </group>
      </Part>

      {/* Khung xương */}
      <Part id="cytoskeleton">
        {fibres.map(([a, b], i) => (
          <Rod key={i} a={a} b={b} r={0.012} c="#94a3b8" o={0.6} />
        ))}
      </Part>

      {/* Thực vật: không bào và lục lạp */}
      <Part id="vacuole">
        <Ball p={[0.6, -0.3, 0]} r={1.5} c="#7dd3fc" o={0.35} s={[1.1, 0.9, 0.9]} />
      </Part>
      <Part id="chloroplast">
        {([[2.4, 0.9, 0.6], [2.2, -1.1, 0.9], [-0.4, 1.9, 0.5], [-2.3, -1.2, 0.2], [1.6, 1.6, -1.0]] as [number, number, number][]).map((p, i) => (
          <Spin key={i} speed={0.1} position={p}>
            <Ball r={0.42} c="#22c55e" o={0.8} s={[1.3, 0.6, 0.8]} />
            {[-0.25, 0, 0.25].map(x => (
              <group key={x} position={[x, 0, 0.05]}>
                {[0, 1, 2].map(k => (
                  <Cyl key={k} p={[0, k * 0.05 - 0.05, 0]} rt={0.09} h={0.035} c="#14532d" />
                ))}
              </group>
            ))}
          </Spin>
        ))}
      </Part>

      <Label id="membrane" p={[-2.3, 1.9, 0.9]} />
      <Label id="wall" p={[3.6, -1.6, 0.6]} />
      <Label id="nucleus" p={[nucPos[0] - 0.4, nucPos[1] + 1.05, nucPos[2]]} />
      <Label id="nucleolus" p={[nucPos[0] + 0.2, nucPos[1] - 0.15, nucPos[2] + 0.4]} />
      <Label id="rer" p={[nucPos[0] - 1.3, nucPos[1] - 0.5, nucPos[2] + 0.6]} />
      <Label id="ser" p={[1.6, -1.35, 0.8]} />
      <Label id="golgi" p={plant ? [0.9, 2.0, -0.4] : [1.9, 1.45, 0.2]} />
      <Label id="mito" p={[1.2, -0.95, -1.2]} />
      <Label id="lysosome" p={[0.6, -1.55, 1.3]} />
      <Label id="peroxisome" p={[0.2, -1.95, -0.6]} />
      <Label id="ribosome" p={[-1.9, 0.2, 1.2]} />
      <Label id="centrosome" p={[1.1, 0.6, 1.5]} />
      <Label id="cytoskeleton" p={[-2.2, -1.9, 0.4]} />
      <Label id="vacuole" p={[0.7, -0.2, 1.4]} />
      <Label id="chloroplast" p={[2.5, 1.35, 0.6]} />
    </group>
  );
};

const def: ModelDef = {
  id: 'm08_eukaryote',
  titleVi: 'Tế bào nhân thực: động vật và thực vật',
  titleEn: 'Eukaryotic cells: animal and plant',
  source: 'SGK Sinh học 10 KNTT – Bài 8, tr. 48–60',
  parts,
  stages: [
    { titleVi: 'Tế bào động vật', titleEn: 'Animal cell', descVi: 'Có nhân chính thức, hệ thống nội màng, ti thể, lysosome, trung thể, khung xương tế bào; không có thành tế bào.', descEn: 'It has a true nucleus, an endomembrane system, mitochondria, lysosomes and a centrosome, but no cell wall.' },
    { titleVi: 'Tế bào thực vật', titleEn: 'Plant cell', descVi: 'Có thêm thành tế bào cellulose, lục lạp và không bào trung tâm lớn; không có trung thể.', descEn: 'It also has a cellulose cell wall, chloroplasts and a large central vacuole; no centrosome.' },
  ],
  Scene,
  camera: [0, 2.2, 8],
  stageInterval: 5000,
};
export default def;
