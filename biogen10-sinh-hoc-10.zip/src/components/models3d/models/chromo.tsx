import React from 'react';
import { Damp, M } from '../engine';

type V3 = [number, number, number];

/** Một chromatid gồm vai trên + vai dưới (để thể hiện trao đổi chéo) và tâm động */
export const Chromatid: React.FC<{ to: V3; len: number; top: string; bottom: string; s?: number; tilt?: number; r?: number }> = ({ to, len, top, bottom, s = 1, tilt = 0, r = 0.075 }) => (
  <Damp to={to} s={s} rot={[0, 0, tilt]} speed={2.6}>
    <mesh position={[0, len * 0.28, 0]}>
      <capsuleGeometry args={[r, len * 0.45, 6, 12]} />
      <M c={top} r={0.35} />
    </mesh>
    <mesh position={[0, -len * 0.33, 0]}>
      <capsuleGeometry args={[r, len * 0.55, 6, 12]} />
      <M c={bottom} r={0.35} />
    </mesh>
  </Damp>
);

export const Centromere: React.FC<{ to: V3; s?: number }> = ({ to, s = 1 }) => (
  <Damp to={to} s={s} speed={2.6}>
    <mesh>
      <sphereGeometry args={[0.07, 12, 8]} />
      <M c="#fde047" e={0.3} />
    </mesh>
  </Damp>
);

export const MAT = '#ef4444';
export const PAT = '#3b82f6';
export const MAT2 = '#f97316';
export const PAT2 = '#8b5cf6';
