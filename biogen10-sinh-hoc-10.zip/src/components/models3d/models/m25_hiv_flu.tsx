import React, { useMemo } from 'react';
import * as THREE from 'three';
import { ModelDef, Part, Label, M, Ball, Rod, Tube, Damp, Spin, Bob, Tag, Flow, Cyl } from '../engine';

type V3 = [number, number, number];
const HIV = [0];
const FLU = [1];
const INF = [2];

const parts: ModelDef['parts'] = [
  { id: 'hiv_env', nameVi: 'Vỏ ngoài (HIV)', nameEn: 'Envelope (HIV)', ipa: '/ˈenvələʊp/', color: '#a78bfa', stages: HIV, descVi: 'Phospholipid kép bên ngoài capsid, có các gai glycoprotein.', descEn: 'A phospholipid bilayer outside the capsid, with glycoprotein spikes.' },
  { id: 'hiv_gp', nameVi: 'Gai glycoprotein (HIV)', nameEn: 'Glycoprotein spikes (HIV)', ipa: '/ˌɡlaɪkəʊˈprəʊtiːn spaɪks/', color: '#facc15', stages: [0, 2], descVi: 'Giúp HIV liên kết với thụ thể đặc hiệu trên tế bào bạch cầu của hệ miễn dịch (T4, đại thực bào) để xâm nhập.', descEn: 'They bind specific receptors on white blood cells (T4 cells, macrophages) so HIV can enter.' },
  { id: 'hiv_capsid', nameVi: 'Vỏ capsid (HIV)', nameEn: 'Capsid (HIV)', ipa: '/ˈkæpsɪd/', color: '#38bdf8', stages: HIV, descVi: 'Bên trong chứa 2 phân tử RNA và các enzyme.', descEn: 'Holds two RNA molecules and enzymes.' },
  { id: 'hiv_rna', nameVi: '2 phân tử RNA', nameEn: 'Two RNA molecules', ipa: '/tuː ˌɑːr en ˈeɪ ˈmɒlɪkjuːlz/', color: '#ef4444', stages: HIV, descVi: 'HIV có vật chất di truyền là RNA; khi nhân lên tạo rất nhiều biến thể mới.', descEn: 'HIV’s genetic material is RNA; it produces many new variants as it multiplies.' },
  { id: 'rt', nameVi: 'Enzyme phiên mã ngược', nameEn: 'Reverse transcriptase', ipa: '/rɪˈvɜːs trænˈskrɪpteɪz/', color: '#f97316', stages: HIV, descVi: 'Tổng hợp DNA từ mạch khuôn RNA. Một số thuốc ức chế enzyme và protein của HIV.', descEn: 'Makes DNA from an RNA template; some drugs block HIV enzymes.' },
  { id: 'integrase', nameVi: 'Enzyme integrase', nameEn: 'Integrase', ipa: '/ˈɪntɪɡreɪz/', color: '#22c55e', stages: HIV, descVi: 'Giúp tích hợp hệ gene virus vào hệ gene tế bào chủ – vì vậy chưa thể loại bỏ HIV khỏi tế bào.', descEn: 'Inserts the viral genome into the host genome, which is why HIV cannot be removed from cells.' },
  { id: 'protease', nameVi: 'Enzyme phân giải protein', nameEn: 'Protease', ipa: '/ˈprəʊtieɪz/', color: '#ec4899', stages: HIV, descVi: 'Enzyme phân giải protein trong hạt HIV, giúp lắp ráp virus mới.', descEn: 'An enzyme that cuts proteins, helping new viruses assemble.' },
  { id: 'flu_env', nameVi: 'Vỏ ngoài (virus cúm)', nameEn: 'Envelope (influenza)', ipa: '/ˈenvələʊp/', color: '#c4b5fd', stages: FLU, descVi: 'Lớp kép phospholipid có các gai glycoprotein H và N.', descEn: 'A phospholipid bilayer with H and N glycoprotein spikes.' },
  { id: 'flu_h', nameVi: 'Gai H', nameEn: 'H spikes (haemagglutinin)', ipa: '/ˌhiːməˈɡluːtɪnɪn/', color: '#facc15', stages: FLU, descVi: 'Nhận biết và liên kết với thụ thể đặc hiệu trên màng tế bào chủ (niêm mạc đường hô hấp). Có 16 phân nhóm H1–H16.', descEn: 'Recognise and bind host-cell receptors in the airway; 16 subtypes H1–H16.' },
  { id: 'flu_n', nameVi: 'Gai N', nameEn: 'N spikes (neuraminidase)', ipa: '/ˌnjʊərəˈmɪnɪdeɪz/', color: '#22c55e', stages: FLU, descVi: 'Là enzyme phá huỷ tế bào chủ, giải phóng virus sau khi nhân lên. Có 9 phân nhóm N1–N9 (VD H1N1, H3N2).', descEn: 'An enzyme that releases new viruses from the host cell; 9 subtypes N1–N9 (e.g. H1N1).' },
  { id: 'flu_rna', nameVi: '7–8 đoạn RNA', nameEn: '7–8 RNA segments', ipa: '/ˈseɡmənts/', color: '#ef4444', stages: FLU, descVi: 'Mỗi đoạn mã hoá một hoặc hai protein; RNA được dùng như mRNA để dịch mã. Virus cúm chỉ nhân lên theo chu kì sinh tan.', descEn: 'Each segment codes for one or two proteins; flu viruses only follow the lytic cycle.' },
  { id: 't4', nameVi: 'Tế bào bạch cầu T4', nameEn: 'T4 white blood cell', ipa: '/ˌtiː ˈfɔː waɪt blʌd sel/', color: '#7dd3fc', stages: INF, descVi: 'HIV tiếp cận bạch cầu nhờ gai glycoprotein liên kết thụ thể; vỏ ngoài dung hợp với màng sinh chất đưa virus vào tế bào. Số lượng T4 giảm dần → suy giảm miễn dịch.', descEn: 'HIV binds receptors on T4 cells; its envelope fuses with the membrane. T4 numbers fall over time.' },
  { id: 'receptor', nameVi: 'Thụ thể đặc hiệu', nameEn: 'Specific receptor', ipa: '/spəˈsɪfɪk rɪˈseptə/', color: '#fb7185', stages: INF, descVi: 'HIV chỉ xâm nhập được tế bào có thụ thể phù hợp với gai glycoprotein của nó.', descEn: 'HIV can only enter cells with receptors that match its spikes.' },
];

const Spikes: React.FC<{ n: number; r: number; c: string; c2?: string; split?: boolean; seed?: number }> = ({ n, r, c, c2, split, seed = 1 }) => {
  const dirs = useMemo(() => {
    const out: { v: THREE.Vector3; k: number }[] = [];
    for (let i = 0; i < n; i++) {
      const y = 1 - (i / (n - 1)) * 2;
      const rad = Math.sqrt(1 - y * y);
      const th = i * 2.399 * seed;
      out.push({ v: new THREE.Vector3(Math.cos(th) * rad, y, Math.sin(th) * rad), k: i % 3 });
    }
    return out;
  }, [n, seed]);
  return (
    <>
      {dirs.map(({ v, k }, i) => {
        const isN = split && k === 0;
        if (split && c2 && (isN ? false : false)) return null;
        return (
          <group key={i}>
            <Rod a={[v.x * r, v.y * r, v.z * r]} b={[v.x * (r + 0.25), v.y * (r + 0.25), v.z * (r + 0.25)]} r={0.025} c={isN ? c2! : c} />
            <Ball p={[v.x * (r + 0.28), v.y * (r + 0.28), v.z * (r + 0.28)]} r={isN ? 0.07 : 0.055} c={isN ? c2! : c} seg={8} />
          </group>
        );
      })}
    </>
  );
};

/** Chỉ một nhóm gai (H hoặc N) của virus cúm để bấm riêng */
const FluSpikes: React.FC<{ kind: 'H' | 'N' }> = ({ kind }) => {
  const dirs = useMemo(() => Array.from({ length: 48 }, (_, i) => {
    const y = 1 - (i / 47) * 2;
    const rad = Math.sqrt(1 - y * y);
    const th = i * 2.399;
    return { v: new THREE.Vector3(Math.cos(th) * rad, y, Math.sin(th) * rad), n: i % 4 === 0 };
  }), []);
  const r = 1.1;
  return (
    <>
      {dirs.filter(d => (kind === 'N' ? d.n : !d.n)).map(({ v }, i) => (
        <group key={i}>
          <Rod a={[v.x * r, v.y * r, v.z * r]} b={[v.x * (r + 0.28), v.y * (r + 0.28), v.z * (r + 0.28)]} r={0.03} c={kind === 'N' ? '#22c55e' : '#facc15'} />
          {kind === 'N' ? (
            <mesh position={[v.x * (r + 0.32), v.y * (r + 0.32), v.z * (r + 0.32)]}>
              <boxGeometry args={[0.12, 0.12, 0.12]} />
              <M c="#22c55e" />
            </mesh>
          ) : (
            <Ball p={[v.x * (r + 0.3), v.y * (r + 0.3), v.z * (r + 0.3)]} r={0.06} c="#facc15" seg={8} />
          )}
        </group>
      ))}
    </>
  );
};

const Scene: ModelDef['Scene'] = ({ stage }) => (
  <group>
    {/* HIV */}
    <Damp s={stage === 0 ? 1 : 0}>
      <Spin speed={0.15}>
        <Part id="hiv_env">
          <mesh rotation={[0, 0.5, 0]}>
            <sphereGeometry args={[1.4, 40, 28, 0.4, Math.PI * 2 - 1.3]} />
            <M c="#a78bfa" o={0.55} side={THREE.DoubleSide} />
          </mesh>
        </Part>
        <Part id="hiv_gp">
          <Spikes n={36} r={1.4} c="#facc15" />
        </Part>
      </Spin>
      <Part id="hiv_capsid">
        <mesh rotation={[0, 0, 0.5]}>
          <coneGeometry args={[0.55, 1.5, 24, 1, true]} />
          <M c="#38bdf8" o={0.55} side={THREE.DoubleSide} />
        </mesh>
      </Part>
      <Part id="hiv_rna">
        <group rotation={[0, 0, 0.5]}>
          <Tube pts={[[-0.06, -0.5, 0], [0.05, -0.2, 0.05], [-0.05, 0.1, 0], [0.04, 0.4, -0.04]]} r={0.035} c="#ef4444" />
          <Tube pts={[[0.1, -0.5, 0.05], [0.18, -0.2, 0], [0.08, 0.1, 0.06], [0.14, 0.38, 0]]} r={0.035} c="#dc2626" />
        </group>
      </Part>
      <Part id="rt">
        <Ball p={[-0.15, -0.35, 0.18]} r={0.09} c="#f97316" />
        <Ball p={[0.25, -0.15, -0.15]} r={0.09} c="#f97316" />
      </Part>
      <Part id="integrase">
        <Ball p={[0.05, 0.1, 0.22]} r={0.08} c="#22c55e" />
      </Part>
      <Part id="protease">
        <Ball p={[-0.25, 0.2, -0.1]} r={0.07} c="#ec4899" />
      </Part>
    </Damp>

    {/* Virus cúm */}
    <Damp s={stage === 1 ? 1 : 0}>
      <Spin speed={0.15}>
        <Part id="flu_env">
          <mesh rotation={[0, 0.5, 0]}>
            <sphereGeometry args={[1.1, 40, 28, 0.4, Math.PI * 2 - 1.2]} />
            <M c="#c4b5fd" o={0.55} side={THREE.DoubleSide} />
          </mesh>
        </Part>
        <Part id="flu_h"><FluSpikes kind="H" /></Part>
        <Part id="flu_n"><FluSpikes kind="N" /></Part>
      </Spin>
      <Part id="flu_rna">
        {Array.from({ length: 8 }).map((_, i) => {
          const a = (i / 8) * Math.PI * 2;
          return (
            <group key={i} position={[Math.cos(a) * 0.38, Math.sin(a) * 0.38, 0]} rotation={[0, 0, a]}>
              <Tube pts={[[0, -0.2, 0], [0.05, -0.07, 0.04], [-0.05, 0.07, -0.04], [0, 0.2, 0]]} r={0.04} c="#ef4444" />
            </group>
          );
        })}
      </Part>
    </Damp>

    {/* HIV tấn công bạch cầu T4 */}
    <Damp s={stage === 2 ? 1 : 0}>
      <group position={[-0.8, -0.2, 0]}>
        <Part id="t4">
          <Ball r={1.5} c="#7dd3fc" o={0.4} />
          <Ball r={0.6} c="#4338ca" o={0.8} />
        </Part>
        <Part id="receptor">
          {[0.3, 0.7, 1.1].map((a, i) => {
            const v: V3 = [Math.cos(a) * 1.5, Math.sin(a) * 1.5, 0.2];
            const w: V3 = [Math.cos(a) * 1.8, Math.sin(a) * 1.8, 0.2];
            return (
              <group key={i}>
                <Rod a={v} b={w} r={0.05} c="#fb7185" />
                <Ball p={w} r={0.08} c="#fb7185" />
              </group>
            );
          })}
        </Part>
      </group>
      {[[1.75, 1.35, 0.2], [2.5, 0.4, -0.2], [2.2, -1.3, 0.3]].map((p, i) => (
        <group key={i} position={p as V3}>
          <Bob amp={0.08} phase={i}>
            <Ball r={0.35} c="#a78bfa" o={0.85} />
            <Part id="hiv_gp"><Spikes n={14} r={0.35} c="#facc15" seed={1.3} /></Part>
          </Bob>
        </group>
      ))}
      <Flow path={[[2.5, 0.4, -0.2], [1.6, 0.35, 0], [0.9, 0.3, 0.1], [0.3, 0.1, 0.1]]} n={3} c="#ef4444" r={0.06} speed={0.3} />
    </Damp>

    <Tag show={stage === 2} p={[-0.8, -2.1, 0]} tone="rose">HIV lây qua: máu · tình dục không an toàn · mẹ sang con</Tag>

    <Label id="hiv_env" p={[-1.35, 1.25, 0]} />
    <Label id="hiv_gp" p={stage === 2 ? [2.55, 1.85, 0] : [1.5, 1.45, 0]} />
    <Label id="hiv_capsid" p={[0.75, 0.7, 0.3]} />
    <Label id="hiv_rna" p={[-0.85, -0.25, 0.4]} />
    <Label id="rt" p={[-0.25, -0.85, 0.5]} />
    <Label id="integrase" p={[0.55, -0.05, 0.6]} />
    <Label id="protease" p={[-0.8, 0.45, 0.3]} />
    <Label id="flu_env" p={[-1.3, 1.2, 0]} />
    <Label id="flu_h" p={[1.45, 1.25, 0]} />
    <Label id="flu_n" p={[1.55, -1.15, 0]} />
    <Label id="flu_rna" p={[0, -0.75, 0.6]} />
    <Label id="t4" p={[-2.1, 1.3, 0]} />
    <Label id="receptor" p={[0.4, 1.95, 0.3]} />
  </group>
);

const def: ModelDef = {
  id: 'm25_hiv_flu',
  titleVi: 'HIV và virus cúm',
  titleEn: 'HIV and influenza viruses',
  source: 'SGK Sinh học 10 KNTT – Bài 25, tr. 145–154',
  parts,
  stages: [
    { titleVi: 'Cấu tạo HIV', titleEn: 'Structure of HIV', descVi: 'Trong vỏ capsid có 2 phân tử RNA, 2 enzyme phiên mã ngược, enzyme integrase và enzyme phân giải protein; ngoài là vỏ ngoài phospholipid kép có gai glycoprotein.', descEn: 'Inside the capsid: two RNA molecules, reverse transcriptase, integrase and protease; outside, an envelope with spikes.' },
    { titleVi: 'Cấu tạo virus cúm', titleEn: 'Structure of the influenza virus', descVi: 'Vật chất di truyền 7–8 đoạn RNA; vỏ capsid; vỏ ngoài có gai H (liên kết thụ thể) và gai N (giải phóng virus). Ba loại A, B, C; cúm A gây đại dịch.', descEn: '7–8 RNA segments, a capsid, and an envelope with H and N spikes. Types A, B and C; type A causes pandemics.' },
    { titleVi: 'HIV tấn công tế bào bạch cầu T4', titleEn: 'HIV attacks T4 cells', descVi: 'Gai glycoprotein liên kết đặc hiệu với thụ thể; vỏ ngoài dung hợp màng, đưa virus vào tế bào. Ba giai đoạn: sơ nhiễm (cửa sổ), không triệu chứng, AIDS.', descEn: 'Spikes bind specific receptors and the envelope fuses with the membrane. Stages: window, no symptoms, AIDS.' },
  ],
  Scene,
  camera: [0, 0.4, 6.5],
  autoRotate: false,
};
export default def;
