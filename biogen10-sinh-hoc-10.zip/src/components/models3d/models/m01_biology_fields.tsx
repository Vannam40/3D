import React, { useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { ModelDef, Part, Label, M, Ball, Tube, Ring, Spin, Caps, BoxM, Cyl, Rod } from '../engine';

type V3 = [number, number, number];

const parts: ModelDef['parts'] = [
  { id: 'biology', nameVi: 'Sinh học', nameEn: 'Biology', ipa: '/baɪˈɒlədʒi/', color: '#22d3ee', descVi: 'Ngành khoa học nghiên cứu về sự sống; đối tượng là các sinh vật cùng các cấp độ tổ chức của thế giới sống.', descEn: 'The science of life; it studies organisms and all levels of organisation of the living world.' },
  { id: 'basic', nameVi: 'Nghiên cứu cơ bản', nameEn: 'Basic research', ipa: '/ˈbeɪsɪk rɪˈsɜːtʃ/', color: '#38bdf8', descVi: 'Tìm hiểu cấu trúc các cấp độ tổ chức sống, phân loại, cách thức vận hành và tiến hoá của thế giới sống.', descEn: 'Studies the structure, classification, functioning and evolution of the living world.' },
  { id: 'applied', nameVi: 'Nghiên cứu ứng dụng', nameEn: 'Applied research', ipa: '/əˈplaɪd rɪˈsɜːtʃ/', color: '#a78bfa', descVi: 'Đưa những phát kiến mới về sinh học vào thực tiễn đời sống; hai lĩnh vực ngày càng giao thoa.', descEn: 'Brings new biological discoveries into everyday life; the two fields increasingly overlap.' },
  { id: 'medicine', nameVi: 'Y – dược học', nameEn: 'Medicine & pharmacy', ipa: '/ˈmedsn ənd ˈfɑːməsi/', color: '#f43f5e', descVi: 'Thuốc hướng đích tác động tới protein riêng biệt chữa bệnh hiểm nghèo như ung thư; vaccine mRNA; y học cá thể hoá.', descEn: 'Targeted drugs act on specific proteins to treat diseases such as cancer; mRNA vaccines; personalised medicine.' },
  { id: 'forensics', nameVi: 'Pháp y', nameEn: 'Forensic science', ipa: '/fəˈrensɪk ˈsaɪəns/', color: '#f59e0b', descVi: 'Giải trình tự DNA từ sợi tóc, vết máu… "dấu vân tay DNA" giúp nhận diện cá thể, xác định quan hệ huyết thống.', descEn: 'DNA from hair or blood is sequenced; a DNA fingerprint identifies individuals and family relationships.' },
  { id: 'agriculture', nameVi: 'Nông – lâm – ngư nghiệp', nameEn: 'Agriculture, forestry & fisheries', ipa: '/ˈæɡrɪkʌltʃə/', color: '#22c55e', descVi: 'Tạo giống năng suất cao, sinh vật biến đổi gene, nhân giống bằng nuôi cấy mô, nhân bản động vật.', descEn: 'Breeding high-yield varieties, GM organisms, tissue-culture propagation and animal cloning.' },
  { id: 'food', nameVi: 'Công nghệ thực phẩm', nameEn: 'Food technology', ipa: '/fuːd tekˈnɒlədʒi/', color: '#fb923c', descVi: 'Sản xuất sữa chua và sản phẩm lên men; biện pháp bảo quản thực phẩm lâu dài.', descEn: 'Making yogurt and other fermented products; methods to preserve food for a long time.' },
  { id: 'environment', nameVi: 'Bảo vệ môi trường', nameEn: 'Environmental protection', ipa: '/ɪnˌvaɪrənˈmentl prəˈtekʃn/', color: '#10b981', descVi: 'Vi sinh vật làm sạch nơi ô nhiễm phóng xạ, kim loại nặng (Deinococcus radiodurans, Shewanella oneidensis); năng lượng sạch.', descEn: 'Microbes clean up radiation and heavy metals (Deinococcus radiodurans, Shewanella oneidensis); clean energy.' },
  { id: 'biomimetics', nameVi: 'Phỏng sinh học', nameEn: 'Biomimetics', ipa: '/ˌbaɪəʊmɪˈmetɪks/', color: '#94a3b8', descVi: 'Công nghệ bắt chước sinh vật, VD robot "giao tiếp" với nhau như loài kiến.', descEn: 'Technology that copies living things, e.g. robots that "communicate" like ants.' },
  { id: 'sustainable', nameVi: 'Phát triển bền vững', nameEn: 'Sustainable development', ipa: '/səˈsteɪnəbl dɪˈveləpmənt/', color: '#4ade80', descVi: 'Đáp ứng nhu cầu hiện tại nhưng không làm tổn hại khả năng đáp ứng nhu cầu của thế hệ tương lai (WCED, 1987).', descEn: 'Meeting present needs without harming the ability of future generations to meet theirs (WCED, 1987).' },
];

const Helix: React.FC = () => {
  const [a, b] = useMemo(() => {
    const p1: V3[] = [], p2: V3[] = [];
    for (let i = 0; i <= 30; i++) {
      const t = i * 0.42;
      const y = -1.1 + i * 0.075;
      p1.push([Math.cos(t) * 0.45, y, Math.sin(t) * 0.45]);
      p2.push([Math.cos(t + Math.PI) * 0.45, y, Math.sin(t + Math.PI) * 0.45]);
    }
    return [p1, p2];
  }, []);
  return (
    <Spin speed={0.6}>
      <Tube pts={a} r={0.05} c="#67e8f9" />
      <Tube pts={b} r={0.05} c="#c4b5fd" />
      {a.filter((_, i) => i % 3 === 0).map((p, i) => (
        <Rod key={i} a={p} b={b[i * 3]} r={0.025} c="#fde68a" />
      ))}
    </Spin>
  );
};

const Orbit: React.FC<{ children: React.ReactNode; speed: number }> = ({ children, speed }) => {
  const ref = useRef<THREE.Group>(null);
  useFrame((_, dt) => {
    if (ref.current) ref.current.rotation.y += dt * speed;
  });
  return <group ref={ref}>{children}</group>;
};

const R = 3.1;
const at = (i: number, n: number, y = 0): V3 => [Math.cos((i / n) * Math.PI * 2) * R, y, Math.sin((i / n) * Math.PI * 2) * R];

const Scene: ModelDef['Scene'] = () => (
  <group position={[0, 0.2, 0]}>
    <Part id="biology">
      <Ball r={0.75} c="#0e7490" o={0.35} />
      <Helix />
    </Part>
    <Part id="basic">
      <Ring R={1.55} r={0.04} c="#38bdf8" rot={[Math.PI / 2, 0, 0]} />
    </Part>
    <Part id="applied">
      <Ring R={2.0} r={0.04} c="#a78bfa" rot={[Math.PI / 2 + 0.25, 0, 0]} />
    </Part>

    <Orbit speed={0.12}>
      <group position={at(0, 6)}>
        <Part id="medicine">
          <Caps len={0.5} r={0.18} c="#f43f5e" rot={[0, 0, 0.8]} />
          <Ball p={[0.25, -0.25, 0]} r={0.12} c="#fda4af" />
        </Part>
      </group>
      <group position={at(1, 6)}>
        <Part id="forensics">
          <Ring R={0.32} r={0.05} c="#f59e0b" />
          <Rod a={[0.22, -0.22, 0]} b={[0.6, -0.6, 0]} r={0.06} c="#78350f" />
          <Tube pts={[[-0.15, -0.15, 0], [-0.05, 0.05, 0.05], [0.05, -0.05, -0.05], [0.15, 0.15, 0]]} r={0.025} c="#fde68a" />
        </Part>
      </group>
      <group position={at(2, 6)}>
        <Part id="agriculture">
          <Cyl rt={0.05} h={0.7} c="#15803d" />
          <Ball p={[0.18, 0.15, 0]} r={0.16} c="#22c55e" s={[1.6, 0.6, 0.8]} />
          <Ball p={[-0.18, 0.3, 0]} r={0.16} c="#4ade80" s={[1.6, 0.6, 0.8]} />
          <Cyl p={[0, -0.45, 0]} rt={0.25} rb={0.18} h={0.25} c="#92400e" />
        </Part>
      </group>
      <group position={at(3, 6)}>
        <Part id="food">
          <Cyl rt={0.28} h={0.55} c="#fde68a" o={0.85} />
          <Cyl p={[0, 0.32, 0]} rt={0.3} h={0.1} c="#fb923c" />
        </Part>
      </group>
      <group position={at(4, 6)}>
        <Part id="environment">
          <Ball r={0.33} c="#10b981" />
          <Ball p={[0.1, 0.12, 0.25]} r={0.12} c="#0ea5e9" />
          <Ring R={0.45} r={0.025} c="#6ee7b7" rot={[1.2, 0, 0]} />
        </Part>
      </group>
      <group position={at(5, 6)}>
        <Part id="biomimetics">
          <BoxM s={[0.4, 0.3, 0.3]} c="#94a3b8" />
          <BoxM p={[0, 0.27, 0]} s={[0.28, 0.22, 0.22]} c="#cbd5e1" />
          <Ball p={[0.07, 0.3, 0.12]} r={0.035} c="#22d3ee" />
          <Ball p={[-0.07, 0.3, 0.12]} r={0.035} c="#22d3ee" />
          {[-0.15, 0, 0.15].map(x => (
            <Rod key={x} a={[x, -0.15, 0.12]} b={[x * 1.6, -0.35, 0.25]} r={0.02} c="#64748b" />
          ))}
        </Part>
      </group>
    </Orbit>

    <group position={[0, -2.3, 0]}>
      <Part id="sustainable">
        <Spin speed={0.3}>
          <Ball r={0.55} c="#2563eb" />
          <Ball p={[0.25, 0.2, 0.32]} r={0.2} c="#22c55e" s={[1.3, 0.7, 0.6]} />
          <Ball p={[-0.3, -0.1, 0.3]} r={0.17} c="#16a34a" s={[1, 0.9, 0.6]} />
        </Spin>
        <Ring R={0.85} r={0.035} c="#4ade80" rot={[Math.PI / 2, 0, 0]} />
      </Part>
    </group>

    <Label id="biology" p={[0, 1.25, 0]} />
    <Label id="basic" p={[-1.55, 0.25, 0.2]} />
    <Label id="applied" p={[1.6, -0.75, 1.0]} />
    <Label id="sustainable" p={[0, -3.35, 0]} />
  </group>
);

/** Nhãn cho các vệ tinh quay: đặt trong nhóm quay để đi theo */
const OrbitLabels: React.FC = () => null;

const SceneWithLabels: ModelDef['Scene'] = props => (
  <group>
    <Scene {...props} />
    <Orbit speed={0.12}>
      <group position={[0, 0.2, 0]}>
        {['medicine', 'forensics', 'agriculture', 'food', 'environment', 'biomimetics'].map((id, i) => {
          const p = at(i, 6, 0.75);
          return <Label key={id} id={id} p={p} />;
        })}
      </group>
    </Orbit>
    <OrbitLabels />
  </group>
);

const def: ModelDef = {
  id: 'm01_biology_fields',
  titleVi: 'Sinh học, các lĩnh vực và ngành nghề liên quan',
  titleEn: 'Biology, its fields and related careers',
  source: 'SGK Sinh học 10 KNTT – Bài 1, tr. 5–11',
  parts,
  Scene: SceneWithLabels,
  camera: [0, 3.2, 8.5],
  autoRotate: false,
};
export default def;
