import React, { useState, useEffect } from 'react';
import {
  Assignment,
  AssignmentSubmission,
} from '../../../types/assignment';
import { useAuth } from '../../../hooks/useAuth';
import { GENETICS_TOPICS } from '../../../data/topicsData';
import {
  subscribeToAssignments,
  subscribeToSubmissions,
  saveAssignmentToCloud,
  deleteAssignmentFromCloud,
  gradeSubmissionInCloud,
} from '../../../firebase/assignmentService';
import { CreateAssignmentModal } from '../modals/CreateAssignmentModal';
import { GradeSubmissionModal } from '../modals/GradeSubmissionModal';
import {
  FileText,
  Plus,
  Search,
  School,
  Calendar,
  Clock,
  CheckCircle2,
  AlertCircle,
  Award,
  Users,
  Edit,
  Trash2,
  Eye,
  Filter,
  Download,
  FileCheck2,
  RotateCcw,
  BookOpen,
  FileSpreadsheet,
  ExternalLink,
} from 'lucide-react';
import {
  syncAllDataToGoogleSheet,
  getGoogleSpreadsheetUrl,
} from '../../../services/googleSheetService';

export const AssignmentManagementTab: React.FC = () => {
  const { user, classes, getStudentsByClass } = useAuth();

  const teacherClasses = classes.filter(
    (c) =>
      c.teacherId === user?.uid ||
      (user?.teacherCode && c.teacherCode === user.teacherCode) ||
      user?.role === 'admin'
  );

  // Real-time data from Firestore & Local Storage
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [submissions, setSubmissions] = useState<AssignmentSubmission[]>([]);

  // Modals
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [editingAssignment, setEditingAssignment] = useState<Assignment | null>(null);

  const [inspectingAssignmentId, setInspectingAssignmentId] = useState<string | null>(null);
  const [selectedSubmissionForGrade, setSelectedSubmissionForGrade] = useState<AssignmentSubmission | null>(null);

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [classFilter, setClassFilter] = useState('all');
  const [topicFilter, setTopicFilter] = useState('all');
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleSyncGoogleSheets = async () => {
    setIsSyncing(true);
    triggerToast('Đang đồng bộ phiếu học tập và bài nộp sang Google Sheets...');
    try {
      const res = await syncAllDataToGoogleSheet();
      if (res.success) {
        triggerToast('✓ Đã đồng bộ toàn bộ Phiếu học tập & Bài nộp sang Google Sheets!');
      } else {
        alert(res.message);
      }
    } catch (err: any) {
      alert('Lỗi: ' + (err.message || err));
    } finally {
      setIsSyncing(false);
    }
  };

  useEffect(() => {
    const unsubAsg = subscribeToAssignments((list) => {
      setAssignments(list);
    });
    const unsubSub = subscribeToSubmissions(null, (subList) => {
      setSubmissions(subList);
    });

    return () => {
      unsubAsg();
      unsubSub();
    };
  }, []);

  // Filter assignments
  const filteredAssignments = assignments.filter((asg) => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      if (!asg.title.toLowerCase().includes(q) && !asg.subject.toLowerCase().includes(q)) {
        return false;
      }
    }
    if (classFilter !== 'all') {
      if (!asg.classIds.includes('all') && !asg.classIds.includes(classFilter)) {
        return false;
      }
    }
    if (topicFilter !== 'all' && asg.topicId !== topicFilter) {
      return false;
    }
    return true;
  });

  // Calculate total stats
  const totalAssignments = assignments.length;
  const totalSubmissions = submissions.filter((s) => s.status === 'submitted' || s.status === 'graded').length;
  const gradedCount = submissions.filter((s) => s.status === 'graded').length;
  const pendingCount = submissions.filter((s) => s.status === 'submitted').length;

  // Active assignment being inspected
  const activeAssignment = assignments.find((a) => a.id === inspectingAssignmentId) || null;

  // Get all target students for active assignment
  const getTargetStudents = (asg: Assignment) => {
    if (asg.classIds.includes('all')) {
      return teacherClasses.flatMap((c) => getStudentsByClass(c.id));
    }
    return asg.classIds.flatMap((cId) => getStudentsByClass(cId));
  };

  const activeRoster = activeAssignment ? getTargetStudents(activeAssignment) : [];

  const handleSaveAssignment = async (assignment: Assignment) => {
    await saveAssignmentToCloud(assignment);
    triggerToast(
      editingAssignment
        ? `Đã cập nhật thành công phiếu "${assignment.title}"!`
        : `Đã giao phiếu học tập "${assignment.title}" tới học sinh!`
    );
    setEditingAssignment(null);
  };

  const handleDeleteAssignment = async (id: string, title: string) => {
    if (confirm(`Bạn có chắc chắn muốn xóa phiếu học tập "${title}"? Mọi bài nộp liên quan cũng sẽ bị xóa.`)) {
      await deleteAssignmentFromCloud(id);
      triggerToast(`Đã xóa phiếu học tập "${title}".`);
      if (inspectingAssignmentId === id) {
        setInspectingAssignmentId(null);
      }
    }
  };

  const handleSaveGrade = async (score: number, feedback: string, allowResubmit: boolean) => {
    if (!selectedSubmissionForGrade) return;
    await gradeSubmissionInCloud(
      selectedSubmissionForGrade.id,
      score,
      feedback,
      allowResubmit,
      user?.uid,
      user?.fullName
    );
    triggerToast(`Đã chấm ${score} điểm cho học sinh ${selectedSubmissionForGrade.studentName}!`);
    setSelectedSubmissionForGrade(null);
  };

  // Export submissions to CSV / Excel
  const handleExportSubmissionsCsv = (asg: Assignment) => {
    const asgSubs = submissions.filter((s) => s.assignmentId === asg.id);
    const roster = getTargetStudents(asg);

    const headers = ['STT', 'Mã HS', 'Họ và tên', 'Lớp', 'Trạng thái', 'Thời gian nộp', 'Điểm số', 'Nhận xét của GV'];
    const rows = roster.map((st, idx) => {
      const sub = asgSubs.find((s) => s.studentId === st.uid);
      const statusText = sub
        ? sub.status === 'graded'
          ? 'Đã chấm'
          : sub.status === 'submitted'
          ? 'Đã nộp'
          : 'Làm lại'
        : 'Chưa nộp';

      return [
        idx + 1,
        st.studentCode,
        `"${st.fullName}"`,
        `"${st.className}"`,
        statusText,
        sub?.submittedAt ? new Date(sub.submittedAt).toLocaleString('vi-VN') : '',
        sub?.score !== undefined ? sub.score : '',
        `"${sub?.feedback || ''}"`,
      ].join(',');
    });

    const csvContent = '\uFEFF' + [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `Ket_qua_${asg.title.replace(/\s+/g, '_')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    triggerToast('Đã xuất file điểm bảng tính CSV thành công!');
  };

  return (
    <div className="space-y-6">
      {/* Toast */}
      {toastMessage && (
        <div className="fixed top-18 right-6 z-50 flex items-center gap-2 rounded-2xl bg-emerald-600 px-4 py-3 text-xs font-bold text-white shadow-xl animate-bounce">
          <CheckCircle2 className="h-4 w-4" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Overview Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-gradient-to-br from-sky-50 to-white border border-sky-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-sky-800">Phiếu Đã Giao</span>
            <FileText className="h-4 w-4 text-sky-600" />
          </div>
          <p className="text-2xl font-black text-slate-900 mt-2 font-mono">{totalAssignments}</p>
          <p className="text-[11px] text-slate-500 mt-0.5">Tất cả lớp học phụ trách</p>
        </div>

        <div className="p-4 rounded-2xl bg-gradient-to-br from-indigo-50 to-white border border-indigo-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-indigo-800">Lượt Nộp Bài</span>
            <Users className="h-4 w-4 text-indigo-600" />
          </div>
          <p className="text-2xl font-black text-slate-900 mt-2 font-mono">{totalSubmissions}</p>
          <p className="text-[11px] text-slate-500 mt-0.5">Bài làm của học sinh</p>
        </div>

        <div className="p-4 rounded-2xl bg-gradient-to-br from-amber-50 to-white border border-amber-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-amber-800">Chờ Chấm Điểm</span>
            <Clock className="h-4 w-4 text-amber-600" />
          </div>
          <p className="text-2xl font-black text-slate-900 mt-2 font-mono">{pendingCount}</p>
          <p className="text-[11px] text-slate-500 mt-0.5">Cần giáo viên chấm</p>
        </div>

        <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-50 to-white border border-emerald-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-emerald-800">Đã Hoàn Tất Chấm</span>
            <Award className="h-4 w-4 text-emerald-600" />
          </div>
          <p className="text-2xl font-black text-slate-900 mt-2 font-mono">{gradedCount}</p>
          <p className="text-[11px] text-slate-500 mt-0.5">Đã gửi điểm & lời phê</p>
        </div>
      </div>

      {/* Action Toolbar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative">
            <Search className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Tìm kiếm phiếu học tập..."
              className="pl-9 pr-4 py-2 rounded-xl border border-slate-200 focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-xs w-48 sm:w-64"
            />
          </div>

          <div className="flex items-center gap-1.5 text-xs">
            <Filter className="h-3.5 w-3.5 text-slate-400" />
            <select
              value={classFilter}
              onChange={(e) => setClassFilter(e.target.value)}
              className="px-2.5 py-1.5 rounded-xl border border-slate-200 bg-white text-xs font-semibold"
            >
              <option value="all">Tất cả lớp</option>
              {teacherClasses.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>

            <select
              value={topicFilter}
              onChange={(e) => setTopicFilter(e.target.value)}
              className="px-2.5 py-1.5 rounded-xl border border-slate-200 bg-white text-xs font-semibold max-w-[160px] truncate"
            >
              <option value="all">Tất cả các bài</option>
              {GENETICS_TOPICS.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.titleVi}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto">
          <button
            onClick={handleSyncGoogleSheets}
            disabled={isSyncing}
            className="px-3.5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-2 shadow-md shadow-emerald-600/30 transition-all cursor-pointer disabled:opacity-50"
            title="Đồng bộ ngay toàn bộ phiếu bài tập & bài làm học sinh sang Google Sheets (14 Sheet)"
          >
            <FileSpreadsheet className="h-4 w-4 text-emerald-200" />
            <span>{isSyncing ? 'Đang đồng bộ...' : 'Đồng bộ 14 Sheet'}</span>
          </button>

          <button
            onClick={() => {
              const url = getGoogleSpreadsheetUrl();
              if (url && url.startsWith('http')) {
                window.open(url, '_blank');
              } else {
                triggerToast('Vui lòng nhập đường dẫn Google Sheet trong tab Bảng Google Sheets.');
              }
            }}
            className="px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center gap-1.5 border border-slate-700 transition-all cursor-pointer"
            title="Mở Google Sheet trên tab mới để xem bài nộp và điểm số trực tiếp"
          >
            <ExternalLink className="h-4 w-4 text-cyan-400" />
            <span>Mở Google Sheet</span>
          </button>

          <button
            onClick={() => {
              setEditingAssignment(null);
              setIsCreateModalOpen(true);
            }}
            className="px-4 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs flex items-center gap-2 shadow-md shadow-sky-600/30 transition-all cursor-pointer"
          >
            <Plus className="h-4 w-4" />
            <span>Tạo Phiếu Học Tập & Giao Bài Mới</span>
          </button>
        </div>
      </div>

      {/* Assignment List */}
      <div className="space-y-4">
        {filteredAssignments.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-3xl border border-slate-200 p-8 space-y-3">
            <FileText className="h-10 w-10 text-slate-300 mx-auto" />
            <h3 className="font-bold text-slate-700 text-sm">Chưa có phiếu học tập nào phù hợp</h3>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              Bấm nút &quot;Tạo Phiếu Học Tập &amp; Giao Bài Mới&quot; ở trên để soạn phiếu câu hỏi, điền bảng và giao cho học sinh.
            </p>
          </div>
        ) : (
          filteredAssignments.map((asg) => {
            const asgSubs = submissions.filter((s) => s.assignmentId === asg.id);
            const roster = getTargetStudents(asg);
            const totalStudents = roster.length || 1;
            const submittedCount = asgSubs.filter((s) => s.status === 'submitted' || s.status === 'graded').length;
            const asgGradedCount = asgSubs.filter((s) => s.status === 'graded').length;
            const percent = Math.min(100, Math.round((submittedCount / totalStudents) * 100));

            const isInspecting = inspectingAssignmentId === asg.id;
            const isDuePassed = new Date(asg.dueDate).getTime() < Date.now();

            return (
              <div
                key={asg.id}
                className={`rounded-3xl bg-white border transition-all overflow-hidden ${
                  isInspecting ? 'border-sky-500 shadow-md ring-2 ring-sky-500/10' : 'border-slate-200/90 shadow-xs'
                }`}
              >
                {/* Main Card Header */}
                <div className="p-5 sm:p-6 space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                    <div className="space-y-1.5 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-sky-100 text-sky-800 border border-sky-200">
                          {asg.subject}
                        </span>
                        {asg.topicTitle && (
                          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-purple-100 text-purple-800 border border-purple-200">
                            {asg.topicTitle}
                          </span>
                        )}
                        {asg.status === 'draft' ? (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700">
                            Bản nháp
                          </span>
                        ) : isDuePassed ? (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800">
                            Đã hết hạn nộp
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                            Đang mở nhận bài
                          </span>
                        )}
                      </div>

                      <h3 className="text-base sm:text-lg font-black text-slate-900">{asg.title}</h3>

                      <p className="text-xs text-slate-600 line-clamp-2">{asg.instructions}</p>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => {
                          setInspectingAssignmentId(isInspecting ? null : asg.id);
                        }}
                        className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                          isInspecting
                            ? 'bg-sky-600 text-white shadow-md shadow-sky-600/30'
                            : 'bg-sky-50 text-sky-700 hover:bg-sky-100 border border-sky-200'
                        }`}
                      >
                        <Eye className="h-3.5 w-3.5" />
                        <span>{isInspecting ? 'Đóng Danh Sách' : 'Xem Bài Nộp & Chấm'}</span>
                      </button>

                      <button
                        onClick={() => {
                          setEditingAssignment(asg);
                          setIsCreateModalOpen(true);
                        }}
                        className="p-2 rounded-xl text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-colors"
                        title="Chỉnh sửa phiếu"
                      >
                        <Edit className="h-4 w-4" />
                      </button>

                      <button
                        onClick={() => handleDeleteAssignment(asg.id, asg.title)}
                        className="p-2 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                        title="Xóa phiếu"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>

                  {/* Metadata and Progress */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t border-slate-100 text-xs">
                    <div className="flex items-center gap-2 text-slate-600">
                      <School className="h-4 w-4 text-slate-400 shrink-0" />
                      <span>
                        Lớp:{' '}
                        <strong className="text-slate-800">
                          {asg.classNames?.join(', ') || asg.classIds.join(', ')}
                        </strong>
                      </span>
                    </div>

                    <div className="flex items-center gap-2 text-slate-600">
                      <Calendar className="h-4 w-4 text-slate-400 shrink-0" />
                      <span>
                        Hạn nộp:{' '}
                        <strong className={isDuePassed ? 'text-amber-700 font-bold' : 'text-slate-800'}>
                          {new Date(asg.dueDate).toLocaleString('vi-VN')}
                        </strong>
                      </span>
                    </div>

                    <div className="flex items-center gap-2 text-slate-600">
                      <FileCheck2 className="h-4 w-4 text-emerald-600 shrink-0" />
                      <span>
                        Gồm <strong>{asg.questions?.length || 0}</strong> câu hỏi,{' '}
                        <strong>{asg.tables?.length || 0}</strong> bảng tương tác
                      </span>
                    </div>
                  </div>

                  {/* Submission Progress bar */}
                  <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-700">Tiến độ nộp bài của học sinh:</span>
                        <span className="font-mono font-black text-sky-700">
                          {submittedCount} / {roster.length} học sinh
                        </span>
                      </div>
                      <div className="flex items-center gap-3 text-[11px] text-slate-500">
                        <span>Đã chấm: <strong className="text-emerald-700">{asgGradedCount}</strong></span>
                        <span>Chờ chấm: <strong className="text-amber-700">{submittedCount - asgGradedCount}</strong></span>
                      </div>
                    </div>
                    <div className="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden">
                      <div
                        className="bg-gradient-to-r from-sky-500 to-emerald-500 h-full rounded-full transition-all duration-500"
                        style={{ width: `${percent}%` }}
                      />
                    </div>
                  </div>
                </div>

                {/* Submissions Details Panel (When expanded) */}
                {isInspecting && (
                  <div className="border-t border-slate-200 bg-slate-50/70 p-5 sm:p-6 space-y-4">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div>
                        <h4 className="font-extrabold text-slate-900 text-sm">
                          Danh Sách Học Sinh &amp; Trạng Thái Bài Nộp
                        </h4>
                        <p className="text-xs text-slate-500">
                          Nhấp vào bài làm của từng học sinh để xem chi tiết, cho điểm và lời phê
                        </p>
                      </div>

                      <button
                        onClick={() => handleExportSubmissionsCsv(asg)}
                        className="px-3 py-1.5 rounded-xl bg-white border border-slate-300 hover:border-emerald-500 text-emerald-700 font-bold text-xs flex items-center gap-1.5 shadow-xs transition-all cursor-pointer self-start sm:self-auto"
                      >
                        <Download className="h-3.5 w-3.5" />
                        <span>Xuất Bảng Điểm (Excel/CSV)</span>
                      </button>
                    </div>

                    {/* Roster Table */}
                    <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white">
                      <table className="w-full text-xs text-left">
                        <thead>
                          <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                            <th className="py-2.5 px-3">STT</th>
                            <th className="py-2.5 px-3">Mã HS</th>
                            <th className="py-2.5 px-3">Họ và tên học sinh</th>
                            <th className="py-2.5 px-3">Lớp</th>
                            <th className="py-2.5 px-3">Trạng thái</th>
                            <th className="py-2.5 px-3">Thời gian nộp</th>
                            <th className="py-2.5 px-3">Điểm số</th>
                            <th className="py-2.5 px-3 text-right">Thao tác</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {roster.length === 0 ? (
                            <tr>
                              <td colSpan={8} className="py-6 text-center text-slate-400 italic">
                                Không tìm thấy học sinh nào trong lớp được giao.
                              </td>
                            </tr>
                          ) : (
                            roster.map((st, idx) => {
                              const sub = asgSubs.find((s) => s.studentId === st.uid);
                              const isSubmitted = sub && (sub.status === 'submitted' || sub.status === 'graded');
                              const isGraded = sub && sub.status === 'graded';
                              const isResubmitReq = sub && sub.status === 'resubmit_requested';

                              return (
                                <tr key={st.uid} className="hover:bg-slate-50 transition-colors">
                                  <td className="py-2.5 px-3 text-slate-400 font-mono">{idx + 1}</td>
                                  <td className="py-2.5 px-3 font-mono font-bold text-slate-700">{st.studentCode}</td>
                                  <td className="py-2.5 px-3 font-bold text-slate-900">{st.fullName}</td>
                                  <td className="py-2.5 px-3 text-slate-600">{st.className}</td>
                                  <td className="py-2.5 px-3">
                                    {isGraded ? (
                                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                                        Đã chấm
                                      </span>
                                    ) : isSubmitted ? (
                                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-100 text-sky-800">
                                        Đã nộp
                                      </span>
                                    ) : isResubmitReq ? (
                                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800">
                                        Yêu cầu làm lại
                                      </span>
                                    ) : sub ? (
                                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-600">
                                        Đang làm dở
                                      </span>
                                    ) : (
                                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-50 text-rose-600">
                                        Chưa nộp
                                      </span>
                                    )}
                                  </td>
                                  <td className="py-2.5 px-3 text-slate-500 font-mono text-[11px]">
                                    {sub?.submittedAt
                                      ? new Date(sub.submittedAt).toLocaleString('vi-VN')
                                      : '—'}
                                  </td>
                                  <td className="py-2.5 px-3">
                                    {sub?.score !== undefined ? (
                                      <span className="font-mono font-black text-emerald-700 text-xs bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                                        {sub.score}/{asg.maxScore}
                                      </span>
                                    ) : (
                                      <span className="text-slate-300 font-mono">—</span>
                                    )}
                                  </td>
                                  <td className="py-2.5 px-3 text-right">
                                    {sub ? (
                                      <button
                                        onClick={() => setSelectedSubmissionForGrade(sub)}
                                        className="px-3 py-1 rounded-xl bg-sky-50 hover:bg-sky-100 text-sky-700 font-bold text-xs transition-colors cursor-pointer border border-sky-200"
                                      >
                                        {isGraded ? 'Xem & Chấm lại' : 'Chấm Bài Ngay'}
                                      </button>
                                    ) : (
                                      <span className="text-[11px] text-slate-400 italic">Chưa có bài</span>
                                    )}
                                  </td>
                                </tr>
                              );
                            })
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Modal Tạo Phiếu Học Tập */}
      <CreateAssignmentModal
        isOpen={isCreateModalOpen}
        onClose={() => {
          setIsCreateModalOpen(false);
          setEditingAssignment(null);
        }}
        onSave={handleSaveAssignment}
        existingAssignment={editingAssignment}
      />

      {/* Modal Chấm Điểm & Lời Phê */}
      <GradeSubmissionModal
        isOpen={Boolean(selectedSubmissionForGrade)}
        submission={selectedSubmissionForGrade}
        assignment={
          assignments.find((a) => a.id === selectedSubmissionForGrade?.assignmentId) || null
        }
        onClose={() => setSelectedSubmissionForGrade(null)}
        onSaveGrade={handleSaveGrade}
      />
    </div>
  );
};
