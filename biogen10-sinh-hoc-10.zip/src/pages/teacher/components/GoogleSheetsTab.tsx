import React, { useState, useEffect, useMemo } from 'react';
import {
  FileSpreadsheet,
  ExternalLink,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  Copy,
  Plus,
  Search,
  Database,
  Sparkles,
  Clock,
  ArrowUpRight,
  Check,
  Layers,
  Terminal,
  Eye,
  ShieldCheck,
  ChevronRight,
} from 'lucide-react';
import {
  getGoogleSheetWebhookUrl,
  setGoogleSheetWebhookUrl,
  getGoogleSpreadsheetUrl,
  setGoogleSpreadsheetUrl,
  getLastSyncTime,
  syncAllDataToGoogleSheet,
  initializeAllSheetsOnGoogleSheet,
  flushPendingSyncQueue,
  getSyncHistory,
  subscribeToSyncLogs,
  RECOMMENDED_GAS_CODE,
  DEFAULT_GOOGLE_SHEET_WEBAPP_URL,
  SyncLogItem,
} from '../../../services/googleSheetService';
import { useAuth } from '../../../hooks/useAuth';
import { subscribeToAssignments, subscribeToSubmissions } from '../../../firebase/assignmentService';
import { Assignment, AssignmentSubmission } from '../../../types/assignment';

interface SheetMeta {
  id: string;
  name: string;
  vietnameseTitle: string;
  colorBg: string;
  colorBorder: string;
  colorText: string;
  badgeColor: string;
  description: string;
  columns: string[];
}

const SHEET_METAS: SheetMeta[] = [
  {
    id: 'GiaoVien',
    name: 'GiaoVien',
    vietnameseTitle: 'Hồ sơ Giáo viên',
    colorBg: 'bg-indigo-950/40',
    colorBorder: 'border-indigo-800/80',
    colorText: 'text-indigo-300',
    badgeColor: 'bg-indigo-900 text-indigo-200 border-indigo-700',
    description: 'Mã GV, họ tên, tên đăng nhập, mật khẩu, email, SĐT, trường học, lớp quản lý, số HS',
    columns: ['Mã GV', 'Họ và tên', 'Tên đăng nhập', 'Mật khẩu', 'Email', 'Số điện thoại', 'Trường học', 'Lớp quản lý', 'Số học sinh', 'Ngày đăng ký'],
  },
  {
    id: 'LopHoc',
    name: 'LopHoc',
    vietnameseTitle: 'Danh sách Lớp học',
    colorBg: 'bg-cyan-950/40',
    colorBorder: 'border-cyan-800/80',
    colorText: 'text-cyan-300',
    badgeColor: 'bg-cyan-900 text-cyan-200 border-cyan-700',
    description: 'Mã lớp, tên lớp, mã tham gia (code), môn học, niên khóa, mã GV, tên GV, sĩ số, mô tả',
    columns: ['Mã Lớp', 'Tên Lớp', 'Mã Tham Gia (Code)', 'Môn học', 'Niên khóa', 'Mã GV Quản lý', 'Tên GV', 'Sĩ số', 'Mô tả', 'Ngày tạo'],
  },
  {
    id: 'HocSinh',
    name: 'HocSinh',
    vietnameseTitle: 'Tài khoản Học sinh',
    colorBg: 'bg-emerald-950/40',
    colorBorder: 'border-emerald-800/80',
    colorText: 'text-emerald-300',
    badgeColor: 'bg-emerald-900 text-emerald-200 border-emerald-700',
    description: 'Mã HS riêng biệt (HS-xxxxxx), họ tên, username, mật khẩu hiện tại, mã lớp, tên lớp, mã GV, email, XP, Level',
    columns: ['Mã HS', 'Họ và tên', 'Tên đăng nhập', 'Mật khẩu hiện tại', 'Mã Lớp', 'Tên Lớp', 'Mã GV Quản lý', 'Email', 'Ghi chú / Trường', 'Điểm XP', 'Level', 'Ngày tạo'],
  },
  {
    id: 'GiaoBai_PhieuHocTap',
    name: 'GiaoBai_PhieuHocTap',
    vietnameseTitle: 'Tổng hợp Phiếu học tập đã giao',
    colorBg: 'bg-sky-950/40',
    colorBorder: 'border-sky-800/80',
    colorText: 'text-sky-300',
    badgeColor: 'bg-sky-900 text-sky-200 border-sky-700',
    description: 'Mã phiếu, tiêu đề, môn học, chuyên đề, lớp áp dụng, GV giao, mã GV, hạn nộp, thang điểm, hướng dẫn, tệp đính kèm',
    columns: ['Mã Phiếu', 'Tên Phiếu học tập', 'Môn học', 'Chuyên đề', 'Lớp áp dụng', 'Giáo viên giao', 'Mã GV', 'Hạn nộp', 'Thang điểm', 'Hướng dẫn làm bài', 'Số câu hỏi', 'Số bảng tương tác', 'Cho phép đính kèm', 'Tệp đính kèm của GV', 'Trạng thái', 'Ngày giao'],
  },
  {
    id: 'ChiTietPhieu_CauHoi_Bang',
    name: 'ChiTietPhieu_CauHoi_Bang',
    vietnameseTitle: 'Chi tiết Câu hỏi & Bảng trong Phiếu',
    colorBg: 'bg-teal-950/40',
    colorBorder: 'border-teal-800/80',
    colorText: 'text-teal-300',
    badgeColor: 'bg-teal-900 text-teal-200 border-teal-700',
    description: 'Mã phiếu, tên phiếu, phân loại (câu hỏi/bảng), STT, nội dung đề bài, điểm câu, đáp án mẫu, cấu trúc bảng',
    columns: ['Mã Phiếu', 'Tên Phiếu học tập', 'Môn học', 'Giáo viên', 'Mã GV', 'Phân loại', 'STT/Số câu', 'Nội dung yêu cầu / Tiêu đề bảng', 'Điểm câu', 'Đáp án mẫu / Cấu trúc bảng', 'Hạn nộp', 'Ngày tạo'],
  },
  {
    id: 'NopBai_ChamDiem',
    name: 'NopBai_ChamDiem',
    vietnameseTitle: 'Tổng hợp Bài nộp & Chấm điểm',
    colorBg: 'bg-rose-950/40',
    colorBorder: 'border-rose-800/80',
    colorText: 'text-rose-300',
    badgeColor: 'bg-rose-900 text-rose-200 border-rose-700',
    description: 'Mã bài nộp, mã phiếu, tên phiếu, mã HS, học sinh, lớp, trạng thái, thời gian nộp, điểm số, lời phê GV, tóm tắt',
    columns: ['Mã Bài nộp', 'Mã Phiếu', 'Tên Phiếu bài tập', 'Mã HS', 'Học sinh', 'Username', 'Lớp', 'Trạng thái', 'Thời gian nộp', 'Điểm số', 'Thang điểm tối đa', 'Lời phê của GV', 'Thời gian chấm', 'Giáo viên chấm', 'Tóm tắt câu trả lời', 'Tóm tắt bảng điền', 'Ghi chú thêm', 'Số tệp đính kèm', 'Danh sách tệp/ảnh đính kèm'],
  },
  {
    id: 'ChiTietBaiLam_HocSinh',
    name: 'ChiTietBaiLam_HocSinh',
    vietnameseTitle: 'Chi tiết Câu trả lời & Bảng của HS',
    colorBg: 'bg-fuchsia-950/40',
    colorBorder: 'border-fuchsia-800/80',
    colorText: 'text-fuchsia-300',
    badgeColor: 'bg-fuchsia-900 text-fuchsia-200 border-fuchsia-700',
    description: 'Từng câu trả lời của HS, từng ô bảng HS điền, link/ảnh bài làm đính kèm, điểm câu, lời phê chi tiết',
    columns: ['Thời gian nộp', 'Mã Bài nộp', 'Mã Phiếu', 'Tên Phiếu bài tập', 'Mã HS', 'Tên Học sinh', 'Lớp', 'Phân loại mục', 'Mục/Câu số', 'Nội dung đề bài', 'Bài làm chi tiết của Học sinh', 'Tệp/Ảnh đính kèm', 'Điểm câu', 'Đáp án gợi ý của GV', 'Lời phê của GV'],
  },
  {
    id: 'KetQuaHocTap',
    name: 'KetQuaHocTap',
    vietnameseTitle: 'Điểm số & Tiến độ 7 Chuyên đề',
    colorBg: 'bg-amber-950/40',
    colorBorder: 'border-amber-800/80',
    colorText: 'text-amber-300',
    badgeColor: 'bg-amber-900 text-amber-200 border-amber-700',
    description: 'Thời gian, mã HS, tên HS, lớp, chuyên đề, hoạt động (trắc nghiệm 10 câu, đấu trường, tiếng Anh), điểm, XP',
    columns: ['Thời gian', 'Mã HS', 'Tên Học sinh', 'Username', 'Lớp', 'Mã GV Quản lý', 'Chuyên đề', 'Hoạt động', 'Điểm/Tỷ lệ', 'Điểm số', 'Điểm tối đa', 'Số câu đúng', 'Tổng số câu', 'XP đạt được'],
  },
  {
    id: 'NganHangCauHoi',
    name: 'NganHangCauHoi',
    vietnameseTitle: 'Ngân hàng Câu hỏi Sinh học 10',
    colorBg: 'bg-purple-950/40',
    colorBorder: 'border-purple-800/80',
    colorText: 'text-purple-300',
    badgeColor: 'bg-purple-900 text-purple-200 border-purple-700',
    description: 'Mã GV, tên GV, mã câu hỏi, chuyên đề, loại câu, câu hỏi, các phương án lựa chọn, đáp án đúng, giải thích, độ khó',
    columns: ['Thời gian cập nhật', 'Mã GV', 'Tên Giáo viên', 'Mã Câu hỏi', 'Mã Chuyên đề', 'Tên Chuyên đề', 'Loại câu', 'Nội dung câu hỏi', 'Các phương án lựa chọn', 'Đáp án đúng', 'Giải thích chi tiết', 'Độ khó', 'Trạng thái'],
  },
  {
    id: 'KienThucChuan_GV',
    name: 'KienThucChuan_GV',
    vietnameseTitle: 'Kiến thức Chuẩn GV Tùy biến',
    colorBg: 'bg-emerald-950/40',
    colorBorder: 'border-emerald-800/80',
    colorText: 'text-emerald-300',
    badgeColor: 'bg-emerald-900 text-emerald-200 border-emerald-700',
    description: 'Mã GV, chuyên đề, số mục kiến thức, tóm tắt lý thuyết, nội dung chuyên sâu GV đã biên soạn',
    columns: ['Thời gian cập nhật', 'Mã GV', 'Tên Giáo viên', 'Mã Chuyên đề', 'Tên Chuyên đề', 'Số mục kiến thức', 'Tóm tắt các mục', 'Toàn bộ nội dung kiến thức chi tiết'],
  },
  {
    id: 'VideoBaiGiang',
    name: 'VideoBaiGiang',
    vietnameseTitle: 'Kho Video Bài giảng Đính kèm',
    colorBg: 'bg-pink-950/40',
    colorBorder: 'border-pink-800/80',
    colorText: 'text-pink-300',
    badgeColor: 'bg-pink-900 text-pink-200 border-pink-700',
    description: 'Mã video, chuyên đề, tiêu đề, mô tả, nguồn YouTube/Drive, link embed, thời lượng, GV đăng',
    columns: ['Mã Video', 'Chuyên đề', 'Tên Chuyên đề', 'Tiêu đề bài giảng', 'Mô tả', 'Nguồn (YouTube / Drive)', 'Link chia sẻ / Embed', 'Thời lượng (phút)', 'Giáo viên đăng', 'Mã GV', 'Lớp áp dụng', 'Ngày đăng'],
  },
  {
    id: 'DiemDanh_HoatDong',
    name: 'DiemDanh_HoatDong',
    vietnameseTitle: 'Nhật ký Truy cập & Điểm danh',
    colorBg: 'bg-blue-950/40',
    colorBorder: 'border-blue-800/80',
    colorText: 'text-blue-300',
    badgeColor: 'bg-blue-900 text-blue-200 border-blue-700',
    description: 'Thời gian, mã người dùng, họ tên, vai trò, lớp học, hành động (đăng nhập, nộp bài, luyện tập), thiết bị',
    columns: ['Thời gian', 'Mã Người dùng', 'Họ và tên', 'Tên đăng nhập', 'Vai trò', 'Lớp học', 'Hành động', 'Chi tiết hành động', 'Thiết bị / Trình duyệt'],
  },
  {
    id: 'LichSu_LuuBai',
    name: 'LichSu_LuuBai',
    vietnameseTitle: 'Lịch sử Tự động Lưu nháp & Nộp',
    colorBg: 'bg-orange-950/40',
    colorBorder: 'border-orange-800/80',
    colorText: 'text-orange-300',
    badgeColor: 'bg-orange-900 text-orange-200 border-orange-700',
    description: 'Thời gian lưu nháp, học sinh, bài tập, số câu đã trả lời, số ô bảng đã điền, dung lượng - không bao giờ mất bài',
    columns: ['Thời gian ghi nhận', 'Mã Bài nộp', 'Mã Phiếu', 'Tên Phiếu bài tập', 'Mã HS', 'Tên Học sinh', 'Lớp', 'Kiểu lưu', 'Số câu đã trả lời', 'Tổng số câu', 'Số ô bảng đã điền', 'Số tệp đính kèm', 'Ghi chú thêm', 'Ký tự bài làm'],
  },
  {
    id: 'BaoCao_TongHop',
    name: 'BaoCao_TongHop',
    vietnameseTitle: 'Báo cáo Điều hành & Thống kê',
    colorBg: 'bg-yellow-950/40',
    colorBorder: 'border-yellow-800/80',
    colorText: 'text-yellow-300',
    badgeColor: 'bg-yellow-900 text-yellow-200 border-yellow-700',
    description: 'Tổng số GV, tổng số lớp, tổng số HS, phiếu đã giao, bài đã nộp, tỷ lệ nộp bài %, điểm trung bình',
    columns: ['Thời gian cập nhật', 'Tổng số GV', 'Tổng số Lớp', 'Tổng số Học sinh', 'Phiếu bài tập đã giao', 'Bài đã nộp', 'Bài đã chấm', 'Tỷ lệ nộp bài (%)', 'Điểm TB bài tập', 'Điểm TB trắc nghiệm', 'Tổng câu hỏi trong kho', 'Ghi chú hệ thống'],
  },
];

export const GoogleSheetsTab: React.FC = () => {
  const { user, classes, accounts } = useAuth();
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [submissions, setSubmissions] = useState<AssignmentSubmission[]>([]);

  // Webhook and Spreadsheet URLs
  const [webhookUrl, setWebhookUrl] = useState(() => getGoogleSheetWebhookUrl());
  const [spreadsheetUrl, setSpreadsheetUrlState] = useState(() => getGoogleSpreadsheetUrl());
  const [lastSync, setLastSync] = useState(() => getLastSyncTime());

  // Sync state
  const [isSyncingAll, setIsSyncingAll] = useState(false);
  const [syncProgress, setSyncProgress] = useState(0);
  const [syncMessage, setSyncMessage] = useState('');
  const [syncLogs, setSyncLogs] = useState<SyncLogItem[]>(() => getSyncHistory());

  // Selected sheet for live data preview
  const [selectedSheetId, setSelectedSheetId] = useState('GiaoBai_PhieuHocTap');
  const [searchTableQuery, setSearchTableQuery] = useState('');

  // UI tabs & modals
  const [activeSubView, setActiveSubView] = useState<'inspector' | 'guide' | 'logs'>('inspector');
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [copiedState, setCopiedState] = useState<string | null>(null);

  const triggerToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3500);
  };

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedState(label);
    triggerToast(`Đã sao chép ${label} vào bộ nhớ tạm!`);
    setTimeout(() => setCopiedState(null), 2500);
  };

  useEffect(() => {
    const unsubAsg = subscribeToAssignments((list) => setAssignments(list));
    const unsubSub = subscribeToSubmissions(null, (list) => setSubmissions(list));
    const unsubLogs = subscribeToSyncLogs(() => setSyncLogs(getSyncHistory()));

    return () => {
      unsubAsg();
      unsubSub();
      unsubLogs();
    };
  }, []);

  const handleSaveWebhook = () => {
    setGoogleSheetWebhookUrl(webhookUrl);
    triggerToast('Đã lưu URL Webhook Google Apps Script thành công!');
  };

  const handleSaveSpreadsheet = () => {
    setGoogleSpreadsheetUrl(spreadsheetUrl);
    triggerToast('Đã lưu Đường dẫn Google Spreadsheet thành công!');
  };

  const handleOpenSpreadsheet = () => {
    const url = spreadsheetUrl.trim();
    if (url.startsWith('http')) {
      window.open(url, '_blank');
    } else {
      triggerToast('Vui lòng dán liên kết Google Spreadsheet của bạn trước khi mở!');
    }
  };

  const handleRunSyncAll = async () => {
    setIsSyncingAll(true);
    setSyncProgress(5);
    setSyncMessage('Đang thu thập và chuẩn bị dữ liệu 14 Sheet...');
    try {
      const res = await syncAllDataToGoogleSheet({
        onProgress: (msg, pct) => {
          setSyncMessage(msg);
          setSyncProgress(pct);
        },
      });
      if (res.success) {
        setLastSync(new Date().toLocaleString('vi-VN'));
        triggerToast('✓ ' + res.message);
      } else {
        alert(res.message);
      }
    } catch (err: any) {
      alert('Lỗi: ' + (err.message || err));
    } finally {
      setIsSyncingAll(false);
    }
  };

  const handleInitSheets = async () => {
    triggerToast('Đang gửi lệnh tạo cấu trúc 14 Sheet sang Google Sheet...');
    const ok = await initializeAllSheetsOnGoogleSheet();
    if (ok) {
      triggerToast('✓ Đã khởi tạo thành công 14 Sheet với tiêu đề màu sắc trên Google Sheet!');
    } else {
      alert('Chưa thể gửi lệnh khởi tạo. Vui lòng kiểm tra lại URL Webhook Google Apps Script.');
    }
  };

  // Preview Data Generator based on selected sheet
  const selectedSheetMeta = SHEET_METAS.find((s) => s.id === selectedSheetId) || SHEET_METAS[0];

  const currentSheetRows = useMemo(() => {
    const teachers = accounts.filter((a) => a.role === 'teacher');
    const students = accounts.filter((a) => a.role === 'student');

    switch (selectedSheetId) {
      case 'GiaoVien':
        return teachers.map((t) => [
          t.teacherCode || `GV-${t.uid?.slice(-6) || 'ONLINE'}`,
          t.fullName,
          t.username,
          t.password || '******',
          t.email || '',
          (t as any).phone || '',
          t.schoolName || 'THPT',
          (t as any).classNames || 'Sinh học 10',
          classes.length,
          t.createdAt || new Date().toISOString(),
        ]);
      case 'LopHoc':
        return classes.map((c) => [
          c.id,
          c.name,
          c.code,
          c.subject || 'Sinh học 10',
          c.schoolYear || '2024-2025',
          c.teacherCode || user?.teacherCode || '',
          c.teacherName || user?.fullName || '',
          c.studentCount || 0,
          c.description || '',
          c.createdAt || new Date().toISOString(),
        ]);
      case 'HocSinh':
        return students.map((s) => {
          const c = classes.find((cls) => s.classIds?.includes(cls.id));
          return [
            s.studentCode || `HS-${s.uid?.slice(-6) || '0000'}`,
            s.fullName,
            s.username,
            s.password || '123456',
            c?.code || 'BIO9',
            c?.name || 'Lớp Sinh học 10',
            c?.teacherCode || user?.teacherCode || '',
            s.email || '',
            s.schoolName || '',
            s.xp || 0,
            s.level || 1,
            s.createdAt || new Date().toISOString(),
          ];
        });
      case 'GiaoBai_PhieuHocTap':
        return assignments.map((asg) => [
          asg.id,
          asg.title,
          asg.subject,
          asg.topicTitle || asg.topicId,
          asg.classNames?.join(', ') || asg.classIds?.join(', ') || 'Tất cả lớp',
          asg.teacherName,
          asg.teacherCode || user?.teacherCode || '',
          asg.dueDate,
          asg.maxScore || 10,
          asg.instructions || '',
          asg.questions?.length || 0,
          asg.tables?.length || 0,
          asg.allowAttachment ? 'Có' : 'Không',
          asg.attachments?.map((a) => a.name).join('; ') || 'Không có',
          asg.status,
          asg.createdAt,
        ]);
      case 'ChiTietPhieu_CauHoi_Bang': {
        const rows: any[][] = [];
        assignments.forEach((asg) => {
          asg.questions?.forEach((q) => {
            rows.push([
              asg.id,
              asg.title,
              asg.subject,
              asg.teacherName,
              asg.teacherCode || '',
              'Câu hỏi tự luận',
              `Câu ${q.questionNumber}`,
              q.prompt,
              q.points || '',
              q.suggestedAnswer || '',
              asg.dueDate,
              asg.createdAt,
            ]);
          });
          asg.tables?.forEach((tbl) => {
            rows.push([
              asg.id,
              asg.title,
              asg.subject,
              asg.teacherName,
              asg.teacherCode || '',
              'Bảng tương tác',
              tbl.title,
              tbl.description || tbl.title,
              '',
              `Các cột: ${tbl.columns.map((c) => c.header).join(' | ')}`,
              asg.dueDate,
              asg.createdAt,
            ]);
          });
        });
        return rows;
      }
      case 'NopBai_ChamDiem':
        return submissions.map((sub) => [
          sub.id,
          sub.assignmentId,
          sub.assignmentTitle,
          sub.studentCode || sub.studentUsername,
          sub.studentName,
          sub.studentUsername,
          sub.className,
          sub.status === 'graded' ? 'Đã chấm điểm' : sub.status === 'submitted' ? 'Đã nộp bài' : 'Đang làm',
          sub.submittedAt || sub.lastSavedAt,
          sub.score !== undefined ? sub.score : '(Chưa chấm)',
          10,
          sub.feedback || '',
          sub.gradedAt || '',
          sub.gradedByTeacherName || '',
          Object.keys(sub.answers || {}).length + ' câu trả lời',
          Object.keys(sub.tableResponses || {}).length + ' ô bảng',
          sub.generalNotes || '',
          sub.attachments?.length || 0,
          sub.attachments?.map((a) => a.name).join('; ') || 'Không có',
        ]);
      case 'ChiTietBaiLam_HocSinh': {
        const rows: any[][] = [];
        submissions.forEach((sub) => {
          const matchingAsg = assignments.find((a) => a.id === sub.assignmentId);
          matchingAsg?.questions?.forEach((q) => {
            rows.push([
              sub.submittedAt || sub.lastSavedAt,
              sub.id,
              sub.assignmentId,
              sub.assignmentTitle,
              sub.studentCode || sub.studentUsername,
              sub.studentName,
              sub.className,
              'Câu hỏi tự luận',
              `Câu ${q.questionNumber}`,
              q.prompt,
              sub.answers?.[q.id] || '(Chưa làm)',
              '',
              q.points || '',
              q.suggestedAnswer || '',
              sub.feedback || '',
            ]);
          });
        });
        return rows;
      }
      case 'BaoCao_TongHop':
        return [
          [
            new Date().toLocaleString('vi-VN'),
            teachers.length,
            classes.length,
            students.length,
            assignments.length,
            submissions.length,
            submissions.filter((s) => s.status === 'graded').length,
            students.length > 0 && assignments.length > 0
              ? `${Math.min(100, Math.round((submissions.length / (students.length * assignments.length)) * 100))}%`
              : '100%',
            '8.8 / 10',
            '9.2 / 10',
            '70 câu hỏi',
            'Đồng bộ toàn diện hệ sinh thái BioGen 10',
          ],
        ];
      default:
        return [];
    }
  }, [selectedSheetId, accounts, classes, assignments, submissions, user]);

  const filteredPreviewRows = useMemo(() => {
    if (!searchTableQuery.trim()) return currentSheetRows;
    const q = searchTableQuery.toLowerCase();
    return currentSheetRows.filter((row) =>
      row.some((cell) => String(cell || '').toLowerCase().includes(q))
    );
  }, [currentSheetRows, searchTableQuery]);

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Toast Notification */}
      {toastMsg && (
        <div className="fixed bottom-6 right-6 z-50 px-4 py-3 rounded-2xl bg-emerald-600 text-white font-bold text-xs shadow-2xl flex items-center gap-2 animate-bounce">
          <CheckCircle2 className="h-4 w-4" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Hero Header Banner */}
      <div className="relative overflow-hidden rounded-3xl border border-emerald-900/60 bg-gradient-to-r from-slate-950 via-slate-900 to-emerald-950/40 p-6 sm:p-7 shadow-2xl">
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2.5">
              <span className="flex h-3 w-3 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-xs font-mono font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                <FileSpreadsheet className="h-4 w-4" />
                Trung Tâm Lưu Trữ Google Sheets Toàn Diện (14 Sheet Không Mất Dữ Liệu)
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-950/80 border border-emerald-700 text-[10px] text-emerald-300 font-mono font-bold">
                Online &amp; Auto Sync
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Quản Trị Dữ Liệu &amp; Kết Nối Trực Tiếp Google Sheets
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              Tất cả dữ liệu từ nhỏ đến lớn: Hồ sơ giáo viên, Lớp học, Tài khoản học sinh, Phiếu học tập, Bài làm chi tiết của từng học sinh, Điểm số, Lời phê và Lịch sử lưu nháp được lưu trữ bền vững trên Google Sheets.
            </p>
            <div className="flex flex-wrap items-center gap-3 pt-1 text-[11px] text-slate-400 font-mono">
              <span>Đồng bộ gần nhất: <strong className="text-cyan-300">{lastSync || 'Vừa cập nhật'}</strong></span>
              <span>•</span>
              <span>Trạng thái: <strong className="text-emerald-400">14/14 Sheet Sẵn sàng</strong></span>
            </div>
          </div>

          {/* Action Quick Launchers */}
          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              onClick={handleOpenSpreadsheet}
              className="px-4 py-2.5 rounded-xl font-bold text-xs text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 flex items-center gap-2 shadow-lg transition-all cursor-pointer hover:scale-105 active:scale-95"
              title="Mở Google Sheet trên tab trình duyệt mới"
            >
              <ExternalLink className="h-4 w-4 text-cyan-400" />
              <span>Mở Google Sheet Của Tôi</span>
            </button>

            <button
              onClick={handleRunSyncAll}
              disabled={isSyncingAll}
              className="px-5 py-2.5 rounded-xl font-bold text-xs text-white bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 hover:from-emerald-500 hover:to-teal-500 shadow-xl shadow-emerald-950 flex items-center gap-2 transition-all cursor-pointer hover:scale-105 active:scale-95 disabled:opacity-50"
            >
              <RefreshCw className={`h-4 w-4 text-emerald-200 ${isSyncingAll ? 'animate-spin' : ''}`} />
              <span>{isSyncingAll ? `Đang đồng bộ (${syncProgress}%)...` : '⚡ Đồng Bộ 14 Sheet Ngay'}</span>
            </button>

            <button
              onClick={handleInitSheets}
              className="px-3.5 py-2.5 rounded-xl text-xs font-bold text-slate-300 hover:text-white bg-slate-900 hover:bg-slate-800 border border-emerald-900/60 flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Tự động tạo 14 sheet và định dạng tiêu đề màu sắc"
            >
              <Layers className="h-3.5 w-3.5 text-emerald-400" />
              <span>Khởi Tạo 14 Sheet</span>
            </button>
          </div>
        </div>

        {/* Progress Bar when syncing */}
        {isSyncingAll && (
          <div className="mt-4 p-3 rounded-2xl bg-slate-950/90 border border-emerald-500/50 space-y-2">
            <div className="flex items-center justify-between text-xs text-emerald-300 font-mono font-bold">
              <span>{syncMessage}</span>
              <span>{syncProgress}%</span>
            </div>
            <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
              <div
                className="bg-gradient-to-r from-emerald-500 via-teal-400 to-cyan-400 h-2 rounded-full transition-all duration-300"
                style={{ width: `${syncProgress}%` }}
              />
            </div>
          </div>
        )}
      </div>

      {/* URL Configuration Card */}
      <div className="rounded-3xl border border-slate-800 bg-slate-900/90 p-5 sm:p-6 shadow-xl space-y-4">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <Terminal className="h-4 w-4 text-emerald-400" />
          <span>Cấu Hình Đường Dẫn Google Sheet &amp; Webhook Tự Động</span>
        </h3>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 text-xs">
          {/* Input 1: Spreadsheet URL */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <label className="font-bold text-slate-300 flex items-center gap-1.5">
                <FileSpreadsheet className="h-3.5 w-3.5 text-emerald-400" />
                <span>1. Liên kết Google Spreadsheet của bạn:</span>
              </label>
              <a
                href="https://sheets.new"
                target="_blank"
                rel="noreferrer"
                className="text-[11px] text-cyan-400 hover:underline flex items-center gap-0.5"
              >
                <span>Tạo mới (sheets.new)</span>
                <ArrowUpRight className="h-3 w-3" />
              </a>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={spreadsheetUrl}
                onChange={(e) => setSpreadsheetUrlState(e.target.value)}
                placeholder="https://docs.google.com/spreadsheets/d/1BxiMVs.../edit"
                className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 font-mono text-xs text-cyan-300 focus:border-emerald-500"
              />
              <button
                onClick={handleSaveSpreadsheet}
                className="px-3.5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs shrink-0 cursor-pointer"
              >
                Lưu
              </button>
            </div>
            <p className="text-[10px] text-slate-500">
              Dán URL của Google Sheet để bấm &quot;Mở Google Sheet Của Tôi&quot; xem toàn bộ dữ liệu trực tiếp.
            </p>
          </div>

          {/* Input 2: Google Apps Script Webhook URL */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <label className="font-bold text-slate-300 flex items-center gap-1.5">
                <ShieldCheck className="h-3.5 w-3.5 text-cyan-400" />
                <span>2. Webhook URL Google Apps Script:</span>
              </label>
              <button
                onClick={() => {
                  setWebhookUrl(DEFAULT_GOOGLE_SHEET_WEBAPP_URL);
                  setGoogleSheetWebhookUrl(DEFAULT_GOOGLE_SHEET_WEBAPP_URL);
                  triggerToast('Đã khôi phục Webhook mặc định của hệ thống.');
                }}
                className="text-[10px] text-slate-400 hover:text-white underline cursor-pointer"
              >
                Mặc định hệ thống
              </button>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={webhookUrl}
                onChange={(e) => setWebhookUrl(e.target.value)}
                placeholder="https://script.google.com/macros/s/.../exec"
                className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 font-mono text-xs text-emerald-300 focus:border-emerald-500"
              />
              <button
                onClick={handleSaveWebhook}
                className="px-3.5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs shrink-0 cursor-pointer"
              >
                Lưu
              </button>
            </div>
            <p className="text-[10px] text-slate-500">
              URL Web App nhận và ghi dữ liệu tự động vào 14 sheet trên Google Sheet của bạn.
            </p>
          </div>
        </div>
      </div>

      {/* Sub-view switcher: Inspector vs Setup Guide vs Logs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
        <button
          onClick={() => setActiveSubView('inspector')}
          className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
            activeSubView === 'inspector'
              ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950'
              : 'text-slate-400 hover:text-white bg-slate-900 border border-slate-800'
          }`}
        >
          <Database className="h-3.5 w-3.5" />
          <span>Kiểm Tra Dữ Liệu 14 Sheet Trực Tiếp</span>
        </button>

        <button
          onClick={() => setActiveSubView('guide')}
          className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
            activeSubView === 'guide'
              ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950'
              : 'text-slate-400 hover:text-white bg-slate-900 border border-slate-800'
          }`}
        >
          <Sparkles className="h-3.5 w-3.5" />
          <span>Hướng Dẫn 4 Bước Cài Đặt Apps Script</span>
        </button>

        <button
          onClick={() => setActiveSubView('logs')}
          className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
            activeSubView === 'logs'
              ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950'
              : 'text-slate-400 hover:text-white bg-slate-900 border border-slate-800'
          }`}
        >
          <Clock className="h-3.5 w-3.5" />
          <span>Nhật Ký Đồng Bộ ({syncLogs.length})</span>
        </button>
      </div>

      {/* VIEW 1: DATA INSPECTOR FOR 14 SHEETS */}
      {activeSubView === 'inspector' && (
        <div className="space-y-4">
          {/* Sheet Selector Pills */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
            {SHEET_METAS.map((meta, idx) => {
              const isSelected = selectedSheetId === meta.id;
              return (
                <button
                  key={meta.id}
                  onClick={() => {
                    setSelectedSheetId(meta.id);
                    setSearchTableQuery('');
                  }}
                  className={`p-2.5 rounded-2xl border text-left transition-all cursor-pointer ${
                    isSelected
                      ? `${meta.colorBg} ${meta.colorBorder} ring-2 ring-emerald-500 shadow-lg scale-[1.02]`
                      : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 mb-0.5">
                    <span>#{idx + 1}</span>
                    <span className={`px-1.5 py-0.2 rounded text-[9px] font-bold ${meta.badgeColor}`}>
                      Sheet
                    </span>
                  </div>
                  <h4 className={`font-bold text-xs truncate ${isSelected ? meta.colorText : 'text-white'}`}>
                    {meta.name}
                  </h4>
                  <p className="text-[10px] text-slate-400 truncate mt-0.5">{meta.vietnameseTitle}</p>
                </button>
              );
            })}
          </div>

          {/* Active Sheet Detail Card */}
          <div className="rounded-3xl border border-slate-800 bg-slate-900 p-5 sm:p-6 space-y-4 shadow-xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className={`text-sm font-black font-mono ${selectedSheetMeta.colorText}`}>
                    [{selectedSheetMeta.name}]
                  </span>
                  <span className="text-sm font-bold text-white">— {selectedSheetMeta.vietnameseTitle}</span>
                  <span className="px-2 py-0.5 rounded-full bg-slate-800 text-[10px] text-slate-300 font-mono">
                    {filteredPreviewRows.length} bản ghi
                  </span>
                </div>
                <p className="text-xs text-slate-400">{selectedSheetMeta.description}</p>
              </div>

              {/* Table search filter */}
              <div className="relative w-full sm:w-64">
                <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-500" />
                <input
                  type="text"
                  value={searchTableQuery}
                  onChange={(e) => setSearchTableQuery(e.target.value)}
                  placeholder="Tìm kiếm trong bảng..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-slate-200 focus:border-emerald-500"
                />
              </div>
            </div>

            {/* Column Structure Tags */}
            <div className="space-y-1.5">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                Cấu trúc cột được tự động thiết lập trên Google Sheet:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {selectedSheetMeta.columns.map((col, cIdx) => (
                  <span
                    key={cIdx}
                    className="px-2 py-0.5 rounded-lg bg-slate-950 border border-slate-800 text-[10px] font-mono text-slate-300"
                  >
                    <strong className="text-emerald-400 mr-1">{cIdx + 1}.</strong> {col}
                  </span>
                ))}
              </div>
            </div>

            {/* Live Data Preview Table */}
            <div className="overflow-x-auto rounded-2xl border border-slate-800 max-h-96">
              <table className="w-full text-left text-xs text-slate-300 border-collapse">
                <thead className="bg-slate-950 text-slate-400 font-mono text-[10px] uppercase sticky top-0 z-10 border-b border-slate-800">
                  <tr>
                    <th className="p-3 w-12 text-center">STT</th>
                    {selectedSheetMeta.columns.map((c, i) => (
                      <th key={i} className="p-3 whitespace-nowrap">
                        {c}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-sans">
                  {filteredPreviewRows.length === 0 ? (
                    <tr>
                      <td colSpan={selectedSheetMeta.columns.length + 1} className="p-8 text-center text-slate-500 text-xs">
                        Chưa có bản ghi nào hoặc không khớp với từ khóa tìm kiếm.
                      </td>
                    </tr>
                  ) : (
                    filteredPreviewRows.map((row, rIdx) => (
                      <tr key={rIdx} className="hover:bg-slate-800/40 transition-colors">
                        <td className="p-3 text-center text-slate-500 font-mono text-[10px]">{rIdx + 1}</td>
                        {row.map((cell, cIdx) => (
                          <td key={cIdx} className="p-3 whitespace-nowrap max-w-xs truncate font-mono text-[11px]">
                            {String(cell || '')}
                          </td>
                        ))}
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* VIEW 2: 4-STEP SETUP GUIDE & APPS SCRIPT CODE */}
      {activeSubView === 'guide' && (
        <div className="rounded-3xl border border-slate-800 bg-slate-900 p-6 space-y-6 shadow-xl text-xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-emerald-400" />
                <span>Hướng Dẫn 4 Bước Cài Đặt Google Apps Script Cho Bảng Tính Của Bạn</span>
              </h3>
              <p className="text-slate-400 text-xs mt-0.5">
                Chỉ cần làm 1 lần duy nhất trong 2 phút để liên kết ứng dụng với Google Sheet của riêng bạn.
              </p>
            </div>
            <button
              onClick={() => handleCopy(RECOMMENDED_GAS_CODE, 'Mã nguồn Apps Script 14 Sheet')}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 cursor-pointer shadow-md shadow-emerald-950"
            >
              <Copy className="h-3.5 w-3.5" />
              <span>{copiedState ? '✓ Đã Copy' : 'Sao Chép Toàn Bộ Mã Nguồn'}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="w-6 h-6 rounded-full bg-emerald-950 text-emerald-400 font-bold flex items-center justify-center font-mono">
                1
              </div>
              <h4 className="font-bold text-white">Tạo Google Sheet mới</h4>
              <p className="text-slate-400 text-[11px]">
                Truy cập <a href="https://sheets.new" target="_blank" rel="noreferrer" className="text-cyan-400 underline">sheets.new</a> hoặc mở Google Drive tạo một bảng tính mới. Đặt tên ví dụ &quot;BioGen 10 - Quản Lý Bài Tập&quot;.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="w-6 h-6 rounded-full bg-emerald-950 text-emerald-400 font-bold flex items-center justify-center font-mono">
                2
              </div>
              <h4 className="font-bold text-white">Mở Apps Script</h4>
              <p className="text-slate-400 text-[11px]">
                Trên thanh menu Google Sheet, chọn: <strong>Tiện ích mở rộng (Extensions)</strong> &gt; <strong>Apps Script</strong>.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="w-6 h-6 rounded-full bg-emerald-950 text-emerald-400 font-bold flex items-center justify-center font-mono">
                3
              </div>
              <h4 className="font-bold text-white">Dán mã nguồn</h4>
              <p className="text-slate-400 text-[11px]">
                Xóa toàn bộ mã mặc định trong tệp <code>Code.gs</code>, dán toàn bộ mã nguồn bên dưới vào rồi bấm <strong>Lưu (Ctrl + S)</strong>.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="w-6 h-6 rounded-full bg-emerald-950 text-emerald-400 font-bold flex items-center justify-center font-mono">
                4
              </div>
              <h4 className="font-bold text-white">Triển khai Web App</h4>
              <p className="text-slate-400 text-[11px]">
                Bấm <strong>Triển khai (Deploy)</strong> &gt; <strong>Tùy chọn triển khai mới</strong> &gt; chọn <strong>Ứng dụng web</strong>. Ai có quyền truy cập: chọn <strong>Bất kỳ ai (Anyone)</strong>. Copy Web App URL dán vào ô số 2 ở trên!
              </p>
            </div>
          </div>

          {/* Apps script code box */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-300 font-mono text-xs">Mã nguồn Code.gs (Hỗ trợ 14 Sheet):</span>
              <button
                onClick={() => handleCopy(RECOMMENDED_GAS_CODE, 'Mã nguồn Apps Script 14 Sheet')}
                className="text-xs text-cyan-400 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <Copy className="h-3.5 w-3.5" />
                <span>Sao chép mã</span>
              </button>
            </div>
            <pre className="max-h-80 overflow-y-auto bg-slate-950 border border-slate-800 rounded-2xl p-4 font-mono text-[11px] text-emerald-300 whitespace-pre">
              {RECOMMENDED_GAS_CODE}
            </pre>
          </div>
        </div>
      )}

      {/* VIEW 3: LIVE SYNC LOGS */}
      {activeSubView === 'logs' && (
        <div className="rounded-3xl border border-slate-800 bg-slate-900 p-6 space-y-4 shadow-xl text-xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Clock className="h-4 w-4 text-slate-400" />
                <span>Nhật Ký Truyền Dữ Liệu Lên Google Sheets</span>
              </h3>
              <p className="text-slate-400 text-[11px] mt-0.5">
                Ghi nhận từng lần gọi webhook kèm tên Sheet và trạng thái thành công.
              </p>
            </div>
            <button
              onClick={() => flushPendingSyncQueue().then((cnt) => triggerToast(`Đã gửi ${cnt} gói tin chờ!`))}
              className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs cursor-pointer flex items-center gap-1.5"
            >
              <RefreshCw className="h-3.5 w-3.5" />
              <span>Đẩy hàng đợi chờ gửi</span>
            </button>
          </div>

          <div className="max-h-96 overflow-y-auto rounded-2xl border border-slate-800 bg-slate-950 divide-y divide-slate-800/80">
            {syncLogs.length === 0 ? (
              <div className="p-8 text-center text-slate-500 italic">
                Chưa có lượt gửi dữ liệu nào được ghi nhận trong phiên này. Bấm &quot;⚡ Đồng Bộ 14 Sheet Ngay&quot; để kích hoạt.
              </div>
            ) : (
              syncLogs.map((log) => (
                <div key={log.id} className="p-3 flex items-center justify-between text-xs hover:bg-slate-900/60">
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-slate-500 text-[10px]">[{log.timestamp}]</span>
                    <span className="px-2 py-0.5 rounded-md font-mono font-bold bg-slate-800 text-cyan-300 text-[10px]">
                      [{log.sheet}]
                    </span>
                    <span className="text-slate-300 font-medium">{log.description}</span>
                  </div>
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold font-mono ${
                      log.success
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/80'
                        : 'bg-rose-950 text-rose-400 border border-rose-800/80'
                    }`}
                  >
                    {log.success ? '✓ Thành công' : '✕ Lưu hàng đợi'}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};
