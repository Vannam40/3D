import React, { useState } from 'react';
import {
  Assignment,
  AssignmentStatus,
  WorksheetQuestion,
  WorksheetTable,
  AssignmentAttachment,
} from '../../../types/assignment';
import { useAuth } from '../../../hooks/useAuth';
import { GENETICS_TOPICS } from '../../../data/topicsData';
import {
  FileText,
  X,
  Plus,
  Trash2,
  Calendar,
  Clock,
  BookOpen,
  School,
  Paperclip,
  Check,
  AlertCircle,
  Table as TableIcon,
  Sparkles,
} from 'lucide-react';

interface CreateAssignmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (assignment: Assignment) => void;
  existingAssignment?: Assignment | null;
}

export const CreateAssignmentModal: React.FC<CreateAssignmentModalProps> = ({
  isOpen,
  onClose,
  onSave,
  existingAssignment,
}) => {
  const { user, classes } = useAuth();

  // Filter classes belonging to the logged-in teacher
  const teacherClasses = classes.filter(
    (c) =>
      c.teacherId === user?.uid ||
      (user?.teacherCode && c.teacherCode === user.teacherCode) ||
      user?.role === 'admin'
  );

  const [title, setTitle] = useState(existingAssignment?.title || '');
  const [subject, setSubject] = useState(
    existingAssignment?.subject || 'Sinh học 10 (KNTT)'
  );
  const [topicId, setTopicId] = useState(
    existingAssignment?.topicId || GENETICS_TOPICS[0]?.id || 'nucleic_acid_gene'
  );
  const [selectedClassIds, setSelectedClassIds] = useState<string[]>(
    existingAssignment?.classIds || ['all']
  );
  const [dueDate, setDueDate] = useState<string>(() => {
    if (existingAssignment?.dueDate) {
      return existingAssignment.dueDate.slice(0, 16);
    }
    const defaultDate = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
    return defaultDate.toISOString().slice(0, 16);
  });
  const [maxScore, setMaxScore] = useState<number>(existingAssignment?.maxScore || 10);
  const [instructions, setInstructions] = useState(
    existingAssignment?.instructions ||
      'Các em đọc kỹ yêu cầu trên phiếu học tập, hoàn thành các câu hỏi và bảng so sánh trực tiếp trên hệ thống hoặc đính kèm ảnh bài làm chi tiết.'
  );

  // Structured Questions
  const [questions, setQuestions] = useState<WorksheetQuestion[]>(
    existingAssignment?.questions || [
      {
        id: 'q_1',
        questionNumber: 1,
        prompt: 'Trình bày đặc điểm cấu trúc và nguyên tắc bổ sung của phân tử DNA?',
        points: 5,
        suggestedAnswer: '',
      },
    ]
  );

  // Biological Data Tables
  const [tables, setTables] = useState<WorksheetTable[]>(
    existingAssignment?.tables || []
  );

  // Teacher Attachments (Files / Documents)
  const [attachments, setAttachments] = useState<AssignmentAttachment[]>(
    existingAssignment?.attachments || []
  );
  const [allowAttachment, setAllowAttachment] = useState(
    existingAssignment?.allowAttachment ?? true
  );
  const [status, setStatus] = useState<AssignmentStatus>(
    existingAssignment?.status || 'published'
  );

  if (!isOpen) return null;

  // Toggle class selection
  const handleToggleClass = (classId: string) => {
    if (classId === 'all') {
      setSelectedClassIds(['all']);
      return;
    }
    const withoutAll = selectedClassIds.filter((id) => id !== 'all');
    if (withoutAll.includes(classId)) {
      const remaining = withoutAll.filter((id) => id !== classId);
      setSelectedClassIds(remaining.length === 0 ? ['all'] : remaining);
    } else {
      setSelectedClassIds([...withoutAll, classId]);
    }
  };

  // Questions handling
  const handleAddQuestion = () => {
    const nextNum = questions.length + 1;
    setQuestions([
      ...questions,
      {
        id: `q_${Date.now()}`,
        questionNumber: nextNum,
        prompt: '',
        points: 2,
        suggestedAnswer: '',
      },
    ]);
  };

  const handleUpdateQuestion = (index: number, field: keyof WorksheetQuestion, value: any) => {
    const updated = [...questions];
    updated[index] = { ...updated[index], [field]: value };
    setQuestions(updated);
  };

  const handleRemoveQuestion = (index: number) => {
    if (questions.length <= 1) return;
    const filtered = questions.filter((_, i) => i !== index);
    const renumbered = filtered.map((q, i) => ({ ...q, questionNumber: i + 1 }));
    setQuestions(renumbered);
  };

  // Preset Tables Template
  const handleAddPresetTable = (presetType: 'dna_rna' | 'mitosis_meiosis' | 'custom') => {
    if (presetType === 'dna_rna') {
      const newTable: WorksheetTable = {
        id: `tbl_${Date.now()}`,
        title: 'Bảng So sánh đặc điểm cấu tạo DNA và RNA',
        description: 'Học sinh điền thông tin vào các cột DNA và RNA:',
        columns: [
          { id: 'criterion', header: 'Tiêu chí so sánh', isEditableByStudent: false },
          { id: 'dna_col', header: 'Phân tử DNA', isEditableByStudent: true },
          { id: 'rna_col', header: 'Phân tử RNA', isEditableByStudent: true },
        ],
        rows: [
          { id: 'r1', cells: { criterion: 'Đường đơn phân', dna_col: '', rna_col: '' } },
          { id: 'r2', cells: { criterion: 'Các loại Base nitơ', dna_col: '', rna_col: '' } },
          { id: 'r3', cells: { criterion: 'Số lượng mạch', dna_col: '', rna_col: '' } },
          { id: 'r4', cells: { criterion: 'Chức năng cơ bản', dna_col: '', rna_col: '' } },
        ],
      };
      setTables([...tables, newTable]);
    } else if (presetType === 'mitosis_meiosis') {
      const newTable: WorksheetTable = {
        id: `tbl_${Date.now()}`,
        title: 'Bảng Phân biệt Nguyên phân và Giảm phân',
        description: 'Học sinh hoàn thành bảng so sánh giữa 2 hình thức phân bào:',
        columns: [
          { id: 'feature', header: 'Đặc điểm', isEditableByStudent: false },
          { id: 'mitosis_col', header: 'Nguyên phân', isEditableByStudent: true },
          { id: 'meiosis_col', header: 'Giảm phân', isEditableByStudent: true },
        ],
        rows: [
          { id: 'r1', cells: { feature: 'Loại tế bào xảy ra', mitosis_col: '', meiosis_col: '' } },
          { id: 'r2', cells: { feature: 'Số lần phân bào', mitosis_col: '', meiosis_col: '' } },
          { id: 'r3', cells: { feature: 'Bộ NST tế bào con', mitosis_col: '', meiosis_col: '' } },
          { id: 'r4', cells: { feature: 'Ý nghĩa sinh học', mitosis_col: '', meiosis_col: '' } },
        ],
      };
      setTables([...tables, newTable]);
    } else {
      const newTable: WorksheetTable = {
        id: `tbl_${Date.now()}`,
        title: 'Bảng Điền Thông Tin Dữ Liệu',
        description: 'Điền các thông tin theo yêu cầu:',
        columns: [
          { id: 'col_1', header: 'Hạng mục', isEditableByStudent: false },
          { id: 'col_2', header: 'Nội dung trả lời', isEditableByStudent: true },
        ],
        rows: [
          { id: 'r1', cells: { col_1: 'Nội dung 1', col_2: '' } },
          { id: 'r2', cells: { col_1: 'Nội dung 2', col_2: '' } },
        ],
      };
      setTables([...tables, newTable]);
    }
  };

  const handleRemoveTable = (index: number) => {
    setTables(tables.filter((_, i) => i !== index));
  };

  // File upload for Teacher Attachments
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      reader.onload = (loadEvt) => {
        const dataUrl = loadEvt.target?.result as string;
        setAttachments((prev) => [
          ...prev,
          {
            id: `att_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
            name: file.name,
            type: file.type.includes('pdf')
              ? 'pdf'
              : file.type.includes('image')
              ? 'image'
              : 'doc',
            url: dataUrl,
            size: file.size,
          },
        ]);
      };
      reader.readAsDataURL(file);
    });
  };

  const handleRemoveAttachment = (id: string) => {
    setAttachments(attachments.filter((a) => a.id !== id));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      alert('Vui lòng nhập tiêu đề phiếu học tập!');
      return;
    }

    const selectedTopic = GENETICS_TOPICS.find((t) => t.id === topicId);
    const classNamesList: string[] = [];
    if (selectedClassIds.includes('all')) {
      classNamesList.push('Tất cả các lớp');
    } else {
      selectedClassIds.forEach((cId) => {
        const found = classes.find((c) => c.id === cId);
        if (found) classNamesList.push(`${found.name} (${found.code})`);
      });
    }

    const newAssignment: Assignment = {
      id: existingAssignment?.id || `asg_${Date.now()}`,
      title: title.trim(),
      subject: subject.trim(),
      topicId,
      topicTitle: selectedTopic?.titleVi || '',
      classIds: selectedClassIds,
      classNames: classNamesList,
      teacherId: user?.uid || 'gv_current',
      teacherName: user?.fullName || 'Giáo viên Bộ môn',
      teacherCode: user?.teacherCode || '',
      dueDate: new Date(dueDate).toISOString(),
      maxScore: Number(maxScore) || 10,
      instructions: instructions.trim(),
      questions,
      tables,
      allowAttachment,
      attachments,
      status,
      createdAt: existingAssignment?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    onSave(newAssignment);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/70 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-4xl rounded-3xl bg-white shadow-2xl border border-slate-200 overflow-hidden my-6 max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-gradient-to-r from-sky-50 via-white to-indigo-50">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-sky-600 text-white shadow-md shadow-sky-600/30">
              <FileText className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-slate-900">
                {existingAssignment ? 'Chỉnh Sửa Phiếu Học Tập' : 'Tạo Phiếu Học Tập & Giao Bài'}
              </h2>
              <p className="text-xs text-slate-500">
                Soạn bài tập trực tiếp, thiết lập bảng điền và giao cho học sinh theo lớp
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-6 text-xs sm:text-sm">
          {/* Basic Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2 space-y-1.5">
              <label className="font-bold text-slate-800 flex items-center gap-1.5">
                <span>Tiêu đề phiếu học tập *</span>
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="VD: Phiếu học tập số 03: Cơ chế Dịch mã và Mối quan hệ Gene - Tính trạng"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 text-slate-800 font-semibold text-xs sm:text-sm"
              />
            </div>

            <div className="space-y-1.5">
              <label className="font-bold text-slate-800 flex items-center gap-1.5">
                <BookOpen className="h-3.5 w-3.5 text-sky-600" />
                <span>Chủ đề di truyền liên quan</span>
              </label>
              <select
                value={topicId}
                onChange={(e) => setTopicId(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 text-slate-800 text-xs sm:text-sm font-medium"
              >
                {GENETICS_TOPICS.map((top) => (
                  <option key={top.id} value={top.id}>
                    {top.titleVi}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="font-bold text-slate-800 flex items-center gap-1.5">
                <Calendar className="h-3.5 w-3.5 text-indigo-600" />
                <span>Thời hạn nộp bài (Hạn chót) *</span>
              </label>
              <input
                type="datetime-local"
                required
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 text-slate-800 text-xs sm:text-sm font-medium"
              />
            </div>
          </div>

          {/* Class Selection */}
          <div className="space-y-2">
            <label className="font-bold text-slate-800 flex items-center gap-1.5">
              <School className="h-3.5 w-3.5 text-emerald-600" />
              <span>Giao cho lớp học nào?</span>
            </label>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => handleToggleClass('all')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                  selectedClassIds.includes('all')
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                Tất cả các lớp ({teacherClasses.length})
              </button>
              {teacherClasses.map((cls) => {
                const isSelected = selectedClassIds.includes(cls.id);
                return (
                  <button
                    key={cls.id}
                    type="button"
                    onClick={() => handleToggleClass(cls.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-sky-600 text-white border-sky-600 shadow-sm'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {cls.name} ({cls.code})
                  </button>
                );
              })}
            </div>
          </div>

          {/* Instructions */}
          <div className="space-y-1.5">
            <label className="font-bold text-slate-800">Hướng dẫn của giáo viên</label>
            <textarea
              rows={2}
              value={instructions}
              onChange={(e) => setInstructions(e.target.value)}
              placeholder="Nhập ghi chú hướng dẫn, tài liệu tham khảo..."
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 text-slate-800 text-xs sm:text-sm"
            />
          </div>

          {/* Teacher Document / File Attachments */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-slate-800">
                <Paperclip className="h-4 w-4 text-sky-600" />
                <span>Tài liệu / File đề bài đính kèm từ Giáo viên</span>
              </div>
              <label className="px-3 py-1.5 rounded-xl bg-white border border-slate-300 hover:border-sky-500 text-sky-700 font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-xs transition-all">
                <Plus className="h-3.5 w-3.5" />
                <span>Tải lên file có sẵn (PDF, Ảnh, Word)</span>
                <input
                  type="file"
                  multiple
                  accept="image/*,.pdf,.doc,.docx"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>

            {attachments.length === 0 ? (
              <p className="text-xs text-slate-400 italic">
                Chưa có file đính kèm. Giáo viên có thể tải lên file đề bài có sẵn để học sinh xem trực tiếp.
              </p>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {attachments.map((att) => (
                  <div
                    key={att.id}
                    className="flex items-center justify-between p-2.5 rounded-xl bg-white border border-slate-200 text-xs"
                  >
                    <div className="flex items-center gap-2 truncate">
                      <span className="px-1.5 py-0.5 rounded font-mono font-bold uppercase bg-sky-100 text-sky-700 text-[10px]">
                        {att.type}
                      </span>
                      <span className="truncate font-medium text-slate-700" title={att.name}>
                        {att.name}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleRemoveAttachment(att.id)}
                      className="text-rose-500 hover:text-rose-700 p-1"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Section: Questions */}
          <div className="space-y-3">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <div className="flex items-center gap-2">
                <span className="flex h-6 w-6 items-center justify-center rounded-lg bg-sky-100 text-sky-800 font-bold text-xs">
                  {questions.length}
                </span>
                <h3 className="font-bold text-slate-900 text-sm">Danh Sách Câu Hỏi / Bài Tập Trong Phiếu</h3>
              </div>
              <button
                type="button"
                onClick={handleAddQuestion}
                className="px-3 py-1.5 rounded-xl bg-sky-50 text-sky-700 hover:bg-sky-100 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer border border-sky-200"
              >
                <Plus className="h-3.5 w-3.5" />
                <span>Thêm Câu Hỏi</span>
              </button>
            </div>

            <div className="space-y-3">
              {questions.map((q, idx) => (
                <div
                  key={q.id}
                  className="p-4 rounded-2xl bg-white border border-slate-200/90 shadow-xs space-y-2.5 relative group"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-extrabold text-sky-700 text-xs">
                      Câu {q.questionNumber}
                    </span>
                    <div className="flex items-center gap-3">
                      <div className="flex items-center gap-1">
                        <span className="text-xs text-slate-500">Điểm:</span>
                        <input
                          type="number"
                          min="0"
                          max="10"
                          step="0.5"
                          value={q.points || 0}
                          onChange={(e) =>
                            handleUpdateQuestion(idx, 'points', parseFloat(e.target.value) || 0)
                          }
                          className="w-14 px-2 py-1 rounded-lg border border-slate-200 text-center font-bold text-xs"
                        />
                      </div>
                      {questions.length > 1 && (
                        <button
                          type="button"
                          onClick={() => handleRemoveQuestion(idx)}
                          className="text-slate-400 hover:text-rose-600 transition-colors p-1"
                          title="Xóa câu hỏi này"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      )}
                    </div>
                  </div>

                  <div>
                    <textarea
                      rows={2}
                      value={q.prompt}
                      onChange={(e) => handleUpdateQuestion(idx, 'prompt', e.target.value)}
                      placeholder={`Nhập nội dung đề bài Câu ${q.questionNumber}...`}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:border-sky-500 focus:ring-1 focus:ring-sky-500 text-xs sm:text-sm"
                    />
                  </div>

                  <div>
                    <input
                      type="text"
                      value={q.suggestedAnswer || ''}
                      onChange={(e) => handleUpdateQuestion(idx, 'suggestedAnswer', e.target.value)}
                      placeholder="Gợi ý đáp án / Tiêu chí chấm (Chỉ giáo viên thấy)"
                      className="w-full px-3 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-[11px] text-slate-600 italic"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Section: Biological Interactive Tables */}
          <div className="space-y-3">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <div className="flex items-center gap-2">
                <TableIcon className="h-4 w-4 text-purple-600" />
                <h3 className="font-bold text-slate-900 text-sm">
                  Bảng Dữ Liệu Tương Tác (Học sinh điền trực tiếp)
                </h3>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleAddPresetTable('dna_rna')}
                  className="px-2.5 py-1.5 rounded-xl bg-purple-50 hover:bg-purple-100 text-purple-700 font-bold text-xs flex items-center gap-1 border border-purple-200 transition-colors"
                >
                  <Plus className="h-3 w-3" />
                  <span>Bảng So Sánh ADN/ARN</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleAddPresetTable('mitosis_meiosis')}
                  className="px-2.5 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold text-xs flex items-center gap-1 border border-emerald-200 transition-colors"
                >
                  <Plus className="h-3 w-3" />
                  <span>Bảng Nguyên Phân/Giảm Phân</span>
                </button>
              </div>
            </div>

            {tables.length === 0 ? (
              <p className="text-xs text-slate-400 italic">
                Chưa có bảng tương tác. Bạn có thể thêm bảng so sánh để học sinh điền trực tiếp trên phiếu.
              </p>
            ) : (
              <div className="space-y-3">
                {tables.map((tbl, tIdx) => (
                  <div
                    key={tbl.id}
                    className="p-4 rounded-2xl bg-purple-50/50 border border-purple-200/80 space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <TableIcon className="h-4 w-4 text-purple-600" />
                        <span className="font-bold text-purple-900 text-xs sm:text-sm">
                          {tbl.title}
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleRemoveTable(tIdx)}
                        className="text-rose-500 hover:text-rose-700 p-1"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>

                    {/* Preview of table */}
                    <div className="overflow-x-auto rounded-xl border border-purple-200 bg-white">
                      <table className="w-full text-xs">
                        <thead>
                          <tr className="bg-purple-100 text-purple-900 font-bold">
                            {tbl.columns.map((c) => (
                              <th key={c.id} className="p-2 border-b border-purple-200 text-left">
                                {c.header} {c.isEditableByStudent && '(HS điền)'}
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {tbl.rows.map((r) => (
                            <tr key={r.id} className="border-b border-slate-100">
                              {tbl.columns.map((c) => (
                                <td key={c.id} className="p-2 text-slate-700">
                                  {c.isEditableByStudent ? (
                                    <span className="text-purple-600 italic bg-purple-50 px-2 py-0.5 rounded border border-purple-200/60 block">
                                      [Ô học sinh nhập câu trả lời]
                                    </span>
                                  ) : (
                                    <span className="font-semibold">{r.cells[c.id]}</span>
                                  )}
                                </td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Options */}
          <div className="flex flex-wrap items-center justify-between p-4 rounded-2xl bg-slate-50 border border-slate-200 gap-4">
            <label className="flex items-center gap-2 font-semibold text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={allowAttachment}
                onChange={(e) => setAllowAttachment(e.target.checked)}
                className="h-4 w-4 rounded text-sky-600 focus:ring-sky-500"
              />
              <span>Cho phép học sinh tải ảnh / đính kèm file bài làm</span>
            </label>

            <div className="flex items-center gap-3">
              <label className="text-xs font-bold text-slate-700">Trạng thái phiếu:</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as any)}
                className="px-3 py-1.5 rounded-xl border border-slate-200 bg-white text-xs font-bold"
              >
                <option value="published">Đã Giao Ngay (Học sinh thấy ngay)</option>
                <option value="draft">Bản Nháp (Lưu tạm, chưa giao)</option>
              </select>
            </div>
          </div>

          {/* Submit buttons */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 transition-colors"
            >
              Hủy Bỏ
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl text-xs font-black text-white bg-sky-600 hover:bg-sky-500 shadow-md shadow-sky-600/30 transition-all flex items-center gap-2 cursor-pointer"
            >
              <Check className="h-4 w-4" />
              <span>{existingAssignment ? 'Cập Nhật Phiếu Học Tập' : 'Hoàn Tất & Giao Bài'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
