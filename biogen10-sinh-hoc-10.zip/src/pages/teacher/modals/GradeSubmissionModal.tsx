import React, { useState } from 'react';
import {
  Assignment,
  AssignmentSubmission,
} from '../../../types/assignment';
import {
  Award,
  X,
  Check,
  RotateCcw,
  Clock,
  User,
  Paperclip,
  Printer,
  ExternalLink,
  MessageSquare,
  AlertCircle,
  FileCheck2,
} from 'lucide-react';

interface GradeSubmissionModalProps {
  isOpen: boolean;
  submission: AssignmentSubmission | null;
  assignment: Assignment | null;
  onClose: () => void;
  onSaveGrade: (score: number, feedback: string, allowResubmit: boolean) => void;
}

export const GradeSubmissionModal: React.FC<GradeSubmissionModalProps> = ({
  isOpen,
  submission,
  assignment,
  onClose,
  onSaveGrade,
}) => {
  const [score, setScore] = useState<string>(
    submission?.score !== undefined ? submission.score.toString() : ''
  );
  const [feedback, setFeedback] = useState<string>(submission?.feedback || '');
  const [allowResubmit, setAllowResubmit] = useState<boolean>(
    submission?.allowResubmit || false
  );
  const [selectedImagePreview, setSelectedImagePreview] = useState<string | null>(null);

  if (!isOpen || !submission || !assignment) return null;

  const isLate =
    submission.submittedAt &&
    assignment.dueDate &&
    new Date(submission.submittedAt).getTime() > new Date(assignment.dueDate).getTime();

  const handlePrint = () => {
    window.print();
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const numericScore = parseFloat(score);
    if (isNaN(numericScore) || numericScore < 0 || numericScore > assignment.maxScore) {
      alert(`Vui lòng nhập điểm hợp lệ từ 0 đến ${assignment.maxScore}!`);
      return;
    }
    onSaveGrade(numericScore, feedback.trim(), allowResubmit);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/70 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-4xl rounded-3xl bg-white shadow-2xl border border-slate-200 overflow-hidden my-6 max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-gradient-to-r from-emerald-50 via-white to-sky-50">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-emerald-600 text-white shadow-md shadow-emerald-600/30">
              <FileCheck2 className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-slate-900">
                Chấm Điểm & Nhận Xét Bài Làm
              </h2>
              <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
                <span className="font-bold text-slate-800">{submission.studentName}</span>
                <span>•</span>
                <span>Lớp: {submission.className}</span>
                <span>•</span>
                <span>{assignment.title}</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              type="button"
              className="p-2 rounded-xl text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-colors"
              title="In bài làm / Tải file"
            >
              <Printer className="h-4 w-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-xs sm:text-sm">
          {/* Submission Meta Banner */}
          <div className="flex flex-wrap items-center justify-between p-4 rounded-2xl bg-slate-50 border border-slate-200 gap-3">
            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-sky-100 text-sky-700 font-bold">
                <User className="h-4 w-4" />
              </div>
              <div>
                <p className="font-extrabold text-slate-900">{submission.studentName}</p>
                <p className="text-[11px] text-slate-500">Tên đăng nhập: {submission.studentUsername}</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1.5 text-xs text-slate-600">
                <Clock className="h-3.5 w-3.5 text-slate-400" />
                <span>
                  Thời gian nộp:{' '}
                  {submission.submittedAt
                    ? new Date(submission.submittedAt).toLocaleString('vi-VN')
                    : 'Chưa nộp'}
                </span>
              </div>
              {isLate ? (
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 text-amber-800 border border-amber-200">
                  Nộp muộn
                </span>
              ) : (
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                  Đúng hạn
                </span>
              )}
            </div>
          </div>

          {/* Student's Question Answers */}
          <div className="space-y-4">
            <h3 className="font-extrabold text-slate-900 text-sm border-b border-slate-200 pb-2">
              Nội Dung Bài Làm Từng Câu Hỏi
            </h3>
            {assignment.questions.map((q) => {
              const studentAnswer = submission.answers?.[q.id] || '(Học sinh chưa điền câu này)';
              return (
                <div
                  key={q.id}
                  className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-2"
                >
                  <div className="flex items-start justify-between gap-2">
                    <p className="font-bold text-slate-900">
                      Câu {q.questionNumber}: {q.prompt}
                    </p>
                    <span className="text-[11px] font-mono font-bold text-sky-700 bg-sky-50 px-2 py-0.5 rounded border border-sky-200 shrink-0">
                      {q.points} điểm
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-slate-800 whitespace-pre-wrap font-sans">
                    <span className="text-[10px] font-bold uppercase text-slate-400 block mb-1">
                      Bài làm của học sinh:
                    </span>
                    {studentAnswer}
                  </div>

                  {q.suggestedAnswer && (
                    <div className="text-[11px] text-slate-500 italic bg-amber-50/60 p-2.5 rounded-lg border border-amber-200/60">
                      <span className="font-semibold text-amber-800">Gợi ý đáp án của GV:</span>{' '}
                      {q.suggestedAnswer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Student's Biological Tables */}
          {assignment.tables && assignment.tables.length > 0 && (
            <div className="space-y-4">
              <h3 className="font-extrabold text-slate-900 text-sm border-b border-slate-200 pb-2">
                Bảng Dữ Liệu Học Sinh Đã Điền
              </h3>
              {assignment.tables.map((tbl) => (
                <div
                  key={tbl.id}
                  className="p-4 rounded-2xl bg-purple-50/40 border border-purple-200/80 space-y-2"
                >
                  <h4 className="font-bold text-purple-900 text-xs sm:text-sm">{tbl.title}</h4>
                  <div className="overflow-x-auto rounded-xl border border-purple-200 bg-white">
                    <table className="w-full text-xs">
                      <thead>
                        <tr className="bg-purple-100 text-purple-900 font-bold">
                          {tbl.columns.map((c) => (
                            <th key={c.id} className="p-2 border-b border-purple-200 text-left">
                              {c.header}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {tbl.rows.map((r) => (
                          <tr key={r.id} className="border-b border-slate-100">
                            {tbl.columns.map((c) => {
                              const filledVal =
                                submission.tableResponses?.[tbl.id]?.[r.id]?.[c.id] ||
                                r.cells[c.id] ||
                                '(trống)';
                              return (
                                <td key={c.id} className="p-2 text-slate-800">
                                  {c.isEditableByStudent ? (
                                    <span className="font-bold text-purple-800 bg-purple-50 px-2 py-0.5 rounded border border-purple-200/60 block">
                                      {filledVal}
                                    </span>
                                  ) : (
                                    <span className="font-medium">{r.cells[c.id]}</span>
                                  )}
                                </td>
                              );
                            })}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* General Notes */}
          {submission.generalNotes && (
            <div className="space-y-2">
              <h3 className="font-extrabold text-slate-900 text-sm">Ghi Chú / Lời Giải Bổ Sung</h3>
              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-slate-800 whitespace-pre-wrap">
                {submission.generalNotes}
              </div>
            </div>
          )}

          {/* Student Attachments / Hand-written Photos */}
          {submission.attachments && submission.attachments.length > 0 && (
            <div className="space-y-3">
              <h3 className="font-extrabold text-slate-900 text-sm border-b border-slate-200 pb-2 flex items-center gap-2">
                <Paperclip className="h-4 w-4 text-sky-600" />
                <span>Ảnh / File Bài Làm Đính Kèm Của Học Sinh ({submission.attachments.length})</span>
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {submission.attachments.map((att) => (
                  <div
                    key={att.id}
                    className="p-2 rounded-2xl bg-slate-50 border border-slate-200 space-y-2 text-center group"
                  >
                    {att.dataUrl?.startsWith('data:image') ? (
                      <div
                        onClick={() => setSelectedImagePreview(att.dataUrl)}
                        className="h-28 w-full rounded-xl overflow-hidden bg-slate-200 cursor-pointer relative group-hover:opacity-90"
                      >
                        <img
                          src={att.dataUrl}
                          alt={att.name}
                          className="h-full w-full object-cover"
                        />
                        <div className="absolute inset-0 bg-slate-900/30 opacity-0 group-hover:opacity-100 flex items-center justify-center text-white text-xs font-bold transition-opacity">
                          Xem to
                        </div>
                      </div>
                    ) : (
                      <div className="h-28 w-full rounded-xl bg-sky-100 flex items-center justify-center text-sky-800 font-bold text-xs p-2 break-all">
                        {att.name}
                      </div>
                    )}
                    <a
                      href={att.dataUrl}
                      download={att.name}
                      className="text-[11px] text-sky-600 font-bold hover:underline block truncate"
                    >
                      Tải về: {att.name}
                    </a>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Grading & Feedback Form */}
          <form onSubmit={handleSave} className="p-5 rounded-3xl bg-emerald-50/70 border border-emerald-200 space-y-4">
            <div className="flex items-center gap-2 text-emerald-900 font-black text-sm">
              <Award className="h-5 w-5 text-emerald-600" />
              <span>Chấm Điểm & Phê Nhận Xét Của Giáo Viên</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 items-center">
              <div className="space-y-1">
                <label className="font-bold text-slate-800 block">
                  Điểm số (Thang {assignment.maxScore}) *
                </label>
                <input
                  type="number"
                  min="0"
                  max={assignment.maxScore}
                  step="0.25"
                  required
                  value={score}
                  onChange={(e) => setScore(e.target.value)}
                  placeholder={`0 - ${assignment.maxScore}`}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-emerald-300 bg-white font-mono font-black text-lg text-emerald-900 text-center shadow-xs focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="sm:col-span-3 space-y-1">
                <label className="font-bold text-slate-800 flex items-center gap-1.5">
                  <MessageSquare className="h-3.5 w-3.5 text-emerald-700" />
                  <span>Lời phê / Nhận xét chi tiết cho học sinh</span>
                </label>
                <textarea
                  rows={2}
                  value={feedback}
                  onChange={(e) => setFeedback(e.target.value)}
                  placeholder="VD: Bài làm trình bày tốt, tính đúng chiều dài DNA; chú ý bổ sung hệ quả của nguyên tắc bổ sung..."
                  className="w-full px-3.5 py-2 rounded-xl border border-emerald-300 bg-white text-xs sm:text-sm focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between pt-2 border-t border-emerald-200/80 gap-3">
              <label className="flex items-center gap-2 font-semibold text-slate-700 cursor-pointer text-xs">
                <input
                  type="checkbox"
                  checked={allowResubmit}
                  onChange={(e) => setAllowResubmit(e.target.checked)}
                  className="h-4 w-4 rounded text-amber-600 focus:ring-amber-500"
                />
                <span className="text-amber-800 font-bold">
                  Yêu cầu học sinh làm lại / Mở khóa cho phép nộp lại
                </span>
              </label>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-200/60 transition-colors"
                >
                  Đóng
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-black text-white bg-emerald-600 hover:bg-emerald-500 shadow-md shadow-emerald-600/30 flex items-center gap-1.5 cursor-pointer transition-all"
                >
                  <Check className="h-4 w-4" />
                  <span>Lưu Điểm & Gửi Nhận Xét</span>
                </button>
              </div>
            </div>
          </form>
        </div>

        {/* Image Full Preview Modal */}
        {selectedImagePreview && (
          <div
            onClick={() => setSelectedImagePreview(null)}
            className="fixed inset-0 z-60 bg-black/80 flex items-center justify-center p-4 cursor-pointer"
          >
            <div className="relative max-w-3xl max-h-[90vh]">
              <img
                src={selectedImagePreview}
                alt="Xem to"
                className="max-h-[85vh] max-w-full rounded-2xl shadow-2xl object-contain"
              />
              <button
                onClick={() => setSelectedImagePreview(null)}
                className="absolute top-2 right-2 p-2 bg-black/60 rounded-full text-white hover:bg-black/90"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
