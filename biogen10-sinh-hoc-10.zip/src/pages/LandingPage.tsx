import React from 'react';
import { useNavigation } from '../hooks/useNavigation';
import { useAuth } from '../hooks/useAuth';
import { ModelLoader } from '../components/models3d/ModelLoader';
import { LESSONS, CHAPTERS, TOTAL_TERMS } from '../data/bio10';
import {
  Dna,
  BookOpen,
  Sparkles,
  KeyRound,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Atom,
  Boxes,
  School,
  GraduationCap,
  Bot,
  Swords,
  Flame,
} from 'lucide-react';

const PARTS = [
  {
    title: 'Phần mở đầu',
    subtitle: 'Giới thiệu môn Sinh học & các cấp độ tổ chức sống',
    chapters: ['mo_dau'],
    icon: BookOpen,
    iconBg: 'bg-gradient-to-tr from-sky-500 to-cyan-500',
    accent: 'text-sky-600',
    border: 'border-sky-100 shadow-sky-100/50',
  },
  {
    title: 'Phần một',
    subtitle: 'Sinh học tế bào (Cell Biology)',
    chapters: ['chuong1', 'chuong2', 'chuong3', 'chuong4', 'chuong5'],
    icon: Atom,
    iconBg: 'bg-gradient-to-tr from-emerald-500 to-teal-500',
    accent: 'text-emerald-600',
    border: 'border-emerald-100 shadow-emerald-100/50',
  },
  {
    title: 'Phần hai',
    subtitle: 'Sinh học vi sinh vật và virus (Microbiology & Viruses)',
    chapters: ['chuong6', 'chuong7'],
    icon: Boxes,
    iconBg: 'bg-gradient-to-tr from-rose-500 to-pink-500',
    accent: 'text-rose-600',
    border: 'border-rose-100 shadow-rose-100/50',
  },
];

export const LandingPage: React.FC = () => {
  const { navigate, openJoinClassModal, openTopic } = useNavigation();
  const { user, role } = useAuth();

  return (
    <div className="space-y-16 py-6 md:py-10">
      {/* Hero Section */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-12 space-y-6 max-w-4xl">
            <div className="inline-flex items-center gap-2 text-xs font-bold text-sky-700 bg-sky-100/70 border border-sky-200/80 px-3.5 py-1.5 rounded-full shadow-xs">
              <Sparkles className="h-4 w-4 text-sky-600" />
              <span>Sinh học 10 · Kết nối tri thức với cuộc sống · 3D + English</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight text-slate-900 leading-tight">
              BIOGEN <span className="bg-gradient-to-r from-sky-500 to-teal-500 bg-clip-text text-transparent">10</span>
              <span className="block text-2xl sm:text-3xl lg:text-3xl font-extrabold text-slate-600 mt-2">
                Digital Biology Learning Hub
              </span>
            </h1>

            {/* Author Attribution */}
            <div className="inline-flex items-center gap-2 text-xs sm:text-sm font-bold text-slate-800 bg-white border border-slate-200/90 px-3.5 py-1.5 rounded-xl shadow-xs">
              <span className="text-sky-600 font-extrabold">Nội dung Sinh học 10:</span>
              <span>Thầy Nguyễn Văn Nam – THPT Bình Sơn</span>
            </div>

            <p className="text-base sm:text-lg text-slate-600 leading-relaxed font-normal">
              Nền tảng học Sinh học 10 cho học sinh và giáo viên THPT: kiến thức bám sát SGK, mô hình 3D xoay 360° có nhãn Việt – Anh,
              thuật ngữ English Biology kèm phát âm, tóm tắt bài bằng tiếng Anh, bài luyện tập và đấu trường.
            </p>

            {/* Core Action Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={() => navigate('knowledge_map')}
                className="px-6 py-3.5 rounded-2xl font-bold text-sm text-white bg-gradient-to-r from-sky-500 to-cyan-600 hover:from-sky-600 hover:to-cyan-700 shadow-lg shadow-sky-500/25 flex items-center gap-2 transition-all hover:scale-105 active:scale-95"
              >
                <BookOpen className="h-4 w-4" />
                <span>Bản đồ {LESSONS.length} bài học</span>
                <ArrowRight className="h-4 w-4" />
              </button>

              <button
                onClick={openJoinClassModal}
                className="px-5 py-3.5 rounded-2xl font-bold text-sm text-sky-700 bg-white border border-sky-200 hover:bg-sky-50 hover:border-sky-300 shadow-sm flex items-center gap-2 transition-all"
              >
                <KeyRound className="h-4 w-4 text-sky-600" />
                <span>Tham gia Lớp</span>
              </button>

              {!user && (
                <button
                  onClick={() => navigate('login')}
                  className="px-5 py-3.5 rounded-2xl font-bold text-sm text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 shadow-sm transition-all"
                >
                  Đăng nhập
                </button>
              )}
            </div>

            {/* Feature highlights without pills */}
            <div className="pt-4 grid grid-cols-3 gap-3 border-t border-slate-200/80 text-xs">
              <div className="p-3 rounded-2xl bg-white border border-sky-100 shadow-xs">
                <span className="block font-mono text-sky-600 font-extrabold text-base">{LESSONS.length} bài · 3D</span>
                <span className="text-slate-500 font-medium">Tế bào, vi sinh vật, virus</span>
              </div>
              <div className="p-3 rounded-2xl bg-white border border-emerald-100 shadow-xs">
                <span className="block font-mono text-emerald-600 font-extrabold text-base">English Bio</span>
                <span className="text-slate-500 font-medium">{TOTAL_TERMS} thuật ngữ + IPA</span>
              </div>
              <div className="p-3 rounded-2xl bg-white border border-amber-100 shadow-xs">
                <span className="block font-mono text-amber-600 font-extrabold text-base">Summary EN</span>
                <span className="text-slate-500 font-medium">Tóm tắt bài tiếng Anh</span>
              </div>
            </div>
          </div>

          {/* Mô hình 3D tế bào nhân thực (Bài 8) */}
          <div className="lg:col-span-12">
            <ModelLoader modelId="m08_eukaryote" />
          </div>
        </div>
      </section>

      {/* Các phần của SGK Sinh học 10 */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center gap-2 text-xs font-bold text-indigo-700 bg-indigo-50 border border-indigo-200 px-3.5 py-1 rounded-full mb-3">
            <span>SGK SINH HỌC 10 · KẾT NỐI TRI THỨC VỚI CUỘC SỐNG</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            {LESSONS.length} bài lý thuyết · {CHAPTERS.length - 1} chương
          </h2>
          <p className="text-sm text-slate-600 mt-2">
            Mỗi bài có kiến thức chuẩn SGK (ghi trang), mô hình 3D nhãn Việt – Anh, thuật ngữ English Biology và tóm tắt bài bằng tiếng Anh
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {PARTS.map(part => (
            <div key={part.title} className={`rounded-3xl border bg-white p-6 shadow-lg relative overflow-hidden flex flex-col ${part.border}`}>
              <div className="flex items-center gap-3 mb-4">
                <div className={`p-3 rounded-2xl text-white shadow-md ${part.iconBg}`}>
                  <part.icon className="h-6 w-6" />
                </div>
                <div>
                  <span className={`text-xs font-mono font-bold uppercase ${part.accent}`}>{part.title}</span>
                  <h3 className="text-base font-black text-slate-900 leading-snug">{part.subtitle}</h3>
                </div>
              </div>
              <div className="space-y-2 flex-1">
                {LESSONS.filter(l => part.chapters.includes(l.chapter)).map(l => (
                  <button
                    key={l.id}
                    onClick={() => openTopic(l.id)}
                    className="w-full text-left text-xs font-semibold text-slate-700 hover:text-sky-700 bg-slate-50 hover:bg-sky-50/70 px-3.5 py-2.5 rounded-xl border border-slate-200/80 hover:border-sky-200 flex items-center justify-between gap-2 group transition-all"
                  >
                    <span>
                      {l.titleVi}
                      <span className="block text-[10px] font-medium text-slate-400 italic">{l.titleEn}</span>
                    </span>
                    <ArrowRight className="h-3.5 w-3.5 shrink-0 text-slate-400 group-hover:text-sky-600 transition-colors" />
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Role Feature Comparison Section */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="rounded-3xl border border-sky-100 bg-white p-6 sm:p-10 shadow-lg shadow-sky-100/40">
          <div className="text-center max-w-2xl mx-auto mb-8">
            <h3 className="text-xl sm:text-2xl font-black text-slate-900">Trải nghiệm Chuyên biệt cho Học Sinh &amp; Giáo Viên</h3>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">Phân quyền phù hợp với hoạt động dạy và học môn Sinh học 10</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Student perspective */}
            <div className="space-y-5 p-6 rounded-2xl bg-gradient-to-br from-sky-50/50 via-white to-sky-50/30 border border-sky-100 shadow-xs flex flex-col justify-between">
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-2xl bg-sky-500 text-white shadow-md shadow-sky-500/25">
                    <GraduationCap className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-extrabold text-slate-900">ROLE: HỌC SINH THPT (STUDENT)</h4>
                    <p className="text-[11px] text-slate-500">Tự do khám phá không gian 3D, làm bài luyện tập và thi đấu</p>
                  </div>
                </div>
                <ul className="space-y-2.5 text-xs text-slate-700">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-sky-600 shrink-0" />
                    <span>Tham gia lớp học nhanh chóng bằng Mã lớp giáo viên cung cấp</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-sky-600 shrink-0" />
                    <span>Xoay mô hình 3D 360°, bấm từng bộ phận, đổi nhãn Việt / Anh</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-sky-600 shrink-0" />
                    <span>Học thuật ngữ English Biology có IPA, nghe phát âm, đọc tóm tắt bài bằng tiếng Anh</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-sky-600 shrink-0" />
                    <span>Hỏi đáp cùng Bio-Bot: tra cứu nội dung SGK có ghi trang</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-sky-600 shrink-0" />
                    <span>Tham gia Thử thách đơn 15 câu &amp; Phòng thi đấu trực tiếp 1v1</span>
                  </li>
                </ul>
              </div>
              <button
                onClick={() => navigate('student_dashboard')}
                className="w-full py-3 rounded-xl text-xs font-bold text-white bg-sky-600 hover:bg-sky-500 shadow-md shadow-sky-600/25 transition-all"
              >
                Vào Bảng Học Tập Học Sinh
              </button>
            </div>

            {/* Teacher perspective */}
            <div className="space-y-5 p-6 rounded-2xl bg-gradient-to-br from-purple-50/50 via-white to-purple-50/30 border border-purple-100 shadow-xs flex flex-col justify-between">
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-2xl bg-purple-600 text-white shadow-md shadow-purple-600/25">
                    <School className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-extrabold text-slate-900">ROLE: GIÁO VIÊN BỘ MÔN (TEACHER)</h4>
                    <p className="text-[11px] text-slate-500">Quản lý lớp học, cấp mã phòng thi đấu và theo dõi tiến độ</p>
                  </div>
                </div>
                <ul className="space-y-2.5 text-xs text-slate-700">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-purple-600 shrink-0" />
                    <span><strong>Tải danh sách học sinh lên</strong> và hệ thống <strong>tự động sinh TK &amp; MK</strong> cho toàn bộ lớp</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-purple-600 shrink-0" />
                    <span>Tạo lớp học Sinh học 10, tự động cấp mã tham gia cho học sinh</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-purple-600 shrink-0" />
                    <span>Xuất bảng điểm Excel UTF-8 và in phiếu cấp tài khoản cho học sinh</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-purple-600 shrink-0" />
                    <span>Duyệt ngân hàng câu hỏi theo SGK và mở phòng thi đấu trực tiếp (Live Battle)</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-purple-600 shrink-0" />
                    <span>Theo dõi bảng xếp hạng thi đua và tiến độ học tập chi tiết</span>
                  </li>
                </ul>
              </div>
              <div className="flex flex-col sm:flex-row gap-2 pt-2">
                <button
                  onClick={() => navigate('register')}
                  className="flex-1 py-3 rounded-xl text-xs font-bold text-white bg-purple-600 hover:bg-purple-700 shadow-md shadow-purple-600/25 transition-all text-center"
                >
                  Đăng Ký Tài Khoản Giáo Viên
                </button>
                <button
                  onClick={() => navigate('teacher_dashboard')}
                  className="py-3 px-4 rounded-xl text-xs font-bold text-purple-700 bg-purple-100/70 hover:bg-purple-200/70 transition-all text-center"
                >
                  Vào Bảng Điều Khiển
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
