import React, { useState } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { searchSgk, relatedTerms, pickGuideQuestion, lessonLabel } from '../../utils/sgkSearch';
import type { McqTuple } from '../../data/bio10';
import { Bot, Send, Sparkles, MessageSquare, Lightbulb, CheckCircle2, User } from 'lucide-react';

interface ChatMessage {
  id: string;
  sender: 'bot' | 'user';
  text: string;
  mode?: 'ask' | 'guided';
  timestamp: string;
}

export const BioBotPage: React.FC = () => {
  const { user } = useAuth();
  const [mode, setMode] = useState<'ask' | 'guided'>('guided');
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg_welcome',
      sender: 'bot',
      text: `Xin chào ${user?.fullName || 'bạn'}! Mình là Bio-Bot – trợ lý học tập Sinh học lớp 10 của bạn.\n\nHiện tại mình đang ở chế độ [HƯỚNG DẪN TƯ DUY] (Guided Learning). Mình trả lời dựa trên nội dung 19 bài lý thuyết SGK Sinh học 10 (KNTT), có ghi số trang và thuật ngữ tiếng Anh. Ở chế độ này, mình sẽ hỏi lại bạn một câu gợi mở trước khi đưa lời giải. Bạn muốn ôn nội dung nào hôm nay?`,
      mode: 'guided',
      timestamp: '14:00',
    },
  ]);

  const [pendingQuiz, setPendingQuiz] = useState<{ q: McqTuple; label: string; pages: string } | null>(null);

  const answerFromSgk = (text: string): string => {
    const lower = text.toLowerCase();
    // Học sinh muốn xem đáp án câu hỏi gợi mở vừa nhận
    if (pendingQuiz && /(đáp án|kết quả|giải|đáp an|^[abcd]$|chọn [abcd])/i.test(lower.trim())) {
      const [question, opts, correct, explanation] = pendingQuiz.q;
      const picked = lower.trim().match(/^(?:chọn\s*)?([abcd])$/i);
      const verdict = picked
        ? 'ABCD'.indexOf(picked[1].toUpperCase()) === correct
          ? '✅ Chính xác!'
          : `❌ Chưa đúng. Đáp án đúng là ${'ABCD'[correct]}.`
        : `Đáp án đúng: ${'ABCD'[correct]}. ${opts[correct]}`;
      setPendingQuiz(null);
      return `${verdict}\n\nCâu hỏi: ${question}\nGiải thích: ${explanation}\n\n📖 Nguồn: ${pendingQuiz.label} (${pendingQuiz.pages}).`;
    }

    const hit = searchSgk(text);
    if (!hit) {
      return 'Mình chưa tìm thấy nội dung này trong 19 bài lý thuyết SGK Sinh học 10 (KNTT) của ứng dụng. Bạn thử hỏi bằng từ khoá có trong bài, ví dụ: "thẩm thấu", "ti thể", "pha luỹ thừa", "chu kì sinh tan", hoặc gõ một thuật ngữ tiếng Anh như "osmosis".';
    }
    const { chunk } = hit;
    const label = lessonLabel(chunk.lesson);
    const terms = relatedTerms(chunk);
    const termLine = terms.map(t => `${t[0]} ${t[2]} – ${t[1]}`).join('\n');

    if (mode === 'guided') {
      const q = pickGuideQuestion(chunk.lesson, text);
      setPendingQuiz({ q, label, pages: chunk.lesson.pages });
      return `Câu hỏi của bạn thuộc ${label} – mục "${chunk.heading}" (${chunk.lesson.pages}).\n\nTrước khi xem lời giải, hãy thử trả lời câu hỏi gợi mở sau:\n\n❓ ${q[0]}\n${q[1].map((o, i) => `${'ABCD'[i]}. ${o}`).join('\n')}\n\n💡 Gợi ý: đọc lại mục "${chunk.heading}" trong SGK. Gõ A/B/C/D để kiểm tra, hoặc gõ "đáp án" để xem lời giải.\n\n🔤 English Biology:\n${termLine}`;
    }

    return `📘 ${label} – ${chunk.heading}\n\n${chunk.lines.slice(0, 6).join('\n')}\n\n📖 Nguồn: SGK Sinh học 10 (KNTT), ${chunk.lesson.pages}.\n\n🔤 English Biology:\n${termLine}`;
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    const userMsg: ChatMessage = {
      id: 'user_' + Date.now(),
      sender: 'user',
      text: inputText.trim(),
      mode,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages(prev => [...prev, userMsg]);
    setInputText('');
    setIsTyping(true);

    setTimeout(() => {
      const botResponse = answerFromSgk(userMsg.text);
      setMessages(prev => [
        ...prev,
        {
          id: 'bot_' + Date.now(),
          sender: 'bot',
          text: botResponse,
          mode,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
      setIsTyping(false);
    }, 500);
  };

  return (
    <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400 mb-1">
            <Bot className="h-4 w-4" />
            <span>TRỢ LÝ HỌC TẬP SINH HỌC 10</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white">
            Bio-Bot – Trợ Lý Học Tập Sinh Học 10
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Hỗ trợ giải đáp thắc mắc, phân tích bản chất cơ chế sinh học theo nội dung SGK Sinh học 10
          </p>
        </div>

        {/* Mode Selector (Section 18 & 43) */}
        <div className="flex items-center p-1 bg-slate-900 rounded-xl border border-slate-800 text-xs shrink-0 self-start sm:self-center">
          <button
            onClick={() => setMode('guided')}
            className={`px-3.5 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 ${
              mode === 'guided'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Lightbulb className="h-3.5 w-3.5" />
            <span>Chế độ 2: Hướng dẫn tư duy</span>
          </button>
          <button
            onClick={() => setMode('ask')}
            className={`px-3.5 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 ${
              mode === 'ask'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <MessageSquare className="h-3.5 w-3.5" />
            <span>Chế độ 1: Hỏi đáp trực tiếp</span>
          </button>
        </div>
      </div>

      {/* Mode Description Banner */}
      <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-800/40 text-xs text-emerald-300 flex items-center gap-2">
        <Sparkles className="h-4 w-4 shrink-0 text-emerald-400" />
        <span>
          {mode === 'guided'
            ? 'Đang bật [Chế độ Hướng dẫn tư duy]: Bio-Bot sẽ không đưa đáp án ngay mà gợi ý từng bước để bạn tự suy luận.'
            : 'Đang bật [Chế độ Hỏi đáp trực tiếp]: Bio-Bot sẽ giải thích cụ thể định nghĩa và lý thuyết Sinh học 10.'}
        </span>
      </div>

      {/* Chat Window */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/90 flex flex-col h-[520px] shadow-2xl overflow-hidden">
        {/* Messages Scroll Area */}
        <div className="flex-1 p-5 overflow-y-auto space-y-4">
          {messages.map(msg => (
            <div
              key={msg.id}
              className={`flex items-start gap-3 ${
                msg.sender === 'user' ? 'flex-row-reverse' : ''
              }`}
            >
              <div
                className={`h-8 w-8 rounded-xl flex items-center justify-center shrink-0 ${
                  msg.sender === 'user'
                    ? 'bg-cyan-600 text-white'
                    : 'bg-emerald-950 text-emerald-400 border border-emerald-800/60'
                }`}
              >
                {msg.sender === 'user' ? <User className="h-4 w-4" /> : <Bot className="h-5 w-5" />}
              </div>

              <div
                className={`max-w-[80%] rounded-2xl p-4 text-xs sm:text-sm whitespace-pre-line leading-relaxed ${
                  msg.sender === 'user'
                    ? 'bg-cyan-600 text-white rounded-tr-none'
                    : 'bg-slate-950 border border-slate-800 text-slate-200 rounded-tl-none'
                }`}
              >
                {msg.text}
                <div
                  className={`mt-1.5 text-[10px] font-mono ${
                    msg.sender === 'user' ? 'text-cyan-200' : 'text-slate-500'
                  }`}
                >
                  {msg.timestamp}
                </div>
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="flex items-center gap-2 text-xs text-slate-400 italic">
              <Bot className="h-4 w-4 text-emerald-400 animate-spin" />
              <span>Bio-Bot đang suy nghĩ gợi ý sư phạm...</span>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <form onSubmit={handleSendMessage} className="p-3 border-t border-slate-800 bg-slate-950/80 flex items-center gap-2">
          <input
            type="text"
            value={inputText}
            onChange={e => setInputText(e.target.value)}
            placeholder={
              mode === 'guided'
                ? 'Nhập câu hỏi hoặc suy luận của bạn (Ví dụ: Vì sao lá rau héo khi ngâm nước muối?)...'
                : 'Đặt câu hỏi Sinh học 10 cần giải đáp...'
            }
            className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder:text-slate-500 focus:border-emerald-500 focus:outline-none"
          />
          <button
            type="submit"
            disabled={!inputText.trim()}
            className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white text-xs font-bold flex items-center gap-1.5 shadow-md shadow-emerald-900/40"
          >
            <span>Gửi</span>
            <Send className="h-3.5 w-3.5" />
          </button>
        </form>
      </div>
    </div>
  );
};
