import React, { useState, useEffect, useRef } from 'react';
import {
  Assignment,
  AssignmentSubmission,
  StudentAttachment,
} from '../../../types/assignment';
import { useAuth } from '../../../hooks/useAuth';
import {
  saveSubmissionToCloud,
  getStudentSubmission,
} from '../../../firebase/assignmentService';
import {
  FileText,
  Clock,
  Calendar,
  CheckCircle2,
  AlertCircle,
  Paperclip,
  Printer,
  Save,
  Send,
  Lock,
  Unlock,
  Award,
  MessageSquare,
  ArrowLeft,
  Upload,
  Trash2,
  Table as TableIcon,
  Sparkles,
  Check,
  Eye,
  X,
} from 'lucide-react';

interface StudentWorksheetEditorProps {
  assignment: Assignment;
  onBack: () => void;
  onSubmitted?: () => void;
}

export const StudentWorksheetEditor: React.FC<StudentWorksheetEditorProps> = ({
  assignment,
  onBack,
  onSubmitted,
}) => {
  const { user } = useAuth();

  // Load existing submission if any
  const existingSub = user ? getStudentSubmission(assignment.id, user.uid) : null;

  const [answers, setAnswers] = useState<Record<string, string>>(
    existingSub?.answers || {}
  );
  const [tableResponses, setTableResponses] = useState<
    Record<string, Record<string, Record<string, string>>>
  >(existingSub?.tableResponses || {});
  const [generalNotes, setGeneralNotes] = useState<string>(
    existingSub?.generalNotes || ''
  );
  const [attachments, setAttachments] = useState<StudentAttachment[]>(
    existingSub?.attachments || []
  );

  const [status, setStatus] = useState<AssignmentSubmission['status']>(
    existingSub?.status || 'in_progress'
  );
  const [score, setScore] = useState<number | undefined>(existingSub?.score);
  const [feedback, setFeedback] = useState<string | undefined>(existingSub?.feedback);
  const [submittedAt, setSubmittedAt] = useState<string | undefined>(
    existingSub?.submittedAt
  );
  const [allowResubmit, setAllowResubmit] = useState<boolean>(
    existingSub?.allowResubmit || false
  );

  // Auto-save state
  const [saveStatus, setSaveStatus] = useState<'saved' | 'saving' | 'unsaved'>('saved');
  const [lastSavedTime, setLastSavedTime] = useState<string>('');
  const [isConfirmSubmitOpen, setIsConfirmSubmitOpen] = useState(false);
  const [selectedImagePreview, setSelectedImagePreview] = useState<string | null>(null);

  const isLocked = (status === 'submitted' || status === 'graded') && !allowResubmit;

  // Auto-save debouncer
  const autoSaveTimerRef = useRef<NodeJS.Timeout | null>(null);

  const triggerSave = async (isFinalSubmit: boolean = false) => {
    if (!user) return;
    setSaveStatus('saving');

    const newStatus = isFinalSubmit ? 'submitted' : status;
    const subTime = isFinalSubmit ? new Date().toISOString() : submittedAt;

    const subObj: AssignmentSubmission = {
      id: `${assignment.id}_${user.uid}`,
      assignmentId: assignment.id,
      assignmentTitle: assignment.title,
      studentId: user.uid,
      studentCode: (user as any).studentCode || `HS-${user.uid.slice(-6)}`,
      studentName: user.fullName || 'Học sinh',
      studentUsername: user.username || 'student',
      classId: user.classIds?.[0] || 'class_default',
      className: assignment.classNames?.[0] || 'Lớp 10',
      answers,
      tableResponses,
      generalNotes,
      attachments,
      status: newStatus,
      lastSavedAt: new Date().toISOString(),
      submittedAt: subTime,
      score,
      feedback,
      allowResubmit: isFinalSubmit ? false : allowResubmit,
    };

    await saveSubmissionToCloud(subObj);
    setSaveStatus('saved');
    setLastSavedTime(
      new Date().toLocaleTimeString('vi-VN', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      })
    );

    if (isFinalSubmit) {
      setStatus('submitted');
      setSubmittedAt(subTime);
      setAllowResubmit(false);
      if (onSubmitted) onSubmitted();
    }
  };

  const scheduleAutoSave = () => {
    if (isLocked) return;
    setSaveStatus('unsaved');
    if (autoSaveTimerRef.current) {
      clearTimeout(autoSaveTimerRef.current);
    }
    autoSaveTimerRef.current = setTimeout(() => {
      triggerSave(false);
    }, 1500);
  };

  // Answer change handler
  const handleAnswerChange = (questionId: string, text: string) => {
    if (isLocked) return;
    setAnswers((prev) => ({ ...prev, [questionId]: text }));
    scheduleAutoSave();
  };

  // Quick symbol inserter (e.g. A, T, G, C, U, 2n, n, ♂, ♀, F1, F2...)
  const handleInsertSymbol = (questionId: string, symbol: string) => {
    if (isLocked) return;
    const currentText = answers[questionId] || '';
    setAnswers((prev) => ({ ...prev, [questionId]: currentText + symbol }));
    scheduleAutoSave();
  };

  // Table cell change handler
  const handleTableCellChange = (
    tableId: string,
    rowId: string,
    colId: string,
    value: string
  ) => {
    if (isLocked) return;
    setTableResponses((prev) => {
      const copy = { ...prev };
      if (!copy[tableId]) copy[tableId] = {};
      if (!copy[tableId][rowId]) copy[tableId][rowId] = {};
      copy[tableId][rowId][colId] = value;
      return copy;
    });
    scheduleAutoSave();
  };

  // Student file/image upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (isLocked) return;
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      reader.onload = (loadEvt) => {
        const dataUrl = loadEvt.target?.result as string;
        setAttachments((prev) => [
          ...prev,
          {
            id: `st_att_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
            name: file.name,
            type: file.type.includes('image') ? 'image' : 'file',
            dataUrl,
            size: file.size,
            uploadedAt: new Date().toISOString(),
          },
        ]);
        scheduleAutoSave();
      };
      reader.readAsDataURL(file);
    });
  };

  const handleRemoveAttachment = (attId: string) => {
    if (isLocked) return;
    setAttachments((prev) => prev.filter((a) => a.id !== attId));
    scheduleAutoSave();
  };

  const handleConfirmSubmit = () => {
    setIsConfirmSubmitOpen(false);
    triggerSave(true);
  };

  const handleUnlockResubmit = () => {
    setStatus('resubmit_requested');
    setAllowResubmit(true);
  };

  const isDuePassed = new Date(assignment.dueDate).getTime() < Date.now();

  return (
    <div className="mx-auto max-w-5xl px-3 sm:px-6 py-6 space-y-6 text-slate-800">
      {/* Top Header & Navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs font-bold text-slate-600 hover:text-sky-600 transition-colors self-start"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Quay lại danh sách bài tập</span>
        </button>

        <div className="flex items-center gap-3">
          {/* Auto-save badge */}
          <div className="flex items-center gap-1.5 text-[11px] font-semibold text-slate-500">
            {saveStatus === 'saving' ? (
              <span className="flex items-center gap-1 text-sky-600 animate-pulse">
                <Save className="h-3.5 w-3.5" />
                <span>Đang tự động lưu...</span>
              </span>
            ) : saveStatus === 'saved' ? (
              <span className="flex items-center gap-1 text-emerald-600">
                <CheckCircle2 className="h-3.5 w-3.5" />
                <span>Đã lưu {lastSavedTime ? `lúc ${lastSavedTime}` : 'tự động'}</span>
              </span>
            ) : (
              <span className="flex items-center gap-1 text-amber-600">
                <span>Chưa lưu thay đổi...</span>
              </span>
            )}
          </div>

          <button
            onClick={() => window.print()}
            type="button"
            className="p-2 rounded-xl border border-slate-200 text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-colors"
            title="In / Lưu trang bài làm"
          >
            <Printer className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Main Worksheet Document Card */}
      <div className="rounded-3xl bg-white border border-slate-200 shadow-xl overflow-hidden divide-y divide-slate-100">
        {/* Document Header Banner */}
        <div className="p-6 sm:p-8 bg-gradient-to-r from-sky-50 via-indigo-50/40 to-white space-y-4">
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-3 py-1 rounded-full text-xs font-extrabold uppercase bg-sky-600 text-white shadow-xs">
              {assignment.subject}
            </span>
            {assignment.topicTitle && (
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-purple-100 text-purple-800 border border-purple-200">
                {assignment.topicTitle}
              </span>
            )}
            <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-800 font-mono">
              Thang điểm {assignment.maxScore}
            </span>
          </div>

          <div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              {assignment.title}
            </h1>
            <p className="text-xs text-slate-600 mt-1">
              Giáo viên giao:{' '}
              <strong className="text-slate-800">{assignment.teacherName}</strong>
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs pt-2">
            <div className="flex items-center gap-2 text-slate-600">
              <Calendar className="h-4 w-4 text-sky-600 shrink-0" />
              <span>
                Hạn chót nộp bài:{' '}
                <strong className={isDuePassed ? 'text-amber-700 font-bold' : 'text-slate-800'}>
                  {new Date(assignment.dueDate).toLocaleString('vi-VN')}
                </strong>
              </span>
            </div>

            <div className="flex items-center gap-2 text-slate-600">
              <Clock className="h-4 w-4 text-indigo-600 shrink-0" />
              <span>
                {isLocked
                  ? `Đã nộp bài vào: ${submittedAt ? new Date(submittedAt).toLocaleString('vi-VN') : 'Đã nộp'}`
                  : isDuePassed
                  ? 'Đã qua hạn chót nộp bài (vẫn có thể nộp bổ sung)'
                  : 'Đang mở nhận bài làm trực tuyến'}
              </span>
            </div>
          </div>

          {/* Teacher Instructions */}
          {assignment.instructions && (
            <div className="p-4 rounded-2xl bg-white/90 border border-sky-100 text-xs text-slate-700 space-y-1 shadow-xs">
              <span className="font-bold text-sky-800 block">Hướng dẫn từ giáo viên:</span>
              <p className="leading-relaxed whitespace-pre-wrap">{assignment.instructions}</p>
            </div>
          )}

          {/* Teacher Attachments */}
          {assignment.attachments && assignment.attachments.length > 0 && (
            <div className="p-3.5 rounded-2xl bg-white border border-slate-200 text-xs space-y-2">
              <span className="font-bold text-slate-700 block">Tài liệu / Đề bài giáo viên đính kèm:</span>
              <div className="flex flex-wrap gap-2">
                {assignment.attachments.map((att) => (
                  <a
                    key={att.id}
                    href={att.url}
                    download={att.name}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-sky-50 text-sky-700 hover:bg-sky-100 font-bold border border-sky-200 transition-colors"
                  >
                    <Paperclip className="h-3.5 w-3.5" />
                    <span>{att.name}</span>
                  </a>
                ))}
              </div>
            </div>
          )}

          {/* Status Banners */}
          {status === 'graded' && score !== undefined && (
            <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Award className="h-5 w-5 text-emerald-600" />
                  <span className="font-black text-emerald-900 text-sm">
                    KẾT QUẢ CHẤM ĐIỂM TỪ GIÁO VIÊN
                  </span>
                </div>
                <span className="font-mono font-black text-2xl text-emerald-700 bg-white px-3 py-1 rounded-xl border border-emerald-300">
                  {score} / {assignment.maxScore} điểm
                </span>
              </div>
              {feedback && (
                <div className="p-3 rounded-xl bg-white text-slate-800 text-xs border border-emerald-100 whitespace-pre-wrap">
                  <strong className="text-emerald-800">Lời phê:</strong> {feedback}
                </div>
              )}
            </div>
          )}

          {status === 'submitted' && (
            <div className="p-3.5 rounded-2xl bg-sky-50 border border-sky-200 text-xs text-sky-800 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-sky-600 shrink-0" />
                <span>
                  Bài làm của bạn đã được nộp thành công vào lúc{' '}
                  <strong>{submittedAt ? new Date(submittedAt).toLocaleString('vi-VN') : ''}</strong>.{' '}
                  Bài làm đang được khóa để giáo viên chấm điểm.
                </span>
              </div>
              {allowResubmit && (
                <button
                  onClick={handleUnlockResubmit}
                  className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-white font-bold text-xs shrink-0 cursor-pointer"
                >
                  Mở Khóa Làm Lại
                </button>
              )}
            </div>
          )}

          {status === 'resubmit_requested' && (
            <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-200 text-xs text-amber-900 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <AlertCircle className="h-4 w-4 text-amber-600 shrink-0" />
                <span>
                  Giáo viên yêu cầu bạn xem lại và nộp lại phiếu học tập này. Bạn có thể chỉnh sửa và nộp lại.
                </span>
              </div>
            </div>
          )}
        </div>

        {/* SECTION 1: QUESTION ANSWERS */}
        <div className="p-6 sm:p-8 space-y-6">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <span className="flex h-7 w-7 items-center justify-center rounded-xl bg-sky-600 text-white font-black text-xs">
              1
            </span>
            <h2 className="font-black text-slate-900 text-base">
              Phần 1: Trả Lời Câu Hỏi &amp; Bài Tập Tự Luận
            </h2>
          </div>

          <div className="space-y-6">
            {assignment.questions.map((q) => {
              const studentAnswer = answers[q.id] || '';
              return (
                <div
                  key={q.id}
                  className="p-5 rounded-3xl bg-slate-50/70 border border-slate-200/80 space-y-3"
                >
                  <div className="flex items-start justify-between gap-3">
                    <p className="font-extrabold text-slate-900 text-sm leading-relaxed">
                      Câu {q.questionNumber}: {q.prompt}
                    </p>
                    {q.points && (
                      <span className="px-2.5 py-0.5 rounded-lg text-xs font-bold font-mono bg-sky-100 text-sky-800 shrink-0">
                        ({q.points} điểm)
                      </span>
                    )}
                  </div>

                  {/* Biology Symbol Helper Keyboard */}
                  {!isLocked && (
                    <div className="flex flex-wrap items-center gap-1.5 pt-1">
                      <span className="text-[10px] text-slate-400 font-bold uppercase mr-1">
                        Chèn nhanh:
                      </span>
                      {['A', 'T', 'G', 'C', 'U', '2n', 'n', 'P', 'F₁', 'F₂', '♂', '♀', 'Å', '→'].map(
                        (sym) => (
                          <button
                            key={sym}
                            type="button"
                            onClick={() => handleInsertSymbol(q.id, sym)}
                            className="px-2 py-0.5 rounded-md bg-white border border-slate-200 hover:border-sky-400 text-slate-700 font-mono text-xs font-bold shadow-2xs hover:scale-105 active:scale-95 transition-all"
                          >
                            {sym}
                          </button>
                        )
                      )}
                    </div>
                  )}

                  {/* Answer Input */}
                  <div>
                    <textarea
                      rows={4}
                      disabled={isLocked}
                      value={studentAnswer}
                      onChange={(e) => handleAnswerChange(q.id, e.target.value)}
                      placeholder={
                        isLocked
                          ? '(Học sinh chưa trả lời)'
                          : 'Nhập câu trả lời hoặc lời giải chi tiết của em tại đây...'
                      }
                      className={`w-full p-3.5 rounded-2xl border text-xs sm:text-sm font-sans transition-all ${
                        isLocked
                          ? 'bg-slate-100 text-slate-700 border-slate-200 cursor-not-allowed'
                          : 'bg-white border-slate-300 focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 text-slate-900'
                      }`}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* SECTION 2: BIOLOGICAL INTERACTIVE TABLES */}
        {assignment.tables && assignment.tables.length > 0 && (
          <div className="p-6 sm:p-8 space-y-6">
            <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
              <span className="flex h-7 w-7 items-center justify-center rounded-xl bg-purple-600 text-white font-black text-xs">
                2
              </span>
              <h2 className="font-black text-slate-900 text-base">
                Phần 2: Bảng Dữ Liệu Tương Tác (Học Sinh Điền Trực Tiếp)
              </h2>
            </div>

            <div className="space-y-6">
              {assignment.tables.map((tbl) => (
                <div
                  key={tbl.id}
                  className="p-5 rounded-3xl bg-purple-50/40 border border-purple-200/80 space-y-3"
                >
                  <div>
                    <h3 className="font-black text-purple-950 text-sm">{tbl.title}</h3>
                    {tbl.description && (
                      <p className="text-xs text-purple-700/80 mt-0.5">{tbl.description}</p>
                    )}
                  </div>

                  <div className="overflow-x-auto rounded-2xl border border-purple-200 bg-white shadow-xs">
                    <table className="w-full text-xs">
                      <thead>
                        <tr className="bg-purple-100 text-purple-950 font-bold border-b border-purple-200">
                          {tbl.columns.map((c) => (
                            <th key={c.id} className="p-3 text-left">
                              {c.header} {c.isEditableByStudent && !isLocked && '(Nhập dữ liệu)'}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-purple-100">
                        {tbl.rows.map((r) => (
                          <tr key={r.id}>
                            {tbl.columns.map((c) => {
                              const cellValue =
                                tableResponses[tbl.id]?.[r.id]?.[c.id] ?? r.cells[c.id] ?? '';

                              return (
                                <td key={c.id} className="p-2">
                                  {c.isEditableByStudent ? (
                                    <input
                                      type="text"
                                      disabled={isLocked}
                                      value={cellValue}
                                      onChange={(e) =>
                                        handleTableCellChange(
                                          tbl.id,
                                          r.id,
                                          c.id,
                                          e.target.value
                                        )
                                      }
                                      placeholder={
                                        isLocked ? '' : 'Nhấp để điền thông tin...'
                                      }
                                      className={`w-full px-3 py-2 rounded-xl text-xs font-medium border transition-colors ${
                                        isLocked
                                          ? 'bg-slate-50 text-slate-800 border-transparent font-bold'
                                          : 'bg-purple-50/60 hover:bg-purple-50 focus:bg-white border-purple-200 focus:border-purple-500 focus:ring-1 focus:ring-purple-500 text-purple-950 font-semibold'
                                      }`}
                                    />
                                  ) : (
                                    <span className="font-bold text-slate-800 px-3 py-2 block">
                                      {r.cells[c.id]}
                                    </span>
                                  )}
                                </td>
                              );
                            })}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* SECTION 3: GENERAL NOTES / ESSAY */}
        <div className="p-6 sm:p-8 space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <span className="flex h-7 w-7 items-center justify-center rounded-xl bg-emerald-600 text-white font-black text-xs">
              3
            </span>
            <h2 className="font-black text-slate-900 text-base">
              Phần 3: Lời Giải Bổ Sung / Ghi Chú Làm Bài
            </h2>
          </div>

          <textarea
            rows={3}
            disabled={isLocked}
            value={generalNotes}
            onChange={(e) => {
              if (isLocked) return;
              setGeneralNotes(e.target.value);
              scheduleAutoSave();
            }}
            placeholder={
              isLocked
                ? '(Không có ghi chú thêm)'
                : 'Nhập ghi chú hoặc các bước tính toán mở rộng nếu cần...'
            }
            className={`w-full p-3.5 rounded-2xl border text-xs sm:text-sm font-sans ${
              isLocked
                ? 'bg-slate-100 text-slate-700 border-slate-200 cursor-not-allowed'
                : 'bg-white border-slate-300 focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 text-slate-900'
            }`}
          />
        </div>

        {/* SECTION 4: STUDENT ATTACHMENTS (HAND-WRITTEN PHOTO) */}
        {assignment.allowAttachment && (
          <div className="p-6 sm:p-8 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <span className="flex h-7 w-7 items-center justify-center rounded-xl bg-amber-500 text-white font-black text-xs">
                  4
                </span>
                <h2 className="font-black text-slate-900 text-base">
                  Phần 4: Ảnh Chụp Bài Làm Tay / Sơ Đồ Tư Duy Đính Kèm
                </h2>
              </div>

              {!isLocked && (
                <label className="px-3.5 py-1.5 rounded-xl bg-sky-50 hover:bg-sky-100 text-sky-700 font-bold text-xs flex items-center gap-1.5 border border-sky-200 cursor-pointer transition-colors shadow-2xs">
                  <Upload className="h-3.5 w-3.5" />
                  <span>Tải ảnh bài làm (Chụp ảnh/File)</span>
                  <input
                    type="file"
                    multiple
                    accept="image/*,.pdf"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>
              )}
            </div>

            {attachments.length === 0 ? (
              <p className="text-xs text-slate-400 italic">
                {isLocked
                  ? 'Không có ảnh hoặc tệp đính kèm nào trong bài nộp này.'
                  : 'Nếu em làm bài giải chi tiết ra giấy kiểm tra, em có thể chụp ảnh và tải lên đây để giáo viên chấm điểm trực tiếp.'}
              </p>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {attachments.map((att) => (
                  <div
                    key={att.id}
                    className="p-2 rounded-2xl bg-slate-50 border border-slate-200 space-y-2 text-center group"
                  >
                    {att.dataUrl?.startsWith('data:image') ? (
                      <div
                        onClick={() => setSelectedImagePreview(att.dataUrl)}
                        className="h-28 w-full rounded-xl overflow-hidden bg-slate-200 cursor-pointer relative group-hover:opacity-90"
                      >
                        <img
                          src={att.dataUrl}
                          alt={att.name}
                          className="h-full w-full object-cover"
                        />
                        <div className="absolute inset-0 bg-slate-900/40 opacity-0 group-hover:opacity-100 flex items-center justify-center text-white text-xs font-bold transition-opacity">
                          Xem to
                        </div>
                      </div>
                    ) : (
                      <div className="h-28 w-full rounded-xl bg-sky-100 flex items-center justify-center text-sky-800 font-bold text-xs p-2 break-all">
                        {att.name}
                      </div>
                    )}

                    <div className="flex items-center justify-between text-[11px] px-1">
                      <span className="truncate text-slate-700 font-medium" title={att.name}>
                        {att.name}
                      </span>
                      {!isLocked && (
                        <button
                          type="button"
                          onClick={() => handleRemoveAttachment(att.id)}
                          className="text-rose-500 hover:text-rose-700 p-1"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* BOTTOM FIXED ACTION BAR */}
        <div className="p-6 bg-slate-50 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            {isLocked ? (
              <span className="flex items-center gap-1 font-bold text-slate-700">
                <Lock className="h-4 w-4 text-slate-500" />
                <span>Bài làm đã nộp (Đang khóa chỉnh sửa)</span>
              </span>
            ) : (
              <span className="flex items-center gap-1 text-slate-600">
                <Unlock className="h-4 w-4 text-emerald-600" />
                <span>Hệ thống tự động lưu liên tục sau mỗi thao tác</span>
              </span>
            )}
          </div>

          <div className="flex items-center gap-3 self-end sm:self-auto">
            <button
              onClick={onBack}
              type="button"
              className="px-4 py-2.5 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-200 transition-colors"
            >
              Quay Lại
            </button>

            {!isLocked && (
              <>
                <button
                  onClick={() => triggerSave(false)}
                  type="button"
                  className="px-4 py-2.5 rounded-xl text-xs font-bold text-sky-700 bg-sky-50 hover:bg-sky-100 border border-sky-200 transition-colors flex items-center gap-1.5"
                >
                  <Save className="h-4 w-4" />
                  <span>Lưu Nháp</span>
                </button>

                <button
                  onClick={() => setIsConfirmSubmitOpen(true)}
                  type="button"
                  className="px-6 py-2.5 rounded-xl text-xs font-black text-white bg-emerald-600 hover:bg-emerald-500 shadow-md shadow-emerald-600/30 transition-all flex items-center gap-2 cursor-pointer hover:scale-105 active:scale-95"
                >
                  <Send className="h-4 w-4" />
                  <span>NỘP BÀI CHÍNH THỨC</span>
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Confirmation Modal before Submit */}
      {isConfirmSubmitOpen && (
        <div className="fixed inset-0 z-60 bg-slate-900/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-3xl bg-white shadow-2xl p-6 space-y-4 border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-100 text-emerald-700 mx-auto">
              <Send className="h-6 w-6" />
            </div>

            <div className="text-center space-y-1">
              <h3 className="text-base font-black text-slate-900">
                Xác Nhận Nộp Bài Phiếu Học Tập?
              </h3>
              <p className="text-xs text-slate-600">
                Sau khi bấm <strong>&quot;Xác nhận nộp bài&quot;</strong>, bài làm của em sẽ được gửi tới giáo viên và khóa chỉnh sửa để giáo viên chấm điểm.
              </p>
            </div>

            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 text-xs space-y-1 text-slate-600">
              <p>• Phiếu: <strong>{assignment.title}</strong></p>
              <p>• Số câu hỏi đã làm: <strong>{Object.keys(answers).length}</strong> câu</p>
              <p>• Tệp/Ảnh đính kèm: <strong>{attachments.length}</strong> tệp</p>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={() => setIsConfirmSubmitOpen(false)}
                className="flex-1 py-2.5 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 transition-colors"
              >
                Kiểm tra lại
              </button>
              <button
                onClick={handleConfirmSubmit}
                className="flex-1 py-2.5 rounded-xl text-xs font-black text-white bg-emerald-600 hover:bg-emerald-500 shadow-md shadow-emerald-600/30 transition-all cursor-pointer"
              >
                Xác Nhận Nộp Bài
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Image Preview Modal */}
      {selectedImagePreview && (
        <div
          onClick={() => setSelectedImagePreview(null)}
          className="fixed inset-0 z-60 bg-black/80 flex items-center justify-center p-4 cursor-pointer"
        >
          <div className="relative max-w-3xl max-h-[90vh]">
            <img
              src={selectedImagePreview}
              alt="Xem to"
              className="max-h-[85vh] max-w-full rounded-2xl shadow-2xl object-contain"
            />
            <button
              onClick={() => setSelectedImagePreview(null)}
              className="absolute top-2 right-2 p-2 bg-black/60 rounded-full text-white hover:bg-black/90"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
