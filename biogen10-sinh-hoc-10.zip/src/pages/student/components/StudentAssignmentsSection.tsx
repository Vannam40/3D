import React, { useState, useEffect } from 'react';
import {
  Assignment,
  AssignmentSubmission,
} from '../../../types/assignment';
import { useAuth } from '../../../hooks/useAuth';
import {
  subscribeToAssignments,
  subscribeToSubmissions,
  getStudentSubmission,
} from '../../../firebase/assignmentService';
import { StudentWorksheetEditor } from './StudentWorksheetEditor';
import {
  FileText,
  Clock,
  Calendar,
  CheckCircle2,
  AlertCircle,
  Award,
  Play,
  RotateCcw,
  BookOpen,
  ArrowRight,
  School,
  Lock,
  Search,
} from 'lucide-react';

export const StudentAssignmentsSection: React.FC = () => {
  const { user, classes } = useAuth();

  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [submissions, setSubmissions] = useState<AssignmentSubmission[]>([]);
  const [activeAssignment, setActiveAssignment] = useState<Assignment | null>(null);

  const [statusFilter, setStatusFilter] = useState<'all' | 'todo' | 'submitted' | 'graded'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const unsubAsg = subscribeToAssignments((list) => {
      // Filter published assignments targeted to this student's classes or 'all'
      const studentClassIds = user?.classIds || [];
      const relevant = list.filter((a) => {
        if (a.status !== 'published') return false;
        if (a.classIds.includes('all')) return true;
        return a.classIds.some((cId) => studentClassIds.includes(cId));
      });
      setAssignments(relevant);
    });

    const unsubSub = subscribeToSubmissions(null, (subList) => {
      if (user) {
        setSubmissions(subList.filter((s) => s.studentId === user.uid));
      }
    });

    return () => {
      unsubAsg();
      unsubSub();
    };
  }, [user]);

  // If student is currently doing a worksheet, render the editor full view
  if (activeAssignment) {
    return (
      <StudentWorksheetEditor
        assignment={activeAssignment}
        onBack={() => setActiveAssignment(null)}
        onSubmitted={() => {
          // Keep active to let student review or return
        }}
      />
    );
  }

  // Filtered list
  const filteredAssignments = assignments.filter((asg) => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      if (!asg.title.toLowerCase().includes(q) && !asg.subject.toLowerCase().includes(q)) {
        return false;
      }
    }

    const sub = submissions.find((s) => s.assignmentId === asg.id);
    const isSubmitted = sub && (sub.status === 'submitted' || sub.status === 'graded');
    const isGraded = sub && sub.status === 'graded';

    if (statusFilter === 'todo' && isSubmitted) return false;
    if (statusFilter === 'submitted' && (!sub || sub.status !== 'submitted')) return false;
    if (statusFilter === 'graded' && !isGraded) return false;

    return true;
  });

  // Counts
  const todoCount = assignments.filter((a) => {
    const sub = submissions.find((s) => s.assignmentId === a.id);
    return !sub || sub.status === 'in_progress' || sub.status === 'resubmit_requested';
  }).length;

  const submittedWaitingCount = submissions.filter((s) => s.status === 'submitted').length;
  const gradedCount = submissions.filter((s) => s.status === 'graded').length;

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-sky-900 via-indigo-900 to-slate-900 p-6 sm:p-8 text-white relative overflow-hidden shadow-xl border border-sky-800">
        <div className="relative z-10 space-y-3 max-w-2xl">
          <div className="flex items-center gap-2 text-xs font-bold text-sky-400">
            <FileText className="h-4 w-4" />
            <span>HỆ THỐNG PHIẾU HỌC TẬP & BÀI TẬP TRỰC TUYẾN</span>
          </div>
          <h2 className="text-xl sm:text-3xl font-black tracking-tight">
            Phiếu Học Tập &amp; Bài Tập Được Giao
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Làm bài trực tiếp trên phiếu số hóa, điền bảng dữ liệu sinh học tương tác, nộp bài đúng hạn và nhận nhận xét, điểm số chi tiết từ thầy cô giáo.
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-2 text-xs">
            <span className="px-3 py-1.5 rounded-xl bg-sky-950/80 border border-sky-700/60 font-bold text-sky-300 flex items-center gap-1.5">
              <span>Cần làm:</span>
              <strong className="text-white font-mono text-sm">{todoCount}</strong>
            </span>
            <span className="px-3 py-1.5 rounded-xl bg-indigo-950/80 border border-indigo-700/60 font-bold text-indigo-300 flex items-center gap-1.5">
              <span>Đã nộp chờ chấm:</span>
              <strong className="text-white font-mono text-sm">{submittedWaitingCount}</strong>
            </span>
            <span className="px-3 py-1.5 rounded-xl bg-emerald-950/80 border border-emerald-700/60 font-bold text-emerald-300 flex items-center gap-1.5">
              <span>Đã có điểm:</span>
              <strong className="text-white font-mono text-sm">{gradedCount}</strong>
            </span>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
        <div className="flex items-center gap-2 overflow-x-auto text-xs pb-1 sm:pb-0">
          <button
            onClick={() => setStatusFilter('all')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer whitespace-nowrap ${
              statusFilter === 'all'
                ? 'bg-sky-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 bg-slate-50'
            }`}
          >
            Tất cả ({assignments.length})
          </button>
          <button
            onClick={() => setStatusFilter('todo')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer whitespace-nowrap ${
              statusFilter === 'todo'
                ? 'bg-sky-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 bg-slate-50'
            }`}
          >
            Cần làm ({todoCount})
          </button>
          <button
            onClick={() => setStatusFilter('submitted')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer whitespace-nowrap ${
              statusFilter === 'submitted'
                ? 'bg-sky-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 bg-slate-50'
            }`}
          >
            Đã nộp ({submittedWaitingCount})
          </button>
          <button
            onClick={() => setStatusFilter('graded')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer whitespace-nowrap ${
              statusFilter === 'graded'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 bg-slate-50'
            }`}
          >
            Đã có điểm ({gradedCount})
          </button>
        </div>

        <div className="relative">
          <Search className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Tìm kiếm phiếu học tập..."
            className="pl-9 pr-4 py-2 rounded-xl border border-slate-200 text-xs w-full sm:w-60 focus:border-sky-500 focus:ring-1 focus:ring-sky-500"
          />
        </div>
      </div>

      {/* Assignment Cards Grid */}
      <div className="space-y-4">
        {filteredAssignments.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-3xl border border-slate-200 p-8 space-y-3">
            <FileText className="h-10 w-10 text-slate-300 mx-auto" />
            <h3 className="font-bold text-slate-700 text-sm">Không có phiếu học tập nào trong mục này</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Khi giáo viên giao phiếu bài tập cho lớp của em, phiếu sẽ tự động xuất hiện tại đây.
            </p>
          </div>
        ) : (
          filteredAssignments.map((asg) => {
            const sub = submissions.find((s) => s.assignmentId === asg.id);
            const isGraded = sub && sub.status === 'graded';
            const isSubmitted = sub && (sub.status === 'submitted' || sub.status === 'graded');
            const isResubmitReq = sub && sub.status === 'resubmit_requested';
            const isDuePassed = new Date(asg.dueDate).getTime() < Date.now();

            return (
              <div
                key={asg.id}
                className="rounded-3xl bg-white border border-slate-200 shadow-xs hover:shadow-md transition-all overflow-hidden p-5 sm:p-6 space-y-4 group"
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                  <div className="space-y-2 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-sky-100 text-sky-800 border border-sky-200">
                        {asg.subject}
                      </span>
                      {asg.topicTitle && (
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-purple-100 text-purple-800 border border-purple-200">
                          {asg.topicTitle}
                        </span>
                      )}

                      {/* Status Badges */}
                      {isGraded ? (
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-100 text-emerald-800 border border-emerald-200 flex items-center gap-1">
                          <Award className="h-3 w-3" />
                          <span>Đã chấm điểm: {sub.score}/{asg.maxScore}</span>
                        </span>
                      ) : isSubmitted ? (
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-sky-100 text-sky-800 border border-sky-200 flex items-center gap-1">
                          <CheckCircle2 className="h-3 w-3" />
                          <span>Đã nộp bài</span>
                        </span>
                      ) : isResubmitReq ? (
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200 flex items-center gap-1">
                          <RotateCcw className="h-3 w-3" />
                          <span>Yêu cầu sửa &amp; nộp lại</span>
                        </span>
                      ) : sub ? (
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700">
                          Đang làm dở
                        </span>
                      ) : (
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-50 text-rose-600 border border-rose-200">
                          Chưa làm
                        </span>
                      )}
                    </div>

                    <h3 className="text-base sm:text-lg font-black text-slate-900 group-hover:text-sky-600 transition-colors">
                      {asg.title}
                    </h3>

                    <p className="text-xs text-slate-600 line-clamp-2">
                      {asg.instructions}
                    </p>
                  </div>

                  {/* Action Button */}
                  <div className="shrink-0 self-start sm:self-center">
                    <button
                      onClick={() => setActiveAssignment(asg)}
                      className={`px-5 py-2.5 rounded-xl text-xs font-black flex items-center gap-2 transition-all cursor-pointer shadow-sm hover:scale-105 active:scale-95 ${
                        isGraded
                          ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/30'
                          : isSubmitted
                          ? 'bg-slate-800 hover:bg-slate-700 text-white'
                          : 'bg-sky-600 hover:bg-sky-500 text-white shadow-sky-600/30'
                      }`}
                    >
                      {isGraded ? (
                        <>
                          <Award className="h-4 w-4" />
                          <span>Xem Điểm &amp; Lời Phê</span>
                        </>
                      ) : isSubmitted ? (
                        <>
                          <Lock className="h-4 w-4" />
                          <span>Xem Lại Bài Đã Nộp</span>
                        </>
                      ) : sub ? (
                        <>
                          <Play className="h-4 w-4 fill-white" />
                          <span>Tiếp Tục Làm Bài</span>
                        </>
                      ) : (
                        <>
                          <Play className="h-4 w-4 fill-white" />
                          <span>Làm Bài Ngay</span>
                        </>
                      )}
                      <ArrowRight className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>

                {/* Card Meta */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-3 border-t border-slate-100 text-xs text-slate-500">
                  <div className="flex items-center gap-1.5">
                    <School className="h-3.5 w-3.5 text-slate-400" />
                    <span>GV: <strong className="text-slate-700">{asg.teacherName}</strong></span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <Calendar className="h-3.5 w-3.5 text-slate-400" />
                    <span>
                      Hạn nộp:{' '}
                      <strong className={isDuePassed ? 'text-amber-700 font-bold' : 'text-slate-700'}>
                        {new Date(asg.dueDate).toLocaleString('vi-VN')}
                      </strong>
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <FileText className="h-3.5 w-3.5 text-slate-400" />
                    <span>
                      Gồm <strong>{asg.questions?.length || 0}</strong> câu hỏi
                      {asg.tables && asg.tables.length > 0 && `, ${asg.tables.length} bảng dữ liệu`}
                    </span>
                  </div>
                </div>

                {/* Score & Feedback Preview if Graded */}
                {isGraded && sub?.feedback && (
                  <div className="p-3 rounded-2xl bg-emerald-50/70 border border-emerald-200 text-xs text-slate-800 space-y-1">
                    <span className="font-bold text-emerald-900 block">Lời phê của thầy cô:</span>
                    <p className="italic text-slate-700">{sub.feedback}</p>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
