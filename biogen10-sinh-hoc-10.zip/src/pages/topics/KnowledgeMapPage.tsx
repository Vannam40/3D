import React, { useState } from 'react';
import { useGeneticsTopics } from '../../data/topicsData';
import { useAuth } from '../../hooks/useAuth';
import { TopicCard } from '../../components/TopicCard';
import { CHAPTERS, ChapterKey } from '../../data/bio10';
import { Compass, Layers } from 'lucide-react';

export const KnowledgeMapPage: React.FC = () => {
  const { userProgress } = useAuth();
  const { topics } = useGeneticsTopics();
  const [active, setActive] = useState<'all' | ChapterKey>('all');

  const chapters = CHAPTERS.filter(c => topics.some(t => t.module === c.key));
  const shown = active === 'all' ? chapters : chapters.filter(c => c.key === active);

  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8 space-y-8 text-slate-800">
      <div className="space-y-4 pb-6 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-sky-600 mb-1">
            <Compass className="h-4 w-4" />
            <span>SGK SINH HỌC 10 · KẾT NỐI TRI THỨC VỚI CUỘC SỐNG</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
            Bản đồ kiến thức (Knowledge Map)
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 mt-1">
            {topics.length} bài lý thuyết, sắp xếp theo chương SGK. Mỗi bài có mô hình 3D song ngữ, thuật ngữ English Biology và tóm tắt tiếng Anh.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-white rounded-2xl border border-slate-200 shadow-xs text-xs">
          <button
            onClick={() => setActive('all')}
            className={`px-3 py-1.5 rounded-xl font-bold transition-all ${active === 'all' ? 'bg-sky-600 text-white' : 'text-slate-600 hover:text-slate-900'}`}
          >
            Tất cả ({topics.length})
          </button>
          {chapters.map(c => (
            <button
              key={c.key}
              onClick={() => setActive(c.key)}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all ${active === c.key ? 'text-white' : 'text-slate-600 hover:text-slate-900'}`}
              style={active === c.key ? { background: c.color } : undefined}
            >
              {c.key === 'mo_dau' ? 'Mở đầu' : c.titleVi.split('.')[0]} ({topics.filter(t => t.module === c.key).length})
            </button>
          ))}
        </div>
      </div>

      {shown.map((c, ci) => {
        const list = topics.filter(t => t.module === c.key);
        return (
          <section key={c.key} className={`space-y-5 ${ci > 0 ? 'pt-6 border-t border-slate-200' : ''}`}>
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-2xl text-white shadow-md" style={{ background: c.color }}>
                <Layers className="h-5 w-5" />
              </div>
              <div>
                <span className="text-xs font-mono font-bold uppercase" style={{ color: c.color }}>{c.part}</span>
                <h2 className="text-lg font-black text-slate-900">
                  {c.titleVi} <span className="text-sm font-semibold italic text-slate-500">· {c.titleEn}</span>
                </h2>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {list.map(topic => (
                <TopicCard
                  key={topic.id}
                  topic={topic}
                  status={userProgress[topic.id]?.status || 'available'}
                  progressPercent={userProgress[topic.id]?.progressPercent || 0}
                />
              ))}
            </div>
          </section>
        );
      })}
    </div>
  );
};
