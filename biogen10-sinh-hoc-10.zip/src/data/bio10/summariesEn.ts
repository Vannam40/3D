/**
 * Tóm tắt bài học bằng tiếng Anh (Lesson summary in English).
 * Mỗi câu là bản dịch tiếng Anh của phần "Kiến thức cốt lõi" / nội dung chính trong SGK Sinh học 10 (KNTT).
 * Không bổ sung kiến thức ngoài SGK.
 */
export const SUMMARIES_EN: Record<string, string[]> = {
  bai01_gioi_thieu_sinh_hoc: [
    'Biology studies life at every level of organisation: molecules, cells, multicellular organisms, populations, communities and ecosystems.',
    'Biological research has many applications in medicine and pharmacy, food technology, environmental protection, agriculture, forestry and fisheries.',
    'Biological research must aim at sustainable development and take social ethics into account.',
    'The future of biology is very promising thanks to its links with other natural sciences and the development of technology, especially information technology.',
  ],
  bai02_phuong_phap_nghien_cuu: [
    'Common methods in biology are observation, laboratory work and scientific experiments.',
    'The scientific process: observe → ask a question → form a hypothesis → test it with an experiment → analyse the results → draw a conclusion.',
    'Bioinformatics uses software, algorithms and models to store, classify and analyse large amounts of biological data.',
  ],
  bai03_cap_do_to_chuc: [
    'A level of organisation of life shows all the functions of life: growth, development, reproduction, response, and metabolism of matter and energy.',
    'The basic levels of organisation are the cell, the organism, the population, the community and the ecosystem.',
    'The living world is organised hierarchically; the interacting parts of each level create emergent properties.',
    'The levels are connected through life activities at the cellular level and through the transfer of energy and matter.',
  ],
  bai04_nguyen_to_va_nuoc: [
    'Modern cell theory: all organisms are made of cells; the cell is the smallest basic unit of life; cells only arise from pre-existing cells.',
    'Macro-elements mainly have structural roles; trace elements make up a very small proportion but are important in regulating life activities.',
    'Because water molecules are polar, water is the main component of cells, a solvent, a raw material and the medium for chemical reactions.',
  ],
  bai05_phan_tu_sinh_hoc: [
    'Carbohydrates (C : H : O = 1 : 2 : 1) include monosaccharides, disaccharides and polysaccharides; they store energy and build structures.',
    'Lipids are hydrophobic: triglycerides, phospholipids, steroids, carotenoids and vitamins A, D, E, K; they store energy long-term and build membranes.',
    'Proteins are polymers of amino acids; their three-dimensional shape determines their function.',
    'DNA has two polynucleotide chains (A pairs with T, G pairs with C) and carries, stores and passes on genetic information. RNA has one chain with the bases A, U, G, C and has many functions.',
  ],
  bai07_te_bao_nhan_so: [
    'Prokaryotic cells are small, have no nuclear membrane, and their cytoplasm contains only ribosomes, with no membrane-bound organelles.',
    'Their main parts are the cell wall, the cell membrane, the cytoplasm and the nucleoid; some also have pili, flagella or an outer membrane.',
    'Prokaryotic cells grow and develop quickly and can adapt to many kinds of environments.',
  ],
  bai08_te_bao_nhan_thuc: [
    'Eukaryotic cells have a true nucleus (nuclear envelope, nucleolus and chromatin), which is the control centre of the cell.',
    'Ribosomes make proteins; the rough endoplasmic reticulum makes proteins, the smooth endoplasmic reticulum makes lipids and removes toxins; the Golgi apparatus packages and distributes products.',
    'Mitochondria and chloroplasts have two membranes and contain their own DNA and ribosomes; both produce ATP.',
    'The cell membrane follows the fluid mosaic model; it controls the exchange of substances and cell signalling.',
  ],
  bai10_trao_doi_chat_qua_mang: [
    'Passive transport moves substances down a concentration gradient and does not use energy (simple diffusion, facilitated diffusion, osmosis).',
    'Active transport moves substances against a concentration gradient and needs ATP and pump proteins.',
    'Large molecules are moved by pinocytosis, phagocytosis and exocytosis through changes in the shape of the membrane, which also need energy.',
  ],
  bai12_truyen_tin_te_bao: [
    'Cells can send signal molecules to each other in several different ways.',
    'A signal is received by a receptor, transduced through a chain of proteins to target proteins, and then causes a response: turning genes on or off, changing metabolism, movement or cell division.',
  ],
  bai13_chuyen_hoa_nang_luong: [
    'Chemical energy is the main form of energy that cells store and use for life activities.',
    'ATP is made of adenine, ribose and three phosphate groups; it stores energy for the short term and supplies it immediately when needed.',
    'Enzymes lower the activation energy; each enzyme has a specific active site; enzyme activity is affected by temperature, pH, substrate concentration, enzyme concentration and regulators.',
  ],
  bai14_phan_giai_tong_hop: [
    'Cellular respiration includes glycolysis, the Krebs cycle and the electron transport chain, and gives the highest energy yield. Fermentation produces less ATP.',
    'Photosynthesis: the light reactions convert light energy into chemical energy in ATP and NADPH; the dark reactions fix CO₂ through the Calvin cycle.',
    'Anabolism supplies materials for catabolism, and catabolism supplies energy and materials for anabolism.',
  ],
  bai16_chu_ki_nguyen_phan: [
    'The cell cycle includes interphase, division of the genetic material and division of the cytoplasm; it is strictly controlled.',
    'Mitosis consists of nuclear division (prophase, metaphase, anaphase, telophase) and cytoplasmic division.',
    'Accurate DNA replication and equal separation of chromosomes give daughter cells identical genetic material.',
    'Cancer develops when mitosis is not controlled.',
  ],
  bai17_giam_phan: [
    'Meiosis has two successive cell divisions but only one round of DNA replication.',
    'One cell produces four daughter cells with half the number of chromosomes and different combinations of chromosomes.',
    'Meiosis, fertilisation and mitosis together keep the diploid chromosome number of a species stable and create diverse gene combinations.',
  ],
  bai19_cong_nghe_te_bao: [
    'Animal cell technology grows stem cells so that they divide and differentiate; it is used to clone animals and to make cells that replace diseased cells.',
    'Plant cell technology uses nutrient media containing hormones so that cells regenerate into whole plants; it helps to propagate valuable varieties quickly and to create interspecific hybrid plants and homozygous plants.',
  ],
  bai20_da_dang_vi_sinh_vat: [
    'Microorganisms are very small organisms that can usually be seen only under a microscope.',
    'Prokaryotic microorganisms include bacteria and archaea; eukaryotic microorganisms include microalgae, microfungi and protozoa.',
    'There are four modes of nutrition: photoautotrophy, photoheterotrophy, chemoautotrophy and chemoheterotrophy.',
    'Common research methods are observation, and isolation and culture of microorganisms.',
  ],
  bai21_trao_doi_chat_sinh_truong_vsv: [
    'Microorganisms build macromolecules from simple substances and secrete enzymes to break down complex organic matter.',
    'Growth of a bacterial population is an increase in the number of cells; a batch culture has four phases.',
    'Growth is affected by physical and chemical factors, antibiotics and other factors.',
    'The three main types of reproduction are binary fission, spore formation and budding.',
  ],
  bai22_vai_tro_ung_dung_vsv: [
    'Decomposing microorganisms are an important link in the cycling of matter; many microorganisms enrich the soil with nutrients.',
    'Microorganisms affect humans in two ways: they can be beneficial or harmful.',
    'Applications are based on their biological features, through fermentation technology and product recovery technology.',
  ],
  bai24_khai_quat_virus: [
    'A virus is a non-cellular entity, very small, that can only multiply inside living cells.',
    'A virus consists of a nucleic acid core and a protein coat (capsid); some viruses also have an envelope.',
    'Lytic cycle: attachment → penetration → synthesis → assembly → release. Lysogenic cycle: integration → replication together with the host cell → excision and expression.',
  ],
  bai25_benh_do_virus: [
    'Viruses cause disease by destroying cells, producing toxins or causing mutations in host cells.',
    'Influenza spreads through droplets and contact; HIV spreads through blood, unsafe sex and from mother to child; plant viruses spread through wounds or through reproduction.',
    'Diseases are prevented mainly by vaccines, avoiding sources of infection and strengthening the body’s resistance.',
    'Applications of viruses: vaccines, viral insecticides and vectors for gene transfer.',
  ],
};
