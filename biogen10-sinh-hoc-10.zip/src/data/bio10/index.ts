/**
 * Bộ dữ liệu Sinh học 10 – Kết nối tri thức với cuộc sống (19 bài lý thuyết = 19 chủ đề).
 * Ghép từ các file bài học → dữ liệu dùng chung cho toàn ứng dụng.
 */
import { bai01 } from './lessons/bai01';
import { bai02 } from './lessons/bai02';
import { bai03 } from './lessons/bai03';
import { bai04 } from './lessons/bai04';
import { bai05 } from './lessons/bai05';
import { bai07 } from './lessons/bai07';
import { bai08 } from './lessons/bai08';
import { bai10 } from './lessons/bai10';
import { bai12 } from './lessons/bai12';
import { bai13 } from './lessons/bai13';
import { bai14 } from './lessons/bai14';
import { bai16 } from './lessons/bai16';
import { bai17 } from './lessons/bai17';
import { bai19 } from './lessons/bai19';
import { bai20 } from './lessons/bai20';
import { bai21 } from './lessons/bai21';
import { bai22 } from './lessons/bai22';
import { bai24 } from './lessons/bai24';
import { bai25 } from './lessons/bai25';
import { CHAPTERS, ChapterKey, LessonPack, KnowledgeSection } from './types';

export * from './types';

import { SUMMARIES_EN } from './summariesEn';

/** 19 bài lý thuyết (không gồm các bài thực hành 6, 9, 11, 15, 18, 23, 26) */
export const LESSONS: LessonPack[] = [
  bai01, bai02, bai03, bai04, bai05, bai07, bai08, bai10, bai12, bai13,
  bai14, bai16, bai17, bai19, bai20, bai21, bai22, bai24, bai25,
].map(l => ({ ...l, summaryEn: SUMMARIES_EN[l.id] || [] }));

export const LESSON_BY_ID: Record<string, LessonPack> = Object.fromEntries(LESSONS.map(l => [l.id, l]));

export function getLesson(id: string): LessonPack | undefined {
  return LESSON_BY_ID[id];
}

export function getChapter(key: ChapterKey | string) {
  return CHAPTERS.find(c => c.key === key) || CHAPTERS[0];
}

/** Bỏ tiền tố "Bài 12. " để lấy tên ngắn */
export function shortTitle(titleVi: string): string {
  return titleVi.replace(/^Bài\s*\d+\.\s*/, '');
}

/** Toàn bộ nội dung kiến thức của một bài: yêu cầu cần đạt → các mục SGK → kiến thức cốt lõi */
export function buildKnowledgeSections(l: LessonPack): KnowledgeSection[] {
  return [
    { heading: 'Yêu cầu cần đạt', bulletPoints: l.objectives },
    ...l.sections,
    { heading: 'Kiến thức cốt lõi', bulletPoints: l.core },
  ];
}

/** Văn bản thuần của bài – dùng làm ngữ cảnh cho BioBot và tra cứu ngoại tuyến */
export function lessonPlainText(l: LessonPack): string {
  const parts: string[] = [`${l.titleVi} (${l.pages})`];
  buildKnowledgeSections(l).forEach(s => {
    parts.push(`## ${s.heading}`);
    s.paragraphs?.forEach(p => parts.push(p));
    s.bulletPoints?.forEach(b => parts.push(`- ${b}`));
    s.formulaBox?.formulas.forEach(f => parts.push(`* ${f}`));
    if (s.highlightBox) parts.push(s.highlightBox);
  });
  return parts.join('\n');
}

export const TOTAL_TERMS = LESSONS.reduce((n, l) => n + l.terms.length, 0);
export const TOTAL_QUESTIONS = LESSONS.reduce((n, l) => n + l.mcq.length + l.tf.length, 0);

/** Nhóm lớn dùng cho thống kê: A = Mở đầu + Phần một (Sinh học tế bào); B = Phần hai (Vi sinh vật & virus) */
export type PartKey = 'A' | 'B';
export function partOf(chapter: ChapterKey | string): PartKey {
  return chapter === 'chuong6' || chapter === 'chuong7' ? 'B' : 'A';
}
export const PART_LABELS: Record<PartKey, { short: string; full: string }> = {
  A: { short: 'Mở đầu & Sinh học tế bào', full: 'Phần mở đầu + Phần một: Sinh học tế bào' },
  B: { short: 'Vi sinh vật & virus', full: 'Phần hai: Sinh học vi sinh vật và virus' },
};
