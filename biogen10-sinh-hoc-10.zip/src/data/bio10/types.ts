/**
 * Kiểu dữ liệu cho bộ nội dung Sinh học 10 – Kết nối tri thức với cuộc sống.
 * Mỗi bài trong SGK là một "LessonPack" = một chủ đề trong ứng dụng.
 *
 * Nguồn kiến thức: SGK Sinh học 10 (KNTT), NXB Giáo dục Việt Nam.
 * Phần tiếng Anh (thuật ngữ, câu định nghĩa) là bản dịch tương ứng nội dung SGK.
 */

export type ChapterKey =
  | 'mo_dau'
  | 'chuong1'
  | 'chuong2'
  | 'chuong3'
  | 'chuong4'
  | 'chuong5'
  | 'chuong6'
  | 'chuong7';

export interface ChapterInfo {
  key: ChapterKey;
  part: string;
  titleVi: string;
  titleEn: string;
  color: string;
}

export const CHAPTERS: ChapterInfo[] = [
  { key: 'mo_dau', part: 'Phần mở đầu', titleVi: 'Mở đầu', titleEn: 'Introduction to Biology', color: '#0ea5e9' },
  { key: 'chuong1', part: 'Phần một – Sinh học tế bào', titleVi: 'Chương 1. Thành phần hoá học của tế bào', titleEn: 'Chemical Composition of the Cell', color: '#10b981' },
  { key: 'chuong2', part: 'Phần một – Sinh học tế bào', titleVi: 'Chương 2. Cấu trúc tế bào', titleEn: 'Cell Structure', color: '#22c55e' },
  { key: 'chuong3', part: 'Phần một – Sinh học tế bào', titleVi: 'Chương 3. Trao đổi chất qua màng và truyền tin tế bào', titleEn: 'Membrane Transport & Cell Signalling', color: '#14b8a6' },
  { key: 'chuong4', part: 'Phần một – Sinh học tế bào', titleVi: 'Chương 4. Chuyển hoá năng lượng trong tế bào', titleEn: 'Energy Metabolism in the Cell', color: '#f59e0b' },
  { key: 'chuong5', part: 'Phần một – Sinh học tế bào', titleVi: 'Chương 5. Chu kì tế bào và phân bào', titleEn: 'Cell Cycle & Cell Division', color: '#a855f7' },
  { key: 'chuong6', part: 'Phần hai – Sinh học vi sinh vật và virus', titleVi: 'Chương 6. Sinh học vi sinh vật', titleEn: 'Microbiology', color: '#ec4899' },
  { key: 'chuong7', part: 'Phần hai – Sinh học vi sinh vật và virus', titleVi: 'Chương 7. Virus', titleEn: 'Viruses', color: '#ef4444' },
];

export interface KnowledgeSection {
  heading: string;
  paragraphs?: string[];
  bulletPoints?: string[];
  formulaBox?: { title: string; formulas: string[] };
  highlightBox?: string;
}

/** [câu hỏi, 4 phương án (không kèm A/B/C/D), chỉ số đáp án đúng 0-3, giải thích] */
export type McqTuple = [string, [string, string, string, string], number, string];
/** [nhận định, đúng/sai, giải thích] */
export type TfTuple = [string, boolean, string];
/** [English term, nghĩa tiếng Việt, IPA, English definition, định nghĩa tiếng Việt, câu ví dụ tiếng Anh] */
export type TermTuple = [string, string, string, string, string, string];

export interface LessonPack {
  id: string;
  lesson: number;
  chapter: ChapterKey;
  titleVi: string;
  titleEn: string;
  pages: string;
  isPractice?: boolean;
  /** Khoá mô hình 3D trong MODEL_REGISTRY */
  modelId: string;
  descriptionVi: string;
  objectives: string[];
  keyConcepts: string[];
  sections: KnowledgeSection[];
  core: string[];
  mcq: McqTuple[];
  tf: TfTuple[];
  terms: TermTuple[];
  minutes?: number;
  /** Tóm tắt bài bằng tiếng Anh (dịch từ nội dung SGK) */
  summaryEn?: string[];
}
