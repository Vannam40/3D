import { LessonPack } from '../types';

export const bai03: LessonPack = {
  id: 'bai03_cap_do_to_chuc',
  lesson: 3,
  chapter: 'mo_dau',
  titleVi: 'Bài 3. Các cấp độ tổ chức của thế giới sống',
  titleEn: 'Levels of Organisation of the Living World',
  pages: 'SGK tr. 18–22',
  modelId: 'm03_levels',
  descriptionVi:
    'Khái niệm cấp độ tổ chức sống; các cấp độ tổ chức trung gian và cơ bản; mối quan hệ giữa các cấp độ; đặc điểm chung: tổ chức theo thứ bậc, hệ mở và tự điều chỉnh, liên tục tiến hoá.',
  objectives: [
    'Phát biểu được khái niệm cấp độ tổ chức sống.',
    'Trình bày được các đặc điểm chung của các cấp độ tổ chức sống.',
    'Dựa vào sơ đồ, phân biệt được cấp độ tổ chức sống.',
    'Giải thích được mối quan hệ giữa các cấp độ tổ chức sống.',
  ],
  keyConcepts: ['Cấp độ tổ chức sống', 'Cấp độ cơ bản & trung gian', 'Nguyên tắc thứ bậc', 'Đặc tính nổi trội', 'Hệ mở, tự điều chỉnh', 'Cân bằng nội môi', 'Tiến hoá'],
  sections: [
    {
      heading: 'I. Các cấp độ tổ chức của thế giới sống',
      paragraphs: [
        'Cấp độ tổ chức sống là cấp độ tổ chức của vật chất có biểu hiện đầy đủ đặc tính của sự sống.',
        'Thế giới sống được tổ chức thành nhiều cấp bậc từ nhỏ đến lớn: các cấp tổ chức trung gian (nguyên tử, phân tử, bào quan, mô) và các cấp tổ chức cơ bản (tế bào, cơ thể, quần thể, quần xã, hệ sinh thái). Tất cả cấp độ tổ chức cơ bản đều được cấu tạo từ một hoặc nhiều tế bào.',
      ],
      bulletPoints: [
        'Tế bào: đơn vị tổ chức nhỏ nhất có đầy đủ các đặc điểm của sự sống, tổ chức từ bào quan, phân tử, nguyên tử.',
        'Cơ thể: có các bậc cấu trúc trung gian là mô, cơ quan, hệ cơ quan.',
        'Quần thể: tập hợp các cá thể cùng loài sống trong một khu vực địa lí, vào thời điểm nhất định.',
        'Quần xã: các quần thể của nhiều loài cùng tồn tại trong một khu vực, ở cùng thời điểm.',
        'Hệ sinh thái: các quần xã tương tác với nhau và với môi trường.',
      ],
      highlightBox:
        'Mối quan hệ hữu cơ giữa các cấp độ dựa trên hoạt động sống ở cấp độ tế bào và quá trình chuyển hoá vật chất, năng lượng. Năng lượng cung cấp cho thế giới sống chủ yếu đến từ Mặt Trời.',
    },
    {
      heading: 'II. Đặc điểm chung của thế giới sống',
      bulletPoints: [
        'Tổ chức theo nguyên tắc thứ bậc: từ thấp đến cao, từ đơn giản đến phức tạp; cấp thấp làm nền tảng cấu thành cấp cao hơn. Mỗi cấp có đặc tính nổi trội mà cấp nhỏ hơn không có (VD: tế bào thần kinh riêng biệt không giúp "tư duy", chỉ khi tổ chức thành bộ não).',
        'Là hệ mở và tự điều chỉnh: không ngừng trao đổi vật chất, năng lượng và thông tin với môi trường; có khả năng duy trì các thông số bên trong ổn định – gọi là cân bằng nội môi (thân nhiệt, pH, đường huyết…).',
        'Liên tục tiến hoá: thông tin di truyền trong DNA được truyền qua các thế hệ tương đối chính xác nhưng luôn phát sinh đột biến; môi trường lựa chọn những thể đột biến có kiểu hình thích nghi nhất.',
      ],
      paragraphs: [
        'Vật không sống cũng có thể được tổ chức theo các cấp độ nhưng không thể tự sinh trưởng, sinh sản, chuyển hoá vật chất và năng lượng.',
      ],
    },
  ],
  core: [
    'Cấp độ tổ chức sống có biểu hiện đầy đủ chức năng của sự sống: sinh trưởng, phát triển, sinh sản, cảm ứng, chuyển hoá vật chất và năng lượng,…',
    'Các cấp độ cơ bản: tế bào, cơ thể, quần thể, quần xã và hệ sinh thái.',
    'Thế giới sống tổ chức theo thứ bậc; các bộ phận tương tác tạo đặc tính nổi trội.',
    'Mối quan hệ giữa các cấp độ dựa trên hoạt động sống ở cấp tế bào, sự truyền năng lượng và vật chất.',
  ],
  mcq: [
    ['Đơn vị tổ chức nhỏ nhất có đầy đủ các đặc điểm của sự sống là', ['phân tử', 'bào quan', 'tế bào', 'mô'], 2, 'SGK: tế bào là đơn vị tổ chức nhỏ nhất có đầy đủ các đặc điểm của sự sống.'],
    ['Cấp độ nào sau đây là cấp tổ chức trung gian (không phải cấp cơ bản)?', ['Tế bào', 'Quần thể', 'Bào quan', 'Hệ sinh thái'], 2, 'Cấp trung gian: nguyên tử, phân tử, bào quan, mô.'],
    ['Tập hợp các cá thể của cùng một loài, sống trong một khu vực địa lí nhất định vào thời điểm nhất định là', ['quần xã', 'quần thể', 'hệ sinh thái', 'cơ thể'], 1, 'Đó là định nghĩa quần thể trong SGK.'],
    ['Các quần xã tương tác với nhau và với môi trường tạo nên cấp tổ chức', ['quần thể', 'sinh quyển', 'hệ sinh thái', 'cơ thể'], 2, 'SGK: các quần xã tương tác với nhau và với môi trường tạo nên hệ sinh thái.'],
    ['Đặc tính mới xuất hiện ở cấp tổ chức cao mà cấp nhỏ hơn không có được gọi là', ['đặc tính nổi trội', 'cân bằng nội môi', 'tính thích nghi', 'tính di truyền'], 0, 'Các bộ phận tương tác tạo nên đặc tính nổi trội.'],
    ['Khả năng duy trì môi trường bên trong cơ thể ổn định dù môi trường ngoài thay đổi được gọi là', ['hệ mở', 'cân bằng nội môi', 'tiến hoá', 'chuyển hoá'], 1, 'Đó là sự cân bằng nội môi (VD: thân nhiệt, pH, đường huyết).'],
    ['Nguồn năng lượng cung cấp cho thế giới sống chủ yếu đến từ', ['Mặt Trời', 'lòng đất', 'gió', 'thuỷ triều'], 0, 'SGK: năng lượng chủ yếu đến từ Mặt Trời và được truyền qua các cấp độ.'],
    ['Thế giới sống liên tục tiến hoá là nhờ', ['thông tin di truyền truyền qua các thế hệ tương đối chính xác nhưng luôn phát sinh đột biến, được môi trường chọn lọc', 'sinh vật không trao đổi chất với môi trường', 'mọi sinh vật đều giống hệt nhau', 'vật không sống tự biến thành vật sống'], 0, 'Theo mục II.3 của bài.'],
  ],
  tf: [
    ['Tất cả các cấp độ tổ chức cơ bản của thế giới sống đều được cấu tạo từ một hoặc nhiều tế bào.', true, 'Đúng theo SGK.'],
    ['Vật không sống có thể tự sinh trưởng, sinh sản và chuyển hoá vật chất.', false, 'Sai. Vật không sống không thể tự sinh trưởng, sinh sản, chuyển hoá vật chất và năng lượng.'],
    ['Các cấp tổ chức sống là những hệ thống mở, không ngừng trao đổi vật chất và năng lượng với môi trường.', true, 'Đúng; đây là đặc điểm cơ bản đảm bảo sự tồn tại và phát triển.'],
    ['Sinh vật chỉ chịu tác động của môi trường mà không làm biến đổi môi trường.', false, 'Sai. Sinh vật còn góp phần làm biến đổi môi trường.'],
  ],
  terms: [
    ['level of organisation', 'cấp độ tổ chức', '/ˈlevl əv ˌɔːɡənaɪˈzeɪʃn/', 'A level of matter that shows the properties of life.', 'Cấp tổ chức của vật chất biểu hiện đặc tính sống.', 'The cell is the smallest level of organisation of life.'],
    ['cell', 'tế bào', '/sel/', 'The smallest unit with all the characteristics of life.', 'Đơn vị nhỏ nhất có đầy đủ đặc điểm sự sống.', 'All organisms are made of cells.'],
    ['tissue', 'mô', '/ˈtɪʃuː/', 'A group of similar cells working together.', 'Tập hợp tế bào cùng làm một chức năng.', 'Muscle tissue helps the body move.'],
    ['organ', 'cơ quan', '/ˈɔːɡən/', 'A structure made of different tissues.', 'Cấu trúc gồm nhiều loại mô.', 'The heart is an organ.'],
    ['population', 'quần thể', '/ˌpɒpjuˈleɪʃn/', 'Individuals of the same species in one area at one time.', 'Các cá thể cùng loài, cùng khu vực, cùng thời điểm.', 'A population of fish lives in this lake.'],
    ['community', 'quần xã', '/kəˈmjuːnəti/', 'Populations of different species living together.', 'Các quần thể nhiều loài cùng sống.', 'A forest community contains many species.'],
    ['ecosystem', 'hệ sinh thái', '/ˈiːkəʊsɪstəm/', 'Communities interacting with each other and their environment.', 'Quần xã tương tác với nhau và với môi trường.', 'A pond is a small ecosystem.'],
    ['emergent property', 'đặc tính nổi trội', '/ɪˈmɜːdʒənt ˈprɒpəti/', 'A new property that appears when parts interact at a higher level.', 'Đặc tính mới xuất hiện ở cấp cao hơn.', 'Thinking is an emergent property of the brain.'],
    ['open system', 'hệ mở', '/ˈəʊpən ˈsɪstəm/', 'A system that constantly exchanges matter and energy with its surroundings.', 'Hệ không ngừng trao đổi vật chất, năng lượng với môi trường.', 'Every living cell is an open system.'],
    ['homeostasis', 'cân bằng nội môi', '/ˌhəʊmiəʊˈsteɪsɪs/', 'Keeping internal conditions stable.', 'Duy trì môi trường bên trong ổn định.', 'Body temperature is controlled by homeostasis.'],
    ['evolution', 'tiến hoá', '/ˌiːvəˈluːʃn/', 'The continuous change of the living world over generations.', 'Sự biến đổi liên tục của sinh giới qua các thế hệ.', 'Mutations provide material for evolution.'],
  ],
};
