import { LessonPack } from '../types';

export const bai17: LessonPack = {
  id: 'bai17_giam_phan',
  lesson: 17,
  chapter: 'chuong5',
  titleVi: 'Bài 17. Giảm phân',
  titleEn: 'Meiosis',
  pages: 'SGK tr. 104–107',
  modelId: 'm17_meiosis',
  descriptionVi: 'Diễn biến giảm phân I và II; kết quả giảm phân, phát sinh tinh trùng và trứng; các yếu tố ảnh hưởng đến giảm phân; ý nghĩa của giảm phân kết hợp thụ tinh và nguyên phân.',
  minutes: 30,
  objectives: [
    'Dựa vào cơ chế nhân đôi và phân li của NST giải thích giảm phân, thụ tinh cùng với nguyên phân là cơ sở của sinh sản hữu tính.',
    'Trình bày được một số nhân tố ảnh hưởng đến quá trình giảm phân.',
    'Lập được bảng so sánh nguyên phân và giảm phân.',
    'Vận dụng kiến thức về nguyên phân và giảm phân giải thích một số vấn đề thực tiễn.',
  ],
  keyConcepts: ['Giảm phân I & II', 'Cặp NST tương đồng', 'Trao đổi chéo', 'Phân li độc lập ngẫu nhiên', 'Giao tử n', 'Thụ tinh – hợp tử 2n'],
  sections: [
    {
      heading: 'I. Diễn biến của giảm phân',
      paragraphs: [
        'Giảm phân (phân bào giảm nhiễm) là hình thức phân chia của tế bào mầm sinh dục khi sản sinh giao tử; gồm hai lần phân bào liên tiếp. Ở kì trung gian trước giảm phân I, mỗi NST nhân đôi thành NST kép.',
      ],
      bulletPoints: [
        'Kì đầu I: các NST kép bắt đôi thành từng cặp tương đồng, dần co xoắn; các chromatid không chị em có thể trao đổi đoạn (trao đổi chéo); thoi phân bào hình thành; màng nhân, hạch nhân tiêu biến.',
        'Kì giữa I: các cặp NST kép tương đồng co xoắn cực đại, tập trung thành hai hàng ở mặt phẳng xích đạo; vi ống đính vào một phía tâm động của mỗi NST kép.',
        'Kì sau I: hai NST kép trong cặp tương đồng tách nhau, mỗi NST đi về một cực.',
        'Kì cuối I: NST dãn xoắn, thoi phân bào tiêu biến, hai nhân mới hình thành; tế bào chất phân chia tạo hai tế bào con có số NST kép giảm một nửa.',
        'Giảm phân II: kì đầu II NST kép co xoắn; kì giữa II NST kép xếp một hàng, vi ống gắn cả hai phía tâm động; kì sau II hai chromatid tách nhau về hai cực; kì cuối II tạo hai tế bào con.',
      ],
    },
    {
      heading: 'Kết quả của giảm phân',
      paragraphs: [
        'Từ một tế bào qua hai lần phân bào tạo bốn tế bào con có số NST giảm đi một nửa, chứa các hệ gene đơn bội khác nhau (do phân li ngẫu nhiên các cặp NST tương đồng và trao đổi chéo).',
        'Ở động vật: 1 tế bào sinh tinh → 4 tinh trùng; 1 tế bào sinh trứng → 1 trứng lớn và 3 thể cực tiêu biến. Ở người, noãn sau giảm phân I nếu được thụ tinh mới hoàn tất giảm phân II.',
      ],
    },
    {
      heading: 'II. Các yếu tố ảnh hưởng đến giảm phân',
      bulletPoints: [
        'Yếu tố di truyền.',
        'Điều kiện thời tiết, chế độ chiếu sáng: thắp đèn ban đêm cho thanh long ra hoa trái vụ.',
        'Hormone sinh dục: tiêm hormone kích thích sinh sản ở vật nuôi.',
        'Tuổi tác: phụ nữ càng lớn tuổi (đặc biệt từ 35) tỉ lệ sinh con bị hội chứng Down (thừa NST 21) càng tăng.',
      ],
    },
    {
      heading: 'III. Ý nghĩa của giảm phân',
      paragraphs: [
        'NST nhân đôi một lần nhưng phân chia hai lần → giao tử n. Thụ tinh tạo hợp tử 2n; hợp tử nguyên phân, biệt hoá thành cơ thể. → Giảm phân + thụ tinh + nguyên phân là cơ sở của sinh sản hữu tính, duy trì bộ NST 2n đặc trưng cho loài.',
        'Trao đổi đoạn ở kì đầu I và phân li, tổ hợp ngẫu nhiên tạo nhiều loại giao tử → vô số biến dị tổ hợp, nguyên liệu cho tiến hoá và chọn giống.',
      ],
    },
  ],
  core: [
    'Giảm phân gồm hai lần phân bào liên tiếp nhưng chỉ có một lần nhân đôi DNA.',
    'Từ một tế bào tạo bốn tế bào con có bộ NST giảm một nửa và chứa tổ hợp NST khác nhau.',
    'Giảm phân + thụ tinh + nguyên phân duy trì ổn định bộ NST lưỡng bội của loài và tạo tổ hợp gene đa dạng.',
  ],
  mcq: [
    ['Giảm phân xảy ra ở loại tế bào nào?', ['Tế bào sinh dưỡng', 'Tế bào mầm sinh dục khi sản sinh giao tử', 'Tế bào vi khuẩn', 'Tế bào hợp tử'], 1, 'Giảm phân là hình thức phân chia của tế bào mầm sinh dục.'],
    ['Sự kiện các NST kép bắt đôi thành từng cặp tương đồng xảy ra ở', ['kì đầu I', 'kì giữa I', 'kì đầu II', 'kì sau II'], 0, 'Kì đầu I.'],
    ['Ở kì giữa I, các cặp NST kép tương đồng tập trung ở mặt phẳng xích đạo thành', ['một hàng', 'hai hàng', 'ba hàng', 'bốn hàng'], 1, 'Kì giữa I: thành hai hàng; kì giữa II: một hàng.'],
    ['Kì sau I khác kì sau II ở chỗ', ['kì sau I hai NST kép trong cặp tương đồng tách nhau; kì sau II hai chromatid tách nhau', 'kì sau I hai chromatid tách nhau; kì sau II cặp tương đồng tách nhau', 'cả hai đều tách chromatid', 'kì sau I không có thoi phân bào'], 0, 'Theo hình 17.1 và 17.2.'],
    ['Từ 1 tế bào sinh trứng qua giảm phân tạo ra', ['4 trứng', '1 trứng và 3 thể cực', '2 trứng và 2 thể cực', '4 tinh trùng'], 1, 'Một tế bào trứng lớn và ba thể cực bị tiêu biến.'],
    ['Giảm phân có bao nhiêu lần nhân đôi DNA?', ['1 lần', '2 lần', '3 lần', '4 lần'], 0, 'Hai lần phân bào nhưng chỉ một lần nhân đôi DNA.'],
    ['Nguyên nhân tạo ra các giao tử có hệ gene đơn bội khác nhau là', ['đột biến gene', 'phân li ngẫu nhiên các cặp NST tương đồng và trao đổi chéo', 'nhân đôi DNA hai lần', 'nguyên phân'], 1, 'SGK: do phân li ngẫu nhiên và trao đổi chéo.'],
    ['Để cây thanh long ra hoa trái vụ, nông dân thường', ['tưới nhiều nước', 'thắp đèn chiếu sáng vào ban đêm', 'bón nhiều phân đạm', 'cắt bỏ hết lá'], 1, 'Chế độ chiếu sáng ảnh hưởng đến giảm phân, ra hoa.'],
    ['Phụ nữ càng lớn tuổi, tỉ lệ sinh con mắc hội chứng Down càng tăng, do', ['giảm phân dễ bị rối loạn, tạo giao tử thừa một NST 21', 'nguyên phân nhanh hơn', 'thiếu hormone sinh dục', 'trao đổi chéo không xảy ra'], 0, 'Kì đầu giảm phân I kéo dài quá lâu dễ rối loạn phân li NST.'],
  ],
  tf: [
    ['Giảm phân kết hợp với thụ tinh và nguyên phân đảm bảo duy trì bộ NST 2n đặc trưng cho loài.', true, 'Đúng – cơ sở của sinh sản hữu tính.'],
    ['Bốn tế bào con tạo ra sau giảm phân có vật chất di truyền giống hệt nhau.', false, 'Sai. Chúng chứa các hệ gene đơn bội khác nhau.'],
    ['Ở người, noãn sau giảm phân I chỉ tiếp tục hoàn tất giảm phân II nếu được thụ tinh.', true, 'Đúng theo SGK.'],
    ['Ở kì giữa II, mỗi NST kép gắn với vi ống ở cả hai phía của tâm động.', true, 'Đúng theo hình 17.2.'],
  ],
  terms: [
    ['meiosis', 'giảm phân', '/maɪˈəʊsɪs/', 'Two divisions that halve the chromosome number to make gametes.', 'Hai lần phân bào làm giảm một nửa số NST, tạo giao tử.', 'Meiosis produces four haploid cells.'],
    ['homologous chromosomes', 'NST tương đồng', '/həˈmɒləɡəs ˈkrəʊməsəʊmz/', 'A pair of chromosomes, one from each parent, with the same genes.', 'Cặp NST giống nhau về hình dạng, một từ bố một từ mẹ.', 'Homologous chromosomes pair up in prophase I.'],
    ['crossing over', 'trao đổi chéo', '/ˈkrɒsɪŋ ˈəʊvə/', 'Exchange of segments between non-sister chromatids.', 'Trao đổi đoạn giữa các chromatid không chị em.', 'Crossing over creates new gene combinations.'],
    ['haploid (n)', 'đơn bội (n)', '/ˈhæplɔɪd/', 'Having one set of chromosomes.', 'Có một bộ NST.', 'Gametes are haploid.'],
    ['diploid (2n)', 'lưỡng bội (2n)', '/ˈdɪplɔɪd/', 'Having two sets of chromosomes.', 'Có hai bộ NST.', 'The zygote is diploid.'],
    ['gamete', 'giao tử', '/ˈɡæmiːt/', 'A sex cell such as a sperm or an egg.', 'Tế bào sinh dục như tinh trùng, trứng.', 'Meiosis forms gametes.'],
    ['fertilisation', 'thụ tinh', '/ˌfɜːtəlaɪˈzeɪʃn/', 'The fusion of male and female gametes.', 'Sự kết hợp giao tử đực và cái.', 'Fertilisation restores the diploid number.'],
    ['zygote', 'hợp tử', '/ˈzaɪɡəʊt/', 'The diploid cell formed by fertilisation.', 'Tế bào 2n tạo thành do thụ tinh.', 'The zygote divides by mitosis.'],
    ['polar body', 'thể cực', '/ˈpəʊlə ˈbɒdi/', 'A small cell formed with the egg that later degenerates.', 'Tế bào nhỏ tạo cùng trứng rồi tiêu biến.', 'One egg cell and three polar bodies are formed.'],
    ['genetic variation', 'biến dị tổ hợp', '/dʒəˈnetɪk ˌveəriˈeɪʃn/', 'Differences among offspring due to new combinations of genes.', 'Sự khác nhau ở đời con do tổ hợp gene mới.', 'Meiosis increases genetic variation.'],
  ],
};
