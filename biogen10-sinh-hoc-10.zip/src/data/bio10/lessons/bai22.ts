import { LessonPack } from '../types';

export const bai22: LessonPack = {
  id: 'bai22_vai_tro_ung_dung_vsv',
  lesson: 22,
  chapter: 'chuong6',
  titleVi: 'Bài 22. Vai trò và ứng dụng của vi sinh vật',
  titleEn: 'Roles and Applications of Microorganisms',
  pages: 'SGK tr. 131–137',
  modelId: 'm22_microbe_applications',
  descriptionVi: 'Vai trò của vi sinh vật với tự nhiên và con người; cơ sở khoa học và ứng dụng trong nông nghiệp, chế biến thực phẩm, y dược, xử lí chất thải; thành tựu, triển vọng và ngành nghề liên quan công nghệ vi sinh vật.',
  minutes: 30,
  objectives: [
    'Phân tích được vai trò của vi sinh vật trong đời sống con người và trong tự nhiên.',
    'Trình bày được cơ sở khoa học của việc ứng dụng vi sinh vật trong thực tiễn.',
    'Trình bày được một số ứng dụng vi sinh vật (sản xuất và bảo quản thực phẩm, sản xuất thuốc, xử lí môi trường…).',
    'Kể tên được một số thành tựu hiện đại; phân tích triển vọng công nghệ vi sinh vật; kể tên một số ngành nghề liên quan.',
  ],
  keyConcepts: ['Tuần hoàn vật chất', 'Màng sinh học (biofilm)', 'Phân bón vi sinh', 'Lên men ethanol & lactic', 'Biogas', 'Công nghệ lên men & thu hồi sản phẩm'],
  sections: [
    {
      heading: 'I. Vai trò của vi sinh vật',
      bulletPoints: [
        'Đối với tự nhiên: phân giải chất thải, xác sinh vật thành chất khoáng – đảm bảo tuần hoàn vật chất, làm giàu dinh dưỡng cho đất; vi sinh vật tự dưỡng tạo O₂ và chất dinh dưỡng; cộng sinh với nhiều loài.',
        'Đối với con người: phân giải chất thải độc hại (nhựa, hoá chất nhân tạo, chất phóng xạ); cộng sinh trong cơ thể giúp tăng miễn dịch, tiêu hoá, tổng hợp vitamin, amino acid không thay thế; dùng trong chế biến thực phẩm, sản xuất kháng sinh, vitamin.',
        'Tác hại: gây bệnh (lao, uốn ván, nhiễm trùng huyết…), bệnh cho vật nuôi, cây trồng; làm hỏng thực phẩm, đồ dùng; tạo màng sinh học (biofilm) làm tắc nghẽn đường ống.',
      ],
      highlightBox: 'Năm 1982, Robin Warren và Barry Marshall phân lập vi khuẩn Helicobacter pylori – tác nhân gây phần lớn trường hợp loét dạ dày tá tràng; lây qua đường ăn uống.',
    },
    {
      heading: 'II. Cơ sở khoa học của việc ứng dụng vi sinh vật',
      bulletPoints: [
        'Kích thước hiển vi (từ 0,2 µm) → tỉ lệ S/V lớn → trao đổi chất, sinh trưởng nhanh; nuôi được số lượng lớn trong không gian nhỏ.',
        'Tổng hợp và phân giải các chất nhanh: 1 g vi khuẩn lactic có thể sinh 15–22,8 g lactate/giờ; E. coli sau 24 giờ cho hơn 4 700 tấn tế bào; thời gian thế hệ nấm men Saccharomyces cerevisiae là 120 phút.',
        'Đa dạng di truyền; phổ sinh thái và dinh dưỡng rộng.',
      ],
    },
    {
      heading: 'Ứng dụng của công nghệ vi sinh vật',
      bulletPoints: [
        'Nông nghiệp: cố định N₂, chuyển lân khó tiêu thành dễ tiêu, phân giải mùn → phân bón vi sinh; thuốc trừ sâu vi sinh.',
        'Chế biến thực phẩm: bánh mì, bia, rượu (nấm men Saccharomyces cerevisiae – lên men ethanol); sữa chua, pho mát (vi khuẩn lactic); nước tương, xì dầu, nước mắm (nấm mốc tương Aspergillus oryzae…).',
        'Y dược: kháng sinh, vaccine, amino acid, protein đơn bào, hormone, probiotics; insulin, hormone sinh trưởng, interferon từ vi sinh vật tái tổ hợp; chẩn đoán bằng PCR.',
        'Xử lí chất thải: bể hiếu khí, thiếu khí, kị khí; vi khuẩn "ăn" dầu Alcanivorax borkumensis; Archaea sinh methane tạo biogas; enzyme amylase, lipase, protease trong bột giặt sinh học, thuộc da.',
      ],
    },
    {
      heading: 'III. Thành tựu, triển vọng và ngành nghề',
      paragraphs: [
        'Then chốt là công nghệ lên men và công nghệ thu hồi sản phẩm. Kết hợp với công nghệ nano, công nghệ thông tin, trí tuệ nhân tạo; nghiên cứu hệ vi sinh vật Trái Đất và con người; điện từ vi khuẩn (Shewanella oneidensis); bê tông tự lành nhờ Bacillus sản sinh đá vôi.',
        'Ngành nghề: kĩ sư chế biến thực phẩm, dược sĩ, nhân viên xét nghiệm, kĩ sư môi trường, nhà dịch tễ học…',
      ],
      highlightBox: 'Sâu răng: vi khuẩn trong mảng bám (màng sinh học) lên men đường thành lactic acid làm giảm pH, phá vỡ men răng.',
    },
  ],
  core: [
    'Vi sinh vật phân giải là mắt xích quan trọng đảm bảo tuần hoàn vật chất; nhiều vi sinh vật làm giàu dinh dưỡng cho đất.',
    'Vi sinh vật tác động hai hướng: có lợi và có hại đối với con người.',
    'Ứng dụng dựa trên đặc điểm sinh học, qua công nghệ lên men và công nghệ thu hồi sản phẩm.',
  ],
  mcq: [
    ['Bánh mì, bia, rượu là sản phẩm lên men của', ['vi khuẩn lactic', 'nấm men Saccharomyces cerevisiae', 'nấm mốc tương', 'vi khuẩn E. coli'], 1, 'Lên men ethanol của nấm men Saccharomyces cerevisiae.'],
    ['Sữa chua là sản phẩm lên men của', ['nấm men bia', 'vi khuẩn lactic', 'vi khuẩn nitrate hoá', 'Archaea sinh methane'], 1, 'Vi khuẩn lactic chuyển glucose thành lactic acid.'],
    ['Khí biogas được tạo ra nhờ hoạt động của', ['vi khuẩn lactic', 'Archaea sinh methane', 'nấm men', 'vi khuẩn lam'], 1, 'Chất thải chăn nuôi được phân giải bởi Archaea sinh methane.'],
    ['Vi khuẩn được dùng xử lí sự cố tràn dầu trên biển là', ['Alcanivorax borkumensis', 'Lactobacillus casei', 'Rhizobium', 'Bacillus thuringiensis'], 0, 'Vi sinh vật "ăn" dầu Alcanivorax borkumensis.'],
    ['Hai công nghệ then chốt trong công nghệ vi sinh vật là', ['công nghệ lên men và công nghệ thu hồi sản phẩm', 'nuôi cấy mô và lai tế bào', 'nhân bản vô tính và liệu pháp gene', 'giải trình tự gene và PCR'], 0, 'Theo hình 22.5.'],
    ['Vi khuẩn gây loét dạ dày được Warren và Marshall phân lập năm 1982 là', ['E. coli', 'Helicobacter pylori', 'Bacillus', 'Shewanella'], 1, 'Helicobacter pylori.'],
    ['Thời gian thế hệ của nấm men Saccharomyces cerevisiae theo SGK là', ['20 phút', '60 phút', '120 phút', '12 giờ'], 2, 'SGK: 120 phút.'],
    ['Cơ sở giúp vi sinh vật trao đổi chất và sinh trưởng nhanh là', ['kích thước lớn', 'tỉ lệ diện tích/thể tích (S/V) lớn', 'có nhiều bào quan', 'sống lâu'], 1, 'Kích thước nhỏ → S/V lớn → trao đổi chất nhanh.'],
    ['Enzyme do vi sinh vật sinh ra được bổ sung vào bột giặt sinh học gồm', ['amylase, lipase, protease', 'ATP synthase', 'DNA polymerase', 'luciferase'], 0, 'Amylase, lipase, protease giúp tẩy sạch vết bẩn.'],
  ],
  tf: [
    ['Vi sinh vật chỉ có hại nên cần tiêu diệt tất cả chúng.', false, 'Sai. Vi sinh vật tác động hai hướng, nhiều vi sinh vật rất có lợi.'],
    ['Màng sinh học (biofilm) là một kiểu tổ chức đa bào giúp vi sinh vật sống sót tốt hơn.', true, 'Đúng theo SGK.'],
    ['Phân bón vi sinh giúp cải tạo đất và không gây ô nhiễm môi trường như phân bón hoá học.', true, 'Đúng.'],
    ['Vi khuẩn Bacillus sản sinh đá vôi được nghiên cứu ứng dụng làm bê tông tự lành vết nứt.', true, 'Đúng theo hình 22.6.'],
  ],
  terms: [
    ['decomposer', 'sinh vật phân giải', '/ˌdiːkəmˈpəʊzə/', 'An organism that breaks down waste and dead bodies into minerals.', 'Sinh vật phân giải chất thải, xác thành chất khoáng.', 'Bacteria are important decomposers.'],
    ['biofilm', 'màng sinh học', '/ˈbaɪəʊfɪlm/', 'A community of microbes stuck together on a surface.', 'Tập hợp vi sinh vật bám trên bề mặt.', 'Dental plaque is a biofilm.'],
    ['probiotic', 'lợi khuẩn (probiotic)', '/ˌprəʊbaɪˈɒtɪk/', 'Beneficial live microbes that support health.', 'Vi sinh vật sống có lợi cho sức khoẻ.', 'Yogurt contains probiotics.'],
    ['yeast', 'nấm men', '/jiːst/', 'A single-celled fungus used to make bread and beer.', 'Nấm đơn bào dùng làm bánh mì, bia.', 'Yeast produces ethanol and CO₂.'],
    ['lactic acid bacteria', 'vi khuẩn lactic', '/ˈlæktɪk ˈæsɪd bækˈtɪəriə/', 'Bacteria that ferment sugar into lactic acid.', 'Vi khuẩn lên men đường thành lactic acid.', 'Lactic acid bacteria make yogurt.'],
    ['biofertiliser', 'phân bón vi sinh', '/ˌbaɪəʊˈfɜːtəlaɪzə/', 'Fertiliser containing useful microbes.', 'Phân bón chứa vi sinh vật có ích.', 'Biofertilisers improve soil without pollution.'],
    ['biopesticide', 'thuốc trừ sâu vi sinh', '/ˌbaɪəʊˈpestɪsaɪd/', 'A pest control product made from microbes.', 'Chế phẩm trừ sâu từ vi sinh vật.', 'Bt is a common biopesticide.'],
    ['biogas', 'khí sinh học (biogas)', '/ˈbaɪəʊɡæs/', 'Fuel gas produced by methane-producing microbes.', 'Khí đốt do vi sinh vật sinh methane tạo ra.', 'Farm waste can be turned into biogas.'],
    ['wastewater treatment', 'xử lí nước thải', '/ˈweɪstwɔːtə ˈtriːtmənt/', 'Cleaning polluted water using microbes.', 'Làm sạch nước ô nhiễm nhờ vi sinh vật.', 'Aerobic tanks are used in wastewater treatment.'],
    ['fermentation technology', 'công nghệ lên men', '/ˌfɜːmenˈteɪʃn tekˈnɒlədʒi/', 'Using microbes in fermenters to make useful products.', 'Dùng vi sinh vật trong bình lên men tạo sản phẩm.', 'Antibiotics are made by fermentation technology.'],
  ],
};
