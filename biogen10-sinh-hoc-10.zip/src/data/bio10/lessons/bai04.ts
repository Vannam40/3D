import { LessonPack } from '../types';

export const bai04: LessonPack = {
  id: 'bai04_nguyen_to_va_nuoc',
  lesson: 4,
  chapter: 'chuong1',
  titleVi: 'Bài 4. Các nguyên tố hoá học và nước',
  titleEn: 'Chemical Elements and Water',
  pages: 'SGK tr. 23–27',
  modelId: 'm04_water',
  descriptionVi:
    'Học thuyết tế bào; nguyên tố đa lượng, vi lượng và vai trò đặc biệt của carbon; cấu trúc phân cực của phân tử nước, liên kết hydrogen, tính chất và vai trò sinh học của nước.',
  objectives: [
    'Nêu được khái quát học thuyết tế bào; giải thích được tế bào là đơn vị cấu trúc và chức năng của cơ thể sống.',
    'Liệt kê được một số nguyên tố hoá học chính có trong tế bào (C, H, O, N, S, P).',
    'Nêu được vai trò của các nguyên tố vi lượng, đa lượng trong tế bào.',
    'Trình bày được vai trò quan trọng của nguyên tố carbon trong tế bào.',
    'Trình bày được đặc điểm cấu tạo phân tử nước quy định tính chất vật lí, hoá học, sinh học của nước.',
  ],
  keyConcepts: ['Học thuyết tế bào', 'Nguyên tố đa lượng & vi lượng', 'Vai trò của carbon', 'Phân tử nước phân cực', 'Liên kết hydrogen', 'Vai trò của nước'],
  sections: [
    {
      heading: 'I. Khái quát về học thuyết tế bào',
      paragraphs: [
        'Năm 1839, Matthias Jakob Schleiden và Theodor Schwann (Đức) đưa ra học thuyết tế bào đầu tiên.',
      ],
      bulletPoints: [
        'Tất cả mọi sinh vật đều được cấu tạo từ một hoặc nhiều tế bào; sự sống tiếp diễn nhờ sự chuyển hoá và di truyền bên trong tế bào.',
        'Tế bào là đơn vị nhỏ nhất, đơn vị cấu trúc và đơn vị chức năng cấu tạo nên mọi cơ thể sinh vật.',
        'Tế bào chỉ được sinh ra từ sự phân chia các tế bào có trước.',
      ],
    },
    {
      heading: 'II. Các nguyên tố hoá học trong tế bào',
      paragraphs: [
        'Trong 92 nguyên tố tự nhiên, chỉ khoảng 20–25% cần thiết cho sinh vật (nguyên tố thiết yếu).',
        'Nguyên tố đa lượng: cần lượng lớn; riêng C, H, O, N chiếm khoảng 96% khối lượng vật chất sống; Ca, P, K, S… chiếm khoảng 3,4%. Vai trò: cấu tạo nên mọi phân tử sinh học.',
        'Nguyên tố vi lượng: chỉ cần lượng rất nhỏ (VD: mỗi ngày người cần 0,15 mg iodine); thường cấu tạo nên enzyme và nhiều hợp chất quan trọng; thiếu sẽ rối loạn hoạt động sống (thiếu iodine → bướu cổ).',
        'Cơ thể người cần 25 loại nguyên tố, thực vật chỉ cần 17 loại nguyên tố thiết yếu.',
      ],
      bulletPoints: [
        'Carbon có 4 electron hoá trị ở vòng ngoài → tạo bốn liên kết cộng hoá trị, hình thành bộ khung carbon đa dạng.',
        'Khung hydrocarbon (mạch thẳng, mạch vòng, phân nhánh hoặc không) liên kết với các nhóm chức tạo nên carbohydrate, lipid, protein, nucleic acid.',
        'Carbon linh hoạt tạo các phân tử có cấu trúc và tính chất khác nhau từ cùng một công thức hoá học.',
      ],
      formulaBox: {
        title: 'Tỉ lệ một số nguyên tố trong cơ thể người (Hình 4.1)',
        formulas: ['Oxygen (O): 65%', 'Carbon (C): 18%', 'Nitrogen (N): 3%', 'Calcium (Ca): 1,5%', 'Phosphorus (P): 1,1%', 'K, S, Na, Mg, Cl: 0,8%'],
      },
    },
    {
      heading: 'III. Nước và vai trò của nước đối với sự sống',
      paragraphs: [
        'Nước chiếm khoảng 70% khối lượng cơ thể người. Mỗi phân tử H₂O có 1 nguyên tử oxygen liên kết với 2 nguyên tử hydrogen bằng hai liên kết cộng hoá trị. Oxygen hút electron mạnh hơn nên phía oxygen tích điện âm (δ–), phía hydrogen tích điện dương (δ+) → nước là phân tử phân cực.',
        'Lực hút giữa các phần mang điện trái dấu của các phân tử tạo nên liên kết hydrogen; một phân tử nước có thể hình thành tối đa 4 liên kết hydrogen.',
      ],
      bulletPoints: [
        'Sức căng bề mặt: nhiều sinh vật nhỏ có thể đi lại trên mặt nước.',
        'Nhiệt dung đặc trưng cao: sinh vật dễ điều chỉnh nhiệt độ, tránh thay đổi nhiệt độ đột ngột.',
        'Nhiệt bay hơi cao: nước bay hơi lấy nhiều nhiệt, giúp giảm nhiệt độ cơ thể.',
        'Vai trò: thành phần chủ yếu cấu tạo tế bào; dung môi hoà tan nhiều chất; nguyên liệu và môi trường của phản ứng sinh hoá; định hình cấu trúc không gian của phân tử hữu cơ; điều hoà nhiệt độ.',
      ],
      highlightBox: 'Không có nước sẽ không có sự sống – vì vậy các nhà thiên văn tìm sự sống ngoài hành tinh bắt đầu bằng việc tìm kiếm nước.',
    },
  ],
  core: [
    'Học thuyết tế bào hiện đại: mọi sinh vật cấu tạo từ tế bào; tế bào là đơn vị nhỏ nhất, cơ bản cấu tạo nên sinh vật; tế bào chỉ sinh ra từ tế bào có trước.',
    'Nguyên tố đa lượng giữ vai trò cấu trúc; nguyên tố vi lượng chiếm tỉ lệ rất nhỏ nhưng quan trọng trong điều hoà hoạt động sống.',
    'Do tính phân cực, nước là thành phần chính của tế bào, dung môi, nguyên liệu và môi trường phản ứng.',
  ],
  mcq: [
    ['Học thuyết tế bào đầu tiên được đưa ra năm 1839 bởi', ['Watson và Crick', 'Schleiden và Schwann', 'Mendel và Morgan', 'Darwin và Wallace'], 1, 'Matthias Jakob Schleiden và Theodor Schwann (Đức), năm 1839.'],
    ['Bốn nguyên tố C, H, O, N chiếm khoảng bao nhiêu phần trăm khối lượng vật chất sống?', ['3,4%', '25%', '70%', '96%'], 3, 'SGK: chỉ riêng C, H, O, N đã chiếm khoảng 96% khối lượng vật chất sống.'],
    ['Thiếu nguyên tố vi lượng nào dẫn đến bệnh bướu cổ ở người?', ['Sắt', 'Iodine', 'Calcium', 'Kẽm'], 1, 'Thiếu iodine, tuyến giáp phát triển bất thường, dẫn đến bệnh bướu cổ.'],
    ['Carbon có vai trò đặc biệt quan trọng vì nguyên tử carbon', ['có 4 electron hoá trị, tạo được 4 liên kết cộng hoá trị', 'có khối lượng lớn nhất', 'tích điện âm mạnh', 'chỉ liên kết được với oxygen'], 0, 'Nhờ 4 electron hoá trị, carbon tạo bộ khung carbon đa dạng.'],
    ['Trong phân tử nước, phía nguyên tử oxygen', ['tích điện dương (δ+)', 'tích điện âm (δ–)', 'không tích điện', 'tích điện giống phía hydrogen'], 1, 'Oxygen hút electron mạnh hơn nên tích điện âm (δ–).'],
    ['Liên kết giữa các phân tử nước với nhau là', ['liên kết cộng hoá trị', 'liên kết ion', 'liên kết hydrogen', 'liên kết peptide'], 2, 'Lực hút giữa các phần mang điện trái dấu tạo nên liên kết hydrogen.'],
    ['Một phân tử nước có thể hình thành tối đa bao nhiêu liên kết hydrogen với các phân tử khác?', ['1', '2', '3', '4'], 3, 'Hình 4.3: tối đa 4 liên kết hydrogen.'],
    ['Nhờ đặc tính nào của nước mà nhiều sinh vật nhỏ có thể đi lại trên mặt nước?', ['Sức căng bề mặt', 'Nhiệt dung đặc trưng cao', 'Nhiệt bay hơi cao', 'Khả năng hoà tan'], 0, 'Phân tử nước ở bề mặt liên kết chặt với nhau tạo sức căng bề mặt.'],
    ['Nước có khả năng hoà tan nhiều chất cần thiết cho tế bào là nhờ', ['tính phân cực', 'khối lượng phân tử lớn', 'liên kết peptide', 'có nhiều nguyên tử carbon'], 0, 'Nhờ tính phân cực nên nước là dung môi hoà tan nhiều chất.'],
  ],
  tf: [
    ['Tế bào chỉ được sinh ra từ sự phân chia các tế bào có trước.', true, 'Đúng – nội dung thứ ba của học thuyết tế bào hiện đại.'],
    ['Nguyên tố vi lượng chiếm tỉ lệ rất nhỏ nên thiếu chúng không ảnh hưởng đến hoạt động sống.', false, 'Sai. Thiếu nguyên tố vi lượng, các hoạt động sống sẽ bị rối loạn.'],
    ['Cơ thể người cần 25 loại nguyên tố, trong khi thực vật chỉ cần 17 loại nguyên tố thiết yếu.', true, 'Đúng theo SGK.'],
    ['Nước chiếm khoảng 70% khối lượng cơ thể người.', true, 'Đúng theo SGK.'],
    ['Nước có nhiệt dung đặc trưng thấp nên nhiệt độ cơ thể dễ thay đổi đột ngột.', false, 'Sai. Nước có nhiệt dung đặc trưng cao, giúp tránh thay đổi nhiệt độ đột ngột.'],
  ],
  terms: [
    ['cell theory', 'học thuyết tế bào', '/sel ˈθɪəri/', 'The theory that all organisms are made of cells and cells come from pre-existing cells.', 'Học thuyết cho rằng mọi sinh vật cấu tạo từ tế bào và tế bào sinh ra từ tế bào có trước.', 'Schleiden and Schwann proposed the cell theory in 1839.'],
    ['macronutrient element', 'nguyên tố đa lượng', '/ˈmækrəʊˌnjuːtriənt ˈelɪmənt/', 'An element needed in large amounts, such as C, H, O, N.', 'Nguyên tố cần với lượng lớn như C, H, O, N.', 'Carbon is a macronutrient element.'],
    ['trace element', 'nguyên tố vi lượng', '/treɪs ˈelɪmənt/', 'An element needed in very small amounts.', 'Nguyên tố chỉ cần lượng rất nhỏ.', 'Iodine is a trace element for humans.'],
    ['carbon skeleton', 'bộ khung carbon', '/ˈkɑːbən ˈskelɪtn/', 'A chain or ring of carbon atoms in an organic molecule.', 'Mạch hoặc vòng nguyên tử carbon trong phân tử hữu cơ.', 'Carbon skeletons can be straight, branched or ring-shaped.'],
    ['covalent bond', 'liên kết cộng hoá trị', '/kəʊˈveɪlənt bɒnd/', 'A strong bond formed by sharing electrons.', 'Liên kết bền tạo bởi cặp electron dùng chung.', 'Oxygen joins two hydrogen atoms by covalent bonds.'],
    ['polar molecule', 'phân tử phân cực', '/ˈpəʊlə ˈmɒlɪkjuːl/', 'A molecule with a slightly positive end and a slightly negative end.', 'Phân tử có một đầu tích điện dương, một đầu tích điện âm.', 'Water is a polar molecule.'],
    ['hydrogen bond', 'liên kết hydrogen', '/ˈhaɪdrədʒən bɒnd/', 'A weak attraction between opposite charges of polar molecules.', 'Lực hút yếu giữa các phần mang điện trái dấu.', 'One water molecule can form up to four hydrogen bonds.'],
    ['surface tension', 'sức căng bề mặt', '/ˈsɜːfɪs ˈtenʃn/', 'The strong attraction of water molecules at the surface.', 'Lực liên kết chặt của phân tử nước ở bề mặt.', 'Surface tension lets small insects walk on water.'],
    ['specific heat', 'nhiệt dung đặc trưng', '/spəˈsɪfɪk hiːt/', 'The heat needed to raise the temperature of a substance.', 'Nhiệt lượng cần để làm tăng nhiệt độ một chất.', 'Water has a high specific heat.'],
    ['solvent', 'dung môi', '/ˈsɒlvənt/', 'A liquid that dissolves other substances.', 'Chất lỏng hoà tan các chất khác.', 'Water is the main solvent in cells.'],
  ],
};
