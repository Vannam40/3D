import { LessonPack } from '../types';

export const bai01: LessonPack = {
  id: 'bai01_gioi_thieu_sinh_hoc',
  lesson: 1,
  chapter: 'mo_dau',
  titleVi: 'Bài 1. Giới thiệu khái quát môn Sinh học',
  titleEn: 'Introduction to Biology',
  pages: 'SGK tr. 5–11',
  modelId: 'm01_biology_fields',
  descriptionVi:
    'Khái niệm, đối tượng, mục tiêu và các lĩnh vực nghiên cứu của sinh học; vai trò của sinh học, các ngành nghề liên quan, sinh học với phát triển bền vững và các vấn đề xã hội.',
  objectives: [
    'Nêu được đối tượng và các lĩnh vực nghiên cứu của sinh học.',
    'Trình bày được mục tiêu môn Sinh học.',
    'Phân tích được vai trò của sinh học với cuộc sống hằng ngày, với sự phát triển kinh tế – xã hội và những vấn đề toàn cầu.',
    'Trình bày được định nghĩa về phát triển bền vững, vai trò của sinh học với sự phát triển bền vững môi trường sống.',
    'Nêu được triển vọng phát triển sinh học trong tương lai, tên các ngành nghề liên quan đến sinh học.',
  ],
  keyConcepts: ['Đối tượng của sinh học', 'Nghiên cứu cơ bản & ứng dụng', 'Ngành nghề liên quan', 'Phát triển bền vững', 'Đạo đức sinh học'],
  sections: [
    {
      heading: 'I. Sinh học và các lĩnh vực của sinh học',
      paragraphs: [
        'Sinh học là ngành khoa học nghiên cứu về sự sống. Đối tượng của sinh học là các sinh vật cùng các cấp độ tổ chức của thế giới sống.',
        'Mục tiêu của sinh học là tìm hiểu cấu trúc và sự vận hành của các quá trình sống ở các cấp độ tổ chức của sự sống, qua đó con người có thể điều khiển, tối ưu hoá nguồn tài nguyên sinh học cũng như phi sinh học, phục vụ sự phát triển bền vững của xã hội loài người.',
        'Các lĩnh vực nghiên cứu sinh học chia thành hai loại chính: nghiên cứu cơ bản (tìm hiểu cấu trúc các cấp độ tổ chức sống, phân loại, cách thức vận hành và tiến hoá của thế giới sống) và nghiên cứu ứng dụng (đưa phát kiến mới về sinh học vào thực tiễn đời sống). Hai lĩnh vực này ngày càng giao thoa với nhau.',
      ],
      bulletPoints: [
        'Lớp 10: sinh học tế bào và thế giới vi sinh vật.',
        'Lớp 11: sinh học cơ thể.',
        'Lớp 12: di truyền học, tiến hoá và sinh thái học.',
      ],
    },
    {
      heading: 'Vai trò của sinh học và sinh học trong tương lai',
      paragraphs: [
        'Hiểu biết về sinh học, đặc biệt về thế giới vi sinh vật, đã giúp giảm tỉ lệ bệnh tật, gia tăng đáng kể tuổi thọ con người qua cải thiện vệ sinh, chăm sóc sức khoẻ và điều trị bệnh tật.',
        'Sự kết hợp của sinh học với hoá học, tin học, toán học và vật lí đang hình thành ngành sinh học hệ thống. Ví dụ ứng dụng: sản xuất thuốc hướng đích; vaccine mRNA – tổng hợp mRNA nhân tạo quy định trình tự gai protein của SARS-CoV-2, bao bọc trong màng phospholipid rồi tiêm vào người để tế bào tạo protein gai, kích hoạt hệ miễn dịch tạo kháng thể.',
      ],
    },
    {
      heading: 'II. Các ngành nghề liên quan đến sinh học',
      bulletPoints: [
        'Y – dược học: thuốc hướng đích tác động tới những protein riêng biệt để chữa bệnh hiểm nghèo như ung thư; y học hướng đến cá thể hoá chăm sóc sức khoẻ.',
        'Pháp y: giải trình tự DNA từ sợi tóc, vết máu… để truy tìm chủ nhân; "dấu vân tay DNA" giúp nhận diện cá thể, xác định quan hệ huyết thống.',
        'Nông – lâm – ngư nghiệp: tạo giống năng suất, chất lượng cao; sinh vật biến đổi gene; nhân giống bằng nuôi cấy mô; nhân bản động vật (cừu, bò, mèo, khỉ, lợn…).',
        'Công nghệ thực phẩm: sữa chua và các sản phẩm lên men; biện pháp bảo quản thực phẩm.',
        'Bảo vệ môi trường: Deinococcus radiodurans chống chịu phóng xạ tốt nhất; Shewanella oneidensis làm sạch nước nhiễm thuỷ ngân, chì, sắt và sản sinh năng lượng điện; ngành phỏng sinh học (bắt chước sinh học).',
      ],
    },
    {
      heading: 'III. Sinh học với phát triển bền vững và những vấn đề xã hội',
      paragraphs: [
        'Phát triển bền vững (WCED – Liên Hợp quốc, 1987) là sự phát triển đáp ứng được nhu cầu của xã hội hiện tại nhưng không làm tổn hại đến khả năng tiếp cận với nhu cầu phát triển của các thế hệ tương lai.',
        'Vai trò của sinh học: phổ biến kiến thức bảo vệ đa dạng sinh vật, khai thác tài nguyên hợp lí; mọi nghiên cứu sinh học cần tính đến tác động tới môi trường, xã hội; cung cấp cơ sở khoa học giúp chính phủ có chiến lược phát triển kinh tế phù hợp.',
      ],
      bulletPoints: [
        'Sinh học và đạo đức (đạo đức sinh học): ai có quyền biết thông tin hệ gene? có nên chỉnh sửa gene người, nhân bản vô tính người?',
        'Sinh học và kinh tế: giống năng suất cao tạo bằng gây đột biến, lai hữu tính, biến đổi gene, nuôi cấy mô; nhưng cũng có rủi ro (VD: trồng cây nuôi cấy mô diện tích lớn có thể mất mùa khi môi trường bất lợi).',
        'Sinh học và công nghệ: công nghệ phỏng sinh học – VD: robot bắt chước tập tính của kiến.',
      ],
    },
  ],
  core: [
    'Sinh học nghiên cứu sự sống ở tất cả các cấp độ từ phân tử, tế bào, cơ thể đa bào, quần thể, quần xã và hệ sinh thái.',
    'Nghiên cứu sinh học đem lại nhiều ứng dụng: y – dược học, công nghệ thực phẩm, bảo vệ môi trường, nông – lâm – ngư nghiệp,…',
    'Nghiên cứu sinh học cần hướng tới sự phát triển bền vững và tính tới vấn đề đạo đức xã hội.',
    'Tương lai của sinh học vô cùng to lớn nhờ kết hợp với nhiều ngành khoa học tự nhiên và sự phát triển của công nghệ, đặc biệt là công nghệ tin học.',
  ],
  mcq: [
    ['Đối tượng nghiên cứu của sinh học là', ['các sinh vật cùng các cấp độ tổ chức của thế giới sống', 'chỉ các loài động vật và thực vật', 'các chất hoá học trong tự nhiên', 'các hiện tượng vật lí trong cơ thể'], 0, 'SGK: Sinh học là ngành khoa học nghiên cứu về sự sống; đối tượng là các sinh vật cùng các cấp độ tổ chức của thế giới sống.'],
    ['Theo chương trình phổ thông, Sinh học lớp 10 tìm hiểu về', ['sinh học cơ thể', 'di truyền học, tiến hoá và sinh thái học', 'sinh học tế bào và thế giới vi sinh vật', 'sinh thái học và môi trường'], 2, 'Lớp 10: sinh học tế bào và vi sinh vật; lớp 11: sinh học cơ thể; lớp 12: di truyền, tiến hoá, sinh thái.'],
    ['Các lĩnh vực nghiên cứu sinh học được chia thành hai loại chính là', ['nghiên cứu cơ bản và nghiên cứu ứng dụng', 'nghiên cứu động vật và nghiên cứu thực vật', 'nghiên cứu phân tử và nghiên cứu tế bào', 'nghiên cứu trong phòng và ngoài trời'], 0, 'SGK chia thành nghiên cứu cơ bản và nghiên cứu ứng dụng; hai lĩnh vực ngày càng giao thoa.'],
    ['Ngành mới hình thành từ sự kết hợp của sinh học với hoá học, tin học, toán học và vật lí được gọi là', ['sinh học hệ thống', 'tin sinh học', 'phỏng sinh học', 'sinh học phân tử'], 0, 'SGK: sự kết hợp đó đang hình thành ngành sinh học hệ thống.'],
    ['"Dấu vân tay DNA" được ứng dụng chủ yếu trong ngành nào sau đây?', ['Công nghệ thực phẩm', 'Pháp y', 'Lâm nghiệp', 'Phỏng sinh học'], 1, 'Trong pháp y, trình tự nucleotide đặc biệt giúp nhận diện từng cá thể, xác định quan hệ huyết thống.'],
    ['Thuốc tác động tới những loại protein riêng biệt để chữa các bệnh hiểm nghèo như ung thư được gọi là', ['vaccine mRNA', 'kháng sinh', 'thuốc hướng đích', 'chế phẩm sinh học'], 2, 'SGK: thuốc hướng đích tác động tới những protein riêng biệt để chữa bệnh hiểm nghèo như ung thư.'],
    ['Loài vi khuẩn nào được SGK nêu là chống chịu được phóng xạ tốt nhất được biết đến?', ['Shewanella oneidensis', 'Chlorobium tepidum', 'Deinococcus radiodurans', 'Escherichia coli'], 2, 'Deinococcus radiodurans có thể giúp làm sạch nơi ô nhiễm phóng xạ và hoá chất độc hại.'],
    ['Phát triển bền vững được hiểu là sự phát triển', ['chỉ chú trọng tăng trưởng kinh tế nhanh nhất', 'đáp ứng nhu cầu hiện tại nhưng không làm tổn hại khả năng đáp ứng nhu cầu của các thế hệ tương lai', 'ngừng khai thác mọi tài nguyên thiên nhiên', 'chỉ bảo vệ các loài sinh vật quý hiếm'], 1, 'Định nghĩa của WCED – Liên Hợp quốc (1987).'],
    ['Việc chế tạo robot hoạt động độc lập nhưng "giao tiếp" với nhau dựa trên nghiên cứu tập tính của kiến là ví dụ về', ['công nghệ phỏng sinh học', 'công nghệ di truyền', 'nuôi cấy mô tế bào', 'sinh học hệ thống'], 0, 'SGK: công nghệ bắt chước sinh vật gọi là công nghệ phỏng sinh học.'],
  ],
  tf: [
    ['Vaccine mRNA được tạo ra bằng cách bao bọc mRNA nhân tạo quy định gai protein của virus trong màng phospholipid.', true, 'Đúng theo SGK: mRNA nhân tạo được bao bọc trong màng phospholipid rồi tiêm vào người.'],
    ['Nghiên cứu cơ bản và nghiên cứu ứng dụng trong sinh học hoàn toàn tách biệt, không liên quan với nhau.', false, 'Sai. SGK: hai lĩnh vực này ngày càng giao thoa với nhau.'],
    ['Việc giải trình tự hệ gene của một người có thể làm nảy sinh vấn đề đạo đức sinh học.', true, 'Đúng. VD: ai có quyền biết thông tin này, công ty bảo hiểm có sẵn sàng bảo hiểm…'],
    ['Trồng cây giống tạo bằng nuôi cấy mô trên diện tích lớn không bao giờ có rủi ro.', false, 'Sai. SGK nêu có thể tiềm ẩn rủi ro mất mùa nếu điều kiện môi trường bất lợi.'],
    ['Vi khuẩn Shewanella oneidensis có khả năng sản sinh năng lượng điện.', true, 'Đúng. Ngoài làm sạch nước nhiễm thuỷ ngân, chì, sắt, chúng còn sản sinh năng lượng điện.'],
  ],
  terms: [
    ['biology', 'sinh học', '/baɪˈɒlədʒi/', 'The science that studies life.', 'Ngành khoa học nghiên cứu về sự sống.', 'Biology studies organisms at all levels of organisation.'],
    ['organism', 'sinh vật', '/ˈɔːɡənɪzəm/', 'A living thing.', 'Một cá thể sống.', 'Every organism is made of one or more cells.'],
    ['basic research', 'nghiên cứu cơ bản', '/ˈbeɪsɪk rɪˈsɜːtʃ/', 'Research that explores the structure, classification, function and evolution of the living world.', 'Nghiên cứu tìm hiểu cấu trúc, phân loại, cách vận hành và tiến hoá của thế giới sống.', 'Basic research helps us understand how cells work.'],
    ['applied research', 'nghiên cứu ứng dụng', '/əˈplaɪd rɪˈsɜːtʃ/', 'Research that brings new biological discoveries into real life.', 'Nghiên cứu đưa phát kiến sinh học mới vào thực tiễn đời sống.', 'Making mRNA vaccines is an example of applied research.'],
    ['sustainable development', 'phát triển bền vững', '/səˈsteɪnəbl dɪˈveləpmənt/', 'Development that meets present needs without harming the ability of future generations to meet their needs.', 'Sự phát triển đáp ứng nhu cầu hiện tại mà không làm tổn hại khả năng đáp ứng nhu cầu của thế hệ tương lai.', 'Biology plays an important role in sustainable development.'],
    ['bioethics', 'đạo đức sinh học', '/ˌbaɪəʊˈeθɪks/', 'Ethical issues that arise from biological research.', 'Các vấn đề đạo đức nảy sinh từ nghiên cứu sinh học.', 'Human cloning raises questions of bioethics.'],
    ['targeted drug', 'thuốc hướng đích', '/ˈtɑːɡɪtɪd drʌɡ/', 'A medicine that acts on specific proteins of diseased cells.', 'Thuốc tác động đặc hiệu tới những protein riêng biệt của tế bào bệnh.', 'Targeted drugs are used to treat some cancers.'],
    ['DNA fingerprint', 'dấu vân tay DNA', '/ˌdiː en ˈeɪ ˈfɪŋɡəprɪnt/', 'A special DNA sequence pattern that identifies each individual.', 'Trình tự nucleotide đặc biệt giúp nhận diện từng cá thể.', 'Forensic scientists use DNA fingerprints to identify people.'],
    ['biomimetics', 'phỏng sinh học', '/ˌbaɪəʊmɪˈmetɪks/', 'Technology that copies the way living things work.', 'Công nghệ bắt chước nguyên lí vận hành của sinh vật.', 'Ant-like robots are a product of biomimetics.'],
    ['systems biology', 'sinh học hệ thống', '/ˈsɪstəmz baɪˈɒlədʒi/', 'A field that combines biology with chemistry, computing, maths and physics.', 'Ngành kết hợp sinh học với hoá học, tin học, toán học và vật lí.', 'Systems biology helps scientists design new medicines.'],
  ],
};
