import { LessonPack } from '../types';

export const bai20: LessonPack = {
  id: 'bai20_da_dang_vi_sinh_vat',
  lesson: 20,
  chapter: 'chuong6',
  titleVi: 'Bài 20. Sự đa dạng và phương pháp nghiên cứu vi sinh vật',
  titleEn: 'Diversity of Microorganisms and Research Methods',
  pages: 'SGK tr. 116–121',
  modelId: 'm20_microbe_diversity',
  descriptionVi: 'Khái niệm và các nhóm vi sinh vật; bốn kiểu dinh dưỡng; phương pháp quan sát (soi tươi, nhuộm đơn, nhuộm Gram), phân lập và nuôi cấy vi sinh vật.',
  objectives: [
    'Nêu được khái niệm vi sinh vật. Kể tên các nhóm vi sinh vật.',
    'Phân biệt được các kiểu dinh dưỡng của vi sinh vật.',
    'Trình bày được một số phương pháp nghiên cứu vi sinh vật.',
  ],
  keyConcepts: ['Vi sinh vật nhân sơ & nhân thực', 'Archaea', 'Quang tự dưỡng', 'Hoá tự dưỡng', 'Quang dị dưỡng', 'Hoá dị dưỡng', 'Nhuộm Gram', 'Khuẩn lạc'],
  sections: [
    {
      heading: 'I. Các nhóm vi sinh vật',
      paragraphs: [
        'Vi sinh vật là những sinh vật có kích thước nhỏ bé, thường chỉ quan sát được dưới kính hiển vi.',
        'Đặc điểm chung: tốc độ chuyển hoá vật chất và năng lượng nhanh, sinh trưởng, sinh sản nhanh, phân bố rộng.',
        'Vi khuẩn là nhóm có số lượng lớn nhất (khoảng 1/2 sinh khối trên Trái Đất); con người mới phát hiện khoảng 10%.',
      ],
      bulletPoints: [
        'Vi sinh vật nhân sơ: vi khuẩn, Archaea (cổ khuẩn – nhiều loài là vi sinh vật cực đoan).',
        'Vi sinh vật nhân thực: nấm đơn bào, tảo đơn bào, động vật nguyên sinh; vi nấm, vi tảo và động vật đa bào kích thước hiển vi.',
        'Ví dụ vi sinh vật chịu điều kiện khắc nghiệt: Thermococcus piezophilus (áp suất gấp 1 200 lần khí quyển), Halobacterium salinarum (độ mặn gấp 10 lần nước biển), Deinococcus radiodurans (phóng xạ gấp 3 000 lần mức gây chết người), Planococcus halocryophilus (nhiệt độ âm hàng chục độ).',
      ],
    },
    {
      heading: 'II. Các kiểu dinh dưỡng của vi sinh vật (Bảng 20)',
      bulletPoints: [
        'Quang tự dưỡng: năng lượng ánh sáng; nguồn carbon CO₂, HCO₃⁻ hoặc chất vô cơ tương tự – vi sinh vật quang hợp (vi khuẩn lam, trùng roi, tảo).',
        'Hoá tự dưỡng: năng lượng từ chất vô cơ (H₂S, NH₃ hoặc Fe²⁺); carbon CO₂, HCO₃⁻ – chỉ một số vi khuẩn và Archaea (vi khuẩn nitrate hoá, vi khuẩn oxy hoá hydrogen…).',
        'Quang dị dưỡng: năng lượng ánh sáng; carbon từ chất hữu cơ – một số vi khuẩn và Archaea (vi khuẩn không lưu huỳnh màu lục và màu tía).',
        'Hoá dị dưỡng: năng lượng và carbon từ chất hữu cơ – nhiều vi khuẩn, nấm, động vật nguyên sinh.',
      ],
    },
    {
      heading: 'III. Một số phương pháp nghiên cứu vi sinh vật',
      bulletPoints: [
        'Soi tươi: thao tác đơn giản, quan sát trạng thái sống, khả năng di động của vi khuẩn.',
        'Nhuộm đơn: một bước nhuộm (xanh methylene, tím kết tinh, đỏ fuchsin) để đánh giá sơ bộ hình thái, cách sắp xếp.',
        'Nhuộm Gram (Hans Christian Gram): dùng tím kết tinh → iodine → ethyl alcohol 95% → fuchsin. Gram dương giữ màu tím, Gram âm mất màu rồi bắt màu đỏ; giúp bác sĩ chọn thuốc điều trị.',
        'Phân tích hoá sinh, sinh học phân tử (DNA, RNA): định loại chính xác.',
        'Phân lập và nuôi cấy: pha loãng mẫu, phết lên thạch đặc → mỗi tế bào tạo một khuẩn lạc riêng rẽ (quan sát bằng mắt thường); nuôi trong môi trường lỏng để nhân số lượng lớn.',
      ],
    },
  ],
  core: [
    'Vi sinh vật là nhóm sinh vật kích thước rất nhỏ, thường chỉ quan sát được dưới kính hiển vi.',
    'Vi sinh vật nhân sơ gồm vi khuẩn, Archaea; nhân thực gồm vi tảo, vi nấm, nguyên sinh động vật.',
    'Bốn kiểu dinh dưỡng: quang tự dưỡng, quang dị dưỡng, hoá tự dưỡng, hoá dị dưỡng.',
    'Phương pháp thường dùng: quan sát; phân lập và nuôi cấy vi sinh vật.',
  ],
  mcq: [
    ['Nhóm nào sau đây thuộc vi sinh vật nhân sơ?', ['Tảo đơn bào', 'Nấm men', 'Archaea', 'Động vật nguyên sinh'], 2, 'Vi sinh vật nhân sơ gồm vi khuẩn và Archaea.'],
    ['Vi sinh vật sử dụng năng lượng ánh sáng và nguồn carbon là CO₂ có kiểu dinh dưỡng', ['quang tự dưỡng', 'quang dị dưỡng', 'hoá tự dưỡng', 'hoá dị dưỡng'], 0, 'Quang tự dưỡng: vi khuẩn lam, trùng roi, tảo.'],
    ['Vi khuẩn nitrate hoá có kiểu dinh dưỡng', ['quang tự dưỡng', 'hoá tự dưỡng', 'quang dị dưỡng', 'hoá dị dưỡng'], 1, 'Năng lượng từ chất vô cơ, carbon từ CO₂.'],
    ['Nấm và động vật nguyên sinh có kiểu dinh dưỡng', ['quang tự dưỡng', 'hoá tự dưỡng', 'quang dị dưỡng', 'hoá dị dưỡng'], 3, 'Hoá dị dưỡng: năng lượng và carbon đều từ chất hữu cơ.'],
    ['Vi khuẩn không lưu huỳnh màu lục và màu tía thuộc kiểu dinh dưỡng', ['quang dị dưỡng', 'hoá tự dưỡng', 'hoá dị dưỡng', 'quang tự dưỡng'], 0, 'Theo bảng 20.'],
    ['Thuốc thử đầu tiên được dùng trong quy trình nhuộm Gram là', ['fuchsin', 'iodine', 'tím kết tinh', 'ethyl alcohol 95%'], 2, 'Thứ tự: tím kết tinh → iodine → ethyl alcohol 95% → fuchsin.'],
    ['Sau nhuộm Gram, vi khuẩn Gram âm có màu', ['tím', 'đỏ', 'xanh lục', 'không màu'], 1, 'Gram âm mất màu tím khi rửa cồn rồi bắt màu đỏ fuchsin.'],
    ['Tập hợp các tế bào sinh ra từ một tế bào ban đầu trên môi trường thạch, quan sát được bằng mắt thường gọi là', ['khuẩn lạc', 'mô sẹo', 'quần xã', 'bào tử'], 0, 'Khuẩn lạc.'],
    ['Vi khuẩn chiếm khoảng bao nhiêu sinh khối trên Trái Đất theo SGK?', ['1/10', '1/4', '1/2', '3/4'], 2, 'Khoảng 1/2 sinh khối trên Trái Đất.'],
  ],
  tf: [
    ['Archaea có đặc điểm giống vi khuẩn nhưng có họ hàng gần với sinh vật nhân thực.', true, 'Đúng theo SGK.'],
    ['Phương pháp nhuộm đơn cần nhiều bước nhuộm với bốn loại thuốc thử.', false, 'Sai. Nhuộm đơn chỉ cần một bước nhuộm; nhuộm Gram mới dùng bốn loại thuốc thử.'],
    ['Halobacterium salinarum chịu được độ mặn gấp 10 lần nước biển.', true, 'Đúng theo SGK.'],
    ['Phân lập vi sinh vật nhằm thu được vi sinh vật ở dạng thuần khiết, không lẫn loại khác.', true, 'Đúng.'],
  ],
  terms: [
    ['microorganism', 'vi sinh vật', '/ˌmaɪkrəʊˈɔːɡənɪzəm/', 'A tiny organism usually seen only under a microscope.', 'Sinh vật rất nhỏ thường chỉ thấy dưới kính hiển vi.', 'Bacteria and yeasts are microorganisms.'],
    ['archaea', 'cổ khuẩn (Archaea)', '/ɑːˈkiːə/', 'Prokaryotes similar to bacteria but closely related to eukaryotes.', 'Sinh vật nhân sơ giống vi khuẩn nhưng gần nhân thực.', 'Many archaea live in extreme environments.'],
    ['extremophile', 'vi sinh vật cực đoan', '/ɪkˈstriːməfaɪl/', 'An organism that lives in extremely harsh conditions.', 'Sinh vật sống ở điều kiện cực kì khắc nghiệt.', 'Halobacterium is an extremophile.'],
    ['photoautotroph', 'sinh vật quang tự dưỡng', '/ˌfəʊtəʊˈɔːtətrəʊf/', 'Uses light energy and CO₂ as the carbon source.', 'Dùng năng lượng ánh sáng và nguồn carbon CO₂.', 'Cyanobacteria are photoautotrophs.'],
    ['chemoautotroph', 'sinh vật hoá tự dưỡng', '/ˌkiːməʊˈɔːtətrəʊf/', 'Gets energy from inorganic chemicals and carbon from CO₂.', 'Năng lượng từ chất vô cơ, carbon từ CO₂.', 'Nitrifying bacteria are chemoautotrophs.'],
    ['photoheterotroph', 'sinh vật quang dị dưỡng', '/ˌfəʊtəʊˈhetərətrəʊf/', 'Uses light energy and organic carbon.', 'Dùng năng lượng ánh sáng và carbon hữu cơ.', 'Purple non-sulfur bacteria are photoheterotrophs.'],
    ['chemoheterotroph', 'sinh vật hoá dị dưỡng', '/ˌkiːməʊˈhetərətrəʊf/', 'Gets both energy and carbon from organic compounds.', 'Năng lượng và carbon đều từ chất hữu cơ.', 'Fungi are chemoheterotrophs.'],
    ['Gram stain', 'nhuộm Gram', '/ɡræm steɪn/', 'A staining method that separates Gram-positive and Gram-negative bacteria.', 'Phương pháp nhuộm phân biệt Gram dương và Gram âm.', 'The Gram stain helps doctors choose antibiotics.'],
    ['colony', 'khuẩn lạc', '/ˈkɒləni/', 'A visible group of cells grown from one cell on agar.', 'Tập hợp tế bào từ một tế bào ban đầu trên thạch.', 'Each white spot on the plate is a colony.'],
    ['agar plate', 'đĩa thạch', '/ˈeɪɡɑː pleɪt/', 'A Petri dish with solid nutrient medium.', 'Đĩa Petri chứa môi trường dinh dưỡng đặc.', 'Spread the diluted sample on an agar plate.'],
  ],
};
