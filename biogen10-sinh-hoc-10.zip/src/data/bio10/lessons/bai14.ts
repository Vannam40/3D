import { LessonPack } from '../types';

export const bai14: LessonPack = {
  id: 'bai14_phan_giai_tong_hop',
  lesson: 14,
  chapter: 'chuong4',
  titleVi: 'Bài 14. Phân giải và tổng hợp các chất trong tế bào',
  titleEn: 'Catabolism and Anabolism in the Cell',
  pages: 'SGK tr. 85–93',
  modelId: 'm14_respiration_photosynthesis',
  descriptionVi: 'Phân giải các chất: hô hấp tế bào (đường phân, chu trình Krebs, chuỗi truyền electron), lên men; tổng hợp các chất: quang hợp (pha sáng, pha tối – chu trình Calvin), quang khử, hoá tổng hợp ở vi khuẩn; mối quan hệ giữa phân giải và tổng hợp.',
  minutes: 40,
  objectives: [
    'Phát biểu được khái niệm phân giải các chất; trình bày các giai đoạn phân giải hiếu khí (hô hấp tế bào) và phân giải kị khí (lên men).',
    'Nêu được khái niệm tổng hợp các chất; lấy ví dụ; trình bày quá trình tổng hợp song song với tích luỹ năng lượng.',
    'Nêu được vai trò của quang hợp; vai trò của hoá tổng hợp và quang khử ở vi khuẩn.',
    'Phân tích được mối quan hệ giữa tổng hợp và phân giải các chất trong tế bào.',
  ],
  keyConcepts: ['Hô hấp tế bào', 'Đường phân', 'Chu trình Krebs', 'Chuỗi truyền electron', 'Lên men lactate & ethanol', 'Quang hợp: pha sáng – pha tối', 'Quang khử & hoá tổng hợp'],
  sections: [
    {
      heading: 'I. Phân giải các chất và giải phóng năng lượng',
      paragraphs: [
        'Phân giải là quá trình phá vỡ liên kết trong phân tử sinh học tạo phân tử nhỏ hơn, đồng thời giải phóng năng lượng (một phần tích luỹ trong ATP, một phần thành nhiệt năng).',
        'Phân giải đường theo 3 con đường: hô hấp tế bào (hiếu khí, cần O₂), hô hấp kị khí (không cần O₂), lên men (không có chuỗi truyền electron).',
      ],
      formulaBox: {
        title: 'Phương trình tổng quát hô hấp tế bào',
        formulas: ['C₆H₁₂O₆ + 2ATP + 6O₂ → 6CO₂ + 6H₂O + 30–32 ATP + Nhiệt năng'],
      },
      bulletPoints: [
        'Đường phân: ở tế bào chất, không cần O₂; 1 glucose (6C) → 2 pyruvate (3C) + 2 NADH + 2 ATP.',
        'Chu trình Krebs: mỗi pyruvate → acetyl-CoA (2C) đi vào chu trình, giải phóng 2 CO₂, 3 NADH, 1 FADH₂, 1 ATP.',
        'Chuỗi truyền electron: ở màng trong ti thể; NADH, FADH₂ bị oxy hoá tạo ATP và nước – giai đoạn tạo nhiều ATP nhất.',
        'Tổng cộng: 1 glucose → khoảng 30–32 ATP (điều kiện thực nghiệm tối ưu: 36–38 ATP).',
      ],
    },
    {
      heading: 'Lên men',
      paragraphs: ['Phân giải không hoàn toàn đường, không có O₂ và chuỗi truyền electron; gồm đường phân và lên men. 1 glucose chỉ tạo 2 ATP.'],
      bulletPoints: [
        'Lên men lactate: pyruvate nhận electron từ NADH → lactate (tế bào động vật, người).',
        'Lên men ethanol: acetaldehyde nhận electron từ NADH → ethanol (chủ yếu ở thực vật).',
      ],
      highlightBox: 'Bảo quản nông sản bằng cách ức chế hô hấp: làm lạnh (2–8 °C), sấy khô, hút chân không, bảo quản trong môi trường CO₂ cao.',
    },
    {
      heading: 'II. Tổng hợp các chất và tích luỹ năng lượng',
      paragraphs: [
        'Tổng hợp là sự hình thành hợp chất phức tạp từ chất đơn giản và tiêu tốn năng lượng (VD: nucleic acid – liên kết phosphodiester; protein – liên kết peptide; lipid từ acid béo và glycerol; tinh bột, glycogen, chitin từ đường đơn).',
        'Quang hợp: 6H₂O + 6CO₂ → C₆H₁₂O₆ + 6O₂ (năng lượng ánh sáng, hệ sắc tố).',
      ],
      bulletPoints: [
        'Pha sáng (màng thylakoid): photon kích thích diệp lục, electron qua chuỗi truyền electron tạo ATP và NADPH; quang phân li nước giải phóng electron, H⁺ và O₂.',
        'Pha tối – chu trình Calvin (chất nền lục lạp): 3 CO₂ được ATP, NADPH chuyển thành 1 G3P; 2 G3P tạo 1 glucose.',
        'Quang khử (vi khuẩn lục, tía): dùng năng lượng ánh sáng khử CO₂ nhưng dùng H₂S, S, H₂… thay H₂O → không giải phóng O₂.',
        'Hoá tổng hợp: cố định CO₂ nhờ năng lượng từ oxy hoá chất vô cơ (vi khuẩn lưu huỳnh, vi khuẩn nitrate hoá Nitrosomonas, Nitrobacter, vi khuẩn sắt).',
      ],
    },
    {
      heading: 'Mối quan hệ giữa phân giải và tổng hợp',
      paragraphs: ['Hai quá trình trái ngược nhưng thống nhất: tổng hợp cung cấp nguyên liệu cho phân giải; phân giải tạo năng lượng và sản phẩm trung gian cho tổng hợp.'],
    },
  ],
  core: [
    'Hô hấp tế bào gồm đường phân, chu trình Krebs, chuỗi truyền electron – hiệu quả năng lượng cao nhất. Lên men hiệu quả ATP thấp hơn.',
    'Quang hợp: pha sáng chuyển quang năng thành hoá năng trong ATP và NADPH; pha tối cố định CO₂ qua chu trình Calvin.',
    'Tổng hợp cung cấp nguyên liệu cho phân giải; phân giải tạo năng lượng và nguyên liệu cho tổng hợp.',
  ],
  mcq: [
    ['Giai đoạn đường phân diễn ra ở', ['chất nền ti thể', 'màng trong ti thể', 'tế bào chất', 'lục lạp'], 2, 'Đường phân xảy ra trong tế bào chất, không có O₂.'],
    ['Kết quả của đường phân từ 1 phân tử glucose là', ['2 pyruvate, 2 NADH, 2 ATP', '6 CO₂, 6 H₂O', '2 acetyl-CoA, 2 CO₂', '30–32 ATP'], 0, 'Glucose → 2 pyruvate + 2 NADH + 2 ATP.'],
    ['Giai đoạn tạo ra nhiều ATP nhất trong hô hấp tế bào là', ['đường phân', 'chu trình Krebs', 'chuỗi truyền electron', 'lên men'], 2, 'Chuỗi truyền electron ở màng trong ti thể tạo nhiều ATP nhất.'],
    ['Chuỗi truyền electron trong hô hấp tế bào diễn ra ở', ['tế bào chất', 'màng trong ti thể', 'màng thylakoid', 'chất nền lục lạp'], 1, 'Diễn ra ở màng trong ti thể.'],
    ['Lên men từ 1 phân tử glucose tạo ra', ['2 ATP', '4 ATP', '30–32 ATP', '36–38 ATP'], 0, '1 glucose qua lên men chỉ tạo 2 ATP.'],
    ['Tế bào cơ người khi thiếu O₂ thực hiện lên men tạo sản phẩm là', ['ethanol', 'lactate', 'acetaldehyde', 'CO₂ và H₂O'], 1, 'Tế bào động vật, người dùng lên men lactate.'],
    ['Pha sáng của quang hợp diễn ra ở', ['chất nền lục lạp', 'màng thylakoid', 'màng trong ti thể', 'tế bào chất'], 1, 'Pha sáng xảy ra ở màng thylakoid.'],
    ['Sản phẩm của pha sáng được dùng cho chu trình Calvin là', ['O₂ và H₂O', 'ATP và NADPH', 'CO₂ và glucose', 'G3P và RuBP'], 1, 'ATP và NADPH được dùng trong chu trình Calvin.'],
    ['Khí O₂ trong quang hợp được giải phóng từ', ['CO₂', 'quang phân li nước', 'glucose', 'chu trình Calvin'], 1, 'Năng lượng photon làm phân li nước giải phóng electron, H⁺ và O₂.'],
    ['Quang khử ở vi khuẩn khác quang hợp ở thực vật ở chỗ', ['không dùng ánh sáng', 'không dùng H₂O làm nguồn H⁺, electron và không giải phóng O₂', 'không cố định CO₂', 'chỉ xảy ra ban đêm'], 1, 'Vi khuẩn dùng H₂S, S, H₂…; không giải phóng O₂.'],
    ['Vi khuẩn chuyển hoá NH₃ thành HNO₂ rồi thành HNO₃ thuộc nhóm', ['vi khuẩn lưu huỳnh', 'vi khuẩn nitrate hoá', 'vi khuẩn sắt', 'vi khuẩn lam'], 1, 'Nitrosomonas, Nitrobacter – vi khuẩn nitrate hoá.'],
  ],
  tf: [
    ['Cứ 3 phân tử CO₂ đi vào chu trình Calvin tạo ra 1 phân tử G3P.', true, 'Đúng; 2 G3P kết hợp tạo 1 glucose.'],
    ['Lên men có sự tham gia của O₂ và chuỗi truyền electron.', false, 'Sai. Lên men không có O₂ và chuỗi truyền electron.'],
    ['Làm lạnh nông sản ở khoảng 2–8 °C giúp ức chế hô hấp, bảo quản lâu hơn.', true, 'Đúng theo mục "Khoa học và đời sống".'],
    ['Tổng hợp và phân giải là hai quá trình trái ngược nên không liên quan gì với nhau.', false, 'Sai. Chúng trái ngược nhưng thống nhất, liên quan mật thiết.'],
    ['Mỗi pyruvate đi vào chu trình Krebs giải phóng 2 CO₂, 3 NADH, 1 FADH₂ và 1 ATP.', true, 'Đúng theo SGK (H 14.3).'],
  ],
  terms: [
    ['cellular respiration', 'hô hấp tế bào', '/ˈseljələ ˌrespəˈreɪʃn/', 'Complete breakdown of glucose to CO₂ and water using O₂, releasing ATP.', 'Phân giải hoàn toàn glucose thành CO₂ và nước nhờ O₂, giải phóng ATP.', 'Cellular respiration mainly happens in mitochondria.'],
    ['glycolysis', 'đường phân', '/ɡlaɪˈkɒləsɪs/', 'Splitting glucose into two pyruvate in the cytoplasm.', 'Tách glucose thành 2 pyruvate trong tế bào chất.', 'Glycolysis does not need oxygen.'],
    ['Krebs cycle', 'chu trình Krebs', '/ˈkrebz ˌsaɪkl/', 'A cycle of reactions that releases CO₂, NADH, FADH₂ and ATP.', 'Chu trình giải phóng CO₂, NADH, FADH₂, ATP.', 'Acetyl-CoA enters the Krebs cycle.'],
    ['electron transport chain', 'chuỗi truyền electron', '/ɪˈlektrɒn ˈtrænspɔːt tʃeɪn/', 'Redox reactions on the inner mitochondrial membrane that make most ATP.', 'Chuỗi oxy hoá khử ở màng trong ti thể tạo nhiều ATP nhất.', 'Most ATP is made by the electron transport chain.'],
    ['fermentation', 'lên men', '/ˌfɜːmenˈteɪʃn/', 'Incomplete breakdown of sugar without O₂, making only 2 ATP.', 'Phân giải không hoàn toàn đường khi không có O₂, chỉ tạo 2 ATP.', 'Yeast makes ethanol by fermentation.'],
    ['photosynthesis', 'quang hợp', '/ˌfəʊtəʊˈsɪnθəsɪs/', 'Using light energy to make sugar from CO₂ and water, releasing O₂.', 'Dùng năng lượng ánh sáng tổng hợp đường từ CO₂ và nước, giải phóng O₂.', 'Photosynthesis takes place in chloroplasts.'],
    ['light-dependent reactions', 'pha sáng', '/laɪt dɪˈpendənt riˈækʃnz/', 'Reactions on thylakoids that make ATP and NADPH and release O₂.', 'Phản ứng ở thylakoid tạo ATP, NADPH và giải phóng O₂.', 'Water is split in the light-dependent reactions.'],
    ['Calvin cycle', 'chu trình Calvin (pha tối)', '/ˈkælvɪn ˌsaɪkl/', 'Reactions in the stroma that fix CO₂ into sugar.', 'Phản ứng ở chất nền cố định CO₂ thành đường.', 'The Calvin cycle uses ATP and NADPH.'],
    ['chemosynthesis', 'hoá tổng hợp', '/ˌkiːməʊˈsɪnθəsɪs/', 'Fixing CO₂ using energy from oxidising inorganic compounds.', 'Cố định CO₂ nhờ năng lượng oxy hoá chất vô cơ.', 'Nitrifying bacteria carry out chemosynthesis.'],
    ['anoxygenic photosynthesis', 'quang khử', '/ˌænɒksɪˈdʒenɪk ˌfəʊtəʊˈsɪnθəsɪs/', 'Bacterial photosynthesis that does not release O₂.', 'Quang hợp ở vi khuẩn không giải phóng O₂.', 'Purple bacteria perform anoxygenic photosynthesis using H₂S.'],
  ],
};
