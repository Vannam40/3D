import { LessonPack } from '../types';

export const bai02: LessonPack = {
  id: 'bai02_phuong_phap_nghien_cuu',
  lesson: 2,
  chapter: 'mo_dau',
  titleVi: 'Bài 2. Phương pháp nghiên cứu và học tập môn Sinh học',
  titleEn: 'Research and Learning Methods in Biology',
  pages: 'SGK tr. 12–17',
  modelId: 'm02_lab_methods',
  descriptionVi:
    'Phương pháp quan sát, làm việc trong phòng thí nghiệm, thực nghiệm khoa học; thiết bị nghiên cứu (kính hiển vi, máy li tâm…); quy trình nghiên cứu khoa học và tin sinh học.',
  objectives: [
    'Trình bày và vận dụng được một số phương pháp nghiên cứu sinh học: quan sát, làm việc phòng thí nghiệm, thực nghiệm khoa học.',
    'Nêu được một số thiết bị nghiên cứu và học tập môn Sinh học.',
    'Trình bày, vận dụng được quy trình và các kĩ năng trong tiến trình nghiên cứu khoa học.',
    'Giới thiệu được phương pháp tin sinh học như là công cụ hữu ích trong nghiên cứu và học tập sinh học.',
  ],
  keyConcepts: ['Phương pháp quan sát', 'An toàn phòng thí nghiệm', 'Thực nghiệm khoa học', 'Kính hiển vi & máy li tâm', 'Quy trình nghiên cứu', 'Tin sinh học'],
  sections: [
    {
      heading: 'I. Phương pháp nghiên cứu sinh học',
      paragraphs: [
        'Phương pháp quan sát gồm các bước: lựa chọn đối tượng và phạm vi quan sát → lựa chọn công cụ quan sát → ghi chép số liệu. Số liệu phải đủ lớn (lặp lại nhiều lần) và khách quan để xử lí bằng toán thống kê và xác suất.',
        'Phương pháp làm việc trong phòng thí nghiệm: đảm bảo an toàn (cháy nổ, hoá chất – làm việc với hoá chất độc dễ bay hơi ở tủ hút khí độc hoặc nơi thoáng khí; vận hành thiết bị đúng quy tắc, ghi nhật kí; trang bị cá nhân: áo choàng, găng tay, kính bảo hộ hoặc mặt nạ).',
      ],
      bulletPoints: [
        'Phương pháp giải phẫu: quan sát các bộ phận cấu thành (rễ, thân, lá của cây; bộ phận cơ thể động vật).',
        'Làm tiêu bản tế bào/NST: mẫu mô cắt lát đủ mỏng để quan sát dưới kính hiển vi; tiêu bản tươi NST: cố định bằng hoá chất, nhuộm màu, chia nhỏ mẫu, dầm ép giải phóng NST.',
        'Phương pháp thực nghiệm khoa học: nghiên cứu, phân loại sinh vật (định danh theo hình thái, phân tích gene, phân lập vi khuẩn); tách chiết (enzyme, gene, chất có hoạt tính sinh học); nuôi cấy (vi khuẩn, mô tế bào động vật, thực vật…).',
      ],
    },
    {
      heading: 'II. Các thiết bị nghiên cứu và học tập môn Sinh học',
      paragraphs: [
        'Kính hiển vi gồm kính hiển vi quang học (nguồn sáng điện hay ánh sáng mặt trời) và kính hiển vi điện tử (chùm electron). Ba thông số quan trọng: độ phóng đại, độ phân giải và độ tương phản.',
        'Máy li tâm dùng trong kĩ thuật phân đoạn tế bào – tách các loại bào quan dựa trên khối lượng của chúng nhờ lực li tâm ở các tốc độ vòng quay khác nhau.',
        'Các thiết bị khác: kính lúp, ống hút đơn giản hay pipet, ống hút điều chỉnh định lượng chính xác.',
      ],
      formulaBox: {
        title: 'So sánh kính hiển vi (theo SGK)',
        formulas: [
          'Kính hiển vi quang học: phóng đại tối đa 1 500 lần; độ phân giải khoảng 200 nm',
          'Kính hiển vi điện tử (TEM): phóng đại tới 50 triệu lần; độ phân giải nhỏ hơn 1 Å',
        ],
      },
    },
    {
      heading: 'III. Các kĩ năng trong tiến trình nghiên cứu khoa học',
      paragraphs: [
        'Quy trình: Quan sát, thu thập dữ liệu → Đặt câu hỏi → Hình thành giả thuyết → Thiết kế và tiến hành thí nghiệm kiểm chứng → Phân tích kết quả → Rút ra kết luận (chấp nhận hoặc bác bỏ giả thuyết).',
        'Giả thuyết khoa học là cách giải thích có thể kiểm chứng được bằng thực nghiệm. Để kiểm chứng, nhà khoa học dùng suy luận diễn giải (đi từ cái chung tới cái riêng), đưa ra dự đoán dạng "nếu… thì…".',
        'Thí nghiệm kiểm chứng thường gồm lô đối chứng và lô thí nghiệm: đối tượng và mọi yếu tố môi trường giống nhau, ngoại trừ yếu tố cần nghiên cứu.',
        'Trên đồ thị: trục hoành thể hiện biến độc lập (người nghiên cứu chủ động thay đổi), trục tung thể hiện biến phụ thuộc. Toán thống kê giúp xác định cỡ mẫu và khẳng định sai khác có ý nghĩa hay chỉ là ngẫu nhiên.',
        'Giả thuyết được kiểm nghiệm ở nhiều đối tượng bởi nhiều nhà khoa học và được giới khoa học thừa nhận sẽ trở thành học thuyết khoa học.',
      ],
    },
    {
      heading: 'IV. Tin sinh học – công cụ nghiên cứu và học tập',
      paragraphs: [
        'Tin sinh học (Bioinformatics) là ngành khoa học sử dụng phần mềm máy tính chuyên dụng, các thuật toán, mô hình để lưu trữ, phân loại, phân tích các bộ dữ liệu sinh học ở quy mô lớn.',
        'Ứng dụng: tìm kiếm gene trong hệ gene, so sánh hệ gene các loài để tìm hiểu quan hệ tiến hoá; trí tuệ nhân tạo xử lí thông tin bệnh nhân giúp bác sĩ đưa ra biện pháp chữa bệnh hiệu quả.',
      ],
    },
  ],
  core: [
    'Phương pháp thường dùng: quan sát, làm việc trong phòng thí nghiệm, thực nghiệm khoa học.',
    'Quy trình: Quan sát → Đặt câu hỏi → Hình thành giả thuyết → Thí nghiệm kiểm chứng → Phân tích kết quả → Rút ra kết luận.',
    'Tin sinh học dùng phần mềm, thuật toán, mô hình để lưu trữ, phân loại, phân tích dữ liệu sinh học quy mô lớn.',
  ],
  mcq: [
    ['Bước đầu tiên của quy trình nghiên cứu khoa học là', ['hình thành giả thuyết', 'quan sát, thu thập dữ liệu', 'thiết kế thí nghiệm', 'rút ra kết luận'], 1, 'Mọi nghiên cứu đều bắt đầu từ những quan sát để thu thập dữ liệu.'],
    ['Độ phóng đại tối đa của kính hiển vi quang học theo SGK là khoảng', ['150 lần', '1 500 lần', '50 000 lần', '50 triệu lần'], 1, 'Kính hiển vi quang học phóng đại tối đa 1 500 lần, độ phân giải khoảng 200 nm.'],
    ['Kính hiển vi điện tử sử dụng nguồn sáng là', ['ánh sáng mặt trời', 'đèn điện', 'chùm electron', 'tia hồng ngoại'], 2, 'Kính hiển vi điện tử dùng chùm electron chiếu qua hoặc lên bề mặt mẫu vật.'],
    ['Máy li tâm được dùng trong kĩ thuật', ['nhuộm màu tiêu bản', 'phân đoạn tế bào – tách bào quan dựa trên khối lượng', 'giải trình tự gene', 'nuôi cấy mô thực vật'], 1, 'Lực li tâm ở các tốc độ khác nhau tách riêng các bộ phận tế bào có khối lượng khác nhau.'],
    ['Trong thí nghiệm kiểm chứng, lô đối chứng và lô thí nghiệm khác nhau ở', ['số lượng đối tượng nghiên cứu', 'loài sinh vật được dùng', 'yếu tố cần nghiên cứu', 'toàn bộ điều kiện môi trường'], 2, 'Mọi yếu tố ở hai lô đều giống nhau ngoại trừ yếu tố cần nghiên cứu.'],
    ['Cách suy luận đi từ cái chung tới cái riêng để kiểm chứng giả thuyết được gọi là', ['quy nạp', 'diễn giải', 'so sánh', 'thống kê'], 1, 'SGK: suy luận logic ngược lại với quy nạp, đi từ cái chung tới cái riêng gọi là diễn giải.'],
    ['Trên đồ thị kết quả nghiên cứu, trục hoành thường thể hiện', ['biến phụ thuộc', 'biến độc lập', 'sai số thống kê', 'kết luận'], 1, 'Trục hoành thể hiện biến độc lập – thông số người nghiên cứu chủ động thay đổi.'],
    ['Ngành sử dụng phần mềm máy tính, thuật toán, mô hình để phân tích dữ liệu sinh học quy mô lớn là', ['tin sinh học', 'phỏng sinh học', 'pháp y', 'giải phẫu học'], 0, 'Đó là tin sinh học (Bioinformatics).'],
    ['Khi làm việc với hoá chất độc hại dễ bay hơi, cần thực hiện ở', ['nơi kín gió', 'tủ hút khí độc hoặc nơi thoáng khí', 'gần nguồn lửa để hoá chất bay hơi nhanh', 'ngoài sân trường'], 1, 'Theo quy định an toàn về hoá chất trong SGK.'],
  ],
  tf: [
    ['Một giả thuyết chỉ được gọi là khoa học khi nó có thể được kiểm chứng bằng thực nghiệm.', true, 'Đúng theo SGK.'],
    ['Độ phân giải của kính hiển vi điện tử (TEM) có thể nhỏ hơn 1 Å.', true, 'Đúng; nhờ đó nghiên cứu được cấu trúc siêu hiển vi và cấu trúc phân tử.'],
    ['Nếu sai khác giữa nhóm đối chứng và nhóm thực nghiệm là ngẫu nhiên thì giả thuyết được chấp nhận.', false, 'Sai. Nếu sai khác là ngẫu nhiên thì giả thuyết bị bác bỏ.'],
    ['Để quan sát NST bằng tiêu bản tươi, mẫu vật được cố định, nhuộm màu, chia nhỏ và dầm ép để giải phóng NST.', true, 'Đúng các bước làm tiêu bản tươi NST trong SGK.'],
    ['Học thuyết khoa học là một giả thuyết chỉ cần một nhà khoa học kiểm chứng một lần.', false, 'Sai. Phải được kiểm nghiệm ở nhiều đối tượng, bởi nhiều nhà khoa học và được giới khoa học thừa nhận.'],
  ],
  terms: [
    ['observation', 'quan sát', '/ˌɒbzəˈveɪʃn/', 'Watching organisms and life processes carefully and recording data.', 'Theo dõi sinh vật, quá trình sống và ghi chép số liệu.', 'Every biological study starts with observation.'],
    ['hypothesis', 'giả thuyết', '/haɪˈpɒθəsɪs/', 'A testable explanation for a question.', 'Cách giải thích có thể kiểm chứng bằng thực nghiệm.', 'Scientists design experiments to test a hypothesis.'],
    ['control group', 'lô (nhóm) đối chứng', '/kənˈtrəʊl ɡruːp/', 'The group kept the same except for the factor being studied.', 'Lô giống lô thí nghiệm, trừ yếu tố cần nghiên cứu.', 'The control group did not receive the mineral element.'],
    ['independent variable', 'biến độc lập', '/ˌɪndɪˈpendənt ˈveəriəbl/', 'The factor the researcher changes; usually on the x-axis.', 'Thông số người nghiên cứu chủ động thay đổi; thường ở trục hoành.', 'The number of cigarettes per day is the independent variable.'],
    ['dependent variable', 'biến phụ thuộc', '/dɪˈpendənt ˈveəriəbl/', 'The factor that changes in response; usually on the y-axis.', 'Thông số thay đổi theo biến độc lập; thường ở trục tung.', 'The lung cancer rate is the dependent variable.'],
    ['light microscope', 'kính hiển vi quang học', '/laɪt ˈmaɪkrəskəʊp/', 'A microscope that uses light; up to about 1,500× magnification.', 'Kính dùng nguồn sáng; phóng đại tối đa khoảng 1 500 lần.', 'We use a light microscope to observe onion cells.'],
    ['electron microscope', 'kính hiển vi điện tử', '/ɪˈlektrɒn ˈmaɪkrəskəʊp/', 'A microscope that uses a beam of electrons.', 'Kính hiển vi dùng chùm electron.', 'An electron microscope shows the ultrastructure of cells.'],
    ['magnification', 'độ phóng đại', '/ˌmæɡnɪfɪˈkeɪʃn/', 'How many times larger an image is than the real object.', 'Số lần ảnh lớn hơn vật thật.', 'A TEM can reach a magnification of 50 million times.'],
    ['resolution', 'độ phân giải', '/ˌrezəˈluːʃn/', 'The ability to show two close points as separate.', 'Khả năng phân biệt hai điểm gần nhau.', 'The resolution of a light microscope is about 200 nm.'],
    ['centrifuge', 'máy li tâm', '/ˈsentrɪfjuːdʒ/', 'A machine that separates cell parts by mass using spinning force.', 'Máy tách các bộ phận tế bào theo khối lượng nhờ lực li tâm.', 'Organelles are separated in a centrifuge.'],
    ['bioinformatics', 'tin sinh học', '/ˌbaɪəʊɪnfəˈmætɪks/', 'Using computer software, algorithms and models to analyse large biological data sets.', 'Dùng phần mềm, thuật toán, mô hình phân tích dữ liệu sinh học quy mô lớn.', 'Bioinformatics helps compare genomes of different species.'],
  ],
};
