import { LessonPack } from '../types';

export const bai19: LessonPack = {
  id: 'bai19_cong_nghe_te_bao',
  lesson: 19,
  chapter: 'chuong5',
  titleVi: 'Bài 19. Công nghệ tế bào',
  titleEn: 'Cell Technology',
  pages: 'SGK tr. 110–114',
  modelId: 'm19_cell_technology',
  descriptionVi: 'Công nghệ tế bào động vật (tế bào gốc, nhân bản vô tính, liệu pháp tế bào gốc, liệu pháp gene) và công nghệ tế bào thực vật (nuôi cấy mô, lai tế bào sinh dưỡng, nuôi cấy hạt phấn/noãn).',
  minutes: 30,
  objectives: [
    'Nêu được khái niệm, nguyên lí công nghệ và một số thành tựu công nghệ tế bào động vật.',
    'Nêu được khái niệm, nguyên lí công nghệ và một số thành tựu công nghệ tế bào thực vật.',
  ],
  keyConcepts: ['Tế bào gốc phôi (vạn năng)', 'Tế bào gốc trưởng thành (đa tiềm năng)', 'Nhân bản vô tính', 'Liệu pháp tế bào gốc', 'Liệu pháp gene', 'Mô sẹo (callus)', 'Lai tế bào sinh dưỡng'],
  sections: [
    {
      heading: 'I. Công nghệ tế bào động vật',
      paragraphs: [
        'Khái niệm: quy trình nuôi cấy tế bào động vật và tế bào người trong môi trường nhân tạo để tạo lượng lớn tế bào nhằm nghiên cứu và ứng dụng.',
        'Nguyên lí: nuôi cấy tế bào gốc trong môi trường thích hợp, tạo điều kiện để chúng phân chia rồi biệt hoá thành các loại tế bào khác nhau.',
        'Tế bào gốc có thể phân chia và biệt hoá thành nhiều loại tế bào: tế bào gốc phôi (vạn năng) biệt hoá thành mọi loại tế bào; tế bào gốc trưởng thành (đa tiềm năng) chỉ biệt hoá thành một số loại.',
      ],
      bulletPoints: [
        'Nhân bản vô tính vật nuôi: chuyển nhân tế bào tuyến vú cừu A vào trứng đã loại nhân của cừu B, phát triển thành phôi, cấy vào tử cung cừu C → cừu Dolly (1996). Ở Việt Nam, Viện Chăn nuôi nhân bản thành công lợn Ỉ.',
        'Liệu pháp tế bào gốc: truyền tế bào gốc nuôi cấy ngoài cơ thể vào người bệnh để thay thế tế bào bệnh (VD: tiểu đường type 1; tế bào gốc tuỷ xương chữa ung thư máu). Kì vọng chữa Parkinson, tổn thương cơ tim, thần kinh.',
        'Liệu pháp gene: thay thế gene bệnh bằng gene lành – nuôi tế bào, chỉnh sửa gene, sàng lọc, nhân bản rồi truyền lại cho bệnh nhân.',
        'Ứng dụng khác: thịt nhân tạo, sản xuất protein chữa bệnh.',
      ],
      highlightBox: 'Năm 2006, Shinya Yamanaka tìm ra cách chuyển tế bào chuyên hoá ở người trưởng thành thành tế bào gốc.',
    },
    {
      heading: 'II. Công nghệ tế bào thực vật',
      paragraphs: [
        'Khái niệm: nuôi cấy tế bào, mô thực vật ở điều kiện vô trùng để tạo các cây có kiểu gene giống nhau nhằm nhân giống.',
        'Nguyên lí: dùng môi trường dinh dưỡng có bổ sung hormone thực vật thích hợp để tế bào thực vật tái sinh thành cây.',
      ],
      bulletPoints: [
        'Nuôi cấy mô tế bào: mô chuyên hoá → (môi trường dinh dưỡng + hormone, vô trùng) → mô sẹo (callus) chưa phân hoá → rễ, thân, lá → cây con. Nhân nhanh cây quý hiếm, cây kháng bệnh virus.',
        'Lai tế bào sinh dưỡng: lai hai tế bào sinh dưỡng của hai loài sau khi loại bỏ thành cellulose → tế bào lai → cây lai khác loài.',
        'Nuôi cấy hạt phấn hoặc noãn chưa thụ tinh: tạo cây đơn bội hoặc lưỡng bội hoá → cây đồng hợp tử về tất cả các gene.',
      ],
    },
  ],
  core: [
    'Công nghệ tế bào động vật nuôi cấy tế bào gốc để phân chia, biệt hoá; giúp nhân bản động vật, tạo tế bào thay thế tế bào bệnh.',
    'Công nghệ tế bào thực vật dùng môi trường dinh dưỡng có hormone để tế bào tái sinh thành cây; nhân nhanh giống quý, tạo cây lai khác loài, cây đồng hợp tử.',
  ],
  mcq: [
    ['Nguyên lí của công nghệ tế bào động vật là', ['lai hai tế bào sinh dưỡng khác loài', 'nuôi cấy tế bào gốc để chúng phân chia rồi biệt hoá thành các loại tế bào', 'chuyển gene từ vi khuẩn', 'gây đột biến nhân tạo'], 1, 'Theo SGK.'],
    ['Tế bào gốc có thể biệt hoá thành mọi loại tế bào của cơ thể trưởng thành là', ['tế bào gốc trưởng thành', 'tế bào gốc phôi (vạn năng)', 'tế bào tuyến vú', 'tế bào hồng cầu'], 1, 'Tế bào gốc phôi hay tế bào gốc vạn năng.'],
    ['Con cừu nhân bản vô tính đầu tiên trên thế giới tên là', ['Dolly', 'Molly', 'Polly', 'Lucy'], 0, 'Cừu Dolly ra đời năm 1996.'],
    ['Trong quy trình nhân bản cừu Dolly, nhân được lấy từ', ['tế bào trứng của cừu B', 'tế bào tuyến vú của cừu A', 'tế bào tử cung của cừu C', 'tinh trùng'], 1, 'Nhân tế bào tuyến vú của cừu A được chuyển vào trứng đã loại nhân của cừu B.'],
    ['Liệu pháp chữa bệnh di truyền bằng cách thay thế gene bệnh bằng gene lành là', ['liệu pháp tế bào gốc', 'liệu pháp gene', 'nhân bản vô tính', 'nuôi cấy mô'], 1, 'Liệu pháp gene.'],
    ['Trong nuôi cấy mô thực vật, tế bào biệt hoá được đưa về trạng thái chưa phân hoá tạo thành', ['mô sẹo (callus)', 'hạt phấn', 'tế bào lai', 'phôi'], 0, 'Mô sẹo hay mô callus.'],
    ['Kĩ thuật tạo cây lai khác loài từ hai tế bào sinh dưỡng đã loại bỏ thành cellulose là', ['nuôi cấy mô', 'lai tế bào sinh dưỡng', 'nuôi cấy hạt phấn', 'nhân bản vô tính'], 1, 'Lai tế bào sinh dưỡng.'],
    ['Kĩ thuật có thể tạo cây có kiểu gene đồng hợp tử về tất cả các gene là', ['nuôi cấy hạt phấn hoặc noãn chưa thụ tinh', 'nuôi cấy mô', 'lai tế bào sinh dưỡng', 'chiết cành'], 0, 'Nuôi cấy hạt phấn/noãn chưa thụ tinh rồi lưỡng bội hoá.'],
  ],
  tf: [
    ['Ở Việt Nam, các nhà khoa học Viện Chăn nuôi đã nhân bản thành công lợn Ỉ.', true, 'Đúng theo SGK.'],
    ['Tế bào gốc trưởng thành có thể biệt hoá thành mọi loại tế bào của cơ thể.', false, 'Sai. Tế bào gốc trưởng thành (đa tiềm năng) chỉ biệt hoá thành một số loại tế bào nhất định.'],
    ['Công nghệ tế bào thực vật tạo ra các cây có kiểu gene giống nhau.', true, 'Đúng – nhằm mục đích nhân giống.'],
    ['Năm 2006, Shinya Yamanaka tìm ra con đường chuyển tế bào chuyên hoá ở người trưởng thành thành tế bào gốc.', true, 'Đúng theo mục "Em có biết".'],
  ],
  terms: [
    ['cell technology', 'công nghệ tế bào', '/sel tekˈnɒlədʒi/', 'Culturing cells in artificial media for research and applications.', 'Nuôi cấy tế bào trong môi trường nhân tạo để nghiên cứu, ứng dụng.', 'Cell technology helps produce medicines.'],
    ['stem cell', 'tế bào gốc', '/stem sel/', 'A cell that can divide and differentiate into many cell types.', 'Tế bào có thể phân chia và biệt hoá thành nhiều loại tế bào.', 'Stem cells can repair damaged tissues.'],
    ['embryonic stem cell', 'tế bào gốc phôi', '/ˌembriˈɒnɪk stem sel/', 'A stem cell from an early embryo that can become any cell type.', 'Tế bào gốc từ phôi sớm, biệt hoá thành mọi loại tế bào.', 'Embryonic stem cells are pluripotent.'],
    ['differentiation', 'biệt hoá', '/ˌdɪfərenʃiˈeɪʃn/', 'The process by which a cell becomes specialised.', 'Quá trình tế bào trở nên chuyên hoá.', 'Differentiation produces nerve cells and muscle cells.'],
    ['cloning', 'nhân bản vô tính', '/ˈkləʊnɪŋ/', 'Producing genetically identical animals without sexual reproduction.', 'Tạo con vật giống hệt kiểu gene không qua sinh sản hữu tính.', 'Dolly the sheep was produced by cloning.'],
    ['gene therapy', 'liệu pháp gene', '/dʒiːn ˈθerəpi/', 'Treating genetic disease by replacing a faulty gene with a healthy one.', 'Chữa bệnh di truyền bằng thay gene bệnh bằng gene lành.', 'Gene therapy needs cells that keep dividing.'],
    ['tissue culture', 'nuôi cấy mô', '/ˈtɪʃuː ˈkʌltʃə/', 'Growing plant tissues in sterile nutrient media to make new plants.', 'Nuôi mô thực vật trong môi trường vô trùng tạo cây mới.', 'Bananas are often propagated by tissue culture.'],
    ['callus', 'mô sẹo', '/ˈkæləs/', 'An undifferentiated mass of plant cells in culture.', 'Khối tế bào thực vật chưa phân hoá trong nuôi cấy.', 'Roots and shoots grow from the callus.'],
    ['somatic hybridisation', 'lai tế bào sinh dưỡng', '/səʊˈmætɪk ˌhaɪbrɪdaɪˈzeɪʃn/', 'Fusing body cells of two plant species to make a hybrid.', 'Dung hợp tế bào sinh dưỡng hai loài tạo cây lai.', 'Somatic hybridisation can create new crops.'],
    ['plant hormone', 'hormone thực vật', '/plɑːnt ˈhɔːməʊn/', 'A chemical that controls plant growth and development.', 'Chất điều hoà sinh trưởng, phát triển của cây.', 'The medium contains plant hormones.'],
  ],
};
