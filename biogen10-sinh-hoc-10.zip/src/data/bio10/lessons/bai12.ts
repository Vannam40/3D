import { LessonPack } from '../types';

export const bai12: LessonPack = {
  id: 'bai12_truyen_tin_te_bao',
  lesson: 12,
  chapter: 'chuong3',
  titleVi: 'Bài 12. Truyền tin tế bào',
  titleEn: 'Cell Signalling',
  pages: 'SGK tr. 73–76',
  modelId: 'm12_cell_signalling',
  descriptionVi: 'Khái niệm truyền tin giữa các tế bào và bốn cách truyền tin; ba giai đoạn truyền tin trong tế bào: tiếp nhận – truyền tín hiệu – đáp ứng.',
  objectives: [
    'Nêu được khái niệm về thông tin giữa các tế bào.',
    'Trình bày được quá trình tiếp nhận: phân tử truyền tin liên kết vào protein thụ thể làm thụ thể thay đổi hình dạng.',
    'Trình bày được quá trình truyền tin: chuỗi tương tác phân tử chuyển tiếp tín hiệu từ thụ thể tới phân tử đích.',
    'Trình bày được quá trình đáp ứng: tế bào điều khiển phiên mã, dịch mã hoặc điều hoà hoạt động của tế bào.',
  ],
  keyConcepts: ['Phân tử tín hiệu', 'Truyền tin trực tiếp, cận tiết, nội tiết, qua synapse', 'Thụ thể', 'Tiếp nhận – Truyền – Đáp ứng'],
  sections: [
    {
      heading: 'I. Truyền tin giữa các tế bào',
      paragraphs: [
        'Truyền tin tế bào là sự phát tán và nhận các phân tử tín hiệu qua lại giữa các tế bào – trong cùng cơ thể, giữa cá thể cùng loài hoặc khác loài.',
        'Tín hiệu chủ yếu là tín hiệu hoá học: amino acid, peptide ngắn, protein lớn, nucleotide, hormone, thậm chí chất khí như NO.',
      ],
      bulletPoints: [
        'Truyền tin trực tiếp: qua mối nối hở giữa các tế bào liền kề.',
        'Truyền tin cận tiết: tế bào truyền tin cho các tế bào lân cận.',
        'Truyền tin nội tiết: hormone tiết vào máu, truyền tới tế bào đích ở xa.',
        'Truyền tin qua synapse: chất dẫn truyền xung thần kinh qua khe synapse giữa tế bào thần kinh và tế bào đích.',
      ],
    },
    {
      heading: 'II. Truyền tin trong tế bào',
      bulletPoints: [
        '(1) Tiếp nhận tín hiệu: thụ thể trên màng hoặc trong tế bào chất liên kết với tín hiệu phù hợp như chìa khoá với ổ khoá; thụ thể có thể là protein kênh, enzyme, protein hoạt hoá gene…',
        '(2) Truyền tín hiệu: thụ thể đổi cấu hình, chuyển từ bất hoạt sang hoạt động, hoạt hoá phân tử kế tiếp… cho tới phân tử đích cuối cùng.',
        '(3) Đáp ứng: tạo enzyme sửa sai DNA, thay đổi hình dạng – di chuyển tế bào, đóng/mở gene, phân bào… VD: aldosterone qua màng, liên kết thụ thể trong tế bào chất, phức hợp vào nhân hoạt hoá gene.',
      ],
      highlightBox: 'Cùng một tín hiệu có thể gây đáp ứng khác nhau: epinephrine kích thích tế bào gan phân giải glycogen thành glucose, nhưng làm tế bào cơ tim co bóp mạnh hơn – do khác nhau về thụ thể, con đường truyền tin và protein đáp ứng.',
      paragraphs: ['Tế bào điều chỉnh được mức độ tiếp nhận và đáp ứng: khi vận động mạnh, thụ thể insulin tăng độ nhạy hoặc số lượng → luyện tập thể dục giảm nguy cơ tiểu đường type 2.'],
    },
  ],
  core: [
    'Các tế bào có thể truyền cho nhau phân tử tín hiệu theo nhiều cách khác nhau.',
    'Tín hiệu được thụ thể tiếp nhận, chuyển đổi qua chuỗi protein tới protein đích, gây đáp ứng: đóng/mở gene, thay đổi chuyển hoá, vận động hoặc phân bào.',
  ],
  mcq: [
    ['Ba giai đoạn của truyền tin trong tế bào theo thứ tự là', ['truyền tín hiệu → tiếp nhận → đáp ứng', 'tiếp nhận → truyền tín hiệu → đáp ứng', 'đáp ứng → tiếp nhận → truyền tín hiệu', 'tiếp nhận → đáp ứng → truyền tín hiệu'], 1, 'Tiếp nhận tín hiệu → truyền tín hiệu → đáp ứng.'],
    ['Hình thức hormone được tiết vào máu và truyền tới tế bào đích ở xa là', ['truyền tin trực tiếp', 'truyền tin cận tiết', 'truyền tin nội tiết', 'truyền tin qua synapse'], 2, 'Truyền tin nội tiết.'],
    ['Khe hở giữa tế bào thần kinh và tế bào đích, nơi chất dẫn truyền đi qua, gọi là', ['mối nối kín', 'synapse', 'cầu sinh chất', 'lỗ màng nhân'], 1, 'Truyền tin qua synapse.'],
    ['Phân tử tiếp nhận tín hiệu của tế bào là', ['thụ thể', 'enzyme ATP synthase', 'ribosome', 'DNA'], 0, 'Tế bào tiếp nhận tín hiệu bằng protein thụ thể.'],
    ['Mối liên kết giữa thụ thể và tín hiệu được ví như', ['bánh răng ăn khớp', 'chìa khoá với ổ khoá', 'nam châm hút sắt', 'dòng điện'], 1, 'Mỗi loại thụ thể liên kết với một tín hiệu phù hợp như chìa khoá với ổ khoá.'],
    ['Epinephrine gây đáp ứng khác nhau ở tế bào gan và tế bào cơ tim vì', ['hai tế bào có hệ gene khác nhau hoàn toàn', 'các tế bào khác nhau về thụ thể, con đường truyền tin và protein đáp ứng', 'epinephrine bị biến đổi trong máu', 'tế bào cơ tim không có thụ thể'], 1, 'Do các tế bào chuyên hoá có nhóm gene khác nhau hoạt động.'],
    ['Chất khí nào được SGK nêu là có thể làm tín hiệu truyền tin?', ['O₂', 'CO₂', 'NO', 'N₂'], 2, 'Tín hiệu có thể là chất khí như NO.'],
    ['Hormone aldosterone liên kết với thụ thể', ['trên thành tế bào', 'trong tế bào chất', 'trên ribosome', 'trên màng ti thể'], 1, 'Aldosterone đi qua màng vào tế bào chất và liên kết với thụ thể.'],
  ],
  tf: [
    ['Sinh vật đơn bào sống biệt lập, không tiếp nhận và phát tán tín hiệu cho nhau.', false, 'Sai. Sinh vật đơn bào luôn tiếp nhận và phát tán phân tử tín hiệu cho nhau.'],
    ['Thường xuyên luyện tập thể dục thể thao giúp giảm nguy cơ tiểu đường type 2.', true, 'Đúng; thụ thể insulin có thể tăng độ nhạy hoặc số lượng.'],
    ['Khi tiếp nhận tín hiệu, thụ thể thay đổi cấu hình và chuyển từ bất hoạt sang hoạt động.', true, 'Đúng theo SGK.'],
    ['Cây ngô khi bị sâu ăn có thể tiết chất hoá học gọi ong kí sinh đến diệt sâu.', true, 'Đúng theo mục "Em có biết".'],
  ],
  terms: [
    ['cell signalling', 'truyền tin tế bào', '/sel ˈsɪɡnəlɪŋ/', 'Sending and receiving signal molecules between cells.', 'Sự phát và nhận phân tử tín hiệu giữa các tế bào.', 'Cell signalling keeps the body working together.'],
    ['signal molecule', 'phân tử tín hiệu', '/ˈsɪɡnəl ˈmɒlɪkjuːl/', 'A chemical that carries a message to a cell.', 'Phân tử hoá học mang thông tin tới tế bào.', 'Hormones are signal molecules.'],
    ['receptor', 'thụ thể', '/rɪˈseptə/', 'A protein that binds a specific signal, like a lock and key.', 'Protein liên kết đặc hiệu với tín hiệu như ổ khoá – chìa khoá.', 'Insulin binds to its receptor.'],
    ['reception', 'tiếp nhận', '/rɪˈsepʃn/', 'The first stage: the signal binds to a receptor.', 'Giai đoạn 1: tín hiệu liên kết với thụ thể.', 'Reception changes the shape of the receptor.'],
    ['transduction', 'truyền tín hiệu', '/trænzˈdʌkʃn/', 'A chain of molecules relaying the signal inside the cell.', 'Chuỗi phân tử chuyển tiếp tín hiệu trong tế bào.', 'Transduction activates one molecule after another.'],
    ['response', 'đáp ứng', '/rɪˈspɒns/', 'The final change in the cell’s activity.', 'Sự thay đổi hoạt động cuối cùng của tế bào.', 'The response may switch a gene on.'],
    ['endocrine signalling', 'truyền tin nội tiết', '/ˈendəʊkraɪn ˈsɪɡnəlɪŋ/', 'Hormones travel in the blood to distant target cells.', 'Hormone theo máu đến tế bào đích ở xa.', 'Insulin works by endocrine signalling.'],
    ['paracrine signalling', 'truyền tin cận tiết', '/ˈpærəkrɪn ˈsɪɡnəlɪŋ/', 'A cell signals to nearby cells.', 'Tế bào truyền tin cho tế bào lân cận.', 'Growth factors often act by paracrine signalling.'],
    ['synapse', 'synapse (khớp thần kinh)', '/ˈsaɪnæps/', 'The gap between a nerve cell and its target cell.', 'Khe giữa tế bào thần kinh và tế bào đích.', 'Neurotransmitters cross the synapse.'],
    ['target cell', 'tế bào đích', '/ˈtɑːɡɪt sel/', 'A cell that has a receptor for a signal.', 'Tế bào có thụ thể với tín hiệu.', 'Hormones only affect their target cells.'],
  ],
};
