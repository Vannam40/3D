import { LessonPack } from '../types';

export const bai10: LessonPack = {
  id: 'bai10_trao_doi_chat_qua_mang',
  lesson: 10,
  chapter: 'chuong3',
  titleVi: 'Bài 10. Trao đổi chất qua màng tế bào',
  titleEn: 'Transport Across the Cell Membrane',
  pages: 'SGK tr. 64–70',
  modelId: 'm10_membrane_transport',
  descriptionVi: 'Khái niệm trao đổi chất qua màng; vận chuyển thụ động (khuếch tán đơn giản, khuếch tán tăng cường, thẩm thấu), vận chuyển chủ động (bơm Na⁺–K⁺), nhập bào (thực bào, ẩm bào) và xuất bào.',
  objectives: [
    'Nêu được khái niệm trao đổi chất qua màng tế bào.',
    'Phân biệt được các hình thức vận chuyển thụ động, chủ động; nêu được ý nghĩa; lấy được ví dụ.',
    'Trình bày được hiện tượng nhập bào và xuất bào thông qua biến dạng màng tế bào.',
    'Vận dụng hiểu biết về vận chuyển các chất qua màng để giải thích một số hiện tượng thực tiễn.',
  ],
  keyConcepts: ['Gradient nồng độ', 'Khuếch tán đơn giản', 'Khuếch tán tăng cường', 'Thẩm thấu', 'Ưu/đẳng/nhược trương', 'Vận chuyển chủ động', 'Thực bào, ẩm bào, xuất bào'],
  sections: [
    {
      heading: 'I. Khái niệm trao đổi chất qua màng tế bào',
      paragraphs: [
        'Trao đổi chất qua màng tế bào thực chất là quá trình vận chuyển các chất ra, vào tế bào qua màng. Màng tế bào chỉ cho những chất nhất định ra vào → tế bào có cơ chế "chọn lọc" và kiểm soát trao đổi chất.',
        'Phân tử nhỏ ra vào chủ yếu nhờ khuếch tán; tốc độ phụ thuộc kích thước, bản chất phân tử, chênh lệch nồng độ, nhiệt độ, áp suất.',
      ],
    },
    {
      heading: 'II.1. Vận chuyển thụ động',
      paragraphs: ['Khuếch tán các chất từ nơi có nồng độ chất tan cao đến nơi có nồng độ thấp (xuôi chiều gradient nồng độ), không tiêu tốn năng lượng.'],
      bulletPoints: [
        'Khuếch tán đơn giản: qua lớp kép phospholipid; chỉ phân tử không phân cực, kích thước nhỏ (O₂, CO₂, nước) đi qua; ion không qua được.',
        'Khuếch tán tăng cường: qua protein xuyên màng (protein kênh tạo lỗ; protein mang biến đổi cấu hình) – cho ion, chất phân cực, amino acid… Kênh aquaporin vận chuyển 3 tỉ phân tử nước/giây. Tốc độ phụ thuộc gradient nồng độ và số kênh; có hiện tượng bão hoà kênh.',
        'Thẩm thấu: sự khuếch tán của nước qua màng, từ nơi có nồng độ chất tan thấp tới nơi có nồng độ chất tan cao.',
      ],
    },
    {
      heading: 'Môi trường ưu trương – đẳng trương – nhược trương',
      bulletPoints: [
        'Ưu trương (nồng độ chất tan ngoài cao hơn trong tế bào): tế bào mất nước, co lại; tế bào thực vật bị co nguyên sinh (lá rau héo).',
        'Đẳng trương: nồng độ chất tan ngoài bằng trong tế bào.',
        'Nhược trương (nồng độ ngoài thấp hơn): nước đi vào tế bào; tế bào vi khuẩn, nấm, thực vật nhờ thành tế bào chỉ trương lên ở mức nhất định.',
      ],
      highlightBox: 'Nước muối sinh lí đẳng trương với tế bào người nhưng ưu trương với vi khuẩn → súc miệng ngăn vi sinh vật gây bệnh mà không hại niêm mạc miệng.',
    },
    {
      heading: 'II.2. Vận chuyển chủ động',
      paragraphs: [
        'Vận chuyển các chất từ nơi có nồng độ chất tan thấp tới nơi có nồng độ cao (ngược gradient), cần năng lượng ATP và protein hoạt động như chiếc bơm (VD: bơm Na⁺–K⁺).',
        'Khi nghỉ ngơi, tế bào người vẫn dùng tới 40% năng lượng cho vận chuyển chủ động; tế bào thận dùng tới 90%; tế bào niêm mạc dạ dày bơm H⁺ và Cl⁻ tạo môi trường acid.',
      ],
    },
    {
      heading: 'II.3. Vận chuyển nhờ biến dạng màng tế bào',
      bulletPoints: [
        'Thực bào: tế bào "ăn" phân tử lớn, thậm chí cả tế bào; màng bao lấy vật tạo túi vận chuyển đi vào tế bào chất.',
        'Ẩm bào: tế bào lấy các chất tan theo cách tương tự.',
        'Nhập bào nhờ thụ thể: VD lipoprotein mang cholesterol liên kết đặc hiệu với thụ thể trên màng.',
        'Xuất bào: túi vận chuyển liên kết với màng, giải phóng chất ra ngoài (VD: protein sữa từ tế bào tuyến sữa).',
        'Tất cả các hình thức này đều tiêu tốn năng lượng.',
      ],
    },
  ],
  core: [
    'Vận chuyển thụ động: xuôi gradient, không tốn năng lượng (khuếch tán đơn giản, tăng cường, thẩm thấu).',
    'Vận chuyển chủ động: ngược gradient, cần năng lượng ATP và protein bơm.',
    'Phân tử lớn được vận chuyển bằng ẩm bào, thực bào, xuất bào nhờ biến dạng màng, cần năng lượng.',
  ],
  mcq: [
    ['Vận chuyển thụ động là hình thức vận chuyển các chất', ['ngược chiều gradient nồng độ, cần năng lượng', 'xuôi chiều gradient nồng độ, không cần năng lượng', 'nhờ biến dạng màng', 'chỉ qua kênh aquaporin'], 1, 'Từ nơi nồng độ cao đến nơi nồng độ thấp, không tiêu tốn năng lượng.'],
    ['Chất nào sau đây có thể khuếch tán đơn giản qua lớp kép phospholipid?', ['Ion Na⁺', 'O₂', 'Glucose', 'Protein'], 1, 'Phân tử nhỏ, không phân cực như O₂, CO₂ khuếch tán qua lớp kép phospholipid; ion thì không.'],
    ['Kênh protein chuyên vận chuyển nước là', ['bơm Na⁺–K⁺', 'aquaporin', 'P-glycoprotein', 'thụ thể'], 1, 'Aquaporin vận chuyển 3 tỉ phân tử nước/giây.'],
    ['Thẩm thấu là sự khuếch tán của', ['các ion qua kênh protein', 'phân tử nước qua màng', 'glucose qua protein mang', 'các đại phân tử qua túi vận chuyển'], 1, 'Sự khuếch tán của các phân tử nước qua màng tế bào gọi là thẩm thấu.'],
    ['Đặt tế bào thực vật vào môi trường ưu trương sẽ xảy ra hiện tượng', ['tế bào trương nước rồi vỡ', 'co nguyên sinh', 'không thay đổi', 'tế bào nhân đôi'], 1, 'Nước thẩm thấu ra ngoài, chất nguyên sinh và màng co lại tách khỏi thành tế bào.'],
    ['Đặc điểm của vận chuyển chủ động là', ['xuôi gradient, không cần ATP', 'ngược gradient, cần năng lượng ATP', 'chỉ xảy ra với nước', 'không cần protein màng'], 1, 'Vận chuyển chủ động ngược chiều gradient, cần ATP.'],
    ['Tế bào thận có thể sử dụng tới bao nhiêu phần trăm năng lượng cho vận chuyển chủ động?', ['10%', '40%', '70%', '90%'], 3, 'SGK: tế bào thận dùng tới 90% năng lượng để lọc máu, bơm amino acid và glucose trở lại máu.'],
    ['Hình thức tế bào "ăn" các phân tử lớn, thậm chí cả một tế bào là', ['ẩm bào', 'thực bào', 'xuất bào', 'thẩm thấu'], 1, 'Thực bào là hoạt động "ăn" của tế bào nhờ biến dạng màng.'],
    ['Tế bào tuyến sữa đưa protein sữa ra ngoài bằng hình thức', ['xuất bào', 'thực bào', 'khuếch tán đơn giản', 'thẩm thấu'], 0, 'Protein sữa được đóng gói trong túi vận chuyển và xuất bào.'],
  ],
  tf: [
    ['Tốc độ khuếch tán tăng cường có thể không tăng thêm dù vẫn còn chênh lệch nồng độ do hiện tượng bão hoà kênh.', true, 'Đúng; khi đó tất cả protein vận chuyển đã hoạt động hết công suất.'],
    ['Thực bào, ẩm bào và xuất bào đều không tiêu tốn năng lượng.', false, 'Sai. Tất cả các hình thức vận chuyển nhờ biến dạng màng đều tiêu tốn năng lượng.'],
    ['Nước khuếch tán từ nơi có nồng độ chất tan thấp tới nơi có nồng độ chất tan cao.', true, 'Đúng; vì vậy tế bào rễ có áp suất thẩm thấu cao hút được nước từ đất.'],
    ['Các ion có kích thước nhỏ nên dễ dàng khuếch tán qua lớp kép phospholipid.', false, 'Sai. Ion dù nhỏ cũng không khuếch tán qua lớp kép phospholipid được.'],
    ['Protein đa kháng thuốc (P-glycoprotein) bơm thuốc ra khỏi tế bào ung thư.', true, 'Đúng theo mục "Em có biết".'],
  ],
  terms: [
    ['passive transport', 'vận chuyển thụ động', '/ˈpæsɪv ˈtrænspɔːt/', 'Movement of substances down a concentration gradient without energy.', 'Vận chuyển xuôi gradient nồng độ, không tốn năng lượng.', 'Oxygen enters cells by passive transport.'],
    ['concentration gradient', 'gradient nồng độ', '/ˌkɒnsnˈtreɪʃn ˈɡreɪdiənt/', 'A difference in concentration between two areas.', 'Sự chênh lệch nồng độ giữa hai vùng.', 'Molecules move down a concentration gradient.'],
    ['simple diffusion', 'khuếch tán đơn giản', '/ˈsɪmpl dɪˈfjuːʒn/', 'Diffusion directly through the phospholipid bilayer.', 'Khuếch tán trực tiếp qua lớp kép phospholipid.', 'CO₂ leaves the cell by simple diffusion.'],
    ['facilitated diffusion', 'khuếch tán tăng cường', '/fəˈsɪlɪteɪtɪd dɪˈfjuːʒn/', 'Diffusion through channel or carrier proteins.', 'Khuếch tán qua protein kênh hoặc protein mang.', 'Ions cross the membrane by facilitated diffusion.'],
    ['osmosis', 'thẩm thấu', '/ɒzˈməʊsɪs/', 'The diffusion of water across a membrane.', 'Sự khuếch tán của nước qua màng.', 'Root cells absorb water by osmosis.'],
    ['hypertonic', 'ưu trương', '/ˌhaɪpəˈtɒnɪk/', 'A solution with a higher solute concentration than the cell.', 'Dung dịch có nồng độ chất tan cao hơn tế bào.', 'In a hypertonic solution, cells lose water.'],
    ['hypotonic', 'nhược trương', '/ˌhaɪpəʊˈtɒnɪk/', 'A solution with a lower solute concentration than the cell.', 'Dung dịch có nồng độ chất tan thấp hơn tế bào.', 'In a hypotonic solution, water enters the cell.'],
    ['isotonic', 'đẳng trương', '/ˌaɪsəˈtɒnɪk/', 'A solution with the same solute concentration as the cell.', 'Dung dịch có nồng độ chất tan bằng tế bào.', 'Saline solution is isotonic to human cells.'],
    ['plasmolysis', 'co nguyên sinh', '/plæzˈmɒləsɪs/', 'The shrinking of the protoplast away from the cell wall.', 'Chất nguyên sinh co lại, tách khỏi thành tế bào.', 'Plasmolysis makes vegetable leaves wilt.'],
    ['active transport', 'vận chuyển chủ động', '/ˈæktɪv ˈtrænspɔːt/', 'Movement against a concentration gradient using ATP.', 'Vận chuyển ngược gradient, dùng ATP.', 'The sodium–potassium pump uses active transport.'],
    ['phagocytosis', 'thực bào', '/ˌfæɡəsaɪˈtəʊsɪs/', 'A cell engulfing large particles or whole cells.', 'Tế bào "ăn" phân tử lớn hoặc cả tế bào.', 'White blood cells destroy bacteria by phagocytosis.'],
    ['exocytosis', 'xuất bào', '/ˌeksəʊsaɪˈtəʊsɪs/', 'Releasing large substances out of the cell in vesicles.', 'Đưa chất lớn ra khỏi tế bào bằng túi vận chuyển.', 'Milk proteins leave the cell by exocytosis.'],
  ],
};
