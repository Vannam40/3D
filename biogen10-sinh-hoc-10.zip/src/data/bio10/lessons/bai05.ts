import { LessonPack } from '../types';

export const bai05: LessonPack = {
  id: 'bai05_phan_tu_sinh_hoc',
  lesson: 5,
  chapter: 'chuong1',
  titleVi: 'Bài 5. Các phân tử sinh học',
  titleEn: 'Biological Molecules',
  pages: 'SGK tr. 28–40',
  modelId: 'm05_biomolecules',
  descriptionVi:
    'Khái niệm phân tử sinh học; cấu tạo, chức năng của carbohydrate, lipid, protein, nucleic acid (DNA, RNA); nguồn thực phẩm cung cấp và ứng dụng thực tiễn (dấu vân tay DNA).',
  minutes: 35,
  objectives: [
    'Nêu được khái niệm phân tử sinh học.',
    'Trình bày được thành phần cấu tạo và vai trò của các phân tử sinh học.',
    'Phân tích được mối quan hệ giữa cấu tạo và chức năng của các phân tử sinh học.',
    'Nêu được một số nguồn thực phẩm cung cấp các phân tử sinh học cho cơ thể.',
    'Vận dụng kiến thức để giải thích hiện tượng và ứng dụng thực tiễn (vai trò của DNA trong xác định huyết thống, truy tìm tội phạm,…).',
  ],
  keyConcepts: ['Đại phân tử – polymer', 'Carbohydrate', 'Lipid', 'Protein & 4 bậc cấu trúc', 'DNA', 'RNA'],
  sections: [
    {
      heading: 'I. Khái niệm phân tử sinh học',
      paragraphs: [
        'Phân tử sinh học là những phân tử hữu cơ được tổng hợp và tồn tại trong tế bào sống, gồm protein, lipid, carbohydrate, nucleic acid.',
        'Protein, carbohydrate và nucleic acid là đại phân tử cấu tạo theo nguyên tắc đa phân (polymer). Bộ khung hydrocarbon liên kết với các nhóm chức (amino, carboxyl,…) tạo ra vô số hợp chất.',
      ],
    },
    {
      heading: '1. Carbohydrate – chất đường bột',
      paragraphs: [
        'Cấu tạo từ C, H, O theo tỉ lệ 1 : 2 : 1, công thức chung Cn(H₂O)m; gồm đường đơn, đường đôi, đường đa.',
      ],
      bulletPoints: [
        'Đường đơn (6C): glucose, fructose, galactose – cung cấp năng lượng và làm nguyên liệu cấu tạo phân tử khác.',
        'Đường đôi: hai đường đơn liên kết bằng liên kết glycosidic (loại 1 phân tử nước). Maltose = glucose + glucose; lactose = glucose + galactose; sucrose = glucose + fructose. Đường đôi là đường vận chuyển.',
        'Đường đa (polymer hàng trăm–nghìn đơn phân): tinh bột (dự trữ ở thực vật, ít phân nhánh); glycogen (dự trữ ở động vật, nấm; phân nhánh mạnh; tổng hợp ở gan, cơ); cellulose (mạch thẳng, cấu tạo thành tế bào thực vật; giúp tiêu hoá); chitin (khung xương ngoài tôm, cua, nhện; thành tế bào nấm).',
      ],
    },
    {
      heading: '2. Lipid – chất béo',
      paragraphs: ['Lipid đa dạng về cấu trúc nhưng có đặc tính chung là kị nước (chứa nhiều liên kết C–H không phân cực, ít nguyên tử oxygen).'],
      bulletPoints: [
        'Mỡ và dầu (triglyceride): 1 glycerol + 3 acid béo. Dầu lỏng (acid béo không no), mỡ rắn (acid béo no). Chức năng: dự trữ năng lượng, cách nhiệt, dung môi hoà tan vitamin A, D, E, K.',
        'Phospholipid: glycerol + 2 acid béo + nhóm phosphate (thường gắn choline) → phân tử lưỡng cực: đầu ưa nước, hai đuôi kị nước; cấu tạo nên màng tế bào.',
        'Steroid: không chứa acid béo, có 4 vòng carbon; gồm cholesterol (thành phần màng, tiền thân testosterone, estrogen), vitamin D, cortisone… HDL – cholesterol "tốt"; LDL – cholesterol "xấu".',
        'Carotenoid: sắc tố vàng cam ở thực vật, được chuyển hoá thành vitamin A có lợi cho thị giác.',
      ],
    },
    {
      heading: '3. Protein – chất đạm',
      paragraphs: [
        'Chức năng: cấu trúc, xúc tác (enzyme), bảo vệ (kháng thể), vận động, tiếp nhận thông tin (thụ thể), điều hoà (hormone).',
        'Đơn phân là amino acid: carbon trung tâm liên kết với nhóm amino (–NH₂), nhóm carboxyl (–COOH), nguyên tử H và nhóm R. Các amino acid nối với nhau bằng liên kết peptide tạo chuỗi polypeptide. Có 20 loại amino acid, trong đó 9 loại không thay thế.',
      ],
      bulletPoints: [
        'Bậc 1: trình tự các amino acid trong chuỗi polypeptide.',
        'Bậc 2: chuỗi polypeptide cuộn xoắn hoặc gấp nếp.',
        'Bậc 3: cấu trúc không gian ba chiều đặc trưng do tương tác giữa các nhóm R.',
        'Bậc 4: hai hay nhiều chuỗi polypeptide liên kết với nhau.',
      ],
      highlightBox:
        'Cấu trúc không gian được duy trì nhờ liên kết yếu (hydrogen, kị nước, Van der Waals), liên kết disulphide và liên kết ion. Khi pH, nhiệt độ, áp suất… thay đổi, protein bị biến tính và mất chức năng (ứng dụng: đun chín, ướp muối, cồn 70° diệt vi sinh vật).',
    },
    {
      heading: '4. Nucleic acid',
      paragraphs: [
        'DNA mang, bảo quản và truyền đạt thông tin di truyền: DNA → (phiên mã) mRNA → (dịch mã) Protein.',
        'DNA gồm hai chuỗi polynucleotide song song, ngược chiều; mỗi nucleotide gồm gốc phosphate, đường deoxyribose và một base (A, T, G, C); các nucleotide nối bằng liên kết phosphodiester. Hai mạch liên kết bằng liên kết hydrogen theo nguyên tắc bổ sung: A–T (2 liên kết), G–C (3 liên kết). Mô hình xoắn kép do Watson và Crick công bố năm 1953.',
        'Sinh vật nhân sơ: một phân tử DNA mạch vòng, kép ở vùng nhân và các plasmid nhỏ ở tế bào chất (nhiều plasmid mang gene kháng kháng sinh).',
        'RNA gồm một chuỗi polynucleotide; nucleotide có đường ribose và base A, U, G, C (không có T). mRNA làm khuôn tổng hợp protein; tRNA vận chuyển amino acid; rRNA cấu tạo ribosome; RNA nhỏ điều hoà gene; ribozyme xúc tác phản ứng.',
      ],
      highlightBox: 'Dấu vân tay DNA: các trình tự nucleotide ngắn lặp lại đặc trưng cho từng cá thể (trừ sinh đôi cùng trứng) – dùng nhận dạng cá thể, điều tra tội phạm, xác định quan hệ họ hàng.',
    },
  ],
  core: [
    'Carbohydrate (C:H:O = 1:2:1) gồm đường đơn, đôi, đa; chức năng dự trữ năng lượng và cấu trúc.',
    'Lipid kị nước: triglyceride, phospholipid, steroid, carotenoid, vitamin A, D, E, K; dự trữ năng lượng dài hạn, cấu trúc màng.',
    'Protein đa phân từ amino acid; cấu hình không gian ba chiều quy định chức năng.',
    'DNA: 2 chuỗi polynucleotide (A=T, G≡C), mang – bảo quản – truyền đạt thông tin di truyền. RNA: một chuỗi, base A, U, G, C, chức năng đa dạng.',
  ],
  mcq: [
    ['Carbohydrate được cấu tạo từ các nguyên tố C, H, O theo tỉ lệ', ['1 : 1 : 1', '1 : 2 : 1', '2 : 1 : 2', '1 : 2 : 2'], 1, 'SGK: C, H, O theo tỉ lệ 1 : 2 : 1, công thức chung Cn(H₂O)m.'],
    ['Đường sucrose được cấu tạo từ', ['hai phân tử glucose', 'glucose và galactose', 'glucose và fructose', 'fructose và galactose'], 2, 'Sucrose = glucose + fructose; maltose = 2 glucose; lactose = glucose + galactose.'],
    ['Loại đường đa dự trữ năng lượng ở động vật, phân nhánh rất mạnh là', ['tinh bột', 'glycogen', 'cellulose', 'chitin'], 1, 'Glycogen tổng hợp chủ yếu ở gan, cơ; dự trữ năng lượng ngắn hạn.'],
    ['Thành phần chính cấu tạo nên thành tế bào thực vật là', ['chitin', 'glycogen', 'cellulose', 'peptidoglycan'], 2, 'Cellulose là thành phần chính cấu tạo thành tế bào thực vật.'],
    ['Một phân tử mỡ (triglyceride) gồm', ['1 glycerol liên kết với 3 acid béo', '1 glycerol liên kết với 2 acid béo và nhóm phosphate', '4 vòng carbon liên kết với nhau', 'nhiều amino acid'], 0, 'Dầu, mỡ = 1 glycerol + 3 acid béo.'],
    ['Phospholipid là phân tử lưỡng cực vì có', ['đầu ưa nước và hai đuôi kị nước', 'hai đầu đều ưa nước', 'bốn vòng carbon', 'nhiều liên kết peptide'], 0, 'Đầu phosphatidylcholine ưa nước, hai đuôi acid béo kị nước.'],
    ['Liên kết nối hai amino acid với nhau là', ['liên kết glycosidic', 'liên kết peptide', 'liên kết phosphodiester', 'liên kết hydrogen'], 1, 'Hai amino acid liên kết bằng liên kết peptide nhờ phản ứng loại một phân tử nước.'],
    ['Cấu trúc bậc 1 của protein là', ['chuỗi polypeptide cuộn xoắn', 'trình tự các amino acid trong chuỗi polypeptide', 'hai chuỗi polypeptide liên kết với nhau', 'cấu trúc không gian ba chiều'], 1, 'Bậc 1 là trình tự amino acid.'],
    ['Khi luộc trứng, protein bị đông đặc là do protein bị', ['phân giải thành amino acid', 'biến tính', 'tổng hợp thêm', 'chuyển thành lipid'], 1, 'Nhiệt độ cao làm đứt liên kết yếu, protein bị biến tính.'],
    ['Trong phân tử DNA, G liên kết với C bằng', ['1 liên kết hydrogen', '2 liên kết hydrogen', '3 liên kết hydrogen', 'liên kết peptide'], 2, 'A–T: 2 liên kết hydrogen; G–C: 3 liên kết hydrogen.'],
    ['Loại RNA vận chuyển amino acid đến ribosome là', ['mRNA', 'tRNA', 'rRNA', 'ribozyme'], 1, 'tRNA vận chuyển amino acid đến ribosome tiến hành dịch mã.'],
    ['Điểm khác biệt về base của RNA so với DNA là RNA có', ['thymine thay cho uracil', 'uracil thay cho thymine', 'adenine thay cho guanine', 'không có cytosine'], 1, 'Base của RNA: A, G, C và U, không có T.'],
  ],
  tf: [
    ['Có 20 loại amino acid tham gia cấu tạo protein, trong đó 9 loại không thay thế.', true, 'Đúng theo SGK.'],
    ['Steroid là loại lipid có chứa 3 phân tử acid béo.', false, 'Sai. Steroid không chứa acid béo, có 4 vòng carbon.'],
    ['LDL được gọi là cholesterol "tốt" vì vận chuyển cholesterol tới gan.', false, 'Sai. HDL mới là cholesterol "tốt"; LDL là cholesterol "xấu".'],
    ['Plasmid ở vi khuẩn là phân tử DNA mạch vòng, kép, kích thước nhỏ, nằm ở tế bào chất.', true, 'Đúng; nhiều plasmid chứa gene kháng kháng sinh.'],
    ['Mô hình xoắn kép DNA do Watson và Crick công bố năm 1953.', true, 'Đúng theo SGK.'],
    ['Con người tiêu hoá được cellulose thành glucose.', false, 'Sai. Con người không tiêu hoá được cellulose nhưng cellulose giúp ích cho tiêu hoá.'],
  ],
  terms: [
    ['biomolecule', 'phân tử sinh học', '/ˌbaɪəʊˈmɒlɪkjuːl/', 'An organic molecule made and found in living cells.', 'Phân tử hữu cơ được tổng hợp và tồn tại trong tế bào sống.', 'Proteins and lipids are biomolecules.'],
    ['polymer', 'đa phân (polymer)', '/ˈpɒlɪmə/', 'A large molecule made of many repeated monomers.', 'Phân tử lớn gồm nhiều đơn phân lặp lại.', 'Starch is a polymer of glucose.'],
    ['monosaccharide', 'đường đơn', '/ˌmɒnəʊˈsækəraɪd/', 'A simple sugar such as glucose, fructose or galactose.', 'Đường đơn như glucose, fructose, galactose.', 'Glucose is the most common monosaccharide.'],
    ['polysaccharide', 'đường đa', '/ˌpɒliˈsækəraɪd/', 'A long chain of many sugar units, e.g. starch, glycogen, cellulose.', 'Chuỗi dài nhiều đường đơn: tinh bột, glycogen, cellulose.', 'Cellulose is a polysaccharide in plant cell walls.'],
    ['glycosidic bond', 'liên kết glycosidic', '/ˌɡlaɪkəˈsɪdɪk bɒnd/', 'The covalent bond joining two sugar molecules.', 'Liên kết cộng hoá trị nối hai phân tử đường.', 'A glycosidic bond joins glucose and fructose in sucrose.'],
    ['lipid', 'lipid (chất béo)', '/ˈlɪpɪd/', 'A diverse group of hydrophobic molecules.', 'Nhóm phân tử đa dạng có tính kị nước.', 'Lipids store energy for a long time.'],
    ['phospholipid', 'phospholipid', '/ˌfɒsfəʊˈlɪpɪd/', 'A lipid with a hydrophilic head and two hydrophobic tails.', 'Lipid có đầu ưa nước và hai đuôi kị nước.', 'Phospholipids form the cell membrane.'],
    ['amino acid', 'amino acid', '/əˌmiːnəʊ ˈæsɪd/', 'The monomer of proteins.', 'Đơn phân cấu tạo protein.', 'There are 20 kinds of amino acids in proteins.'],
    ['peptide bond', 'liên kết peptide', '/ˈpeptaɪd bɒnd/', 'The bond joining two amino acids.', 'Liên kết nối hai amino acid.', 'Peptide bonds form a polypeptide chain.'],
    ['denaturation', 'sự biến tính', '/diːˌneɪtʃəˈreɪʃn/', 'Loss of a protein’s 3D shape and function.', 'Protein mất cấu trúc không gian và chức năng.', 'Boiling causes denaturation of egg proteins.'],
    ['nucleotide', 'nucleotide', '/ˈnjuːkliətaɪd/', 'The monomer of nucleic acids: phosphate, sugar and base.', 'Đơn phân của nucleic acid: phosphate, đường, base.', 'DNA has four kinds of nucleotides.'],
    ['double helix', 'xoắn kép', '/ˈdʌbl ˈhiːlɪks/', 'The twisted two-strand shape of DNA.', 'Cấu trúc hai mạch xoắn của DNA.', 'Watson and Crick described the double helix in 1953.'],
    ['complementary base pairing', 'nguyên tắc bổ sung', '/ˌkɒmplɪˈmentri beɪs ˈpeərɪŋ/', 'A pairs with T, and G pairs with C.', 'A liên kết với T, G liên kết với C.', 'Complementary base pairing keeps DNA copies accurate.'],
  ],
};
