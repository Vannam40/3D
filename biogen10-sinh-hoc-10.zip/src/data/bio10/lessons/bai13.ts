import { LessonPack } from '../types';

export const bai13: LessonPack = {
  id: 'bai13_chuyen_hoa_nang_luong',
  lesson: 13,
  chapter: 'chuong4',
  titleVi: 'Bài 13. Khái quát về chuyển hoá vật chất và năng lượng',
  titleEn: 'Overview of Metabolism and Energy',
  pages: 'SGK tr. 78–84',
  modelId: 'm13_atp_enzyme',
  descriptionVi: 'Các dạng năng lượng trong tế bào; cấu tạo và chức năng của ATP; chuyển hoá vật chất và năng lượng; enzyme: khái niệm, cấu trúc, cơ chế, vai trò, các yếu tố ảnh hưởng, điều hoà chuyển hoá.',
  minutes: 35,
  objectives: [
    'Phân biệt được các dạng năng lượng trong chuyển hoá năng lượng ở tế bào; giải thích năng lượng tích luỹ và sử dụng là dạng hoá năng.',
    'Phân tích được cấu tạo và chức năng của ATP; trình bày quá trình tổng hợp và phân giải ATP gắn với tích luỹ, giải phóng năng lượng.',
    'Phát biểu được khái niệm chuyển hoá năng lượng trong tế bào.',
    'Nêu được khái niệm, cấu trúc, cơ chế tác động và vai trò của enzyme; phân tích các yếu tố ảnh hưởng đến hoạt tính enzyme.',
  ],
  keyConcepts: ['Động năng & thế năng', 'ATP – "đồng tiền" năng lượng', 'Đồng hoá & dị hoá', 'Enzyme & trung tâm hoạt động', 'Năng lượng hoạt hoá', 'Ức chế ngược'],
  sections: [
    {
      heading: 'I. Khái quát về năng lượng và sự chuyển hoá',
      paragraphs: ['Năng lượng là khả năng sinh công hay khả năng tạo nên sự chuyển động của vật chất. Trong tế bào, năng lượng tồn tại ở hai dạng: động năng và thế năng.'],
      bulletPoints: [
        'Động năng: nhiệt năng (nhiệt độ cơ thể), cơ năng (co cơ), điện năng (xung thần kinh, chuỗi truyền electron).',
        'Thế năng: năng lượng trong liên kết hoá học (hoá năng), chênh lệch điện thế và nồng độ giữa trong và ngoài tế bào.',
      ],
    },
    {
      heading: 'ATP – "đồng tiền" năng lượng của tế bào',
      paragraphs: [
        'ATP (adenosine triphosphate) gồm adenine, đường ribose và 3 gốc phosphate, với hai liên kết phosphate giàu năng lượng. ATP hoạt động như viên pin sạc: liên tục được sinh ra và ngay lập tức được sử dụng.',
        'Phá vỡ liên kết ngoài cùng: ATP → ADP + năng lượng; đôi khi phá vỡ cả hai liên kết cao năng: ATP → AMP, giải phóng năng lượng gấp đôi.',
      ],
    },
    {
      heading: 'Chuyển hoá vật chất và năng lượng',
      paragraphs: [
        'Chuyển hoá vật chất: tập hợp các phản ứng hoá học chuyển chất này thành chất khác. Chuyển hoá năng lượng: chuyển đổi năng lượng từ dạng này sang dạng khác, tuân theo quy luật nhiệt động học; luôn đi kèm chuyển hoá vật chất.',
        'Tổng hợp (đồng hoá) cần tiêu tốn năng lượng; phân giải (dị hoá) giải phóng năng lượng. Hầu hết phản ứng là oxy hoá khử, cần enzyme xúc tác.',
      ],
    },
    {
      heading: 'II. Enzyme',
      paragraphs: [
        'Enzyme là chất xúc tác sinh học được tổng hợp trong tế bào sống, làm tăng tốc độ phản ứng ở điều kiện sinh lí bình thường nhưng không bị biến đổi sau phản ứng. Một số RNA có khả năng xúc tác gọi là ribozyme.',
        'Đa số enzyme là protein; nhiều enzyme có thêm cofactor (ion kim loại Fe²⁺, Mg²⁺, Cu²⁺ hoặc phân tử hữu cơ: heme, biotin, FAD, NAD, vitamin).',
        'Trung tâm hoạt động liên kết đặc hiệu với cơ chất; cơ chế 3 giai đoạn: (1) enzyme kết hợp cơ chất → (2) xúc tác phản ứng → (3) sản phẩm tách khỏi enzyme. → Tính đặc hiệu của enzyme.',
        'Vai trò: làm giảm năng lượng hoạt hoá, tăng tốc độ phản ứng lên nhiều lần.',
      ],
      bulletPoints: [
        'Nồng độ enzyme và cơ chất: tăng thì hiệu suất tăng đến ngưỡng rồi dừng.',
        'pH: mỗi enzyme có khoảng pH phù hợp (pepsin, trypsin, arginase khác nhau).',
        'Nhiệt độ: hoạt động hiệu quả trong khoảng nhất định; ngoài khoảng đó hoạt tính giảm hoặc mất.',
        'Chất điều hoà: chất hoạt hoá làm tăng hoạt tính; chất ức chế cạnh tranh trung tâm hoạt động hoặc liên kết vị trí khác làm biến đổi trung tâm hoạt động.',
      ],
      highlightBox: 'Ức chế ngược: sản phẩm cuối cùng khi đã đủ nhu cầu quay lại ức chế enzyme đầu chuỗi chuyển hoá. Enzyme được định vị trong bào quan phù hợp (VD: lysosome bơm H⁺ giảm pH để hoạt hoá enzyme).',
    },
  ],
  core: [
    'Hoá năng là dạng năng lượng chính được tích luỹ và sử dụng cho hoạt động sống của tế bào.',
    'ATP gồm adenine, ribose và ba gốc phosphate; dự trữ năng lượng ngắn hạn, cung cấp ngay khi cần.',
    'Enzyme làm giảm năng lượng hoạt hoá; có trung tâm hoạt động đặc hiệu; hoạt tính chịu ảnh hưởng của nhiệt độ, pH, nồng độ cơ chất, enzyme và chất điều hoà.',
  ],
  mcq: [
    ['Dạng năng lượng chính được tích luỹ và sử dụng cho hoạt động sống của tế bào là', ['nhiệt năng', 'cơ năng', 'hoá năng', 'điện năng'], 2, 'Kiến thức cốt lõi: hoá năng là dạng năng lượng chính.'],
    ['Phân tử ATP được cấu tạo từ', ['adenine, đường deoxyribose và 3 gốc phosphate', 'adenine, đường ribose và 3 gốc phosphate', 'guanine, đường ribose và 2 gốc phosphate', 'adenine, glucose và 3 gốc phosphate'], 1, 'ATP: adenine + ribose + 3 gốc phosphate.'],
    ['Khi liên kết phosphate ngoài cùng bị phá vỡ, ATP chuyển thành', ['AMP', 'ADP', 'cAMP', 'adenine'], 1, 'ATP → ADP + năng lượng.'],
    ['Các phản ứng tổng hợp chất trong tế bào được gọi là', ['dị hoá', 'đồng hoá', 'oxy hoá', 'biến tính'], 1, 'Tổng hợp = đồng hoá, cần năng lượng; phân giải = dị hoá, giải phóng năng lượng.'],
    ['Vùng cấu trúc không gian đặc biệt của enzyme liên kết đặc hiệu với cơ chất là', ['cofactor', 'trung tâm hoạt động', 'vị trí điều hoà', 'nhóm R'], 1, 'Trung tâm hoạt động.'],
    ['Enzyme làm tăng tốc độ phản ứng bằng cách', ['tăng nhiệt độ của tế bào', 'làm giảm năng lượng hoạt hoá', 'tăng nồng độ cơ chất', 'bị tiêu hao trong phản ứng'], 1, 'Enzyme làm giảm năng lượng hoạt hoá cần thiết cho phản ứng.'],
    ['Phân tử RNA có khả năng xúc tác được gọi là', ['ribosome', 'ribozyme', 'cofactor', 'coenzyme'], 1, 'Ribozyme.'],
    ['Hiện tượng sản phẩm cuối của chuỗi chuyển hoá quay lại ức chế enzyme đầu chuỗi gọi là', ['ức chế cạnh tranh', 'ức chế ngược', 'hoạt hoá enzyme', 'biến tính enzyme'], 1, 'Ức chế ngược giúp dừng tổng hợp sản phẩm khi đã đủ nhu cầu.'],
    ['Khi tăng nhiệt độ quá cao so với nhiệt độ tối ưu, hoạt tính enzyme', ['tăng mãi', 'giảm, thậm chí mất hẳn', 'không đổi', 'tăng gấp đôi'], 1, 'Ngoài khoảng nhiệt độ phù hợp, hoạt tính giảm hoặc mất hoàn toàn (enzyme là protein bị biến tính).'],
  ],
  tf: [
    ['ATP liên tục được tổng hợp, vận chuyển và sử dụng trong tế bào sống.', true, 'Đúng – phương án đúng trong câu hỏi luyện tập của SGK.'],
    ['Mỗi phân tử ATP có ba liên kết cao năng.', false, 'Sai. ATP có hai liên kết phosphate giàu năng lượng.'],
    ['Enzyme bị biến đổi hoàn toàn sau phản ứng nên chỉ dùng được một lần.', false, 'Sai. Enzyme không bị biến đổi sau phản ứng, trở lại hình dạng ban đầu.'],
    ['Chất ức chế có thể cạnh tranh với cơ chất để liên kết với trung tâm hoạt động.', true, 'Đúng theo SGK.'],
    ['Enzyme trong lysosome được hoạt hoá khi bơm H⁺ vào làm giảm pH.', true, 'Đúng theo SGK.'],
  ],
  terms: [
    ['kinetic energy', 'động năng', '/kɪˈnetɪk ˈenədʒi/', 'Energy that moves objects or changes their state.', 'Năng lượng làm vật di chuyển hay thay đổi trạng thái.', 'Muscle contraction uses kinetic energy.'],
    ['potential energy', 'thế năng', '/pəˈtenʃl ˈenədʒi/', 'Stored energy, e.g. in chemical bonds.', 'Năng lượng dự trữ, VD trong liên kết hoá học.', 'Glucose stores potential energy.'],
    ['ATP', 'ATP (adenosine triphosphate)', '/ˌeɪ tiː ˈpiː/', 'The energy currency of the cell: adenine, ribose and three phosphates.', '"Đồng tiền" năng lượng: adenine, ribose và 3 phosphate.', 'Cells use ATP for active transport.'],
    ['metabolism', 'chuyển hoá', '/məˈtæbəlɪzəm/', 'All chemical reactions that change substances in the cell.', 'Tập hợp phản ứng biến đổi chất trong tế bào.', 'Enzymes speed up metabolism.'],
    ['anabolism', 'đồng hoá', '/əˈnæbəlɪzəm/', 'Building complex molecules; uses energy.', 'Tổng hợp chất phức tạp; cần năng lượng.', 'Protein synthesis is anabolism.'],
    ['catabolism', 'dị hoá', '/kəˈtæbəlɪzəm/', 'Breaking down molecules; releases energy.', 'Phân giải chất; giải phóng năng lượng.', 'Cellular respiration is catabolism.'],
    ['enzyme', 'enzyme', '/ˈenzaɪm/', 'A biological catalyst made in living cells.', 'Chất xúc tác sinh học tổng hợp trong tế bào sống.', 'Amylase is an enzyme that breaks down starch.'],
    ['substrate', 'cơ chất', '/ˈsʌbstreɪt/', 'The substance an enzyme acts on.', 'Chất chịu tác động của enzyme.', 'Starch is the substrate of amylase.'],
    ['active site', 'trung tâm hoạt động', '/ˈæktɪv saɪt/', 'The region of an enzyme that binds the substrate.', 'Vùng của enzyme liên kết với cơ chất.', 'The substrate fits into the active site.'],
    ['activation energy', 'năng lượng hoạt hoá', '/ˌæktɪˈveɪʃn ˈenədʒi/', 'The energy needed to start a reaction.', 'Năng lượng cần để khởi động phản ứng.', 'Enzymes lower the activation energy.'],
    ['cofactor', 'cofactor (đồng yếu tố)', '/ˈkəʊfæktə/', 'A metal ion or organic molecule an enzyme needs.', 'Ion kim loại hoặc phân tử hữu cơ enzyme cần.', 'Mg²⁺ acts as a cofactor for many enzymes.'],
    ['feedback inhibition', 'ức chế ngược', '/ˈfiːdbæk ˌɪnhɪˈbɪʃn/', 'The end product inhibits the first enzyme of the pathway.', 'Sản phẩm cuối ức chế enzyme đầu chuỗi.', 'Feedback inhibition stops overproduction.'],
  ],
};
