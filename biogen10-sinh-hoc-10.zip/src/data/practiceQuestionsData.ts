export interface MultipleChoiceQuestion {
  id: string;
  type: 'multiple_choice';
  question: string;
  options: string[]; // exactly 4 options (A, B, C, D)
  correctAnswer: number; // 0 for A, 1 for B, 2 for C, 3 for D
  explanation: string;
}

export interface TrueFalseQuestion {
  id: string;
  type: 'true_false';
  question: string;
  correctAnswer: boolean; // true = Đúng, false = Sai
  explanation: string;
}

export type PracticeQuestion = MultipleChoiceQuestion | TrueFalseQuestion;

export interface TopicQuestionBank {
  topicId: string;
  multipleChoice: MultipleChoiceQuestion[];
  trueFalse: TrueFalseQuestion[];
}

import { LESSONS } from './bio10';

/** Ngân hàng câu hỏi mặc định – soạn bám sát SGK Sinh học 10 (KNTT), mỗi bài một ngân hàng */
export const TOPIC_QUESTION_BANKS: Record<string, TopicQuestionBank> = Object.fromEntries(
  LESSONS.map(l => [
    l.id,
    {
      topicId: l.id,
      multipleChoice: l.mcq.map(([question, opts, correct, explanation], i) => ({
        id: `${l.id}_mc_${i + 1}`,
        type: 'multiple_choice' as const,
        question,
        options: opts.map((o, k) => `${'ABCD'[k]}. ${o}`),
        correctAnswer: correct,
        explanation: `${explanation} (${l.pages})`,
      })),
      trueFalse: l.tf.map(([question, correct, explanation], i) => ({
        id: `${l.id}_tf_${i + 1}`,
        type: 'true_false' as const,
        question,
        correctAnswer: correct,
        explanation: `${explanation} (${l.pages})`,
      })),
    },
  ])
);

// Helper function to get randomly sampled questions: strictly 7 MCQs + 3 True/False = 10 questions
export const getRandomizedPracticeQuestionsForTopic = (topicId: string): PracticeQuestion[] => {
  const bank = TOPIC_QUESTION_BANKS[topicId] || Object.values(TOPIC_QUESTION_BANKS)[0];

  // Shuffle multiple choice questions and select exactly 7
  const shuffledMcq = [...bank.multipleChoice].sort(() => 0.5 - Math.random());
  const selectedMcq = shuffledMcq.slice(0, 7);

  // Shuffle true/false questions and select exactly 3
  const shuffledTf = [...bank.trueFalse].sort(() => 0.5 - Math.random());
  const selectedTf = shuffledTf.slice(0, 3);

  return [...selectedMcq, ...selectedTf];
};

// Keep backward compatibility
export const getPracticeQuestionsForTopic = (topicId: string): PracticeQuestion[] => {
  return getRandomizedPracticeQuestionsForTopic(topicId);
};
