import { useState, useEffect } from 'react';
import { GeneticsTopic } from '../types/genetics';
export type { GeneticsTopic };

import { LESSONS, shortTitle } from './bio10';

/**
 * 19 chủ đề = 19 bài lý thuyết của SGK Sinh học 10 – Kết nối tri thức với cuộc sống.
 * Dữ liệu sinh tự động từ src/data/bio10/lessons/*.ts
 */
export const DEFAULT_GENETICS_TOPICS: GeneticsTopic[] = LESSONS.map((l, idx) => ({
  id: l.id,
  order: idx + 1,
  module: l.chapter,
  titleVi: l.titleVi,
  titleEn: l.titleEn,
  slug: l.id.replace(/_/g, '-'),
  descriptionVi: l.descriptionVi,
  keyConcepts: l.keyConcepts,
  interactiveType: l.modelId,
  xpReward: l.isPractice ? 120 : 150,
  estimatedMinutes: l.minutes || (l.isPractice ? 25 : 30),
  lesson: l.lesson,
  pages: l.pages,
  isPractice: !!l.isPractice,
  prerequisiteId: idx > 0 ? LESSONS[idx - 1].id : undefined,
}));

/** Tên ngắn của chủ đề (bỏ tiền tố "Bài n.") */
export function topicShortTitle(t: { titleVi: string }): string {
  return shortTitle(t.titleVi);
}

/**
 * Storage key version for Sinh học 10 curriculum topics
 */
const LOCAL_STORAGE_TOPICS_KEY = 'biogen10_curriculum_topics_19_v1';

/**
 * Các ID tương đương (giữ API cũ). Với Sinh học 10 mỗi bài có một ID duy nhất.
 */
export function getEquivalentTopicIds(topicId: string): string[] {
  return [topicId];
}

function loadStoredTopics(): GeneticsTopic[] {
  try {

    const raw = typeof localStorage !== 'undefined' ? localStorage.getItem(LOCAL_STORAGE_TOPICS_KEY) : null;
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0 && parsed.every((t: GeneticsTopic) => typeof t?.id === 'string')) {
        return parsed;
      }
    }
  } catch (e) {
    console.warn('Failed to load stored topics, using default topics:', e);
  }
  return DEFAULT_GENETICS_TOPICS;
}

// Active array exported and kept updated in place
export const GENETICS_TOPICS: GeneticsTopic[] = [...loadStoredTopics()];

/**
 * Returns current topics
 */
export function getGeneticsTopics(): GeneticsTopic[] {
  return [...GENETICS_TOPICS];
}

/**
 * Saves and emits topic update event
 */
export function saveGeneticsTopics(newTopics: GeneticsTopic[]): void {
  GENETICS_TOPICS.splice(0, GENETICS_TOPICS.length, ...newTopics);
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(LOCAL_STORAGE_TOPICS_KEY, JSON.stringify(newTopics));
    }
  } catch (e) {
    console.warn('Failed to persist topics:', e);
  }
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('biogen10_topics_changed', { detail: newTopics }));
  }
}

/**
 * Update an existing topic by ID
 */
export function updateGeneticsTopic(id: string, updates: Partial<GeneticsTopic>): boolean {
  const current = getGeneticsTopics();
  const idx = current.findIndex(t => t.id === id);
  if (idx === -1) return false;
  current[idx] = { ...current[idx], ...updates };
  saveGeneticsTopics(current);
  return true;
}

/**
 * Delete a topic by ID
 */
export function deleteGeneticsTopic(id: string): boolean {
  const current = getGeneticsTopics();
  const filtered = current.filter(t => t.id !== id);
  if (filtered.length === current.length) return false;
  // Re-number order
  const reordered = filtered.map((t, index) => ({
    ...t,
    order: index + 1,
  }));
  saveGeneticsTopics(reordered);
  return true;
}

/**
 * Add a new topic
 */
export function addGeneticsTopic(topic: GeneticsTopic): boolean {
  const current = getGeneticsTopics();
  if (current.some(t => t.id === topic.id)) return false;
  const newOrder = topic.order || current.length + 1;
  const newTopic: GeneticsTopic = {
    ...topic,
    order: newOrder,
  };
  saveGeneticsTopics([...current, newTopic]);
  return true;
}

/**
 * Reset topics to the 19 default lessons
 */
export function resetGeneticsTopicsToDefault(): void {
  saveGeneticsTopics(DEFAULT_GENETICS_TOPICS);
}

/**
 * React Hook for dynamic topic updates across all pages
 */
export function useGeneticsTopics() {
  const [topics, setTopics] = useState<GeneticsTopic[]>(() => getGeneticsTopics());

  useEffect(() => {
    const handler = () => {
      setTopics(getGeneticsTopics());
    };
    window.addEventListener('biogen10_topics_changed', handler);
    window.addEventListener('storage', handler);
    return () => {
      window.removeEventListener('biogen10_topics_changed', handler);
      window.removeEventListener('storage', handler);
    };
  }, []);

  return {
    topics,
    updateTopic: updateGeneticsTopic,
    deleteTopic: deleteGeneticsTopic,
    addTopic: addGeneticsTopic,
    resetToDefault: resetGeneticsTopicsToDefault,
    saveTopics: saveGeneticsTopics,
  };
}
