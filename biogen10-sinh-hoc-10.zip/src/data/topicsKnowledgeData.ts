export interface TopicKnowledgeContent {
  topicId: string;
  sections: {
    heading: string;
    paragraphs?: string[];
    bulletPoints?: string[];
    formulaBox?: {
      title: string;
      formulas: string[];
    };
    highlightBox?: string;
  }[];
}

import { LESSONS, buildKnowledgeSections } from './bio10';

/** Kiến thức chuẩn SGK Sinh học 10 (KNTT) cho 19 bài lý thuyết */
export const TOPICS_KNOWLEDGE_BASE: Record<string, TopicKnowledgeContent> = Object.fromEntries(
  LESSONS.map(l => [l.id, { topicId: l.id, sections: buildKnowledgeSections(l) }])
);
