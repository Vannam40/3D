import { Assignment } from '../types/assignment';

/** Không có phiếu học tập mẫu: giáo viên tạo phiếu mới cho các bài Sinh học 10. */
export const INITIAL_MOCK_ASSIGNMENTS: Assignment[] = [];
