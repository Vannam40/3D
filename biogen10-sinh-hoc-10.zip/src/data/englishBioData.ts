import { EnglishTerm } from '../types/englishBio';
import { LESSONS } from './bio10';

/**
 * Từ vựng English Biology – Sinh học 10 (KNTT).
 * Thuật ngữ và câu định nghĩa tiếng Anh là bản dịch tương ứng nội dung SGK.
 */
export const ENGLISH_BIO_TERMS: EnglishTerm[] = LESSONS.flatMap(l =>
  l.terms.map(([en, vi, ipa, defEn, defVi, example], i) => ({
    id: `${l.id}_term_${i + 1}`,
    topicId: l.id,
    englishTerm: en,
    vietnameseMeaning: vi,
    pronunciation: ipa,
    definition: defEn,
    definitionVi: defVi,
    functionDesc: defVi,
    exampleSentence: example,
    relatedTerms: l.terms.filter((_, k) => k !== i).slice(0, 3).map(t => t[0]),
    category: l.chapter,
  }))
);
