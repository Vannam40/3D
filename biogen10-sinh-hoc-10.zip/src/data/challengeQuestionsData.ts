export interface SoloQuestionMCQ {
  id: string;
  type: 'multiple_choice';
  questionNumber: number;
  question: string;
  options: { id: 'A' | 'B' | 'C' | 'D'; text: string }[];
  correctAnswer: 'A' | 'B' | 'C' | 'D';
  explanation: string;
  topicTitle: string;
}

export interface SoloQuestionTF {
  id: string;
  type: 'true_false';
  questionNumber: number;
  question: string;
  correctAnswer: boolean; // true = Đúng, false = Sai
  explanation: string;
  topicTitle: string;
}

export type SoloChallengeQuestion = SoloQuestionMCQ | SoloQuestionTF;

import { LESSONS, shortTitle } from './bio10';

/**
 * Câu hỏi đấu trường lấy từ ngân hàng câu hỏi của 19 bài lý thuyết SGK Sinh học 10 (KNTT).
 * Mỗi lần tải trang, Thử thách đơn chọn ngẫu nhiên 15 câu (10 câu 4 đáp án + 5 câu Đúng/Sai) từ các bài khác nhau.
 */
const LETTERS = ['A', 'B', 'C', 'D'] as const;

function shuffled<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

const ALL_MCQ = LESSONS.flatMap(l =>
  l.mcq.map((q, i) => ({ lesson: l, q, i }))
);
const ALL_TF = LESSONS.flatMap(l => l.tf.map((q, i) => ({ lesson: l, q, i })));

/** Chọn n câu, ưu tiên mỗi bài một câu trước khi lặp lại bài */
function spreadPick<T extends { lesson: { id: string } }>(items: T[], n: number): T[] {
  const byLesson = new Map<string, T[]>();
  shuffled(items).forEach(it => {
    const k = it.lesson.id;
    if (!byLesson.has(k)) byLesson.set(k, []);
    byLesson.get(k)!.push(it);
  });
  const out: T[] = [];
  const lists = shuffled([...byLesson.values()]);
  while (out.length < n && lists.some(l => l.length)) {
    for (const l of lists) {
      if (out.length >= n) break;
      const it = l.shift();
      if (it) out.push(it);
    }
  }
  return out;
}

export function buildSoloChallenge(): SoloChallengeQuestion[] {
  const mcqs: SoloChallengeQuestion[] = spreadPick(ALL_MCQ, 10).map(({ lesson, q, i }, k) => ({
    id: `solo_${lesson.id}_mc_${i + 1}`,
    type: 'multiple_choice',
    questionNumber: k + 1,
    topicTitle: `Bài ${lesson.lesson}. ${shortTitle(lesson.titleVi)}`,
    question: q[0],
    options: q[1].map((text, o) => ({ id: LETTERS[o], text })),
    correctAnswer: LETTERS[q[2]],
    explanation: `${q[3]} (${lesson.pages})`,
  }));
  const tfs: SoloChallengeQuestion[] = spreadPick(ALL_TF, 5).map(({ lesson, q, i }, k) => ({
    id: `solo_${lesson.id}_tf_${i + 1}`,
    type: 'true_false',
    questionNumber: 11 + k,
    topicTitle: `Bài ${lesson.lesson}. ${shortTitle(lesson.titleVi)}`,
    question: q[0],
    correctAnswer: q[1],
    explanation: `${q[2]} (${lesson.pages})`,
  }));
  return [...mcqs, ...tfs];
}

// PHẦN THỬ THÁCH ĐƠN: ĐÚNG 15 CÂU HỎI (10 CÂU 4 ĐÁP ÁN + 5 CÂU ĐÚNG SAI)
export const SOLO_CHALLENGE_QUESTIONS: SoloChallengeQuestion[] = buildSoloChallenge();

// --- KHO CÂU HỎI ĐẤU TRƯỜNG THỜI GIAN THỰC (RANDOM BATTLE QUESTION POOL) ---
export interface BattlePoolQuestion {
  id: string;
  topic: string;
  question: string;
  options: { id: 'A' | 'B' | 'C' | 'D'; text: string }[];
  correct: 'A' | 'B' | 'C' | 'D';
  explanation: string;
}

export const BATTLE_QUESTIONS_POOL: BattlePoolQuestion[] = ALL_MCQ.map(({ lesson, q, i }) => ({
  id: `bp_${lesson.id}_${i + 1}`,
  topic: `Bài ${lesson.lesson}. ${shortTitle(lesson.titleVi)}`,
  question: q[0],
  options: q[1].map((text, o) => ({ id: LETTERS[o], text })),
  correct: LETTERS[q[2]],
  explanation: `${q[3]} (${lesson.pages})`,
}));
