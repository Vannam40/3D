import { LESSONS } from './bio10';
import { ClassRoom, UserProfile, UserAccountCredential } from '../types/auth';
import { Badge, Challenge } from '../types/gamification';
import { QuestionItem } from '../types/question';
import { StudentTopicProgress } from '../types/genetics';
import { createFreshProgress } from './progressUtils';

export const DEMO_TEACHER: UserProfile = {
  uid: '',
  username: '',
  fullName: '',
  role: 'teacher',
  classIds: [],
  xp: 0,
  level: 1,
  streakDays: 0,
  badges: [],
  createdAt: new Date().toISOString(),
};

export const DEMO_STUDENT: UserProfile = {
  uid: 'student_demo_1',
  studentCode: 'HS-900001',
  email: 'nguyen.minhanh@student.edu.vn',
  username: 'minhanh9a1',
  fullName: 'Nguyễn Minh Anh',
  role: 'student',
  classIds: ['class_9a1'],
  currentClassId: 'class_9a1',
  initialPassword: '123456',
  xp: 0,
  level: 1,
  streakDays: 0,
  badges: [],
  createdAt: '2026-09-05T09:00:00.000Z',
};

export const DEMO_ADMIN: UserProfile = {
  uid: 'admin_root',
  username: 'admin',
  fullName: 'Quản trị viên Hệ thống',
  email: 'admin@biogen10.edu.vn',
  role: 'admin',
  classIds: [],
  xp: 9999,
  level: 99,
  streakDays: 30,
  badges: ['badge_dna_explorer', 'badge_gene_explorer', 'badge_rna_master'],
  createdAt: '2026-09-01T00:00:00.000Z',
};

export const INITIAL_ACCOUNTS: UserAccountCredential[] = [
  {
    uid: 'admin_root',
    username: 'admin',
    password: 'admin',
    fullName: 'Quản trị viên Hệ thống',
    email: 'admin@biogen10.edu.vn',
    role: 'admin',
    classIds: [],
    xp: 9999,
    level: 99,
    streakDays: 30,
    badges: ['badge_dna_explorer', 'badge_gene_explorer', 'badge_rna_master'],
    createdAt: '2026-09-01T00:00:00.000Z',
  },
  {
    uid: 'student_demo_1',
    studentCode: 'HS-900001',
    email: 'nguyen.minhanh@student.edu.vn',
    username: 'minhanh9a1',
    password: '123456',
    fullName: 'Nguyễn Minh Anh',
    role: 'student',
    classIds: ['class_9a1'],
    currentClassId: 'class_9a1',
    initialPassword: '123456',
    xp: 0,
    level: 1,
    streakDays: 0,
    badges: [],
    createdAt: '2026-09-05T09:00:00.000Z',
  },
  {
    uid: 'student_demo_2',
    studentCode: 'HS-900002',
    email: 'nam.tb@student.edu.vn',
    username: 'nam.tb.9a1',
    password: 'Bio@1024',
    fullName: 'Trần Bảo Nam',
    role: 'student',
    classIds: ['class_9a1'],
    currentClassId: 'class_9a1',
    initialPassword: 'Bio@1024',
    xp: 120,
    level: 1,
    streakDays: 1,
    badges: [],
    createdAt: '2026-09-06T09:00:00.000Z',
  },
  {
    uid: 'student_demo_3',
    studentCode: 'HS-900003',
    email: 'trang.lt@student.edu.vn',
    username: 'trang.lt.9a1',
    password: 'Bio@2048',
    fullName: 'Lê Thu Trang',
    role: 'student',
    classIds: ['class_9a1'],
    currentClassId: 'class_9a1',
    initialPassword: 'Bio@2048',
    xp: 250,
    level: 1,
    streakDays: 2,
    badges: ['badge_dna_explorer'],
    createdAt: '2026-09-06T09:10:00.000Z',
  },
  {
    uid: 'student_demo_4',
    studentCode: 'HS-900004',
    email: 'bao.hg@student.edu.vn',
    username: 'bao.hg.9a2',
    password: 'Bio@4096',
    fullName: 'Hoàng Gia Bảo',
    role: 'student',
    classIds: ['class_9a2'],
    currentClassId: 'class_9a2',
    initialPassword: 'Bio@4096',
    xp: 80,
    level: 1,
    streakDays: 1,
    badges: [],
    createdAt: '2026-09-07T08:00:00.000Z',
  },
  {
    uid: 'student_demo_5',
    studentCode: 'HS-900005',
    email: 'linh.pt@student.edu.vn',
    username: 'linh.pt.9a2',
    password: 'Bio@8192',
    fullName: 'Phạm Thùy Linh',
    role: 'student',
    classIds: ['class_9a2'],
    currentClassId: 'class_9a2',
    initialPassword: 'Bio@8192',
    xp: 310,
    level: 1,
    streakDays: 3,
    badges: ['badge_dna_explorer'],
    createdAt: '2026-09-07T08:15:00.000Z',
  },
];


export const DEMO_CLASSES: ClassRoom[] = [];

export const DEMO_BADGES: Badge[] = [
  { id: 'badge_dna_explorer', name: 'Biology Starter', titleVi: 'Nhà Sinh Học Nhập Môn', descriptionVi: 'Hoàn thành các bài Phần mở đầu (Bài 1–3).', icon: 'Dna', criteria: 'Hoàn thành Bài 1, 2, 3' },
  { id: 'badge_gene_explorer', name: 'Biomolecule Explorer', titleVi: 'Chuyên Gia Phân Tử Sinh Học', descriptionVi: 'Hoàn thành Chương 1: Thành phần hoá học của tế bào.', icon: 'Atom', criteria: 'Hoàn thành Bài 4, 5' },
  { id: 'badge_rna_master', name: 'Cell Architect', titleVi: 'Kiến Trúc Sư Tế Bào', descriptionVi: 'Hoàn thành Chương 2: Cấu trúc tế bào.', icon: 'FileCode2', criteria: 'Hoàn thành Bài 7, 8' },
  { id: 'badge_protein_master', name: 'Energy Master', titleVi: 'Bậc Thầy Năng Lượng', descriptionVi: 'Hoàn thành Chương 3 và Chương 4: trao đổi chất qua màng, truyền tin, chuyển hoá năng lượng.', icon: 'Boxes', criteria: 'Hoàn thành Bài 10, 12, 13, 14' },
  { id: 'badge_mitosis_explorer', name: 'Cell Division Explorer', titleVi: 'Nhà Khám Phá Phân Bào', descriptionVi: 'Hoàn thành Chương 5: Chu kì tế bào, nguyên phân, giảm phân, công nghệ tế bào.', icon: 'CircleDot', criteria: 'Hoàn thành Bài 16, 17, 19' },
  { id: 'badge_microbe_hunter', name: 'Microbe & Virus Hunter', titleVi: 'Thợ Săn Vi Sinh Vật', descriptionVi: 'Hoàn thành Phần hai: Sinh học vi sinh vật và virus.', icon: 'Bug', criteria: 'Hoàn thành Bài 20, 21, 22, 24, 25' },
  { id: 'badge_english_star', name: 'English Biology Star', titleVi: 'Ngôi Sao English Biology', descriptionVi: 'Đạt điểm tuyệt đối trong mini-game thuật ngữ Sinh học tiếng Anh.', icon: 'Sparkles', criteria: 'Hoàn thành 50 thuật ngữ tiếng Anh' },
  { id: 'badge_genetics_challenger', name: 'Biology Challenger', titleVi: 'Đấu Sĩ Sinh Học', descriptionVi: 'Vượt qua 5 bài thử thách tốc độ trong thời gian dưới 60 giây.', icon: 'Trophy', criteria: 'Đạt Top 3 trong Live Battle' },
];

// All topics default to clean 0% progress for new and unstudied users
export const DEMO_PROGRESS: Record<string, StudentTopicProgress> = createFreshProgress();

/**
 * Ngân hàng câu hỏi khởi tạo cho giáo viên: toàn bộ câu trắc nghiệm của 19 bài SGK Sinh học 10 (KNTT),
 * để ở trạng thái BẢN NHÁP (draft) cho giáo viên duyệt. Lời giải có ghi trang SGK.
 */
export const DEMO_QUESTIONS: QuestionItem[] = LESSONS.flatMap(l =>
  l.mcq.map(([question, opts, correct, explanation], i) => ({
    id: `q_${l.id}_${i + 1}`,
    topicId: l.id,
    question,
    type: 'mcq' as const,
    options: opts.map((text, k) => ({ id: `opt_${k + 1}`, text })),
    correctAnswer: `opt_${correct + 1}`,
    explanation: `${explanation} (${l.pages})`,
    difficulty: (i < 4 ? 'easy' : i < 8 ? 'medium' : 'hard') as 'easy' | 'medium' | 'hard',
    language: 'vi' as const,
    createdBy: 'to_chuyen_mon',
    createdByName: 'Soạn theo SGK Sinh học 10',
    status: 'draft' as const,
    createdAt: '2026-11-09T00:00:00Z',
    updatedAt: '2026-11-09T00:00:00Z',
  }))
);

export const DEMO_CHALLENGES: Challenge[] = [
  {
    id: 'ch_dna_speed',
    title: 'Thử thách Tốc độ: Các phân tử sinh học',
    topicId: 'bai05_phan_tu_sinh_hoc',
    questionCount: 10,
    timeLimitSeconds: 60,
    difficulty: 'medium',
    xpReward: 150,
    createdBy: 'to_chuyen_mon',
    isActive: true,
  },
  {
    id: 'ch_mitosis_master',
    title: 'Đấu trường Nguyên phân & Giảm phân',
    topicId: 'bai16_chu_ki_nguyen_phan',
    questionCount: 12,
    timeLimitSeconds: 90,
    difficulty: 'hard',
    xpReward: 200,
    createdBy: 'to_chuyen_mon',
    isActive: true,
  },
];
