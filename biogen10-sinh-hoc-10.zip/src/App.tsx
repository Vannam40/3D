import React from 'react';
import { AuthProvider, useAuth } from './hooks/useAuth';
import { NavigationProvider, useNavigation } from './hooks/useNavigation';
import { MainLayout } from './layouts/MainLayout';
import { LandingPage } from './pages/LandingPage';
import { LoginPage } from './pages/LoginPage';
import { RegisterPage } from './pages/RegisterPage';
import { StudentDashboard } from './pages/student/StudentDashboard';
import { TeacherDashboard } from './pages/teacher/TeacherDashboard';
import { AdminDashboard } from './pages/admin/AdminDashboard';
import { KnowledgeMapPage } from './pages/topics/KnowledgeMapPage';
import { TopicDetailPage } from './pages/topics/TopicDetailPage';
import { EnglishBioPage } from './pages/english-bio/EnglishBioPage';
import { BioBotPage } from './pages/ai-tutor/BioBotPage';
import { ChallengesPage } from './pages/challenges/ChallengesPage';
import { StudentAssignmentsSection } from './pages/student/components/StudentAssignmentsSection';

const AppRouter: React.FC = () => {
  const { currentView } = useNavigation();
  const { role } = useAuth();

  const renderView = () => {
    switch (currentView) {
      case 'landing':
        return <LandingPage />;
      case 'login':
        return <LoginPage />;
      case 'register':
        return <RegisterPage />;
      case 'student_dashboard':
        return <StudentDashboard />;
      case 'teacher_dashboard':
        return <TeacherDashboard />;
      case 'admin_dashboard':
        return <AdminDashboard />;
      case 'knowledge_map':
        return <KnowledgeMapPage />;
      case 'topic_detail':
        return <TopicDetailPage />;
      case 'english_bio':
        return <EnglishBioPage />;
      case 'bio_bot':
        return <BioBotPage />;
      case 'challenges':
      case 'live_battle':
        return <ChallengesPage />;
      case 'student_assignments':
        return (
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
            <StudentAssignmentsSection />
          </div>
        );
      default:
        return <LandingPage />;
    }
  };

  // Các trang thiết kế giao diện tối được đặt trên nền tối riêng
  const DARK_VIEWS = ['bio_bot', 'english_bio', 'teacher_dashboard', 'student_dashboard', 'admin_dashboard'];
  const view = renderView();
  return (
    <MainLayout>
      {DARK_VIEWS.includes(currentView) ? <div className="bg-slate-950 min-h-[calc(100vh-4rem)]">{view}</div> : view}
    </MainLayout>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <NavigationProvider>
        <AppRouter />
      </NavigationProvider>
    </AuthProvider>
  );
}
