/**
 * Phát âm tiếng Anh bằng Web Speech API của trình duyệt (miễn phí, không cần mạng).
 * Giọng đọc phụ thuộc thiết bị; nếu trình duyệt không hỗ trợ thì không làm gì.
 */
export type VoiceGender = 'female' | 'male';

const FEMALE_HINTS = ['female', 'samantha', 'zira', 'victoria', 'google us english', 'karen', 'moira', 'jenny', 'ava', 'aria', 'libby'];
const MALE_HINTS = ['male', 'david', 'mark', 'guy', 'alex', 'daniel', 'oliver', 'fred', 'george', 'ryan', 'google uk english male'];

export function canSpeak(): boolean {
  return typeof window !== 'undefined' && 'speechSynthesis' in window;
}

export function speakEnglish(text: string, gender: VoiceGender = 'female', rate = 0.9): void {
  if (!canSpeak() || !text) return;
  try {
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = 'en-US';
    u.rate = rate;
    u.pitch = gender === 'female' ? 1.15 : 0.9;
    const voices = window.speechSynthesis.getVoices().filter(v => v.lang.toLowerCase().startsWith('en'));
    const hints = gender === 'female' ? FEMALE_HINTS : MALE_HINTS;
    const match = voices.find(v => hints.some(h => v.name.toLowerCase().includes(h)));
    if (match) u.voice = match;
    else if (voices[0]) u.voice = voices[0];
    window.speechSynthesis.speak(u);
  } catch {
    /* ignore */
  }
}

export function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
