/**
 * Tra cứu ngoại tuyến trong nội dung SGK Sinh học 10 (KNTT) đã soạn trong app.
 * Dùng cho Bio-Bot: chỉ trả lời bằng nội dung có sẵn trong bài học (kèm số trang), không tự sinh kiến thức mới.
 */
import { LESSONS, LessonPack, McqTuple, shortTitle } from '../data/bio10';

export interface SgkChunk {
  lesson: LessonPack;
  heading: string;
  lines: string[];
  tokens: Set<string>;
}

const STOP = new Set(
  'là và của các có cho được trong với những một này đó thì mà khi như để từ theo ra vào gì sao nào bao nhiêu không hay hoặc em bạn mình hãy giúp giải thích cho biết thế nào tại vì về the of and a an is are what how why in to'.split(' ')
);

export function normalize(s: string): string {
  return s
    .toLowerCase()
    .replace(/[₀-₉]/g, c => '0123456789'['₀₁₂₃₄₅₆₇₈₉'.indexOf(c)])
    .replace(/[^\p{L}\p{N}\s]/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/** Âm tiết + cặp âm tiết liền nhau (tiếng Việt ghép từ nhiều âm tiết) */
export function tokenize(s: string): Set<string> {
  const words = normalize(s).split(' ').filter(Boolean);
  const out = new Set<string>();
  words.forEach((w, i) => {
    if (!STOP.has(w) && w.length > 1) out.add(w);
    if (i < words.length - 1) out.add(`${w} ${words[i + 1]}`);
  });
  return out;
}

const CHUNKS: SgkChunk[] = LESSONS.flatMap(l => {
  const list: SgkChunk[] = l.sections.map(s => {
    const lines = [
      ...(s.paragraphs || []),
      ...(s.bulletPoints || []).map(b => `• ${b}`),
      ...(s.formulaBox?.formulas || []).map(f => `▸ ${f}`),
      ...(s.highlightBox ? [`💡 ${s.highlightBox}`] : []),
    ];
    return { lesson: l, heading: s.heading, lines, tokens: tokenize(`${l.titleVi} ${s.heading} ${lines.join(' ')}`) };
  });
  list.push({
    lesson: l,
    heading: 'Kiến thức cốt lõi',
    lines: l.core.map(c => `• ${c}`),
    tokens: tokenize(`${l.titleVi} ${l.keyConcepts.join(' ')} ${l.core.join(' ')}`),
  });
  return list;
});

/** IDF: từ càng hiếm trong SGK càng có trọng số cao */
const DF = new Map<string, number>();
CHUNKS.forEach(c => c.tokens.forEach(t => DF.set(t, (DF.get(t) || 0) + 1)));
const N = CHUNKS.length;
const idf = (tok: string) => Math.log(1 + N / (DF.get(tok) || N));

function score(q: Set<string>, t: Set<string>): number {
  let s = 0;
  q.forEach(tok => {
    if (t.has(tok)) s += idf(tok) * (tok.includes(' ') ? 2 : 1);
  });
  return s;
}

/** Thuật ngữ tiếng Anh: nếu câu hỏi chứa từ tiếng Anh trong bảng thuật ngữ, trả về bài chứa thuật ngữ đó */
function matchEnglishTerm(query: string) {
  const q = ` ${normalize(query)} `;
  for (const l of LESSONS) {
    for (const t of l.terms) {
      const en = normalize(t[0].replace(/\(.*?\)/g, ''));
      if (en.length > 2 && q.includes(` ${en} `)) return { lesson: l, term: t };
    }
  }
  return null;
}

export function searchSgk(query: string): { chunk: SgkChunk; score: number } | null {
  const q = tokenize(query);
  const en = matchEnglishTerm(query);
  if (en) {
    const vi = tokenize(en.term[1]);
    vi.forEach(v => q.add(v));
  }
  let best: { chunk: SgkChunk; score: number } | null = null;
  const bigrams = [...q].filter(t => t.includes(' '));
  for (const c of CHUNKS) {
    let s = score(q, c.tokens) + (en && c.lesson.id === en.lesson.id ? 2 : 0);
    // Ưu tiên đoạn có câu định nghĩa bắt đầu bằng cụm từ được hỏi, hoặc tiêu đề mục chứa cụm từ đó
    const starts = c.lines.map(l => normalize(l));
    const head = normalize(c.heading);
    bigrams.forEach(b => {
      if (starts.some(l => l.startsWith(b))) s += 2 * idf(b);
      if (head.includes(b)) s += idf(b);
    });
    if (!best || s > best.score) best = { chunk: c, score: s };
  }
  return best && best.score >= 6 ? best : null;
}

/** Thuật ngữ tiếng Anh liên quan tới đoạn kiến thức */
export function relatedTerms(chunk: SgkChunk, max = 4) {
  const text = normalize(chunk.lines.join(' ') + ' ' + chunk.heading);
  const hits = chunk.lesson.terms.filter(t => text.includes(normalize(t[1].replace(/\(.*?\)/g, ''))));
  return (hits.length ? hits : chunk.lesson.terms).slice(0, max);
}

/** Câu hỏi trắc nghiệm của bài gần với câu hỏi của học sinh nhất (dùng cho chế độ hướng dẫn tư duy) */
export function pickGuideQuestion(lesson: LessonPack, query: string): McqTuple {
  const q = tokenize(query);
  let best = lesson.mcq[0];
  let bestScore = -1;
  lesson.mcq.forEach(m => {
    const s = score(q, tokenize(`${m[0]} ${m[1].join(' ')}`));
    if (s > bestScore) {
      best = m;
      bestScore = s;
    }
  });
  return best;
}

export function lessonLabel(l: LessonPack): string {
  return `Bài ${l.lesson}. ${shortTitle(l.titleVi)}`;
}
