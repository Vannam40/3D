export type AssignmentStatus = 'draft' | 'published' | 'closed';

export type SubmissionStatus = 'in_progress' | 'submitted' | 'graded' | 'resubmit_requested';

export interface WorksheetQuestion {
  id: string;
  questionNumber: number;
  prompt: string;
  points?: number;
  suggestedAnswer?: string; // Hướng dẫn chấm / đáp án mẫu của giáo viên
}

export interface WorksheetTableColumn {
  id: string;
  header: string;
  width?: string;
  isEditableByStudent?: boolean;
}

export interface WorksheetTableRow {
  id: string;
  label?: string;
  cells: Record<string, string>; // columnId -> cell pre-filled text
}

export interface WorksheetTable {
  id: string;
  title: string;
  description?: string;
  columns: WorksheetTableColumn[];
  rows: WorksheetTableRow[];
}

export interface AssignmentAttachment {
  id: string;
  name: string;
  type: string; // 'pdf' | 'image' | 'doc' | 'link'
  url: string; // Data URL hoặc external URL
  size?: number;
}

export interface Assignment {
  id: string;
  title: string;
  subject: string; // Mặc định "Sinh học 10 (KNTT)"
  topicId?: string; // Chủ đề liên quan (bài học Sinh học 10)
  topicTitle?: string;
  classIds: string[]; // Các lớp được giao bài
  classNames?: string[];
  teacherId: string;
  teacherName: string;
  teacherCode?: string;
  dueDate: string; // ISO date string
  maxScore: number; // Mặc định thang điểm 10
  instructions: string; // Hướng dẫn chi tiết của giáo viên
  questions: WorksheetQuestion[];
  tables?: WorksheetTable[];
  allowAttachment: boolean;
  status: AssignmentStatus;
  attachments?: AssignmentAttachment[];
  createdAt: string;
  updatedAt: string;
}

export interface StudentAttachment {
  id: string;
  name: string;
  type: string;
  dataUrl: string;
  size?: number;
  uploadedAt: string;
}

export interface AssignmentSubmission {
  id: string; // `${assignmentId}_${studentId}`
  assignmentId: string;
  assignmentTitle: string;
  studentId: string;
  studentCode?: string;
  studentName: string;
  studentUsername: string;
  classId: string;
  className: string;
  
  // Nội dung học sinh làm bài
  answers: Record<string, string>; // questionId -> studentAnswer
  tableResponses?: Record<string, Record<string, Record<string, string>>>; // tableId -> rowId -> columnId -> cellContent
  generalNotes?: string; // Bài làm bổ sung / giải thích mở rộng
  attachments: StudentAttachment[]; // Ảnh chụp bài làm hoặc file đính kèm của học sinh
  
  // Trạng thái và thời gian
  status: SubmissionStatus;
  lastSavedAt: string;
  submittedAt?: string;
  
  // Chấm điểm và nhận xét của giáo viên
  score?: number; // Điểm số (0 đến maxScore)
  feedback?: string; // Lời phê / nhận xét chi tiết của giáo viên
  gradedAt?: string;
  gradedByTeacherId?: string;
  gradedByTeacherName?: string;
  
  // Cờ cho phép nộp lại / sửa bài
  allowResubmit?: boolean;
}
