import type { ChapterKey } from '../data/bio10/types';

/** Mỗi chủ đề thuộc một chương của SGK Sinh học 10 (KNTT) */
export type ModuleType = ChapterKey;

export type TopicStatus = 'locked' | 'available' | 'in_progress' | 'completed' | 'mastered';

export type TopicTab =
  | 'explore'
  | 'interactive'
  | 'knowledge'
  | 'english_bio'
  | 'materials'
  | 'practice'
  | 'challenge'
  | 'assessment';

export interface GeneticsTopic {
  id: string;
  order: number;
  module: ModuleType;
  titleVi: string;
  titleEn: string;
  slug: string;
  descriptionVi: string;
  keyConcepts: string[];
  /** Khoá mô hình 3D trong MODEL_REGISTRY */
  interactiveType: string;
  lesson?: number;
  pages?: string;
  isPractice?: boolean;
  xpReward: number;
  estimatedMinutes: number;
  prerequisiteId?: string;
}

export interface StudentTopicProgress {
  topicId: string;
  status: TopicStatus;
  progressPercent: number; // 0 - 100
  exploreCompleted: boolean;
  interactiveCompleted: boolean;
  knowledgeRead: boolean;
  englishBioScore: number;
  practiceScore: number;
  challengeBestTimeSec?: number;
  challengeBestScore?: number;
  assessmentScore?: number;
  lastStudiedAt: string;
}
