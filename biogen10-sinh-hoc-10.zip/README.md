# BIOGEN 10 – Digital Biology Learning Hub

Ứng dụng học **Sinh học 10 – SGK Kết nối tri thức với cuộc sống** (19 bài lý thuyết).
Nội dung Sinh học 10: Thầy Nguyễn Văn Nam – THPT Bình Sơn. Phát triển từ ứng dụng BIOGEN 9 (Remix trên Google AI Studio).

## Có gì trong mỗi bài
- **Mô hình 3D** (React Three Fiber): xoay 360°, bấm từng bộ phận, nhãn **Song ngữ / Việt / English**, phát âm tiếng Anh, trò chơi "Find the part".
- **Kiến thức chuẩn SGK** có ghi số trang.
- **English Biology**: tóm tắt bài bằng tiếng Anh (song ngữ từng ý), thẻ thuật ngữ có IPA, flashcard, luyện tập.
- **Luyện tập** 10 câu (7 trắc nghiệm + 3 đúng/sai), **Đấu trường** (thử thách 15 câu, thi đấu trực tiếp).
- **Bio-Bot**: tra cứu nội dung SGK trong app (không dùng AI tạo sinh), trả lời kèm trang SGK và thuật ngữ tiếng Anh.

## Dữ liệu
- Nội dung bài học: `src/data/bio10/lessons/baiXX.ts`, tóm tắt tiếng Anh: `src/data/bio10/summariesEn.ts`.
- Mô hình 3D: `src/components/models3d/models/`.
- Firestore dùng các bộ sưu tập mới `sinh10_*` (tách khỏi dữ liệu lớp 9). Nhớ triển khai lại `firestore.rules`.

## Google Sheets
Link Web App Apps Script cũ đã được gỡ. Dán link mới vào `DEFAULT_GOOGLE_SHEET_WEBAPP_URL`
trong `src/services/googleSheetService.ts`, hoặc nhập trong tab **Google Sheets** của giáo viên/quản trị.

## Chạy
```
npm install
npm run dev
```
